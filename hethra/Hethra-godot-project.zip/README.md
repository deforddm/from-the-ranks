# Hethra, City of the Fallen

A turn-based warband skirmish game in full 3D, set in a burning, ruined city of
the Malazan world. Lead a small warband through Hethra's streets, rooftops and
plank bridges, fight for godshards, and break the enemy's nerve.

Version 0.5 brings five warbands, three battlefields and three kinds of
battle, all playable as one-off skirmishes or as a campaign in which your
warband lives from battle to battle. Fighters are wounded, scarred or killed;
survivors gain experience and advances; godshards you bring out buy weapons,
armour and new fighters.

Version 0.6 gives every fighter a proper body: a jointed figure with a face,
armour, cloth and a helm that fits their warband, who walks, climbs, leaps,
swings, aims, throws, casts and falls. The title screen now shows the warband
you pick, mustered round a brazier above the burning city.

Version 0.7 adds a fourth battlefield, the Starfall, a crater blasted into
the street round a burning lump of the Fallen god's flesh, and a fourth kind
of battle, Take their leader, in which the band that loses its leader breaks
at once.

Version 0.8 adds a sixth warband, the White Face Barghast, with skull-painted
faces, javelins and a bone-shaman who calls on the spirits of the clan's
fathers. The warbands are rebalanced so that each wins about half its
fights, and a campaign band beaten down to a handful now draws in
stragglers instead of dying out.

Version 0.9 adds a fifth battlefield, the Sleeper's Stair, a stepped temple
whose top tier holds the stone image of the goddess who sleeps in the earth,
glowing with fever since the fall. It also adds a fifth kind of battle,
Through their lines: three fighters standing on the enemy's starting ground
wins it.

Version 0.10 adds the night after each campaign battle. One of fourteen
nights comes round your fire: a bonecaster at the well, deserters who want a
band, a fever, a cellar opened by a quake, thieves on the rooftops, a cold
tomb, a champion's challenge and more. Each one asks you to choose, and many
are settled by a die: coin, godshards, experience and new blood, or a fighter
who must sit out the next fight.

Version 0.11 gives the fighters close-up detail. Cloth shows its weave, mail
its rings, leather its grain and iron its dents and rust. Faces have eyes,
brows, noses, lips and ears; hands have fingers. Everyone carries pouches, a
knife and buckled straps, and each warband has its own marks: Moranth
munitions on the marines' hips, chains and manacles on the Chained One's
pilgrims, tassels and charms on the Whirlwind's rebels, silver circlets on the
Tiste Andii, fetishes on the Barghast and a second blade on every Seguleh's
back. The Fast graphics setting leaves the surface detail off.

Version 0.12 adds a sixth battlefield, the Drowned Quarter: the night the god
fell, the river wall broke and the low streets went under. Black water stands
waist deep between the quays, the roofs and the shrine of Mael, where the sea
god's great bell lies cracked in the court. Wading costs half as much again
as walking, plank walks are fast but narrow, and a fighter who drops off a
quay into the water lands safely. The title screen now shows the version.

Version 0.13 adds a seventh warband, the Kin of the Dust: a clan of T'lan
Imass, undead for a hundred thousand years, with flint swords, antler caps and
beast-skull helms, skin dried to leather and empty eye sockets. Every one is
Unliving: a stun becomes a knock-down on 4 or more, and the Barghast's
howling dead mean nothing to them. Their Bonecaster draws on Tellann: Ember
Fall drops old hearth-fire on an enemy and those beside it, and Rise from
Dust stands every fallen friend nearby back up. The Barghast can now buy from
the armoury in a campaign.

Version 0.14 brings the water and the dust to life. Fighters wading in the
Drowned Quarter slosh with every step and leave rings spreading on the black
water, those standing still in it stir it now and then, and anyone who drops
or falls in from a quay throws up a splash. When one of the Kin of the Dust
goes out of action it does not fall: it shudders and comes apart, pouring down
into a heap of grey dust that stays on the field, with a crackle of dry bone.
All of the new sounds are made in code, like the rest.

Version 0.15 adds a seventh battlefield, the Azath Yard: a walled yard of
dead trees and old barrows round one of the Azath houses, a squat keep with a
crooked tower and a door nobody has ever seen open, its slit windows leaking a
cold green light. The yard wall can be climbed and fought along, there are
gates on all four sides and a breach in the east wall, and the barrows give
low cover. The house itself is solid and blocks all sight.

From 0.15 on, Hethra keeps itself up to date. Each time it starts it checks
the download page; if there is a newer version it fetches it in the
background, checks it, and on the title screen restarts into it. If you are
in a battle it waits until the next time you open the game. Turn it off in
Settings, under Updates, and it will only tell you a new version is out.

Version 0.16 adds a sixth kind of battle, the buried strongbox. A paymaster's
strongbox lies under one of four marked spots, each with a stake, a spade and a
lantern, and nobody knows which. Walk onto a spot to dig: most turn up only
bones and broken pots. Whoever strikes iron carries the box on their back and
must get it to their own starting ground. They are too laden to dash, and drop
it where they fall if taken out, for anyone to pick up. While one of yours holds
it and stands, your warband will not break. Carry it home and you win at once;
at nightfall, whoever holds it wins. This is also the first update a 0.15 copy
fetches and installs by itself.

Version 0.17 brings weather. Half the nights are still; the rest bring driving
rain or thick fog. Rain falls on every roof and street and splashes where it
lands, lightning lights the ruins now and then with thunder after it, and the
rain hisses under the wind. In the rain shots need one more to hit, nobody
sees as far, and jumps and drops on the wet stone are harder. In thick fog
nobody sees past 14 m, so fights start close. The weather shows at the top of
the screen. In a skirmish you can choose it, under Weather.

Version 0.18 adds an eighth battlefield, the Jade Stranger. When the god fell,
one of the jade giants that drift in the dark between worlds fell with him and
came down on its back across a ward of Hethra. It lies there still, a hill of
green stone lit from within, cracked by the fall, with light leaking through
the cracks and its eyes still open to the sky. The two sides start on either
side of it: go round by its head or its feet, or climb its arms and legs and
fight across its chest, where the shards are richest. Godshards lie in its
open hands too.

Version 0.19 adds a cinematic camera. Every battle opens with a slow sweep over
the ruins between black bars, under the battlefield's name, the kind of battle,
the weather and the two warbands, and settles where your warband waits. When a
fighter is taken out of action the camera cuts in low beside them and time
slows while they go down, then the view comes back to where it was. Click or
press any key to skip the opening; Settings has a switch to turn both off.

Version 0.20 adds an eighth warband, the Teblor Raiders: a small band of
giant hill warriors down from the mountains, braided and tattooed, with
trophies at their belts and swords carved from red bloodwood. They are few,
but every one of them is Giantkin and may shrug off a blow that would knock
another fighter flat.

Version 0.21 brings Hood's crows to every battlefield. Small flocks sit along
the roofs and in the streets, pecking and hopping about. Come too close and
they burst up cawing, wheel over the ruins and settle again somewhere quieter.
A blast puts up every bird near it, and when a fighter is taken out of action
a crow or two come down beside the body once the fighting has moved on.

Version 0.22 adds sellswords to the campaign. Between battles, the Hire
screen has a Sellswords page with four blades for hire: a Wickan Outrider
with a bow, a huge Trell Bruiser, a Bridge Sapper with a satchel of
munitions, and a Hedge-Healer of Denul. Each fights in their own colours and
wants paying after every battle, win or lose, and walks off if the purse is
empty. They bring their own kit, never search the ruins and learn nothing
from the fighting. The Kin of the Dust find no takers.

Version 0.23 brings shardfall. From the second round, now and then a burning
godshard streaks across the sky and the ground where it will land starts to
glow. At the start of the next round it comes down in a burst of fire: anyone
standing on the spot takes a Strength 5 hit, anyone close by a Strength 3
hit, and a fresh godshard lies smoking in the crater for the taking. At most
two fall in a battle. The move tooltip warns you before you step into the
glow, and the enemy keeps out of it too.

Version 0.24 puts a map of Hethra in the campaign. When you head into the
ruins, you pick where to fight on a drawn chart of the dead city: its eight
wards, the old wall, Mael's water winding through, and the houses packed
between. Each ward shows how many times your band has fought and won there,
coloured green where you mostly win and rust where you mostly lose, and the
chronicle now says where each battle was fought.

Version 0.25 fixes the title screen, where only the Marines and the Chained
could be picked as your warband; all eight can be chosen again. It also lets
your band hold wards. Win twice in a ward, with more wins than losses there,
and your banner goes up over it on the map. Every ward you hold pays 8
jakatas in dues after each battle, up to four wards, and a lost fight in a
ward you hold drives your band out of it.

Version 0.26 brings home ground. When your campaign band fights in a ward it
holds, its banners fly from the roofs and walls round its starting ground,
long cloths in the band's colours rippling in the wind, and the band fights
better for it: its rout tests are taken at +1 Leadership. The self-update is
sturdier too. If Windows or OneDrive holds a file in the Hethra folder, the
update saves under a fresh name, and if the folder refuses it altogether, the
new version runs from Hethra's own data folder instead of giving up.

Version 0.27 brings a grey dawn. One fight in ten runs on till sunrise: a low
gold sun comes up through the ash, the horizon goes rose, the mist catches the
light in shafts down the streets, and long shadows fall across the square. In
the dawn light everyone sees a third further. You can choose it in a skirmish,
under Weather.

Version 0.28 lets dawn break in the middle of a fight. When the weather is
left to chance, on one still night in three the sun comes up in round 3, 4 or
5: the crows go up cawing, the camera lifts to watch the light warm over the
ruins, and from then on everyone sees a third further. The skirmish dialog is
tidier too, with the foes and battlefields in rows of four so it fits a
1080-line screen.

Version 0.29 brings the band home in the morning. When a campaign fight runs
on till dawn, the camp you come back to sits in the same low gold light. The
camp's pages keep their buttons pinned at the bottom now, so Into the ruins
and Not yet are always in view without scrolling, even with the map of the
city open. A new test clicks every button, fighter and ward on the camp screen
with the mouse, as a player would, and checks each one does what it says.

Version 0.30 gives the campaign an ending. Hold four wards of Hethra and the
other bands gather against you: the next time you go into the ruins, the last
night is waiting. A rival band, swollen with every blade it can buy, meets you
round the ring of witch-fire in the Idol Square, and the fight runs on till
the sun comes up. Hold the ring and Hethra is yours: the band is crowned Lords
of Hethra, collects a crown's tribute of 150 jakatas, and the story is told
over the fire. Lose, and they drive you out of a ward. You can put it off and
fight another night's battle first, and a crowned band fights on.

Version 0.31 gives every band you fight a memory. The first time you meet a
warband, its leader becomes your rival. Meet them again and the same leader
comes back, by name and a little harder for every fight they walked away
from. Take a rival leader out of action and they may never get up: a new one
takes their place, swearing to settle the score. The camp tells you who leads
the band you are about to face and how your fights with them have gone, the
battle's opening names the leader you face again, and the chronicle keeps a
list of your rivals.

Version 0.32 brings your rivals onto the battlefield. A rival leader stands in
a gold ring, their card says how often you have met and what their head is
worth, and when they go down the camera always cuts in, with their name in
gold. Put a known rival out of action and the fences pay a bounty: 10
jakatas, and 5 more for every fight they had walked away from.

Version 0.33 adds six new nights round the fire. A rival's runner comes with
a purse to buy you off; a rival's knives wait in an alley for one of your
fighters; the elders of a ward you hold beg for help, and if you pay, they
will hide your people and keep the ward yours through one lost fight. There
are hounds in the dark, an old soldier with stories worth a meal, and a
fighter who wants to taste a godshard.

Version 0.34 opens the rare stalls of the shard market. Two pieces are on
offer each week, and new ones come in after every battle. An otataral knife
makes its bearer untouchable by any warren, for harm or for help, though no
mage will carry one. A darkforged Andii blade cuts deeper and parries. A
Moranth crossbow hits as hard as any and looses in one action. A
shadow-thread cloak makes every shot at its wearer one harder. Each has its
own look on the figure.

Version 0.35 lets the ruins take a hand. Now and then, at the start of a
round, something happens that nobody planned: the Hounds of Shadow bay
somewhere in the dark and the faint-hearted are shaken, the ground shudders
as Burn shifts in her sleep and throws fighters off their feet, a broken wall
comes down on someone's head, or a cloud of rhizan pours out of the sky and
blinds a knot of fighters. Each has its own scene, sound and camera.

Version 0.36 adds a seventh kind of battle, Raise the standards. Three old
cairns stand over the ward's best ground. End your turn with a fighter at a
cairn and no enemy beside it and your band's standard goes up there, in your
colours; the enemy can tear it down and raise theirs the same way. Fly your
standard over all three and keep them flying through a whole enemy turn and
you win at once; when night falls, the band with more standards wins. The enemy plays for the cairns too, and leaves a guard on
its standards.

Version 0.37 brings places in the ruins. When heroes search after a battle and
two or more of their dice match, they find somewhere worth the trip: a voice
under the rubble, a Moranth courier's pack, a shrine of the Twins, a fence's
cellar, an old sappers' tunnel, a Denul healer's house, a temple of the Queen
of Dreams, a Jaghut cold-cellar, a seam of godshards, and two places only four
matching dice will find. Each has its own painted scene and pays out coin,
shards, kit, a new fighter, mending or experience. The places are in
`data/finds.json`.

Version 0.38 brings the band's colours. In camp, press Colours to pick one of
eight colour pairs (or keep the warband's own) and one of seven marks for the
banner: a diamond, crescent, star, ring, chevron, saltire or tower. The choice
dyes your fighters' cloth, flies on the banners of your home ground and on the
standards you raise over cairns, marks your flag on the city map, and stands on
a new banner by the camp fire. The colour pairs are in `data/campaign.json`.

## Warbands

- **Malazan Marines:** steady soldiers with crossbows, a squad mage and a
  sapper who throws Moranth munitions.
- **Cult of the Chained One:** a big, cheap flock of fanatics who shrug off
  pain, led by a priest of the Chained One's warren.
- **Sworn of the Whirlwind:** fast desert raiders, dervishes and archers,
  with a seer of the Whirlwind's sand.
- **Masked of the Seguleh:** a handful of unarmoured swordsmen, masked by
  rank. Few, expensive and deadly; Duellists parry on a tie.
- **Children of the Dark:** tall Tiste Andii with longbows and great blades.
  Their mage draws on Kurald Galain: Night's Edge sharpens a friend's blade,
  Starless Night blinds an enemy's bow or warren.
- **White Face Barghast:** tough hill clansmen with axes, great blades and
  javelins, their faces painted as skulls. Their bone-shaman calls on the
  clan's dead: Call the Fathers hardens a friend, Spirit Howl shakes every
  enemy close by.
- **Kin of the Dust:** slow, unfeared T'lan Imass with flint swords, great
  blades and javelins, who are hard to put down. Their Bonecaster drops
  Tellann fire on the enemy and raises the fallen.
- **Teblor Raiders:** six or so giants from the mountains with bloodwood
  swords (+1 Strength, and armour saves worse against them), a javelin-armed
  Tracker who climbs well, and a War Chief who leads from the front. Every
  Teblor is Giantkin: a blow that would knock them down is shrugged off on
  a 5 or more.

## Battlefields and battles

- **The Idol Square**, around the Chained One's idol; **The Broken
  Causeway**, two quays split by a canal with a few bridges; **The Tower
  Ward**, a block of towers joined by ladders and plank bridges; **The
  Starfall**, a crater round a burning starstone, ringed by tall houses and
  gatehouses joined by planks; **The Sleeper's Stair**, a stepped temple with
  great stairs, a colonnade and the sleeping goddess on its top tier; **The
  Drowned Quarter**, streets standing waist deep in flood water between dry
  quays, roofs and Mael's shrine, joined by plank walks. Wading is slow, but
  the water breaks a fall from one storey.
- **Shard hunt:** carry godshards off the field. **Street fight:** break the
  enemy. **Hold the ground:** both bands want the ring of witch-fire in the
  middle; whoever has more fighters inside it at nightfall wins. **Take their
  leader:** put the enemy's leader out of the fight and their band breaks;
  keep yours standing. **Through their lines:** get three fighters onto the
  enemy's starting ground (it glows jade; yours glows red) and keep theirs
  off yours. **Raise the standards:** end your turn with a fighter at one of three
  cairns and no enemy beside it to raise your standard there; all three kept
  flying through a whole enemy turn win at once, and more standards win at nightfall.

## Play on Windows

1. Run `Hethra.exe`. No install needed.
2. Pick your warband, then press **New campaign** (or **Skirmish** for one
   quick battle). **Continue** picks up your latest campaign.

If Windows SmartScreen warns about an unknown publisher, choose
*More info → Run anyway* (the file is not code-signed).

Slow PC? On the title screen, press **Graphics** to switch to *fast*
(turns off volumetric fog and ambient occlusion).

## Open the project in Godot

1. Install Godot 4.7 (standard, not .NET) from https://godotengine.org
2. Open Godot, choose **Import**, and select `project.godot` (in the `project` folder of this download, or `Hethra-project.zip` unzipped).
3. Press **F5** to play.

## Controls

| | |
|---|---|
| Camera | Rides over the shoulder of the active fighter |
| Close / overhead view | V |
| Look around | Right-drag (close view) or middle-drag; Q and E / R and F |
| Pan | WASD or arrow keys (Shift for faster); right-drag in overhead view |
| Zoom | Mouse wheel |
| Choose a fighter | Click them, or Tab for the next one |
| Move | Click anywhere inside the glowing area (amber means a jump or drop) |
| Fight / charge / shoot | Click an enemy (hover first to see the odds) |
| Actions | 1 Move · 2 Dash · 3 Charge · 4 Shoot · 5 Throw · 6 Cast |
| Cancel | Right-click or Escape |
| Back to the fighter | Space |
| End turn | Enter |
| Help | F1 |

## The campaign

- **The camp** between battles shows your warband round a fire. Choose a
  fighter to see their stat line, experience, skills and scars, to buy or
  sell their kit, or to settle an advance.
- **After each battle**, every fighter taken out of action rolls on the
  injury table (from a full recovery to death), survivors gain experience,
  and heroes still standing search the ruins for coin and godshards. Matching
  search dice find a place in the ruins with something more in it.
- **The night after** every battle brings an event to your fire. Choose how
  to meet it; some choices cost coin or godshards, and many are settled by a
  die. The events are in `data/events.json`.
- **Advances** come at set experience totals: a new skill or a better stat
  for heroes, a stat for henchmen, and now and then a henchman with real
  talent rises to be a hero.
- **The map of Hethra** is where you choose the next fight: click a ward.
  It keeps count of every fight your band has had there and how many it won.
- **Holding wards**: two wins in a ward, and more wins than losses there,
  and your band holds it. Each held ward pays 8 jakatas after every battle.
  Lose a fight there and the ward is lost.
- **Rivals**: every band you fight remembers you. Its leader comes back by
  name, one advance harder for each fight they survive (up to six); take
  them out of action and on a 1 or 2 they die and a new leader steps up.
  On the field a rival stands in a gold ring, and putting one down pays a
  bounty of 10 jakatas plus 5 for each fight they had survived.
- **Happenings**: from the second round, on a 6 at the start of a round the
  ruins take a hand (twice a battle at most, never the same twice): the
  Hounds of Shadow (a Leadership test, or -1 WS and shots one harder for a
  round), a quake (a 6, or a 5 high up, knocks a fighter down), a falling
  wall (a Strength 3 hit) or a rhizan swarm (blind and -1 WS for a round).
- **Rare goods**: the shard market keeps two rare pieces a week in a row of
  gold buttons on each fighter's sheet, and once bought they are gone. New
  pieces come in after every battle.
- **The last night**: hold four wards and the other bands gather against you
  at the Idol Square, stronger than any foe before. Hold the ring of
  witch-fire till dawn and Hethra is yours; lose, and you lose a ward.
- **Home ground**: fight in a ward you hold and your banners fly over it,
  and your band takes its rout tests at +1 Leadership.
- **Weather**: a still night, grey dawn (everyone sees a third further),
  driving rain (shorter sight, harder shots and jumps) or thick fog (nobody
  sees past 14 m). One still night in three turns to dawn in round 3 to 5.
- **Sellswords** hire on for a fee and an upkeep after every battle. They
  take no hero's place but can't buy kit, search or gain experience. Their
  rules are in `data/sellswords.json`.
- **Sell godshards** for jakatas (the more at once, the lower the price),
  then **Hire** new fighters or buy from the armoury.
- **Rating** sums your fighters and their experience. Foes are matched to
  it, and beating a stronger band earns extra experience.
- The campaign saves itself after every change. **Save and leave** returns
  to the title screen.

## The rules in brief

- Each fighter has a stat line: Move, Weapon Skill, Ballistic Skill,
  Strength, Toughness, Wounds, Initiative, Attacks and Leadership.
- Each turn a fighter gets movement (Move × 2.5 m) and two actions.
- The city is three-dimensional: climb ladders and stairs, cross bridges,
  jump gaps and drop from ledges. Jumps and drops need an Initiative test;
  failing one means a fall that can wound.
- Line of sight is traced in 3D. Enemies stay hidden until one of your
  fighters sees them, and a ghost marks where they were last seen.
- Burning godshards sometimes fall mid-battle. The ground glows a round
  ahead; whoever is still standing there when it lands gets hurt, and a new
  godshard is left behind.
- Wounds knock fighters down, stun them or take them out of action. When a
  quarter of a warband is down, its leader tests each turn or the band flees.
- After 12 rounds, the side holding more godshards wins (in a shard hunt),
  or the side with more fighters in the ring (when holding the ground).

All rules and data live in JSON under `data/` (`rules.json`, `warbands/`,
`maps/`), so stats, weapons, spells and warbands can be changed without code.

## For developers

- `scripts/core/` — rules engine, map graph, line of sight, AI (no graphics).
- `scripts/view/` — the 3D city, figures, camera, effects and battle controller.
- `scripts/ui/` — title screen, camp screen and battle HUD.
- `tests/run_battles.gd` — headless rules tests:
  `godot --headless --path . --script res://tests/run_battles.gd`
- `tests/run_campaign.gd` — plays AI campaigns with the full camp between
  battles and checks the books: `... --script res://tests/run_campaign.gd -- 6`
- Campaign rules (injuries, advances, prices, armoury) are in `data/campaign.json`.
- Watch the AI play itself: `godot --path . -- --autoplay`
- `tools/make_map.py` builds the Idol Square, `tools/make_maps.py` the other
  battlefields; `tools/gen_textures.py` the textures.
- Battles on any field: `-- --map=sleeper --scenario=breakthrough --player=seguleh --enemy=andii`

See `CREDITS.md` for the setting's authors and licences.
