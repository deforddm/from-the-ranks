# Hethra, City of the Fallen

A turn-based warband skirmish game in full 3D, set in a burning, ruined city of
the Malazan world. Lead a small warband through Hethra's streets, rooftops and
plank bridges, fight for godshards, and break the enemy's nerve.

Version 0.5 brings five warbands, three battlefields and three kinds of
battle, all playable as one-off skirmishes or as a campaign in which your
warband lives from battle to battle. Fighters are wounded, scarred or killed;
survivors gain experience and advances; godshards you bring out buy weapons,
armour and new fighters.

Version 0.6 gives every fighter a proper body: a jointed figure with a face,
armour, cloth and a helm that fits their warband, who walks, climbs, leaps,
swings, aims, throws, casts and falls. The title screen now shows the warband
you pick, mustered round a brazier above the burning city.

Version 0.7 adds a fourth battlefield, the Starfall, a crater blasted into
the street round a burning lump of the Fallen god's flesh, and a fourth kind
of battle, Take their leader, in which the band that loses its leader breaks
at once.

Version 0.8 adds a sixth warband, the White Face Barghast, with skull-painted
faces, javelins and a bone-shaman who calls on the spirits of the clan's
fathers. The warbands are rebalanced so that each wins about half its
fights, and a campaign band beaten down to a handful now draws in
stragglers instead of dying out.

Version 0.9 adds a fifth battlefield, the Sleeper's Stair, a stepped temple
whose top tier holds the stone image of the goddess who sleeps in the earth,
glowing with fever since the fall. It also adds a fifth kind of battle,
Through their lines: three fighters standing on the enemy's starting ground
wins it.

Version 0.10 adds the night after each campaign battle. One of fourteen
nights comes round your fire: a bonecaster at the well, deserters who want a
band, a fever, a cellar opened by a quake, thieves on the rooftops, a cold
tomb, a champion's challenge and more. Each one asks you to choose, and many
are settled by a die: coin, godshards, experience and new blood, or a fighter
who must sit out the next fight.

## Warbands

- **Malazan Marines:** steady soldiers with crossbows, a squad mage and a
  sapper who throws Moranth munitions.
- **Cult of the Chained One:** a big, cheap flock of fanatics who shrug off
  pain, led by a priest of the Chained One's warren.
- **Sworn of the Whirlwind:** fast desert raiders, dervishes and archers,
  with a seer of the Whirlwind's sand.
- **Masked of the Seguleh:** a handful of unarmoured swordsmen, masked by
  rank. Few, expensive and deadly; Duellists parry on a tie.
- **Children of the Dark:** tall Tiste Andii with longbows and great blades.
  Their mage draws on Kurald Galain: Night's Edge sharpens a friend's blade,
  Starless Night blinds an enemy's bow or warren.
- **White Face Barghast:** tough hill clansmen with axes, great blades and
  javelins, their faces painted as skulls. Their bone-shaman calls on the
  clan's dead: Call the Fathers hardens a friend, Spirit Howl shakes every
  enemy close by.

## Battlefields and battles

- **The Idol Square**, around the Chained One's idol; **The Broken
  Causeway**, two quays split by a canal with a few bridges; **The Tower
  Ward**, a block of towers joined by ladders and plank bridges; **The
  Starfall**, a crater round a burning starstone, ringed by tall houses and
  gatehouses joined by planks; **The Sleeper's Stair**, a stepped temple with
  great stairs, a colonnade and the sleeping goddess on its top tier.
- **Shard hunt:** carry godshards off the field. **Street fight:** break the
  enemy. **Hold the ground:** both bands want the ring of witch-fire in the
  middle; whoever has more fighters inside it at nightfall wins. **Take their
  leader:** put the enemy's leader out of the fight and their band breaks;
  keep yours standing. **Through their lines:** get three fighters onto the
  enemy's starting ground (it glows jade; yours glows red) and keep theirs
  off yours.

## Play on Windows

1. Run `Hethra.exe`. No install needed.
2. Pick your warband, then press **New campaign** (or **Skirmish** for one
   quick battle). **Continue** picks up your latest campaign.

If Windows SmartScreen warns about an unknown publisher, choose
*More info → Run anyway* (the file is not code-signed).

Slow PC? On the title screen, press **Graphics** to switch to *fast*
(turns off volumetric fog and ambient occlusion).

## Open the project in Godot

1. Install Godot 4.7 (standard, not .NET) from https://godotengine.org
2. Open Godot, choose **Import**, and select `project.godot` (in the `project` folder of this download, or `Hethra-project.zip` unzipped).
3. Press **F5** to play.

## Controls

| | |
|---|---|
| Camera | Rides over the shoulder of the active fighter |
| Close / overhead view | V |
| Look around | Right-drag (close view) or middle-drag; Q and E / R and F |
| Pan | WASD or arrow keys (Shift for faster); right-drag in overhead view |
| Zoom | Mouse wheel |
| Choose a fighter | Click them, or Tab for the next one |
| Move | Click anywhere inside the glowing area (amber means a jump or drop) |
| Fight / charge / shoot | Click an enemy (hover first to see the odds) |
| Actions | 1 Move · 2 Dash · 3 Charge · 4 Shoot · 5 Throw · 6 Cast |
| Cancel | Right-click or Escape |
| Back to the fighter | Space |
| End turn | Enter |
| Help | F1 |

## The campaign

- **The camp** between battles shows your warband round a fire. Choose a
  fighter to see their stat line, experience, skills and scars, to buy or
  sell their kit, or to settle an advance.
- **After each battle**, every fighter taken out of action rolls on the
  injury table (from a full recovery to death), survivors gain experience,
  and heroes still standing search the ruins for coin and godshards.
- **The night after** every battle brings an event to your fire. Choose how
  to meet it; some choices cost coin or godshards, and many are settled by a
  die. The events are in `data/events.json`.
- **Advances** come at set experience totals: a new skill or a better stat
  for heroes, a stat for henchmen, and now and then a henchman with real
  talent rises to be a hero.
- **Sell godshards** for jakatas (the more at once, the lower the price),
  then **Hire** new fighters or buy from the armoury.
- **Rating** sums your fighters and their experience. Foes are matched to
  it, and beating a stronger band earns extra experience.
- The campaign saves itself after every change. **Save and leave** returns
  to the title screen.

## The rules in brief

- Each fighter has a stat line: Move, Weapon Skill, Ballistic Skill,
  Strength, Toughness, Wounds, Initiative, Attacks and Leadership.
- Each turn a fighter gets movement (Move × 2.5 m) and two actions.
- The city is three-dimensional: climb ladders and stairs, cross bridges,
  jump gaps and drop from ledges. Jumps and drops need an Initiative test;
  failing one means a fall that can wound.
- Line of sight is traced in 3D. Enemies stay hidden until one of your
  fighters sees them, and a ghost marks where they were last seen.
- Wounds knock fighters down, stun them or take them out of action. When a
  quarter of a warband is down, its leader tests each turn or the band flees.
- After 12 rounds, the side holding more godshards wins (in a shard hunt),
  or the side with more fighters in the ring (when holding the ground).

All rules and data live in JSON under `data/` (`rules.json`, `warbands/`,
`maps/`), so stats, weapons, spells and warbands can be changed without code.

## For developers

- `scripts/core/` — rules engine, map graph, line of sight, AI (no graphics).
- `scripts/view/` — the 3D city, figures, camera, effects and battle controller.
- `scripts/ui/` — title screen, camp screen and battle HUD.
- `tests/run_battles.gd` — headless rules tests:
  `godot --headless --path . --script res://tests/run_battles.gd`
- `tests/run_campaign.gd` — plays AI campaigns with the full camp between
  battles and checks the books: `... --script res://tests/run_campaign.gd -- 6`
- Campaign rules (injuries, advances, prices, armoury) are in `data/campaign.json`.
- Watch the AI play itself: `godot --path . -- --autoplay`
- `tools/make_map.py` builds the Idol Square, `tools/make_maps.py` the other
  battlefields; `tools/gen_textures.py` the textures.
- Battles on any field: `-- --map=sleeper --scenario=breakthrough --player=seguleh --enemy=andii`

See `CREDITS.md` for the setting's authors and licences.
