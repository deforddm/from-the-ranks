extends SceneTree
## Headless test of shardfall: a burning shard is foretold, strikes next round,
## hurts whoever stands beneath it, leaves a godshard, and the AI keeps clear.
## godot --headless --path . --script res://tests/run_shardfall.gd

var failures := 0

func check(cond: bool, msg: String) -> void:
	if not cond:
		failures += 1
		printerr("FAIL: ", msg)

func _init() -> void:
	_forced()
	_natural()
	_ai_avoids()
	print("FAILURES: %d" % failures)
	quit(1 if failures > 0 else 0)

func _run_until(st: BattleState, ais: Array, cond: Callable) -> void:
	var guard := 0
	while not st.over and guard < 3000 and not cond.call():
		guard += 1
		var ai: WarbandAI = ais[st.side]
		var act := ai.next_action()
		var res := ai.execute(act)
		if act["type"] != "end" and not res.get("ok", false):
			act["unit"].ai_done = true

func _forced() -> void:
	var seen_omen := 0
	var seen_fall := 0
	var hits := 0
	var shards_left := 0
	for i in range(8):
		var st := BattleState.new()
		st.setup(GameData.MAP_IDS[i % GameData.MAP_IDS.size()], "marines", "teblor", 500 + i, true, true, [[], []], "shards")
		st.force_shardfall = true
		var ais := [WarbandAI.new(st, 0), WarbandAI.new(st, 1)]
		st.begin()
		_run_until(st, ais, func(): return st.omen_node >= 0)
		if st.over:
			continue
		check(st.round_num == 2, "the first omen comes in round 2 (was %d)" % st.round_num)
		seen_omen += 1
		var nd := st.omen_node
		check(not st.zones[0].has(nd) and not st.zones[1].has(nd), "the shard does not fall on starting ground")
		check(st.in_fall_zone(nd), "the strike point is in its own zone")
		var log_start := st.log_lines.size()
		_run_until(st, ais, func(): return st.omen_node != nd)
		if st.over and st.omen_node == nd:
			continue
		seen_fall += 1
		check(st.round_num == 3, "the shard strikes at the start of round 3 (was %d)" % st.round_num)
		var text := "\n".join(st.log_lines.slice(log_start))
		check(text.contains("Shardfall!"), "the strike is logged")
		if text.contains("smoking in the crater"):
			shards_left += 1
		if text.contains("The burning shard"):
			hits += 1
		check(st.shardfalls <= BattleState.FALL_MAX, "no more than %d shards fall" % BattleState.FALL_MAX)
		_run_until(st, ais, func(): return false)
		check(st.shardfalls <= BattleState.FALL_MAX, "no more than %d shards fall in a battle" % BattleState.FALL_MAX)
	print("forced: omens %d, falls %d, shards left %d, strikes that hit someone %d" % [seen_omen, seen_fall, shards_left, hits])
	check(seen_omen >= 6, "the forced omen comes in most battles")
	check(seen_fall >= 5, "the foretold shard falls")
	check(shards_left >= seen_fall - 1, "a fallen shard leaves a godshard")

func _natural() -> void:
	var falls := 0
	var battles := 30
	for i in range(battles):
		var st := BattleState.new()
		st.setup(GameData.MAP_IDS[i % GameData.MAP_IDS.size()], "chained", "marines", 900 + i, true, true, [[], []], "shards")
		var ais := [WarbandAI.new(st, 0), WarbandAI.new(st, 1)]
		st.begin()
		_run_until(st, ais, func(): return false)
		falls += st.shardfalls
	print("natural: %d omens in %d battles" % [falls, battles])
	check(falls > 0 and falls < battles * 2, "shardfall comes now and then, not always")

func _ai_avoids() -> void:
	## A fighter standing in the glow, free to move, walks out of it.
	var out := 0
	var tried := 0
	for i in range(12):
		var st := BattleState.new()
		st.setup("hethra_square", "marines", "chained", 300 + i, true, true, [[], []], "shards")
		st.begin()
		var u: BUnit = st.side_units(st.side)[0]
		st.omen_node = u.node
		check(st.in_fall_zone(u.node), "the fighter stands in the glow")
		var ai := WarbandAI.new(st, st.side)
		var foes := ai.known_enemies()
		var act: Dictionary = ai._move_choice(u, foes, false)
		if act.is_empty():
			continue
		tried += 1
		if not st.in_fall_zone(int(act["node"])):
			out += 1
	print("ai: %d of %d step out of the glow" % [out, tried])
	check(tried > 0 and out >= tried - 1, "the AI keeps out from under the falling shard")
