extends SceneTree
## Headless rules test: plays AI-vs-AI battles and checks invariants.
## godot --headless --path . --script res://tests/run_battles.gd -- [count]

var failures := 0
var weathers := {}

func check(cond: bool, msg: String) -> void:
	if not cond:
		failures += 1
		printerr("FAIL: ", msg)

func _init() -> void:
	var count := 12
	for a in OS.get_cmdline_user_args():
		if a.is_valid_int():
			count = int(a)
	_test_rules()
	_test_map()
	_test_dawn()
	_test_standards()
	_test_watch()
	_test_hide()
	for mid in GameData.MAP_IDS:
		_test_any_map(mid)
	var wins := {0: 0, 1: 0, -2: 0}
	var by_faction := {}
	var rounds_total := 0
	var t0 := Time.get_ticks_msec()
	var ids := GameData.WARBAND_IDS
	for i in range(count):
		var a: String = ids[i % ids.size()]
		var b: String = ids[(i / ids.size() + 1 + i) % ids.size()]
		if a == b:
			b = ids[(ids.find(a) + 1) % ids.size()]
		var mid: String = GameData.MAP_IDS[i % GameData.MAP_IDS.size()]
		var scn: String = GameData.SCENARIO_IDS[(i / GameData.MAP_IDS.size()) % GameData.SCENARIO_IDS.size()]
		var res := play(a, b, 1000 + i, mid, scn)
		wins[res["winner"]] = wins.get(res["winner"], 0) + 1
		rounds_total += res["rounds"]
		var wf: String = a if res["winner"] == 0 else (b if res["winner"] == 1 else "draw")
		by_faction[wf] = by_faction.get(wf, 0) + 1
		print("battle %d [%s, %s]: %s vs %s -> %s in %d rounds (%s) ooa %d/%d shards %d/%d actions %d" % [i, mid, scn, a, b, wf, res["rounds"], res["reason"], res["ooa0"], res["ooa1"], res["sh0"], res["sh1"], res["actions"]])
	print("wins by side: ", wins, "  by warband: ", by_faction, "  avg rounds %.1f" % (float(rounds_total) / count), "  time %d ms" % (Time.get_ticks_msec() - t0), "  weather ", weathers)
	print("FAILURES: %d" % failures)
	quit(1 if failures > 0 else 0)

func _test_rules() -> void:
	check(Rules.melee_to_hit(4, 3) == 3, "WS4 vs WS3 hits on 3")
	check(Rules.melee_to_hit(3, 3) == 4, "WS3 vs WS3 hits on 4")
	check(Rules.melee_to_hit(2, 5) == 5, "WS2 vs WS5 hits on 5")
	check(Rules.to_wound(3, 3) == 4, "S3 T3 wounds on 4")
	check(Rules.to_wound(5, 3) == 2, "S5 T3 wounds on 2")
	check(Rules.to_wound(3, 6) == 0, "S3 T6 cannot wound")
	check(Rules.save_needed(5, 4, 0) == 6, "heavy armour vs S4 saves on 6")
	check(Rules.save_needed(6, 4, 0) == 7, "light armour vs S4 no save")
	check(Rules.save_needed(4, 3, 1) == 5, "axe worsens save")
	check(Rules.save_needed(7, 3, -1) == 6, "knife lets the unarmoured save on 6")

func _test_map() -> void:
	var m := BattleMap.new()
	m.load_map("hethra_square")
	print("map nodes %d, edge lists %d" % [m.nodes.size(), m.edges.size()])
	var kinds := {}
	for id in m.edges:
		for e in m.edges[id]:
			kinds[e["kind"]] = kinds.get(e["kind"], 0) + 1
	print("edge kinds: ", kinds)
	check(kinds.get("climb", 0) > 0, "map has ladders")
	check(kinds.get("jump", 0) > 0, "map has jumps")
	check(kinds.get("drop", 0) > 0, "map has drops")
	var start := m.top_node(14, 26)
	var reach := m.connected_count(start)
	print("reachable from south street: %d of %d nodes" % [reach, m.nodes.size()])
	check(reach > m.nodes.size() * 0.9, "most of the map is reachable")
	var north := m.top_node(14, 1)
	var dm := m.distance_map_to([north])
	check(dm.has(start), "north deployment reachable from south")
	# every shard reachable
	for sh in m.data["shards"]:
		var id := BattleMap.nid(int(sh[0]), int(sh[1]), int(sh[2]))
		check(m.nodes.has(id) and dm.has(id), "shard at %s reachable" % str(sh))
	# sight: across the open square yes, through a solid keep no
	var a := m.node_pos(m.top_node(11, 11)) + Vector3(0, 1.6, 0)
	var b := m.node_pos(m.top_node(11, 16))
	check(m.visibility(a, b) > 0.0, "can see across the square")
	var c := m.node_pos(m.top_node(14, 26)) + Vector3(0, 1.6, 0)
	var dd := m.node_pos(m.top_node(14, 16))
	print("vis south street -> square: %.2f" % m.visibility(c, dd))
	var e := m.node_pos(m.top_node(6, 12)) + Vector3(0, 1.6, 0)
	var f := m.node_pos(m.top_node(1, 3))
	check(m.visibility(e, f) == 0.0, "keep blocks sight")

func _test_any_map(mid: String) -> void:
	## Every map: both deployment zones join up, every shard and the ring can be
	## reached from both sides, and there is real climbing to do.
	var m := BattleMap.new()
	m.load_map(mid)
	var kinds := {}
	for id in m.edges:
		for e in m.edges[id]:
			kinds[e["kind"]] = kinds.get(e["kind"], 0) + 1
	check(kinds.get("climb", 0) > 0, "%s has ladders" % mid)
	for s in ["0", "1"]:
		check((m.data["deploy"][s] as Array).size() >= 15, "%s deploy zone %s has room" % [mid, s])
	var d0: Array = m.data["deploy"]["0"][0]
	var d1: Array = m.data["deploy"]["1"][0]
	var a := m.top_node(int(d0[0]), int(d0[1]))
	var b := m.top_node(int(d1[0]), int(d1[1]))
	var to_a := m.distance_map_to([a])
	var to_b := m.distance_map_to([b])
	check(to_a.has(b), "%s: the two deployment zones join up" % mid)
	for sh in m.data["shards"]:
		var id := BattleMap.nid(int(sh[0]), int(sh[1]), int(sh[2]))
		check(m.nodes.has(id) and to_a.has(id) and to_b.has(id), "%s: shard at %s reachable both ways" % [mid, str(sh)])
	var reach := m.connected_count(a)
	print("%s: %d nodes, %d reachable from the south, edges %s" % [mid, m.nodes.size(), reach, str(kinds)])
	check(reach > m.nodes.size() * 0.85, "%s: most of the map is reachable" % mid)
	var ob: Array = m.data.get("objective", [m.w / 2 - 1, m.d / 2 - 1])
	var near := 0
	for id in m.nodes:
		var p := m.node_pos(id)
		if Vector2(p.x, p.z).distance_to(Vector2((ob[0] + 1) * m.cell, (ob[1] + 1) * m.cell)) < 6.0 and to_a.has(id) and to_b.has(id):
			near += 1
	check(near >= 8, "%s: the ring has ground to stand on (%d)" % [mid, near])

func _test_dawn() -> void:
	## A still night that runs on till dawn: in the right round the weather
	## turns, the log says so, a dawn event is queued and sight lengthens.
	var st := BattleState.new()
	st.setup("hethra_square", "marines", "chained", 4242, true, true, [[], []], "shards")
	st.set_weather("still", 4242)
	check(st.dawn_round == -1, "a chosen still night stays still")
	var night := st.spot_range()
	st.dawn_round = 2
	var ais := [WarbandAI.new(st, 0), WarbandAI.new(st, 1)]
	st.begin()
	var saw_event := false
	var guard := 0
	while not st.over and st.round_num < 3 and guard < 600:
		guard += 1
		for ev in st.events:
			if ev["type"] == "dawn":
				saw_event = true
		st.events.clear()
		var ai: WarbandAI = ais[st.side]
		var act := ai.next_action()
		var res := ai.execute(act)
		if act["type"] != "end" and not res.get("ok", false):
			act["unit"].ai_done = true
	if st.round_num >= 2:
		check(st.weather == "dawn", "dawn broke in round 2")
		check(saw_event, "a dawn event was queued")
		check(st.spot_range() > night * 1.3, "dawn lengthens sight")
	# rolled weather: some still nights turn, always in rounds 3 to 5
	var turned := 0
	for sd in range(1, 400):
		var s2 := BattleState.new()
		s2.set_weather("random", sd)
		if s2.dawn_round > 0:
			turned += 1
			check(s2.weather == "still" and s2.dawn_round >= 3 and s2.dawn_round <= 5, "dawn only on still nights, rounds 3-5")
	check(turned > 20 and turned < 90, "about one still night in three turns to dawn (%d of 399)" % turned)
	print("dawn test: ", turned, " of 399 rolled nights turn to dawn")

func _test_hide() -> void:
	## Hiding: only out of every enemy's sight; a hidden fighter is unseen
	## beyond close range even in the open, holds through the enemy's turn,
	## and breaks cover the moment they move.
	var st := BattleState.new()
	st.setup("hethra_square", "marines", "chained", 93, true, true, [[], []], "skirmish")
	st.begin()
	var ms: int = 0 if st.sides[0]["wb"]["id"] == "marines" else 1
	if st.side != ms:
		st.end_turn()
	var h: BUnit = st.side_units(ms).filter(func(o): return o.standing())[0]
	var e: BUnit = st.side_units(1 - ms).filter(func(o): return o.standing())[0]
	# an enemy close by sees them, so no hiding
	var near := -1
	for nd in st.map.nodes:
		var dd: float = st.map.node_pos(nd).distance_to(st.pos(h))
		if not st.occupied.has(nd) and dd > 3.4 and dd < 4.6:
			near = nd
			break
	if near >= 0:
		var back: int = e.node
		st._place(e, near)
		check(not st.engaged(h) and not st.hide_info(h)["ok"], "no hiding with an enemy looking on")
		st._place(e, back)
	# find a spot for the hider that no enemy sees
	var spot := -1
	for nd in st.map.nodes:
		if st.occupied.has(nd):
			continue
		st._place(h, nd)
		if st.hide_info(h)["ok"]:
			spot = nd
			break
	check(spot >= 0, "found a place out of sight to hide")
	if spot < 0:
		return
	var r := st.hide(h)
	check(r.get("ok", false) and h.hidden and h.ap == 0, "a fighter goes to ground and spends the turn")
	check(not st.hide(h).get("ok", false), "no hiding twice")
	check(not st.watch_info(h)["ok"], "a hidden fighter cannot also stand watch")
	# an enemy in the open with a clear view, out past close range, cannot see them
	var open_nd := -1
	for nd in st.map.nodes:
		if st.occupied.has(nd):
			continue
		var q: Vector3 = st.map.node_pos(nd)
		var dd: float = q.distance_to(st.pos(h))
		if dd < 7.0 or dd > minf(14.0, st.spot_range() - 1.0):
			continue
		st._place(e, nd)
		if st.map.can_see_any(st.eye(e), st.pos(h)):
			open_nd = nd
			break
	check(open_nd >= 0, "found an open view onto the hider")
	if open_nd >= 0:
		check(not st._sees(e, h), "a hidden fighter is not seen past close range, even in the open")
		h.hidden = false
		check(st._sees(e, h), "the same fighter is seen there when not hidden")
		h.hidden = true
	near = -1
	for nd in st.map.nodes:
		var dd2: float = st.map.node_pos(nd).distance_to(st.pos(h))
		if not st.occupied.has(nd) and dd2 > 3.0 and dd2 < 4.8:
			near = nd
			break
	if near >= 0:
		st._place(e, near)
		check(st._sees(e, h), "close up, a hidden fighter is seen")
		st._place(e, open_nd if open_nd >= 0 else e.node)
	st.end_turn()
	check(h.hidden, "hiding holds through the enemy's turn")
	st.end_turn()
	check(h.hidden, "hiding holds into their own turn")
	var reach := st.reachable(h)
	var dest := -1
	for nd in reach:
		if nd != h.node:
			dest = nd
			break
	if dest >= 0:
		st.move(h, dest)
		check(not h.hidden, "moving breaks cover")
	_invariants(st)

func _test_watch() -> void:
	## Standing watch: a shooter gives up their turn; the first enemy to walk
	## into range and sight in the enemy's turn draws one shot, and the walk
	## is shown in two parts around it. An unused watch ends with the turn.
	var st := BattleState.new()
	st.setup("hethra_square", "marines", "chained", 91, true, true, [[], []], "skirmish")
	st.begin()
	var ms: int = 0 if st.sides[0]["wb"]["id"] == "marines" else 1
	if st.side != ms:
		st.end_turn()
	var shooters: Array = st.side_units(ms).filter(func(o): return o.missile() != "" and o.standing())
	check(shooters.size() >= 2, "marines have two shooters to watch with")
	if shooters.size() < 2:
		return
	var w: BUnit = shooters[0]
	var w2: BUnit = shooters[1]
	var melee_only: Array = st.side_units(ms).filter(func(o): return o.missile() == "")
	if not melee_only.is_empty():
		check(not st.watch_info(melee_only[0])["ok"], "a fighter without a missile weapon cannot watch")
	var r := st.watch(w)
	check(r.get("ok", false) and w.watching and w.ap == 0, "a shooter stands watch and spends the turn")
	check(not st.watch(w).get("ok", false), "no watching twice")
	st.watch(w2)
	# park the second watcher where it sees nothing, so only the first fires
	st.end_turn()
	check(w.watching, "the watch holds through the enemy's turn")
	var wd := GameData.weapon(w.missile())
	var rng: float = wd.get("range", 20)
	var e: BUnit = null
	for o in st.side_units(1 - ms):
		if o.standing():
			e = o
			break
	# find a start out of the watcher's sight and a walk that crosses into it
	var found := false
	for start in st.map.nodes:
		if st.occupied.has(start):
			continue
		var sp := st.map.node_pos(start)
		if sp.distance_to(st.pos(w)) < 6.0 or sp.distance_to(st.pos(w)) > rng + 6.0:
			continue
		st._place(e, start)
		if st._sees(w, e) or st._sees(w2, e):
			continue
		e.mp = e.mp_full
		var reach := st.reachable(e)
		for dest in reach:
			var path := st.path_to(reach, dest)
			var crosses := false
			for nd in path:
				var q := st.map.node_pos(nd)
				if q.distance_to(st.pos(w)) < rng - 2.0 and st.map.can_see_any(st.eye(w), q) and not st.occupied.has(nd):
					crosses = true
					break
			if crosses and not st.adjacent_enemies(e).size():
				st.events.clear()
				st.move(e, dest)
				found = true
				break
		if found:
			break
	check(found, "found a walk into the watcher's sight")
	if not found:
		return
	var shots := st.events.filter(func(v): return v["type"] == "shot" and v["unit"] == w.id and v["target"] == e.id)
	check(shots.size() == 1, "the watcher fires once (%d)" % shots.size())
	check(not w.watching, "firing ends the watch")
	var moves := st.events.filter(func(v): return v["type"] == "move" and v["unit"] == e.id)
	var mi := st.events.find(moves[0]) if not moves.is_empty() else -1
	var si := st.events.find(shots[0]) if not shots.is_empty() else -1
	check(mi >= 0 and si > mi, "the walk is shown up to the shot, then the shot")
	_invariants(st)
	# the other watcher's watch ends when its own turn comes round
	st.end_turn()
	check(not w2.watching, "an unused watch ends at the start of its own turn")

func _test_standards() -> void:
	## Raise the standards: three cairns on every ward, fairly placed and
	## apart; a lone fighter raises one at the end of the turn, an enemy
	## beside the cairn stops it, all three win at once.
	for mid in GameData.MAP_IDS:
		var st := BattleState.new()
		st.setup(mid, "marines", "chained", 77, true, true, [[], []], "standards")
		check(st.standards.size() == 3, "%s has three cairns (%d)" % [mid, st.standards.size()])
		for c in st.standards:
			check(not st.zones[0].has(c) and not st.zones[1].has(c), "%s cairn off both starting grounds" % mid)
			check(st.standards[c] == -1, "%s cairn starts bare" % mid)
		var cs: Array = st.standards.keys()
		for i in range(cs.size()):
			for j in range(i + 1, cs.size()):
				var p: Vector3 = st.map.node_pos(cs[i])
				var q: Vector3 = st.map.node_pos(cs[j])
				check(Vector2(p.x, p.z).distance_to(Vector2(q.x, q.z)) >= st.map.cell * 1.5, "%s cairns not bunched" % mid)
	var st := BattleState.new()
	st.setup("hethra_square", "marines", "chained", 78, true, true, [[], []], "standards")
	st.begin()
	var cs: Array = st.standards.keys()
	var me: BUnit = st.side_units(st.side)[0]
	var foe: BUnit = st.side_units(1 - st.side)[0]
	var s: int = st.side
	# park everyone else far from the cairns: use the cairn nodes directly for the two testers
	st._place(me, cs[0])
	st.end_turn()
	check(st.standards[cs[0]] == s, "a lone fighter at a cairn raises the standard")
	check(st.standards_held(s) == 1, "one standard held")
	# the enemy stands beside it: their turn ends, but ours is still there, so nothing changes
	var nb := -1
	for a in st.map.adjacent.get(cs[0], []):
		if not st.occupied.has(a):
			nb = a
			break
	if nb >= 0:
		st._place(foe, nb)
		st.end_turn()
		check(st.standards[cs[0]] == s, "a contested cairn keeps its standard")
		# our fighter goes down: now theirs can tear it down
		me.status = "down"
		st.end_turn()
		st.end_turn()
		check(st.standards[cs[0]] == 1 - s, "the enemy tears the standard down and raises their own")
	# all three for one side ends it at once
	var st2 := BattleState.new()
	st2.setup("starfall", "marines", "chained", 79, true, true, [[], []], "standards")
	st2.begin()
	var mine: Array = st2.side_units(st2.side)
	var k := 0
	for c in st2.standards:
		st2._place(mine[k], c)
		k += 1
	var s2: int = st2.side
	st2.end_turn()
	# the other band gets a whole turn to answer
	check(not st2.over and st2.standards_held(s2) == 3, "three standards wait out the enemy's turn")
	st2.end_turn()
	check(st2.over and st2.winner == s2, "three standards held through the enemy's turn win at once")
	# and a standard torn down in that turn saves the day
	var st3 := BattleState.new()
	st3.setup("starfall", "marines", "chained", 79, true, true, [[], []], "standards")
	st3.begin()
	var m3: Array = st3.side_units(st3.side)
	var k3 := 0
	for c in st3.standards:
		st3._place(m3[k3], c)
		k3 += 1
	var s3: int = st3.side
	st3.end_turn()
	var c0: int = st3.standards.keys()[0]
	m3[0].status = "ooa"
	st3._place(st3.side_units(1 - s3)[0], c0)
	st3.end_turn()
	check(not st3.over and st3.standards[c0] == 1 - s3, "a torn-down standard stops the win")
	# AI battles in this scenario raise standards and finish
	var raised := 0
	for i in range(GameData.MAP_IDS.size()):
		var b := BattleState.new()
		var ids := GameData.WARBAND_IDS
		b.setup(GameData.MAP_IDS[i], ids[i % ids.size()], ids[(i + 3) % ids.size()], 2000 + i, true, true, [[], []], "standards")
		var ais := [WarbandAI.new(b, 0), WarbandAI.new(b, 1)]
		b.begin()
		var guard := 0
		var ever := false
		while not b.over and guard < 3000:
			guard += 1
			var ai: WarbandAI = ais[b.side]
			var act := ai.next_action()
			var r := ai.execute(act)
			if act["type"] != "end" and not r.get("ok", false):
				act["unit"].ai_done = true
			for c in b.standards:
				if b.standards[c] >= 0:
					ever = true
		check(b.over, "standards battle %d finished" % i)
		if ever:
			raised += 1
		print("standards battle %d [%s]: %s vs %s -> %s (%s) standards %d/%d" % [i, GameData.MAP_IDS[i], ids[i % ids.size()], ids[(i + 3) % ids.size()], b.winner, b.end_reason, b.standards_held(0), b.standards_held(1)])
	check(raised >= 6, "AI raises standards in most battles (%d of 8)" % raised)

func play(a: String, b: String, seed_value: int, mid := "hethra_square", scn := "shards") -> Dictionary:
	var st := BattleState.new()
	st.setup(mid, a, b, seed_value, true, true, [[], []], scn)
	st.set_weather("random", seed_value)
	weathers[st.weather] = int(weathers.get(st.weather, 0)) + 1
	var ais := [WarbandAI.new(st, 0), WarbandAI.new(st, 1)]
	st.begin()
	var actions := 0
	var guard := 0
	while not st.over and guard < 3000:
		guard += 1
		var ai: WarbandAI = ais[st.side]
		var act := ai.next_action()
		var side_before := st.side
		var res := ai.execute(act)
		actions += 1
		if act["type"] != "end" and not res.get("ok", false):
			# a refused action must not repeat forever
			act["unit"].ai_done = true
		_invariants(st)
		if act["type"] == "end":
			check(st.over or st.side != side_before, "end turn passes the turn")
	check(st.over, "battle %d finished" % seed_value)
	var res := {"winner": st.winner, "rounds": st.round_num, "reason": st.end_reason, "actions": actions,
		"ooa0": st.ooa_count(0), "ooa1": st.ooa_count(1), "sh0": st.shards_held(0), "sh1": st.shards_held(1)}
	return res

func _invariants(st: BattleState) -> void:
	var seen := {}
	for u in st.units:
		if u.status == "ooa":
			continue
		check(st.map.nodes.has(u.node), "%s stands on a real node" % u.name)
		check(not seen.has(u.node), "%s shares a node" % u.name)
		seen[u.node] = true
		check(st.occupied.get(u.node) == u, "%s occupancy" % u.name)
		check(u.wounds >= 0 and u.wounds <= u.stat("W"), "%s wounds in range" % u.name)
		check(u.ap >= 0, "%s ap not negative" % u.name)
