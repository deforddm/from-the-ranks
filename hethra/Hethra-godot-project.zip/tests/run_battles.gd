extends SceneTree
## Headless rules test: plays AI-vs-AI battles and checks invariants.
## godot --headless --path . --script res://tests/run_battles.gd -- [count]

var failures := 0

func check(cond: bool, msg: String) -> void:
	if not cond:
		failures += 1
		printerr("FAIL: ", msg)

func _init() -> void:
	var count := 12
	for a in OS.get_cmdline_user_args():
		if a.is_valid_int():
			count = int(a)
	_test_rules()
	_test_map()
	var wins := {0: 0, 1: 0, -2: 0}
	var by_faction := {}
	var rounds_total := 0
	var t0 := Time.get_ticks_msec()
	var ids := GameData.WARBAND_IDS
	for i in range(count):
		var a: String = ids[i % ids.size()]
		var b: String = ids[(i / ids.size() + 1 + i) % ids.size()]
		if a == b:
			b = ids[(ids.find(a) + 1) % ids.size()]
		var res := play(a, b, 1000 + i)
		wins[res["winner"]] = wins.get(res["winner"], 0) + 1
		rounds_total += res["rounds"]
		var wf: String = a if res["winner"] == 0 else (b if res["winner"] == 1 else "draw")
		by_faction[wf] = by_faction.get(wf, 0) + 1
		print("battle %d: %s vs %s -> %s in %d rounds (%s) ooa %d/%d shards %d/%d actions %d" % [i, a, b, wf, res["rounds"], res["reason"], res["ooa0"], res["ooa1"], res["sh0"], res["sh1"], res["actions"]])
	print("wins by side: ", wins, "  by warband: ", by_faction, "  avg rounds %.1f" % (float(rounds_total) / count), "  time %d ms" % (Time.get_ticks_msec() - t0))
	print("FAILURES: %d" % failures)
	quit(1 if failures > 0 else 0)

func _test_rules() -> void:
	check(Rules.melee_to_hit(4, 3) == 3, "WS4 vs WS3 hits on 3")
	check(Rules.melee_to_hit(3, 3) == 4, "WS3 vs WS3 hits on 4")
	check(Rules.melee_to_hit(2, 5) == 5, "WS2 vs WS5 hits on 5")
	check(Rules.to_wound(3, 3) == 4, "S3 T3 wounds on 4")
	check(Rules.to_wound(5, 3) == 2, "S5 T3 wounds on 2")
	check(Rules.to_wound(3, 6) == 0, "S3 T6 cannot wound")
	check(Rules.save_needed(5, 4, 0) == 6, "heavy armour vs S4 saves on 6")
	check(Rules.save_needed(6, 4, 0) == 7, "light armour vs S4 no save")
	check(Rules.save_needed(4, 3, 1) == 5, "axe worsens save")
	check(Rules.save_needed(7, 3, -1) == 6, "knife lets the unarmoured save on 6")

func _test_map() -> void:
	var m := BattleMap.new()
	m.load_map("hethra_square")
	print("map nodes %d, edge lists %d" % [m.nodes.size(), m.edges.size()])
	var kinds := {}
	for id in m.edges:
		for e in m.edges[id]:
			kinds[e["kind"]] = kinds.get(e["kind"], 0) + 1
	print("edge kinds: ", kinds)
	check(kinds.get("climb", 0) > 0, "map has ladders")
	check(kinds.get("jump", 0) > 0, "map has jumps")
	check(kinds.get("drop", 0) > 0, "map has drops")
	var start := m.top_node(14, 26)
	var reach := m.connected_count(start)
	print("reachable from south street: %d of %d nodes" % [reach, m.nodes.size()])
	check(reach > m.nodes.size() * 0.9, "most of the map is reachable")
	var north := m.top_node(14, 1)
	var dm := m.distance_map_to([north])
	check(dm.has(start), "north deployment reachable from south")
	# every shard reachable
	for sh in m.data["shards"]:
		var id := BattleMap.nid(int(sh[0]), int(sh[1]), int(sh[2]))
		check(m.nodes.has(id) and dm.has(id), "shard at %s reachable" % str(sh))
	# sight: across the open square yes, through a solid keep no
	var a := m.node_pos(m.top_node(11, 11)) + Vector3(0, 1.6, 0)
	var b := m.node_pos(m.top_node(11, 16))
	check(m.visibility(a, b) > 0.0, "can see across the square")
	var c := m.node_pos(m.top_node(14, 26)) + Vector3(0, 1.6, 0)
	var dd := m.node_pos(m.top_node(14, 16))
	print("vis south street -> square: %.2f" % m.visibility(c, dd))
	var e := m.node_pos(m.top_node(6, 12)) + Vector3(0, 1.6, 0)
	var f := m.node_pos(m.top_node(1, 3))
	check(m.visibility(e, f) == 0.0, "keep blocks sight")

func play(a: String, b: String, seed_value: int) -> Dictionary:
	var st := BattleState.new()
	st.setup("hethra_square", a, b, seed_value, true, true)
	var ais := [WarbandAI.new(st, 0), WarbandAI.new(st, 1)]
	st.begin()
	var actions := 0
	var guard := 0
	while not st.over and guard < 3000:
		guard += 1
		var ai: WarbandAI = ais[st.side]
		var act := ai.next_action()
		var side_before := st.side
		var res := ai.execute(act)
		actions += 1
		if act["type"] != "end" and not res.get("ok", false):
			# a refused action must not repeat forever
			act["unit"].ai_done = true
		_invariants(st)
		if act["type"] == "end":
			check(st.over or st.side != side_before, "end turn passes the turn")
	check(st.over, "battle %d finished" % seed_value)
	var res := {"winner": st.winner, "rounds": st.round_num, "reason": st.end_reason, "actions": actions,
		"ooa0": st.ooa_count(0), "ooa1": st.ooa_count(1), "sh0": st.shards_held(0), "sh1": st.shards_held(1)}
	return res

func _invariants(st: BattleState) -> void:
	var seen := {}
	for u in st.units:
		if u.status == "ooa":
			continue
		check(st.map.nodes.has(u.node), "%s stands on a real node" % u.name)
		check(not seen.has(u.node), "%s shares a node" % u.name)
		seen[u.node] = true
		check(st.occupied.get(u.node) == u, "%s occupancy" % u.name)
		check(u.wounds >= 0 and u.wounds <= u.stat("W"), "%s wounds in range" % u.name)
		check(u.ap >= 0, "%s ap not negative" % u.name)
