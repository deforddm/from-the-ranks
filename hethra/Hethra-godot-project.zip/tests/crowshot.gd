extends SceneTree
## Look-dev: a few crows on cobbles, perched and flying, close up.
## xvfb-run godot --path . --script res://tests/crowshot.gd -- OUT.png

func _init() -> void:
	var out := "user://crows.png"
	for a in OS.get_cmdline_user_args():
		out = a
	root.size = Vector2i(1600, 900)
	var world := Node3D.new()
	root.add_child(world)
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.05, 0.05, 0.06)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.5, 0.52, 0.6)
	env.ambient_light_energy = 0.4
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	we.environment = env
	world.add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation = Vector3(-0.8, 2.2, 0)
	sun.light_energy = 1.2
	sun.shadow_enabled = true
	world.add_child(sun)
	var fire := OmniLight3D.new()
	fire.position = Vector3(-1.2, 1.0, 1.4)
	fire.light_color = Color(1.0, 0.6, 0.3)
	fire.light_energy = 3.0
	fire.omni_range = 7.0
	world.add_child(fire)
	var fl := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(20, 20)
	fl.mesh = pm
	fl.material_override = Mats.cobbles()
	world.add_child(fl)
	var cam_pos := Vector3(1.4, 1.2, 2.2)
	var cam_at := Vector3(0, 0.3, 0)
	var cr := Crows.new()
	world.add_child(cr)
	var m := BattleMap.new()
	m.load_map("hethra_square")
	cr.build(m, {}, 3, 5)
	cr.calm = true
	cr.gather_at(Vector3.ZERO, 4)
	var bd = cr.birds[4]
	bd.state = "fly"
	bd.node.position = Vector3(0.3, 1.0, 0.4)
	bd.node.rotation.y = 1.2
	cr._wings(bd, 0.5, 0.0)
	cr.set_process(false)
	if OS.get_environment("CROW_NOFLY") != "":
		bd.node.visible = false
	if OS.get_environment("CROW_SOLO") != "":
		for i in range(1, cr.birds.size()):
			cr.birds[i].node.visible = false
		cr.birds[0].node.position = Vector3.ZERO
		cr.birds[0].node.rotation.y = float(OS.get_environment("CROW_SOLO"))
		if OS.get_environment("CROW_HIDE") != "":
			cr.birds[0].get(OS.get_environment("CROW_HIDE")).visible = false
		cam_pos = Vector3(0.75, 0.45, 1.0)
		cam_at = Vector3(0, 0.2, 0)
	var cam := Camera3D.new()
	cam.fov = 40
	world.add_child(cam)
	cam.transform = Transform3D(Basis.looking_at(cam_at - cam_pos), cam_pos)
	cam.current = true
	_out = out
	_shoot.call_deferred()

var _out := ""

func _shoot() -> void:
	for i in range(8):
		await process_frame
	root.get_viewport().get_texture().get_image().save_png(_out)
	quit()
