extends SceneTree
func _init() -> void:
	var st := BattleState.new()
	st.setup("hethra_square", "marines", "chained", 1000, true, true)
	var ais := [WarbandAI.new(st, 0), WarbandAI.new(st, 1)]
	st.begin()
	var guard := 0
	while not st.over and guard < 3000:
		guard += 1
		var ai: WarbandAI = ais[st.side]
		var act := ai.next_action()
		var res := ai.execute(act)
		if act["type"] != "end" and not res.get("ok", false):
			print("  !! refused ", act["type"], " ", res.get("msg", ""))
			act["unit"].ai_done = true
	for l in st.log_lines:
		print(l)
	quit()
