extends SceneTree
## Renders every fighter of every warband side by side, and a row of them
## caught mid-move, to check the figures by eye.
## xvfb-run godot --path . --script res://tests/lineup.gd -- OUT_DIR

var out := "user://lineup"
var figs: Array = []
var cam: Camera3D

func _init() -> void:
	for a in OS.get_cmdline_user_args():
		out = a
	DirAccess.make_dir_recursive_absolute(out)
	root.size = Vector2i(1600, 900)
	var world := Node3D.new()
	root.add_child(world)
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.07, 0.07, 0.09)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.5, 0.5, 0.55)
	env.ambient_light_energy = 0.6
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	we.environment = env
	world.add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation = Vector3(-0.8, 0.6, 0)
	sun.light_energy = 1.3
	sun.shadow_enabled = true
	world.add_child(sun)
	var fill := OmniLight3D.new()
	fill.position = Vector3(-3, 3, 6)
	fill.light_color = Color(1.0, 0.7, 0.45)
	fill.light_energy = 2.0
	fill.omni_range = 20
	world.add_child(fill)
	var floor_m := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(60, 60)
	floor_m.mesh = pm
	var fm := StandardMaterial3D.new()
	fm.albedo_color = Color(0.16, 0.15, 0.14)
	floor_m.material_override = fm
	world.add_child(floor_m)
	cam = Camera3D.new()
	cam.cull_mask = 0xFFFFF
	world.add_child(cam)
	var row := 0
	var uid := 1
	for wid in GameData.WARBAND_IDS:
		var wb := GameData.warband(wid)
		var col := 0
		for key in wb["units"]:
			var def: Dictionary = wb["units"][key]
			var u := BUnit.new()
			u.id = uid
			uid += 1
			u.setup_from(def, wb, {"unit": key})
			var f := Figure.new()
			world.add_child(f)
			f.setup(u, wb)
			f.label.visible = false
			f.position = Vector3(col * 1.35, 0, -row * 2.2)
			f.set_process(false)
			figs.append(f)
			col += 1
		row += 1
	_shoot.call_deferred()

func _step(t: float) -> void:
	var n := int(t / 0.02)
	for i in range(n):
		for f in figs:
			f._process(0.02)

func _snap(nm: String) -> void:
	for i in range(4):
		await process_frame
	var img := root.get_viewport().get_texture().get_image()
	img.save_png(out.path_join(nm))
	print("saved ", nm)

func _shoot() -> void:
	_step(0.5)
	# the whole muster, at rest
	cam.position = Vector3(3.6, 3.2, 6.2)
	cam.look_at(Vector3(3.6, 0.6, -4.2))
	cam.fov = 50
	await _snap("lineup_all.png")
	# close on the front row (the marines)
	cam.position = Vector3(3.4, 1.4, 3.2)
	cam.look_at(Vector3(3.4, 1.0, 0))
	cam.fov = 45
	await _snap("lineup_marines.png")
	for r in range(1, GameData.WARBAND_IDS.size()):
		cam.position = Vector3(3.4, 1.4, 3.2 - r * 2.2)
		cam.look_at(Vector3(3.4, 1.0, -r * 2.2))
		await _snap("lineup_%d.png" % r)
	# in motion: walking, striking, aiming, casting, falling
	var acts := ["walk", "lunge", "aim", "cast", "throw", "down"]
	for i in range(figs.size()):
		var f: Figure = figs[i]
		var a: String = acts[i % acts.size()]
		match a:
			"walk":
				f.moving = true
			"lunge":
				f.lunge(f.global_position + f.global_transform.basis.z * 3.0)
			"aim":
				f.aim(f.global_position + f.global_transform.basis.z * 6.0)
			"cast":
				f.cast_anim()
			"throw":
				f.throw_at(f.global_position + f.global_transform.basis.z * 6.0)
			"down":
				f.set_status("down")
	_step(0.42)
	cam.position = Vector3(5.5, 1.9, 4.0)
	cam.look_at(Vector3(2.5, 0.8, -1.2))
	cam.fov = 50
	await _snap("action_front.png")
	cam.position = Vector3(-2.5, 1.6, -2.0)
	cam.look_at(Vector3(3.0, 0.9, -3.0))
	await _snap("action_side.png")
	quit()
