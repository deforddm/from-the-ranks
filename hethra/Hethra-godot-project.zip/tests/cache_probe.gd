extends SceneTree
## Plays AI-vs-AI strongbox battles and prints how each went, to tune the
## scenario. godot --headless --path . --script res://tests/cache_probe.gd -- [count] [verbose]

func _init() -> void:
	var count := 14
	var verbose := false
	for a in OS.get_cmdline_user_args():
		if a.is_valid_int():
			count = int(a)
		elif a == "verbose":
			verbose = true
	var ids := GameData.WARBAND_IDS
	var reasons := {}
	var rounds := 0
	for i in range(count):
		var a: String = ids[i % ids.size()]
		var b: String = ids[(i * 3 + 1) % ids.size()]
		if a == b:
			b = ids[(ids.find(a) + 1) % ids.size()]
		var mid: String = GameData.MAP_IDS[i % GameData.MAP_IDS.size()]
		var st := BattleState.new()
		st.setup(mid, a, b, 500 + i, true, true, [[], []], "cache")
		var ais := [WarbandAI.new(st, 0), WarbandAI.new(st, 1)]
		st.begin()
		var guard := 0
		var found_round := -1
		while not st.over and guard < 3000:
			guard += 1
			var ai: WarbandAI = ais[st.side]
			var act := ai.next_action()
			var res := ai.execute(act)
			if act["type"] != "end" and not res.get("ok", false):
				act["unit"].ai_done = true
			if found_round < 0 and (st.cache_holder >= 0 or st.cache_node >= 0):
				found_round = st.round_num
		var why: String = st.end_reason.split(".")[0] if st.end_reason.contains("strongbox") else st.end_reason
		var key := "carried home" if st.end_reason.contains("carried") else ("held at night" if st.end_reason.contains("strongbox") else "other")
		reasons[key] = reasons.get(key, 0) + 1
		rounds += st.round_num
		print("%2d %-13s %-9s v %-9s found r%d, over r%d: %s" % [i, mid, a, b, found_round, st.round_num, st.end_reason])
		if verbose:
			for l in st.log_lines:
				if str(l).contains("strongbox") or str(l).contains("digs") or str(l).contains("Turn"):
					print("    ", l)
	print(reasons, "  avg rounds %.1f" % (float(rounds) / count))
	quit()
