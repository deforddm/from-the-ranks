extends SceneTree
## A close portrait of a few fighters on wet cobbles by firelight, for the
## download page.
## xvfb-run godot --path . --script res://tests/closeup.gd -- OUT_DIR [warband]

var out := "user://closeup"
var wid := "marines"
var figs: Array = []

func _init() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size() > 0:
		out = args[0]
	if args.size() > 1:
		wid = args[1]
	DirAccess.make_dir_recursive_absolute(out)
	root.size = Vector2i(1600, 900)
	var world := Node3D.new()
	root.add_child(world)
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.035, 0.03, 0.035)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.45, 0.47, 0.55)
	env.ambient_light_energy = 0.35
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.09, 0.07, 0.07)
	env.fog_density = 0.09
	env.glow_enabled = true
	env.ssao_enabled = true
	we.environment = env
	world.add_child(we)
	var moon := DirectionalLight3D.new()
	moon.rotation = Vector3(-0.7, 2.4, 0)
	moon.light_color = Color(0.62, 0.7, 0.95)
	moon.light_energy = 0.55
	moon.shadow_enabled = true
	world.add_child(moon)
	var fire := OmniLight3D.new()
	fire.position = Vector3(-1.6, 1.0, 1.7)
	fire.light_color = Color(1.0, 0.58, 0.28)
	fire.light_energy = 4.0
	fire.omni_range = 9.0
	fire.shadow_enabled = true
	world.add_child(fire)
	var key := SpotLight3D.new()
	world.add_child(key)
	key.transform = Transform3D(Basis.looking_at(Vector3(0, 1.1, 0) - Vector3(2.6, 2.4, 3.2)), Vector3(2.6, 2.4, 3.2))
	key.light_color = Color(1.0, 0.85, 0.7)
	key.light_energy = 3.0
	key.spot_range = 12.0
	key.spot_angle = 30.0
	key.shadow_enabled = true
	var floor_m := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(30, 30)
	floor_m.mesh = pm
	floor_m.material_override = Mats.cobbles()
	world.add_child(floor_m)
	# a broken wall behind them
	var wall := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(12, 3.2, 0.6)
	wall.mesh = bm
	wall.material_override = Mats.darkstone()
	wall.position = Vector3(0, 1.6, -4.2)
	world.add_child(wall)
	var cam := Camera3D.new()
	cam.fov = 38
	world.add_child(cam)
	var wb := GameData.warband("marines" if wid == "sellswords" else wid)
	var tall := 1.15 if wid == "sellswords" else float(wb.get("tall", 1.0))
	var eye := Vector3(0.55, 1.45 * tall, 3.1 * (1.0 + (tall - 1.0) * 0.8))
	cam.transform = Transform3D(Basis.looking_at(Vector3(0.05, 1.05 * tall, 0) - eye), eye)
	cam.current = true
	var keys: Array = wb["units"].keys()
	var pick: Array = keys.slice(0, mini(4, keys.size()))
	if wid == "sellswords":
		pick = keys.filter(func(k): return String(k).begins_with("sw_"))
	var uid := 3
	for i in range(pick.size()):
		var def: Dictionary = wb["units"][pick[i]]
		var u := BUnit.new()
		u.id = uid
		uid += 7
		u.setup_from(def, wb, {"unit": pick[i]})
		var f := Figure.new()
		world.add_child(f)
		f.setup(u, wb)
		f.label.visible = false
		f.ring.visible = false
		var off: float = i - (pick.size() - 1) * 0.5
		f.position = Vector3(off * 0.95, 0, -absf(off) * 0.45)
		f.rotation.y = -off * 0.22 + 0.1
		f.set_process(false)
		figs.append(f)
	_shoot.call_deferred()

func _shoot() -> void:
	for i in range(25):
		for f in figs:
			f._process(0.02)
	for i in range(6):
		await process_frame
	var img := root.get_viewport().get_texture().get_image()
	img.save_png(out.path_join("closeup_%s.png" % wid))
	print("saved closeup_", wid)
	for f in figs:
		print("meshes per figure: ", f.find_children("*", "MeshInstance3D", true, false).size())
	quit()
