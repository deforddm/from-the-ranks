extends SceneTree
## Sellswords: hire, upkeep, no kit, no xp, and the dead find no takers.
## godot --headless --path . --script res://tests/run_sellswords.gd

var fails := 0

func check(ok: bool, what: String) -> void:
	if not ok:
		fails += 1
		print("FAIL: ", what)

func _init() -> void:
	check(GameData.warband("marines")["units"].has("sw_trell"), "marines can hire a Trell")
	check(not GameData.warband("imass")["units"].has("sw_trell"), "the Kin of the Dust find no takers")
	var c := Campaign.create("marines", "Test", 7)
	c.gold = 500
	check(c.can_hire("sw_trell") == "", "can hire a sellsword")
	var heroes := c.hero_count()
	var f := c.hire("sw_trell")
	check(not f.is_empty() and f["role"] == "sword", "the Trell joins as a sellsword")
	check(c.gold == 430, "hiring costs 70")
	check(c.hero_count() == heroes, "a sellsword takes no hero place")
	check(c.can_hire("sw_trell") != "", "only one Trell")
	check(c.can_buy(int(f["uid"]), "shield") != "", "sellswords bring their own kit")
	# a battle where everyone walks away
	var took := {}
	for x in c.fighters:
		took[str(x["uid"])] = {"status": "ok", "kills": 1}
	var xp0 := int(f["xp"])
	var g0 := c.gold
	var rep := c.apply_result({"won": true, "enemy": "chained", "enemy_rating": c.rating(), "field_shards": 0, "fighters": took})
	check(int(f["xp"]) == xp0, "a sellsword learns nothing")
	check(int(rep.get("upkeep", 0)) == 25, "upkeep 25 paid")
	check(not (rep["search"]["who"] as Array).has(f["name"]), "sellswords do not search")
	# an empty purse
	c.gold = 3
	c.pending_event = {}
	took = {}
	for x in c.fighters:
		took[str(x["uid"])] = {"status": "ok", "kills": 0}
	rep = c.apply_result({"won": false, "enemy": "chained", "enemy_rating": c.rating(), "field_shards": 0, "fighters": took})
	var still := c.fighters.any(func(x): return x["unit"] == "sw_trell")
	check(not still or c.gold >= 0, "unpaid sellsword walks")
	check(c.gold >= 0, "never in debt")
	# the save keeps them
	c.gold = 500
	c.hire("sw_healer")
	c.save()
	var back := Campaign.load_file(c.id)
	check(back != null and back.fighters.any(func(x): return x["unit"] == "sw_healer"), "save keeps the sellsword")
	Campaign.delete_save(c.id)
	# in battle
	var st := BattleState.new()
	st.setup("hethra_square", "marines", "chained", 3, true, true, [c.battle_roster(), []], "shards")
	var found := false
	for u in st.units:
		if u.unit_type == "sw_healer":
			found = true
			check(not u.spells.is_empty(), "the healer has spells")
	check(found, "the healer takes the field")
	print("sellsword test: ", "FAILURES: %d" % fails)
	quit()
