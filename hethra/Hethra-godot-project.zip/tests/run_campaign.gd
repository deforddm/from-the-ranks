extends SceneTree
## Headless campaign test: each warband plays a run of AI battles with the
## full campaign between them (injuries, experience, advances, loot, market,
## hiring, saving and loading), checking the books stay straight.
## godot --headless --path . --script res://tests/run_campaign.gd -- [battles]

var failures := 0

func check(cond: bool, msg: String) -> void:
	if not cond:
		failures += 1
		printerr("FAIL: ", msg)

func _ward_holds() -> void:
	## Holding a ward: two wins and more wins than losses take it, a loss there
	## gives it up, and held wards pay dues.
	var c := Campaign.create("marines", "", 99)
	var r := {"won": true, "draw": false}
	c.record_ward("starfall", r)
	check(c.held_wards().is_empty(), "one win holds nothing")
	r = {"won": true, "draw": false}
	c.record_ward("starfall", r)
	check(c.held_wards() == ["starfall"] and r["ward_taken"] == "starfall", "two wins take the Starfall")
	r = {"won": false, "draw": true}
	c.record_ward("starfall", r)
	check(c.held_wards() == ["starfall"], "a draw keeps the hold")
	r = {"won": false, "draw": false}
	c.record_ward("starfall", r)
	check(c.held_wards().is_empty() and r["ward_lost"] == "starfall", "a loss gives it up")
	r = {"won": true, "draw": false}
	c.record_ward("starfall", r)
	check(c.held_wards() == ["starfall"], "three wins in five take it back")
	var d := Campaign.from_dict(JSON.parse_string(JSON.stringify(c.to_dict())))
	check(d.held_wards() == ["starfall"], "a held ward survives a save")
	print("ward holds checked")

func _last_night() -> void:
	## Four wards held calls the last night; winning it crowns the band, losing
	## it costs one ward (and only one).
	var res_for := func(won: bool, draw := false) -> Dictionary:
		return {"won": won, "draw": draw, "enemy": "chained", "enemy_rating": 0, "map": Campaign.LAST_NIGHT_MAP,
			"field_shards": 0, "fighters": {}, "last_night": true}
	var c := Campaign.create("marines", "", 4242)
	check(not c.last_night_ready(), "a new band is not called to the last night")
	for k in ["causeway", "tower_ward", "starfall", "jade"]:
		c.wards[k] = {"fought": 3, "won": 2 + (1 if k == "jade" else 0), "held": true}
	check(c.last_night_ready(), "four wards call the last night")
	var plain := int(c.enemy_roster("chained")["rating"])
	var big := int(c.enemy_roster("chained", Campaign.LAST_NIGHT_BOOST)["rating"])
	check(big > plain, "the alliance outnumbers a plain foe (%d against %d)" % [big, plain])
	var g := c.gold
	var rep: Dictionary = c.apply_result(res_for.call(true))
	check(rep["crowned"] and c.crowned == c.battles, "winning the last night crowns the band")
	check(c.gold >= g + 150, "the crown's tribute is paid")
	check(not c.last_night_ready(), "a crowned band is not called again")
	check(c.history[-1].contains("Hethra is yours"), "the chronicle records the crown")
	var d := Campaign.from_dict(JSON.parse_string(JSON.stringify(c.to_dict())))
	check(d.crowned == c.crowned, "the crown survives a save")
	# losing: one ward goes, the weakest
	var l := Campaign.create("marines", "", 4243)
	for k in ["causeway", "tower_ward", "starfall", "jade"]:
		l.wards[k] = {"fought": 3, "won": 2 + (1 if k != "starfall" else 0), "held": true}
	rep = l.apply_result(res_for.call(false))
	check(l.held_wards().size() == 3 and rep["ward_lost"] == "starfall" and l.crowned == 0, "losing the last night costs the weakest ward")
	# losing while holding the Idol Square itself costs only that ward
	var m := Campaign.create("marines", "", 4244)
	for k in ["hethra_square", "tower_ward", "starfall", "jade"]:
		m.wards[k] = {"fought": 3, "won": 2, "held": true}
	m.apply_result(res_for.call(false))
	check(m.held_wards().size() == 3 and not m.held_wards().has("hethra_square"), "losing in a held Idol Square costs only it")
	# a draw costs nothing
	var n := Campaign.create("marines", "", 4245)
	for k in ["causeway", "tower_ward", "starfall", "jade"]:
		n.wards[k] = {"fought": 3, "won": 2, "held": true}
	n.apply_result(res_for.call(false, true))
	check(n.held_wards().size() == 4 and n.last_night_ready(), "a drawn last night costs nothing")
	print("last night checked")

func _rivals() -> void:
	## A band you fight becomes a rival: its leader comes back under the same
	## name, harder each time they walk away; one taken down may die and be
	## replaced.
	var c := Campaign.create("marines", "", 777)
	var res := func(won: bool, status: String, nm: String) -> Dictionary:
		return {"won": won, "draw": false, "enemy": "barghast", "enemy_rating": 0, "map": "causeway", "field_shards": 0,
			"fighters": {}, "foe_leader": {"name": nm, "status": status, "kills": 1}, "foe_kills": 2}
	check(c.rival_text("barghast") == "", "no rival before a fight")
	var lead0 := String(c.enemy_roster("barghast")["entries"][0]["name"])
	c.apply_result(res.call(false, "ok", lead0))
	check(c.rivals.has("barghast") and int(c.rivals["barghast"]["adv"]) == 1 and int(c.rivals["barghast"]["they_won"]) == 1, "a leader who walks away hardens")
	var er: Dictionary = c.enemy_roster("barghast")
	var le: Dictionary = er["entries"][0]
	check(le["name"] == lead0 and le.get("rival", false), "the rival leader comes back by name")
	var base: Dictionary = GameData.warband("barghast")["units"][GameData.warband("barghast")["battle_roster"][0]["unit"]]
	check(int(le["xp"]) == int(base.get("xp", 0)) + 5, "a hardened leader carries an advance")
	check(c.rival_text("barghast").contains(lead0), "the camp names the rival leader")
	# a known rival taken down pays a bounty, more for a hardened one
	var g0 := c.gold
	var adv0 := int(c.rivals["barghast"]["adv"])
	var fl: Dictionary = res.call(true, "ooa", lead0)
	fl["foe_leader"]["by"] = "Fiddler"
	var brep: Dictionary = c.apply_result(fl)
	var want := Campaign.RIVAL_BOUNTY + Campaign.RIVAL_BOUNTY_ADV * adv0
	check(int(brep.get("rival_bounty", 0)) == want, "a rival leader's bounty is %d (got %d)" % [want, int(brep.get("rival_bounty", 0))])
	check((brep["lines"] as Array).any(func(l): return String(l).contains("Fiddler put down")), "the bounty names who earned it")
	check(c.gold >= g0 + want - 200, "the bounty is paid")
	# take the leader down until one dies
	var died := false
	var lost0 := int(c.rivals["barghast"]["leaders_lost"])
	for i in range(40):
		var before := String(c.rivals["barghast"]["leader"])
		var rep: Dictionary = c.apply_result(res.call(true, "ooa", before))
		if String(c.rivals["barghast"]["leader"]) != before:
			died = true
			check(rep["rival_line"].contains("takes their place") and int(c.rivals["barghast"]["adv"]) == 0, "a dead leader is replaced, green")
			break
	check(died, "a felled leader dies in forty tries")
	check(int(c.rivals["barghast"]["leaders_lost"]) == lost0 + 1, "the dead leader is counted")
	var d := Campaign.from_dict(JSON.parse_string(JSON.stringify(c.to_dict())))
	check(d.rivals == c.rivals, "rivals survive a save")
	# marines rank: a new sergeant keeps the rank
	var m := Campaign.create("barghast", "", 778)
	var ml := String(m.enemy_roster("marines")["entries"][0]["name"])
	for i in range(60):
		var before := String(m.rivals.get("marines", {"leader": ml})["leader"])
		m.apply_result({"won": true, "draw": false, "enemy": "marines", "enemy_rating": 0, "map": "causeway", "field_shards": 0,
			"fighters": {}, "foe_leader": {"name": before, "status": "ooa", "kills": 0}, "foe_kills": 0})
		if String(m.rivals["marines"]["leader"]) != before:
			break
	check(String(m.rivals["marines"]["leader"]).begins_with("Sergeant "), "a new marine leader keeps the rank (%s)" % m.rivals["marines"]["leader"])
	print("rivals checked: ", c.rival_text("barghast"))

func _new_nights() -> void:
	## The 0.33 nights: every choice of every new night resolves, and the ones
	## that touch a rival or a held ward do what they say.
	for eid in ["rival_envoy", "rival_ambush", "ward_elders", "hounds", "old_soldier", "shard_eater"]:
		var e := Campaign.event_def(eid)
		check(not e.is_empty(), "night %s exists" % eid)
		for i in range((e["choices"] as Array).size()):
			for t in range(6):
				var c := Campaign.create("marines", "", 500 + t * 7 + i)
				c.gold = 500
				c.shards = 5
				c.rivals["barghast"] = {"leader": "Varsk", "adv": 2, "fought": 1, "you_won": 0, "they_won": 1, "felled": 0, "leaders_lost": 0, "met": 1}
				c.wards["starfall"] = {"fought": 2, "won": 2, "held": true}
				c.pending_event = {"id": eid, "who_uid": int(c.fighters[0]["uid"]), "rival": "barghast", "ward": "starfall"}
				var title := c.event_text(e["title"])
				check(not title.contains("{"), "%s title fills in (%s)" % [eid, title])
				var out := c.resolve_event(i)
				check(not out.is_empty() and not String(out["text"]).contains("{"), "%s choice %d resolves" % [eid, i])
				check(int(c.rivals["barghast"]["adv"]) >= 0 and int(c.rivals["barghast"]["adv"]) <= Campaign.RIVAL_ADV_MAX, "rival advances stay in range")
	# the envoy's purse makes the rival bolder
	var c2 := Campaign.create("marines", "", 61)
	c2.rivals["barghast"] = {"leader": "Varsk", "adv": 2, "fought": 1, "you_won": 0, "they_won": 1, "felled": 0, "leaders_lost": 0, "met": 1}
	c2.pending_event = {"id": "rival_envoy", "who_uid": -1, "rival": "barghast"}
	var g := c2.gold
	c2.resolve_event(0)
	check(int(c2.rivals["barghast"]["adv"]) == 3 and c2.gold == g + 35, "taking the envoy's purse pays and emboldens the rival")
	# the elders hide your people once
	var c3 := Campaign.create("marines", "", 62)
	c3.wards["starfall"] = {"fought": 2, "won": 2, "held": true}
	c3.gold = 100
	c3.pending_event = {"id": "ward_elders", "who_uid": -1, "ward": "starfall"}
	c3.resolve_event(0)
	var r := {"won": false, "draw": false}
	c3.record_ward("starfall", r)
	check(c3.held_wards() == ["starfall"] and r["ward_lost"] == "", "a guarded ward survives one lost fight")
	r = {"won": false, "draw": false}
	c3.record_ward("starfall", r)
	check(c3.held_wards().is_empty(), "but not two")
	# drawing: a rival night only once there is a rival, a ward night only with a ward
	var c4 := Campaign.create("marines", "", 63)
	for k in range(200):
		c4.recent_events.clear()
		var pe: Dictionary = c4._draw_event()
		check(not ["rival_envoy", "rival_ambush", "ward_elders"].has(pe.get("id", "")), "no rival or ward night without one")
	c4.rivals["seguleh"] = {"leader": "Third", "adv": 0, "fought": 1, "you_won": 1, "they_won": 0, "felled": 0, "leaders_lost": 0, "met": 1}
	var seen := false
	for k in range(300):
		c4.recent_events.clear()
		var pe: Dictionary = c4._draw_event()
		if String(pe.get("id", "")).begins_with("rival_"):
			seen = pe.get("rival", "") == "seguleh"
			break
	check(seen, "a rival night names a real rival")
	print("new nights checked")

func _rare_goods() -> void:
	## 0.34: the shard market's rare goods. Stock turns over each battle, a bought
	## piece leaves the stall, mages can't carry otataral, and in battle the ore
	## turns spells away and a shadow-cloak spoils aim.
	var c := Campaign.create("marines", "", 77)
	check(c.rare_stock.size() == int(Campaign.data()["rare_offered"]), "the market opens with rare goods")
	for it in c.rare_stock:
		check(Campaign.is_rare(it) and Campaign.item_cost(it) > 0, "%s is priced" % it)
	var off := ""
	for it in Campaign.data()["rare_goods"]:
		if not c.rare_stock.has(it):
			off = it
	c.gold = 500
	var fu := -1
	var mage := -1
	for f in c.fighters:
		if c.is_caster(f):
			mage = int(f["uid"])
		elif f["role"] != "sword" and fu < 0:
			fu = int(f["uid"])
	check(c.can_buy(fu, off) != "", "goods not in stock can't be bought")
	if mage >= 0:
		c.rare_stock = ["otataral"]
		check(c.can_buy(mage, "otataral").contains("warren"), "a mage won't carry otataral")
	c.rare_stock = ["shadowcloak", "darkforged"]
	(c.fighter(fu)["gear"] as Array).clear()
	check(c.buy(fu, "shadowcloak") == "" and not c.rare_stock.has("shadowcloak"), "a bought cloak leaves the stall")
	check(c.can_buy(fu, "shadowcloak") != "", "the cloak is gone")
	check(c.buy(fu, "darkforged") == "" and (c.fighter(fu)["gear"] as Array).has("darkforged"), "a darkforged blade is bought")
	var d := Campaign.from_dict(JSON.parse_string(JSON.stringify(c.to_dict())))
	check(d.rare_stock == c.rare_stock, "the stock is saved")
	var seen := {}
	for i in range(30):
		c.restock()
		check(c.rare_stock.size() == 2 and c.rare_stock[0] != c.rare_stock[1], "two different pieces each week")
		for it in c.rare_stock:
			seen[it] = true
	check(seen.size() == (Campaign.data()["rare_goods"] as Array).size(), "every rare piece turns up")
	# in battle
	var st := BattleState.new()
	st.setup("hethra_square", "marines", "chained", 4243, true, true, [[], []], "brawl")
	var caster: BUnit = null
	for u in st.units:
		if not u.spells.is_empty() and caster == null:
			caster = u
	check(caster != null, "a caster to test with")
	var tgt: BUnit = st.enemies_of(caster)[0]
	var shooter: BUnit = null
	for u in st.units:
		if u.side == tgt.side or u.missile() == "":
			continue
		shooter = u
	# set the target near the caster, seen by both
	var best := -1
	for nd in st.map.nodes:
		if st.occupied.has(nd):
			continue
		var dd: float = st.map.node_pos(nd).distance_to(st.pos(caster))
		if dd > 6.0 and dd < 10.0 and st.map.visibility(st.eye(caster), st.map.node_pos(nd)) > 0.8:
			best = nd
			break
	check(best >= 0, "a node to stand the target on")
	st._place(tgt, best)
	st.spotted[caster.side][tgt.id] = true
	var any_enemy := ""
	for sp in caster.spells:
		if GameData.spell(sp)["target"] == "enemy" and float(GameData.spell(sp)["range"]) >= 10.0:
			any_enemy = sp
	if any_enemy != "":
		check(st.spell_targets(caster, any_enemy).has(tgt), "the target can be hexed bare")
		tgt.gear.append("otataral")
		check(not st.spell_targets(caster, any_enemy).has(tgt), "otataral turns the spell away")
		tgt.gear.erase("otataral")
	caster.ap = 2
	caster.gear.append("otataral")
	check(not st.can_cast(caster), "a caster holding otataral can't cast")
	caster.gear.erase("otataral")
	if shooter != null:
		st._place(shooter, caster.node)
		shooter.ap = 2
		var bare := st.shot_info(shooter, tgt)
		if bare.has("need"):
			tgt.gear.append("shadowcloak")
			var cl := st.shot_info(shooter, tgt)
			check(int(cl["need"]) == int(bare["need"]) + 1 and (cl["mods"] as Array).has("shadow-cloak"), "a shadow-cloak makes the shot harder")
		else:
			print("cloak shot not tested: ", bare.get("why", ""))
	print("rare goods checked")

func _init() -> void:
	var n := 8
	for a in OS.get_cmdline_user_args():
		if a.is_valid_int():
			n = int(a)
	var t0 := Time.get_ticks_msec()
	_ward_holds()
	_last_night()
	_rivals()
	_new_nights()
	_rare_goods()
	for fi in range(GameData.WARBAND_IDS.size()):
		var fac: String = GameData.WARBAND_IDS[fi]
		var c := Campaign.create(fac, "", 4242 + fi)
		c.id = "test_" + fac
		check(c.fighters.size() > 0, "%s starts with fighters" % fac)
		check(c.leader_fighter() != null, "%s has a leader" % fac)
		print("%s: %s, %d fighters, %d %s, rating %d" % [fac, c.name, c.fighters.size(), c.gold, c.coin_word(), c.rating()])
		for b in range(n):
			if c.fighters.is_empty():
				print("  warband wiped out")
				break
			var lines := c.prepare_battle()
			var enemies: Array = GameData.WARBAND_IDS.filter(func(x): return x != fac)
			var foe: String = enemies[b % enemies.size()]
			var er := c.enemy_roster(foe)
			var mine := c.battle_roster()
			check(not mine.is_empty(), "someone fights")
			var st := BattleState.new()
			var ward: String = GameData.MAP_IDS[(b + fi) % GameData.MAP_IDS.size()]
			var fought0 := int(c.wards.get(ward, {}).get("fought", 0))
			st.setup(ward, fac, foe, 9000 + b * 7 + fi, true, true, [mine, er["entries"]])
			for u in st.side_units(0):
				check(u.uid > 0, "campaign fighter %s keeps its uid" % u.name)
				var f := c.fighter(u.uid)
				check(u.base["WS"] == f["stats"]["WS"], "%s brings their stat line" % u.name)
			_play(st)
			var res := Campaign.result_from_battle(st, 0, foe, er["rating"])
			var gold0 := c.gold
			var rep := c.apply_result(res)
			check(int(c.wards.get(ward, {}).get("fought", 0)) == fought0 + 1, "the ward %s records the fight" % ward)
			check(c.leader_fighter() != null or c.fighters.is_empty(), "still has a leader")
			# the night after: take a random choice the band can afford
			var night := ""
			if not c.pending_event.is_empty():
				var ev := Campaign.event_def(c.pending_event["id"])
				check(not ev.is_empty(), "the night's event exists")
				var opts: Array = []
				for i in range((ev["choices"] as Array).size()):
					if c.event_choice_problem(i) == "":
						opts.append(i)
				check(not opts.is_empty(), "%s has a choice the band can take" % ev["id"])
				if not opts.is_empty():
					var n0 := c.fighters.size()
					var out := c.resolve_event(opts[c.rng.randi_range(0, opts.size() - 1)])
					check(not out.is_empty(), "the night resolves")
					check(c.pending_event.is_empty(), "the night is settled")
					check(c.gold >= 0 and c.shards >= 0, "the night leaves no debt")
					check(c.fighters.size() <= int(c.warband()["max_size"]), "a recruit keeps the limit")
					check(not String(out.get("text", "")).contains("{"), "night text filled in: %s" % out.get("text", ""))
					night = "  night: %s -> %s %s" % [ev["id"], out["choice"], str(out["lines"])]
					check(c.fighters.size() >= n0, "the night kills nobody")
			# choose advances, as the player would
			var pend := c.pending_count()
			c.auto_choose_all()
			check(c.pending_count() == 0, "advances settled")
			for f in c.fighters:
				for k in f["stats"]:
					check(int(f["stats"][k]) >= 1 and int(f["stats"][k]) <= int(c.caps()[k]), "%s %s in range" % [f["name"], k])
			# sell most shards, keep one
			var sold := c.sell_shards(maxi(0, c.shards - 1))
			# the market: try to buy each armoury item for a random fighter
			var bought := 0
			for item in c.armoury():
				var f: Dictionary = c.fighters[c.rng.randi_range(0, c.fighters.size() - 1)]
				var g0 := c.gold
				var why := c.buy(int(f["uid"]), item)
				if why == "":
					bought += 1
					check(c.gold == g0 - Campaign.item_cost(item), "buying %s costs its price" % item)
				else:
					check(c.gold == g0, "a refused buy costs nothing")
			# hire whoever we can afford
			var hired := 0
			for k in c.warband()["units"]:
				if c.can_hire(k) == "":
					c.hire(k)
					hired += 1
			check(c.fighters.size() <= int(c.warband()["max_size"]), "within the warband limit")
			check(c.hero_count() <= int(Campaign.data()["max_heroes"]), "hero limit kept")
			check(c.gold >= 0, "never in debt")
			# save and load
			c.save()
			var back := Campaign.load_file(c.id)
			check(back != null, "save loads")
			if back != null:
				for wk in c.wards:
					check(back.wards.has(wk) and int(back.wards[wk]["fought"]) == int(c.wards[wk]["fought"]) and int(back.wards[wk]["won"]) == int(c.wards[wk]["won"]), "the map of fights survives a save (%s)" % wk)
			if back != null:
				check(back.fighters.size() == c.fighters.size(), "fighters survive the save")
				check(back.gold == c.gold and back.shards == c.shards, "purse survives the save")
				check(back.rating() == c.rating(), "rating survives the save")
				check(back.rng.state == c.rng.state, "dice state survives the save")
				c = back
			print("  battle %d vs %s: %s (%s). injuries %d, fallen %s, xp gains %d, advances %d, shards +%d, shards sold for %d, bought %d, hired %d -> %d fighters, %d %s, rating %d (foe %d)%s" % [
				b + 1, foe, "won" if rep["won"] else ("draw" if rep["draw"] else "lost"), res["reason"], rep["injuries"].size(),
				str(rep["fallen"]), rep["xp"].size(), pend, rep["shards_found"], sold, bought, hired, c.fighters.size(), c.gold, c.coin_word(), c.rating(), er["rating"],
				("  [" + "; ".join(lines) + "]") if not lines.is_empty() else ""])
			if night != "":
				print(night)
		Campaign.delete_save(c.id)
	print("campaign test %d ms" % (Time.get_ticks_msec() - t0))
	print("FAILURES: %d" % failures)
	quit(1 if failures > 0 else 0)

func _play(st: BattleState) -> void:
	var ais := [WarbandAI.new(st, 0), WarbandAI.new(st, 1)]
	st.begin()
	var guard := 0
	while not st.over and guard < 4000:
		guard += 1
		var ai: WarbandAI = ais[st.side]
		var act := ai.next_action()
		var res := ai.execute(act)
		if act["type"] != "end" and not res.get("ok", false):
			act["unit"].ai_done = true
	check(st.over, "battle finished")
