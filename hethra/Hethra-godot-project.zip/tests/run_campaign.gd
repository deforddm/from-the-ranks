extends SceneTree
## Headless campaign test: each warband plays a run of AI battles with the
## full campaign between them (injuries, experience, advances, loot, market,
## hiring, saving and loading), checking the books stay straight.
## godot --headless --path . --script res://tests/run_campaign.gd -- [battles]

var failures := 0

func check(cond: bool, msg: String) -> void:
	if not cond:
		failures += 1
		printerr("FAIL: ", msg)

func _init() -> void:
	var n := 8
	for a in OS.get_cmdline_user_args():
		if a.is_valid_int():
			n = int(a)
	var t0 := Time.get_ticks_msec()
	for fi in range(GameData.WARBAND_IDS.size()):
		var fac: String = GameData.WARBAND_IDS[fi]
		var c := Campaign.create(fac, "", 4242 + fi)
		c.id = "test_" + fac
		check(c.fighters.size() > 0, "%s starts with fighters" % fac)
		check(c.leader_fighter() != null, "%s has a leader" % fac)
		print("%s: %s, %d fighters, %d %s, rating %d" % [fac, c.name, c.fighters.size(), c.gold, c.coin_word(), c.rating()])
		for b in range(n):
			if c.fighters.is_empty():
				print("  warband wiped out")
				break
			var lines := c.prepare_battle()
			var enemies: Array = GameData.WARBAND_IDS.filter(func(x): return x != fac)
			var foe: String = enemies[b % enemies.size()]
			var er := c.enemy_roster(foe)
			var mine := c.battle_roster()
			check(not mine.is_empty(), "someone fights")
			var st := BattleState.new()
			st.setup("hethra_square", fac, foe, 9000 + b * 7 + fi, true, true, [mine, er["entries"]])
			for u in st.side_units(0):
				check(u.uid > 0, "campaign fighter %s keeps its uid" % u.name)
				var f := c.fighter(u.uid)
				check(u.base["WS"] == f["stats"]["WS"], "%s brings their stat line" % u.name)
			_play(st)
			var res := Campaign.result_from_battle(st, 0, foe, er["rating"])
			var gold0 := c.gold
			var rep := c.apply_result(res)
			check(c.leader_fighter() != null or c.fighters.is_empty(), "still has a leader")
			# the night after: take a random choice the band can afford
			var night := ""
			if not c.pending_event.is_empty():
				var ev := Campaign.event_def(c.pending_event["id"])
				check(not ev.is_empty(), "the night's event exists")
				var opts: Array = []
				for i in range((ev["choices"] as Array).size()):
					if c.event_choice_problem(i) == "":
						opts.append(i)
				check(not opts.is_empty(), "%s has a choice the band can take" % ev["id"])
				if not opts.is_empty():
					var n0 := c.fighters.size()
					var out := c.resolve_event(opts[c.rng.randi_range(0, opts.size() - 1)])
					check(not out.is_empty(), "the night resolves")
					check(c.pending_event.is_empty(), "the night is settled")
					check(c.gold >= 0 and c.shards >= 0, "the night leaves no debt")
					check(c.fighters.size() <= int(c.warband()["max_size"]), "a recruit keeps the limit")
					check(not String(out.get("text", "")).contains("{"), "night text filled in: %s" % out.get("text", ""))
					night = "  night: %s -> %s %s" % [ev["id"], out["choice"], str(out["lines"])]
					check(c.fighters.size() >= n0, "the night kills nobody")
			# choose advances, as the player would
			var pend := c.pending_count()
			c.auto_choose_all()
			check(c.pending_count() == 0, "advances settled")
			for f in c.fighters:
				for k in f["stats"]:
					check(int(f["stats"][k]) >= 1 and int(f["stats"][k]) <= int(c.caps()[k]), "%s %s in range" % [f["name"], k])
			# sell most shards, keep one
			var sold := c.sell_shards(maxi(0, c.shards - 1))
			# the market: try to buy each armoury item for a random fighter
			var bought := 0
			for item in c.armoury():
				var f: Dictionary = c.fighters[c.rng.randi_range(0, c.fighters.size() - 1)]
				var g0 := c.gold
				var why := c.buy(int(f["uid"]), item)
				if why == "":
					bought += 1
					check(c.gold == g0 - Campaign.item_cost(item), "buying %s costs its price" % item)
				else:
					check(c.gold == g0, "a refused buy costs nothing")
			# hire whoever we can afford
			var hired := 0
			for k in c.warband()["units"]:
				if c.can_hire(k) == "":
					c.hire(k)
					hired += 1
			check(c.fighters.size() <= int(c.warband()["max_size"]), "within the warband limit")
			check(c.hero_count() <= int(Campaign.data()["max_heroes"]), "hero limit kept")
			check(c.gold >= 0, "never in debt")
			# save and load
			c.save()
			var back := Campaign.load_file(c.id)
			check(back != null, "save loads")
			if back != null:
				check(back.fighters.size() == c.fighters.size(), "fighters survive the save")
				check(back.gold == c.gold and back.shards == c.shards, "purse survives the save")
				check(back.rating() == c.rating(), "rating survives the save")
				check(back.rng.state == c.rng.state, "dice state survives the save")
				c = back
			print("  battle %d vs %s: %s (%s). injuries %d, fallen %s, xp gains %d, advances %d, shards +%d, shards sold for %d, bought %d, hired %d -> %d fighters, %d %s, rating %d (foe %d)%s" % [
				b + 1, foe, "won" if rep["won"] else ("draw" if rep["draw"] else "lost"), res["reason"], rep["injuries"].size(),
				str(rep["fallen"]), rep["xp"].size(), pend, rep["shards_found"], sold, bought, hired, c.fighters.size(), c.gold, c.coin_word(), c.rating(), er["rating"],
				("  [" + "; ".join(lines) + "]") if not lines.is_empty() else ""])
			if night != "":
				print(night)
		Campaign.delete_save(c.id)
	print("campaign test %d ms" % (Time.get_ticks_msec() - t0))
	print("FAILURES: %d" % failures)
	quit(1 if failures > 0 else 0)

func _play(st: BattleState) -> void:
	var ais := [WarbandAI.new(st, 0), WarbandAI.new(st, 1)]
	st.begin()
	var guard := 0
	while not st.over and guard < 4000:
		guard += 1
		var ai: WarbandAI = ais[st.side]
		var act := ai.next_action()
		var res := ai.execute(act)
		if act["type"] != "end" and not res.get("ok", false):
			act["unit"].ai_done = true
	check(st.over, "battle finished")
