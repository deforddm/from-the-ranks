extends SceneTree
## Renders a battlefield with no fighters from a few cameras, to check its look.
## xvfb-run godot --path . --script res://tests/mapview.gd -- OUT_DIR map_id

var out := "user://mapview"
var mid := "drowned"
var cams: Array = []

func _init() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size() > 0:
		out = args[0]
	if args.size() > 1:
		mid = args[1]
	DirAccess.make_dir_recursive_absolute(out)
	root.size = Vector2i(1600, 900)
	var map := BattleMap.new()
	map.load_map(mid)
	var world := Node3D.new()
	root.add_child(world)
	var centre := Vector3(map.w * map.cell * 0.5, 0, map.d * map.cell * 0.5)
	var atm := Atmosphere.new()
	world.add_child(atm)
	atm.build(centre, {"graphics_high": true})
	var city := CityBuilder.new()
	world.add_child(city)
	var shards := {}
	for s in map.data["shards"]:
		var nd := BattleMap.nid(int(s[0]), int(s[1]), int(s[2]))
		shards[nd] = true
	city.build(map, shards)
	var cam := Camera3D.new()
	cam.fov = 50
	world.add_child(cam)
	cam.current = true
	cams = [
		[centre + Vector3(-14, 16, 30), centre + Vector3(0, 0, 0)],
		[centre + Vector3(-9, 4.5, 14), centre + Vector3(-2, 1.5, 0)],
		[centre + Vector3(9, 6.5, 7), centre + Vector3(0, 3.5, -1)],
	]
	if mid == "azath":
		cams[2] = [centre + Vector3(7, 5.0, 14.5), centre + Vector3(-1, 5.0, 6)]
	_shoot.call_deferred(cam)

func _shoot(cam: Camera3D) -> void:
	for i in range(cams.size()):
		var p: Vector3 = cams[i][0]
		var t: Vector3 = cams[i][1]
		cam.transform = Transform3D(Basis.looking_at(t - p), p)
		for k in range(12):
			await process_frame
		root.get_viewport().get_texture().get_image().save_png(out.path_join("view_%d.png" % i))
		print("saved view ", i)
	quit()
