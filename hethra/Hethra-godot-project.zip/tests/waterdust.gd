extends SceneTree
## Look-dev for 0.14: a fighter wading through flood water with rings on the
## surface and a splash, and one of the Kin of the Dust crumbling as it falls.
## xvfb-run godot --path . --script res://tests/waterdust.gd -- OUT_DIR

var out := "user://waterdust"
var world: Node3D
var cam: Camera3D

func _init() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size() > 0:
		out = args[0]
	DirAccess.make_dir_recursive_absolute(out)
	root.size = Vector2i(1600, 900)
	_shoot.call_deferred()

func _stage(water: bool) -> void:
	if world != null:
		world.queue_free()
	world = Node3D.new()
	root.add_child(world)
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.035, 0.03, 0.035)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.45, 0.47, 0.55)
	env.ambient_light_energy = 0.4
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.09, 0.08, 0.08)
	env.fog_density = 0.06
	env.glow_enabled = true
	env.ssao_enabled = true
	we.environment = env
	world.add_child(we)
	var moon := DirectionalLight3D.new()
	moon.rotation = Vector3(-0.7, 2.4, 0)
	moon.light_color = Color(0.62, 0.7, 0.95)
	moon.light_energy = 0.7
	moon.shadow_enabled = true
	world.add_child(moon)
	var fire := OmniLight3D.new()
	fire.position = Vector3(-2.2, 1.6, 1.2)
	fire.light_color = Color(1.0, 0.58, 0.28)
	fire.light_energy = 5.0
	fire.omni_range = 10.0
	fire.shadow_enabled = true
	world.add_child(fire)
	var floor_m := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(40, 40)
	floor_m.mesh = pm
	floor_m.material_override = Mats.cobbles()
	world.add_child(floor_m)
	var wall := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(14, 3.4, 0.6)
	wall.mesh = bm
	wall.material_override = Mats.darkstone()
	wall.position = Vector3(0, 1.7, -4.5)
	world.add_child(wall)
	Figure.water_y = -100.0
	if water:
		Figure.water_y = 0.55
		var wm := MeshInstance3D.new()
		var wp := PlaneMesh.new()
		wp.size = Vector2(40, 40)
		wm.mesh = wp
		var sm := ShaderMaterial.new()
		sm.shader = load("res://shaders/water.gdshader")
		wm.material_override = sm
		wm.position.y = 0.55
		world.add_child(wm)
	cam = Camera3D.new()
	cam.fov = 40
	world.add_child(cam)
	cam.current = true

func _fig(wid: String, unit: String, uid: int, pos: Vector3, yaw: float) -> Figure:
	var wb := GameData.warband(wid)
	var u := BUnit.new()
	u.id = uid
	u.setup_from(wb["units"][unit], wb, {"unit": unit})
	var f := Figure.new()
	world.add_child(f)
	f.setup(u, wb)
	f.label.visible = false
	f.ring.visible = false
	f.team_ring.visible = false
	f.position = pos
	f.rotation.y = yaw
	return f

func _wait(sec: float) -> void:
	await create_timer(sec).timeout

func _shoot() -> void:
	# ---- the wading shot
	if OS.get_cmdline_user_args().has("dust"):
		await _dust_shot()
		quit()
		return
	_stage(true)
	cam.transform = Transform3D(Basis.looking_at(Vector3(0, 0.8, -0.4) - Vector3(2.4, 2.2, 4.2)), Vector3(2.4, 2.2, 4.2))
	var a := _fig("marines", "sergeant", 3, Vector3(-1.4, 0, 0.6), 1.2)
	var b := _fig("seguleh", "blade", 10, Vector3(1.2, 0, -1.0), -0.9)
	var c := _fig("marines", "marine", 17, Vector3(-0.3, 0, -1.8), 0.4)
	a.moving = true
	b.moving = true
	var tw := a.create_tween()
	tw.tween_property(a, "position", Vector3(0.6, 0, 0.9), 2.4)
	var tw2 := b.create_tween()
	tw2.tween_property(b, "position", Vector3(0.1, 0, -0.4), 2.4)
	await _wait(1.6)
	# someone drops off a ledge into it
	var at := Vector3(1.6, 0.565, 0.6)
	_plunge(at)
	await _wait(0.22)
	var img := root.get_viewport().get_texture().get_image()
	img.save_png(out.path_join("wading.png"))
	print("saved wading")
	await _dust_shot()
	quit()

func _dust_shot() -> void:
	_stage(false)
	cam.transform = Transform3D(Basis.looking_at(Vector3(0, 0.75, 0) - Vector3(1.9, 1.6, 3.6)), Vector3(1.9, 1.6, 3.6))
	var dead := _fig("imass", "warrior", 24, Vector3(-0.2, 0, 0), 0.5)
	var killer := _fig("barghast", "warrior", 31, Vector3(1.0, 0, -0.9), -2.4)
	var other := _fig("imass", "chief", 38, Vector3(-1.4, 0, -1.2), 0.8)
	await _wait(0.5)
	dead.set_status("ooa")
	await _wait(0.95)
	var img := root.get_viewport().get_texture().get_image()
	img.save_png(out.path_join("crumble_mid.png"))
	await _wait(2.0)
	img = root.get_viewport().get_texture().get_image()
	img.save_png(out.path_join("crumble_end.png"))
	print("saved crumble")

func _plunge(at: Vector3) -> void:
	Figure.spawn_ripple(world, at, 2.6, 1.6)
	var g := GPUParticles3D.new()
	g.one_shot = true
	g.amount = 60
	g.lifetime = 0.9
	g.explosiveness = 0.92
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_RING
	pm.emission_ring_axis = Vector3.UP
	pm.emission_ring_radius = 0.3
	pm.emission_ring_inner_radius = 0.1
	pm.emission_ring_height = 0.02
	pm.direction = Vector3(0, 1, 0)
	pm.spread = 28.0
	pm.initial_velocity_min = 2.0
	pm.initial_velocity_max = 4.2
	pm.gravity = Vector3(0, -12.0, 0)
	pm.scale_min = 0.4
	pm.scale_max = 1.0
	var grad := Gradient.new()
	grad.set_color(0, Color(0.62, 0.68, 0.72, 0.55))
	grad.set_color(grad.get_point_count() - 1, Color(0.5, 0.56, 0.6, 0.0))
	var gt := GradientTexture1D.new()
	gt.gradient = grad
	pm.color_ramp = gt
	g.process_material = pm
	var q := QuadMesh.new()
	q.size = Vector2(0.08, 0.08)
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.vertex_color_use_as_albedo = true
	m.albedo_texture = CityBuilder._soft_dot()
	q.material = m
	g.draw_pass_1 = q
	world.add_child(g)
	g.position = at
	g.emitting = true
