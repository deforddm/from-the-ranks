class_name BattleState
extends RefCounted
## The whole battle as pure data and rules. The 3D view and the AI both drive
## it through the action functions below; the view reads `events` to animate.

signal changed

var map: BattleMap
var dice: Dice
var rules: Dictionary
var units: Array = []
var sides: Array = []          # [{"wb": Dictionary, "ai": bool, "start": int, "routed": bool}]
var side: int = 0
var first_side: int = 0
var round_num: int = 1
var turn_index: int = 0
var over := false
var winner: int = -1           # -1 none yet, -2 draw
var end_reason := ""
var log_lines: Array = []
var events: Array = []         # consumed by the view
var shard_nodes: Dictionary = {}   # node id -> true
var spotted: Array = [{}, {}]      # side -> {unit id: true}
var last_seen: Array = [{}, {}]    # side -> {unit id: node id}
var occupied: Dictionary = {}      # node id -> unit
var mpm: float = 2.5
var turn_limit: int = 12
var scenario_id := "shards"
var map_id := ""
var scenario: Dictionary = {}
var objective := Vector3.ZERO      # centre of the ring in "hold"
var hold_radius := 0.0
var through_need := 0               # "breakthrough": fighters needed on the enemy's ground
var zones: Array = [{}, {}]         # node id -> true: each side's starting ground
# "cache": a strongbox buried at one of a few marked spots
var cache_spots: Dictionary = {}    # node id -> true: spots not yet searched
var cache_dug: Dictionary = {}      # node id -> true: spots searched and found empty
var cache_holder := -1              # unit id carrying the box, or -1
var cache_node := -1                # node where the box lies in the open, or -1
# the night's weather: "still", "rain" or "fog" (see set_weather)
var weather := "still"
# shardfall: now and then a burning godshard comes down out of the sky. It is
# seen a round ahead (the ground beneath it glows), then strikes at the start
# of the next round, hurting anyone close, and leaves a godshard behind.
var omen_node := -1
var shardfalls := 0
var force_shardfall := false        # screenshots: make sure one comes
const FALL_RADIUS := 1.6            # in cells, around the strike
const FALL_MAX := 2
const WEATHERS := {
	"still": {"name": "A still night", "short": "Still", "line": "The night is still."},
	"rain": {"name": "Driving rain", "short": "Rain", "line": "Rain drives across the ruins: shots are harder, sight is shorter, and wet stone makes jumps and drops treacherous."},
	"fog": {"name": "Thick fog", "short": "Fog", "line": "Thick fog has rolled in: nobody can see much past 14 m."},
}

# ---------------------------------------------------------------- setup

func setup(map_id: String, wb0: String, wb1: String, seed_value: int, ai0: bool, ai1: bool, rosters: Array = [[], []], scenario_name := "shards") -> void:
	rules = GameData.rules()
	scenario_id = scenario_name if GameData.SCENARIO_IDS.has(scenario_name) else "shards"
	scenario = GameData.scenario(scenario_id)
	mpm = float(rules["metres_per_move"])
	turn_limit = int(rules["turn_limit"])
	dice = Dice.new(seed_value)
	map = BattleMap.new()
	self.map_id = map_id
	map.load_map(map_id)
	units.clear()
	sides.clear()
	var ids := [wb0, wb1]
	var ais := [ai0, ai1]
	var next_id := 1
	for s in range(2):
		var wb := GameData.warband(ids[s])
		sides.append({"wb": wb, "ai": ais[s], "start": 0, "routed": false})
		var roster: Array = rosters[s] if s < rosters.size() and not (rosters[s] as Array).is_empty() else wb["battle_roster"]
		for entry in roster:
			var def: Dictionary = wb["units"][entry["unit"]]
			var u := BUnit.new()
			u.id = next_id
			next_id += 1
			u.side = s
			u.setup_from(def, wb, entry)
			units.append(u)
		sides[s]["start"] = units.filter(func(x): return x.side == s).size()
	if scenario.get("shards", true):
		for sh in map.data["shards"]:
			var id := BattleMap.nid(int(sh[0]), int(sh[1]), int(sh[2]))
			if map.nodes.has(id):
				shard_nodes[id] = true
	var ob: Array = map.data.get("objective", [map.w / 2 - 1, map.d / 2 - 1])
	objective = Vector3((float(ob[0]) + 1.0) * map.cell, 0.0, (float(ob[1]) + 1.0) * map.cell)
	hold_radius = float(scenario.get("hold_radius", 0.0))
	through_need = int(scenario.get("breakthrough", 0))
	for s in range(2):
		var rows := {}
		for c in map.data["deploy"][str(s)]:
			rows[int(c[1])] = true
		zones[s] = {}
		for id in map.nodes:
			if rows.has(int(map.nodes[id]["z"])):
				zones[s][id] = true
	if scenario.get("cache", false):
		_place_cache_spots()
	_deploy()

func set_weather(w: String, seed_value: int) -> void:
	## "random" rolls it (a still night half the time, rain or fog otherwise).
	## Kept off the battle's own dice so the same seed plays the same battle.
	if WEATHERS.has(w):
		weather = w
		return
	var r := RandomNumberGenerator.new()
	r.seed = seed_value * 7919 + 101
	var x := r.randi_range(1, 10)
	weather = "still" if x <= 5 else ("rain" if x <= 8 else "fog")

func spot_range() -> float:
	match weather:
		"rain":
			return float(rules["spot_range"]) * 0.75
		"fog":
			return 14.0
	return float(rules["spot_range"])

func _place_cache_spots() -> void:
	## Pick the marked spots fairly: those about as far from one band's
	## starting ground as from the other's.
	var d0 := map.distance_map_to(zones[0].keys())
	var d1 := map.distance_map_to(zones[1].keys())
	var cands: Array = []
	for sh in map.data["shards"]:
		var id := BattleMap.nid(int(sh[0]), int(sh[1]), int(sh[2]))
		if map.nodes.has(id) and d0.has(id) and d1.has(id) and not zones[0].has(id) and not zones[1].has(id):
			# never one that sits on a band's doorstep
			if absf(d0[id] - d1[id]) <= 0.4 * (d0[id] + d1[id]):
				cands.append(id)
	dice.shuffle(cands)
	cands.sort_custom(func(a, b): return absf(d0[a] - d1[a]) < absf(d0[b] - d1[b]))
	for i in range(mini(int(scenario.get("cache_spots", 4)), cands.size())):
		cache_spots[cands[i]] = true

func cache_holder_unit() -> BUnit:
	return unit_by_id(cache_holder) if cache_holder >= 0 else null

func cache_side() -> int:
	var h := cache_holder_unit()
	return h.side if h != null else -1

func _deploy() -> void:
	for s in range(2):
		var cells: Array = map.data["deploy"][str(s)].duplicate()
		dice.shuffle(cells)
		# leaders and heroes nearer the middle of the zone
		var mine: Array = units.filter(func(u): return u.side == s)
		var idx := 0
		for u in mine:
			while idx < cells.size():
				var c: Array = cells[idx]
				idx += 1
				var nd := map.top_node(int(c[0]), int(c[1]))
				if nd >= 0 and not occupied.has(nd):
					_place(u, nd)
					break

func _place(u: BUnit, nd: int) -> void:
	if u.node >= 0 and occupied.get(u.node) == u:
		occupied.erase(u.node)
	u.node = nd
	occupied[nd] = u

func begin() -> void:
	first_side = 0 if dice.d6() >= dice.d6() else 1
	side = first_side
	round_num = 1
	turn_index = 0
	log_add("[b]%s: %s.[/b] %s. %s move first." % [map.data.get("name", "The ruins"), scenario["name"], scenario["short"], sides[first_side]["wb"]["name"]])
	if weather != "still":
		log_add("[color=#9fb8d8]%s[/color]" % WEATHERS[weather]["line"])
	_start_side_turn()

# ---------------------------------------------------------------- shardfall

func in_fall_zone(nd: int) -> bool:
	## Whether a node lies where next round's shard will strike.
	if omen_node < 0 or not map.nodes.has(nd):
		return false
	return _near_fall(map.node_pos(nd), map.node_pos(omen_node))

func _near_fall(p: Vector3, c: Vector3) -> bool:
	return abs(p.y - c.y) < 2.6 and Vector2(p.x, p.z).distance_to(Vector2(c.x, c.z)) <= FALL_RADIUS * map.cell

func _round_omens() -> void:
	if omen_node >= 0:
		var nd := omen_node
		omen_node = -1
		_shardfall(nd)
		if over:
			return
	if round_num < 2 or round_num >= turn_limit or shardfalls >= FALL_MAX or scenario.get("no_shardfall", false):
		return
	var r := dice.d6()
	if r < 6 and not (force_shardfall and shardfalls == 0):
		return
	var nd := _pick_fall_node()
	if nd < 0:
		return
	omen_node = nd
	shardfalls += 1
	log_add("[color=#ff9a50]A burning shard streaks across the sky over Hethra. Where the ground glows, it comes down next round.[/color]")
	events.append({"type": "omen", "node": nd})

func _pick_fall_node() -> int:
	## Somewhere in the open middle of the field, near the fighting if it can be.
	var best := -1
	var best_d := INF
	var tries := 0
	var found := 0
	while tries < 60 and found < 6:
		tries += 1
		var x := dice.rng.randi_range(int(map.w * 0.2), int(map.w * 0.8))
		var z := dice.rng.randi_range(int(map.d * 0.2), int(map.d * 0.8))
		var nd := map.top_node(x, z)
		if nd < 0 or shard_nodes.has(nd) or zones[0].has(nd) or zones[1].has(nd) or cache_spots.has(nd) or nd == cache_node:
			continue
		found += 1
		var p := map.node_pos(nd)
		var dmin := 99.0
		for u in units:
			if u.standing():
				dmin = minf(dmin, p.distance_to(pos(u)))
		# close to fighters makes a better story, but not dead on top of one
		var score := absf(dmin - 2.5 * map.cell) + dice.randf() * map.cell
		if score < best_d:
			best_d = score
			best = nd
	return best

func _shardfall(nd: int) -> void:
	var centre := map.node_pos(nd)
	log_add("[color=#ff7a40][b]Shardfall![/b] The godshard strikes the street in a burst of fire.[/color]")
	events.append({"type": "shardfall", "node": nd})
	var victims: Array = []
	for o in units:
		if not o.alive() or o.status == "ooa":
			continue
		if o.node == nd:
			victims.append([o, 5])
		elif _near_fall(pos(o), centre):
			victims.append([o, 3])
	if victims.is_empty():
		log_add("No one is caught beneath it.")
	for v in victims:
		var o: BUnit = v[0]
		if o.alive():
			_wound_roll(null, o, v[1], 0, false, false, "burning shard", "The burning shard")
	var drop_at := nd
	if occupied.has(drop_at) or shard_nodes.has(drop_at):
		drop_at = -1
		for a in map.adjacent.get(nd, []):
			if not occupied.has(a) and not shard_nodes.has(a):
				drop_at = a
				break
	if drop_at >= 0:
		shard_nodes[drop_at] = true
		log_add("[color=#5fe0c0]A godshard lies smoking in the crater.[/color]")
		events.append({"type": "drop", "node": drop_at})
	check_wipe()

# ---------------------------------------------------------------- helpers

func _roll_ev(unit_id: int, label: String, value: int, need: int, ok: bool, sides_n := 6) -> void:
	## A die result for the dice tray (the view shows it beside the fighter).
	events.append({"type": "roll", "unit": unit_id, "label": label, "value": value, "need": need, "ok": ok, "d": sides_n})

func log_add(t: String) -> void:
	log_lines.append(t)
	events.append({"type": "log", "text": t})

func unit_by_id(id: int) -> BUnit:
	for u in units:
		if u.id == id:
			return u
	return null

func side_units(s: int) -> Array:
	return units.filter(func(u): return u.side == s)

func enemies_of(u: BUnit) -> Array:
	return units.filter(func(o): return o.side != u.side and o.alive())

func pos(u: BUnit) -> Vector3:
	return map.node_pos(u.node)

func eye(u: BUnit) -> Vector3:
	return map.node_pos(u.node) + u.eye_offset()

func dist(a: BUnit, b: BUnit) -> float:
	return pos(a).distance_to(pos(b))

func is_adjacent(a: BUnit, b: BUnit) -> bool:
	return map.adjacent.get(a.node, []).has(b.node)

func adjacent_enemies(u: BUnit, standing_only := false) -> Array:
	var out: Array = []
	for nd in map.adjacent.get(u.node, []):
		var o = occupied.get(nd)
		if o != null and o.side != u.side and o.alive():
			if standing_only and not o.standing():
				continue
			out.append(o)
	return out

func engaged(u: BUnit) -> bool:
	return not adjacent_enemies(u, true).is_empty()

func known(viewer_side: int, o: BUnit) -> bool:
	return spotted[viewer_side].has(o.id)

func ooa_count(s: int) -> int:
	return units.filter(func(u): return u.side == s and u.status == "ooa").size()

func shards_held(s: int) -> int:
	var t := 0
	for u in units:
		if u.side == s and u.alive():
			t += u.carrying
	return t

func can_act(u: BUnit) -> bool:
	return not over and u.side == side and u.standing()

# ---------------------------------------------------------------- turn flow

func _start_side_turn() -> void:
	turn_index += 1
	for u in units:
		u.fx = u.fx.filter(func(f): return int(f["expire"]) > turn_index)
	var wb_name: String = sides[side]["wb"]["name"]
	log_add("[color=#c9b98a]— Turn %d: %s —[/color]" % [round_num, wb_name])
	for u in side_units(side):
		u.moved = false
		u.charged = false
		u.shot = false
		u.cast = false
		u.dashed = false
		u.rose = false
		u.ai_done = false
		u.ai_steps = 0
		u.mp_full = u.stat("M") * mpm
		u.mp = u.mp_full
		u.ap = int(rules["action_points"])
		match u.status:
			"down":
				u.status = "ok"
				u.rose = true
				u.mp = u.mp_full * 0.5
				log_add("%s gets back up." % u.name)
				events.append({"type": "status", "unit": u.id})
			"stunned":
				u.status = "down"
				u.mp = 0
				u.ap = 0
				log_add("%s comes round, still on the ground." % u.name)
				events.append({"type": "status", "unit": u.id})
			"ooa":
				u.mp = 0
				u.ap = 0
		if u.status == "ok" and u.has_fx("bound"):
			var r := dice.d6()
			if r <= u.stat("S"):
				log_add("%s tears free of the chains (%d)." % [u.name, r])
			else:
				u.mp = 0
				log_add("%s is held fast by phantom chains (%d)." % [u.name, r])
	if side == first_side:
		_round_omens()
		if over:
			changed.emit()
			return
	refresh_spotting()
	_rout_test()
	changed.emit()

func _rout_test() -> void:
	if over:
		return
	var s := side
	var lost := ooa_count(s)
	var start: int = sides[s]["start"]
	if lost < int(ceil(start * float(rules["rout_fraction"]))):
		return
	var greed := cache_holder_unit()
	if greed != null and greed.side == s and greed.standing():
		log_add("%s hold together: %s has the strongbox, and nobody runs from that." % [sides[s]["wb"]["name"], greed.name])
		return
	var tester: BUnit = null
	for u in side_units(s):
		if u.is_leader() and u.status != "ooa":
			tester = u
	if tester == null:
		for u in side_units(s):
			if u.standing() and (tester == null or u.stat("Ld") > tester.stat("Ld")):
				tester = u
	if tester == null:
		_set_winner(1 - s, "%s have no one left standing." % sides[s]["wb"]["name"])
		return
	var ld := tester.stat("Ld")
	var r := dice.roll2d6()
	if r > ld and tester.is_leader() and tester.has_skill("nerve"):
		log_add("%s refuses to break (re-roll)." % tester.name)
		r = dice.roll2d6()
	_roll_ev(tester.id, "Rout (2d6)", r, ld, r <= ld, 12)
	if r > ld:
		log_add("[color=#e06a50]Rout test: %s rolls %d against Leadership %d. The warband breaks![/color]" % [tester.name, r, ld])
		sides[s]["routed"] = true
		_set_winner(1 - s, "%s fled." % sides[s]["wb"]["name"])
	else:
		log_add("Rout test: %s rolls %d against Leadership %d and holds them together." % [tester.name, r, ld])

func end_turn() -> void:
	if over:
		return
	side = 1 - side
	if side == first_side:
		if through_need > 0:
			var ta := through(0)
			var tb := through(1)
			if maxi(ta, tb) >= through_need and ta != tb:
				var w := 0 if ta > tb else 1
				_set_winner(w, "%s are through the enemy's lines." % sides[w]["wb"]["name"])
				return
		round_num += 1
		if round_num > turn_limit:
			_end_by_limit()
			return
	_start_side_turn()

func voluntary_rout(s: int) -> void:
	if over:
		return
	sides[s]["routed"] = true
	log_add("%s fall back and give up the fight." % sides[s]["wb"]["name"])
	_set_winner(1 - s, "%s withdrew." % sides[s]["wb"]["name"])

func in_ring(u: BUnit) -> bool:
	if hold_radius <= 0.0 or not u.standing():
		return false
	var p := pos(u)
	return Vector2(p.x, p.z).distance_to(Vector2(objective.x, objective.z)) <= hold_radius

func through(s: int) -> int:
	## Fighters of side s standing on the enemy's starting ground.
	return units.filter(func(u): return u.side == s and u.standing() and zones[1 - s].has(u.node)).size()

func holding(s: int) -> int:
	return units.filter(func(u): return u.side == s and in_ring(u)).size()

func score_line(names: Array) -> String:
	## One line for the banner: what decides the battle when night falls.
	match scenario_id:
		"hold":
			return "In the ring:  %s %d   ·   %s %d" % [names[0], holding(0), names[1], holding(1)]
		"breakthrough":
			return "Through their lines (%d wins):  %s %d   ·   %s %d" % [through_need, names[0], through(0), names[1], through(1)]
		"headhunt":
			var la := leader_of(0)
			var lb := leader_of(1)
			var fa: String = "standing" if la != null and la.alive() else "fallen"
			var fb: String = "standing" if lb != null and lb.alive() else "fallen"
			return "Leaders:  %s %s   ·   %s %s" % [names[0], fa, names[1], fb]
		"cache":
			var h := cache_holder_unit()
			if h != null:
				return "The strongbox:  carried by %s (%s)" % [h.name, names[h.side]]
			if cache_node >= 0:
				return "The strongbox:  lying in the open"
			return "The strongbox:  buried in one of %d spots" % cache_spots.size()
		"brawl":
			var a := units.filter(func(u): return u.side == 0 and u.alive()).size()
			var b := units.filter(func(u): return u.side == 1 and u.alive()).size()
			return "Still in the fight:  %s %d   ·   %s %d" % [names[0], a, names[1], b]
	return "Godshards held:  %s %d   ·   %s %d" % [names[0], shards_held(0), names[1], shards_held(1)]

func _end_by_limit() -> void:
	if scenario.get("cache", false) and cache_side() >= 0:
		_set_winner(cache_side(), "Night falls with the strongbox in their hands.")
		return
	if through_need > 0:
		var ta := through(0)
		var tb := through(1)
		if ta != tb:
			_set_winner(0 if ta > tb else 1, "Night falls. More fighters through the enemy's lines.")
			return
	if scenario_id == "hold":
		var ha := holding(0)
		var hb := holding(1)
		if ha != hb:
			_set_winner(0 if ha > hb else 1, "Night falls. More fighters hold the ground.")
			return
	var a := shards_held(0)
	var b := shards_held(1)
	if a != b:
		_set_winner(0 if a > b else 1, "Night falls. More godshards in hand.")
		return
	var sa := units.filter(func(u): return u.side == 0 and u.alive()).size()
	var sb := units.filter(func(u): return u.side == 1 and u.alive()).size()
	if sa != sb:
		_set_winner(0 if sa > sb else 1, "Night falls. More fighters still on their feet.")
	else:
		_set_winner(-2, "Night falls with nothing decided.")

func _set_winner(s: int, why: String) -> void:
	over = true
	winner = s
	end_reason = why
	if s >= 0:
		log_add("[b]%s win. %s[/b]" % [sides[s]["wb"]["name"], why])
	else:
		log_add("[b]A draw. %s[/b]" % why)
	events.append({"type": "over"})
	changed.emit()

func leader_of(s: int) -> BUnit:
	for u in units:
		if u.side == s and u.is_leader():
			return u
	return null

func check_wipe() -> void:
	if over:
		return
	if scenario.get("headhunt", false):
		for s in range(2):
			var ld := leader_of(s)
			if ld != null and not ld.alive():
				_set_winner(1 - s, "%s has fallen, and %s break." % [ld.name, sides[s]["wb"]["name"]])
				return
	for s in range(2):
		var left := units.filter(func(u): return u.side == s and u.alive()).size()
		if left == 0:
			_set_winner(1 - s, "%s were all taken out." % sides[s]["wb"]["name"])
			return

# ---------------------------------------------------------------- spotting

func _sees(viewer: BUnit, target: BUnit) -> bool:
	if viewer.status == "ooa" or viewer.status == "stunned" or target.status == "ooa":
		return false
	var dd := dist(viewer, target)
	if dd <= float(rules["always_spot_range"]):
		return true
	if dd > spot_range():
		return false
	return map.can_see_any(eye(viewer), pos(target))

func refresh_spotting() -> void:
	for s in range(2):
		var now := {}
		for e in units:
			if e.side == s or e.status == "ooa":
				continue
			for f in units:
				if f.side == s and _sees(f, e):
					now[e.id] = true
					break
		for id in spotted[s]:
			if not now.has(id):
				var lost := unit_by_id(id)
				if lost != null and lost.alive():
					last_seen[s][id] = lost.node
		for id in now:
			last_seen[s].erase(id)
		spotted[s] = now
	events.append({"type": "spotting"})

func _spot_from(mover: BUnit) -> Array:
	## Enemies newly revealed to the mover's side by the mover; also whether
	## the mover is now seen by the other side.
	var revealed: Array = []
	for e in units:
		if e.side == mover.side or e.status == "ooa":
			continue
		if not spotted[mover.side].has(e.id) and _sees(mover, e):
			spotted[mover.side][e.id] = true
			last_seen[mover.side].erase(e.id)
			revealed.append(e)
	var seen := false
	for e in units:
		if e.side != mover.side and _sees(e, mover):
			seen = true
			break
	if seen:
		spotted[1 - mover.side][mover.id] = true
		last_seen[1 - mover.side].erase(mover.id)
	elif spotted[1 - mover.side].has(mover.id):
		spotted[1 - mover.side].erase(mover.id)
		last_seen[1 - mover.side][mover.id] = mover.node
	return revealed

# ---------------------------------------------------------------- movement

func _blocked_nodes(u: BUnit, known_only: bool) -> Dictionary:
	var blocked := {}
	for o in units:
		if o == u or o.status == "ooa":
			continue
		if o.side != u.side and known_only and not known(u.side, o):
			continue
		blocked[o.node] = true
	return blocked

func _zoc_nodes(u: BUnit, known_only: bool) -> Dictionary:
	var z := {}
	for o in units:
		if o.side == u.side or not o.standing():
			continue
		if known_only and not known(u.side, o):
			continue
		for nd in map.adjacent.get(o.node, []):
			z[nd] = o.id
	return z

func edge_cost(u: BUnit, e: Dictionary) -> float:
	var c: float = e["cost"]
	if u.has_skill("climber") and (e["kind"] == "climb" or e["kind"] == "jump"):
		c = 2.0 if e["kind"] == "climb" else 4.0
	return c

func search(u: BUnit, budget: float, allow_zoc_end_near: BUnit = null) -> Dictionary:
	## Dijkstra over the movement graph from the unit's node.
	## Returns node -> {"cost", "prev", "kind", "levels"}. Nodes next to known
	## standing enemies are only allowed when charging `allow_zoc_end_near`.
	var blocked := _blocked_nodes(u, true)
	var zoc := _zoc_nodes(u, true)
	var res := {u.node: {"cost": 0.0, "prev": -1, "kind": "start", "levels": 0}}
	var open := [u.node]
	while not open.is_empty():
		var bi := 0
		for i in range(1, open.size()):
			if res[open[i]]["cost"] < res[open[bi]]["cost"]:
				bi = i
		var cur: int = open[bi]
		open.remove_at(bi)
		if cur != u.node and zoc.has(cur):
			continue  # cannot move on once next to an enemy
		for e in map.edges.get(cur, []):
			var to: int = e["to"]
			if blocked.has(to):
				continue
			if zoc.has(to):
				if allow_zoc_end_near == null:
					continue
				if not map.adjacent.get(allow_zoc_end_near.node, []).has(to):
					continue
			var nc: float = res[cur]["cost"] + edge_cost(u, e)
			if nc > budget + 0.001:
				continue
			if nc < res.get(to, {"cost": INF})["cost"]:
				res[to] = {"cost": nc, "prev": cur, "kind": e["kind"], "levels": e["levels"]}
				open.append(to)
	return res

func reachable(u: BUnit) -> Dictionary:
	if not can_act(u) or u.mp <= 0.0:
		return {}
	if engaged(u) and u.ap < 1:
		return {}
	return search(u, u.mp)

func path_to(reach: Dictionary, target: int) -> Array:
	var path: Array = []
	var cur := target
	while cur != -1 and reach.has(cur):
		path.push_front(cur)
		cur = reach[cur]["prev"]
	return path

func move(u: BUnit, dest: int) -> Dictionary:
	if not can_act(u):
		return {"ok": false, "msg": "That fighter cannot act."}
	var reach := reachable(u)
	if dest == u.node or not reach.has(dest):
		return {"ok": false, "msg": "Out of reach."}
	if engaged(u):
		if not _disengage(u):
			return {"ok": true, "msg": "Cut down while breaking away."}
	var path := path_to(reach, dest)
	var res := _walk(u, path, reach)
	u.moved = true
	refresh_spotting()
	check_wipe()
	changed.emit()
	return res

func _disengage(u: BUnit) -> bool:
	u.ap -= 1
	log_add("%s breaks away from the fight." % u.name)
	for e in adjacent_enemies(u, true):
		if not u.standing():
			break
		log_add("%s strikes at %s as they go." % [e.name, u.name])
		_strike(e, u, e.best_melee_weapon(), false)
	return u.standing()

func _walk(u: BUnit, path: Array, reach: Dictionary) -> Dictionary:
	var steps: Array = []   # [{"node", "kind"}]
	var stop_reason := ""
	var start: int = u.node
	steps.append({"node": start, "kind": "start"})
	for i in range(1, path.size()):
		var nd: int = path[i]
		var info: Dictionary = reach[nd]
		if occupied.has(nd):
			var hidden = occupied[nd]
			spotted[u.side][hidden.id] = true
			stop_reason = "%s runs into %s, hidden there!" % [u.name, hidden.name]
			break
		var spent: float = info["cost"] - reach[path[i - 1]]["cost"]
		u.mp = max(0.0, u.mp - spent)
		var kind: String = info["kind"]
		var levels: int = info["levels"]
		var slick := 1 if weather == "rain" else 0
		if kind == "jump":
			var r := dice.d6()
			if r > u.stat("I") - slick and not u.has_skill("climber"):
				# falls into the gap between
				var a := map.node_xz(path[i - 1])
				var b := map.node_xz(nd)
				var gx: int = (a.x + b.x) / 2
				var gz: int = (a.y + b.y) / 2
				var gnode := map.top_node(gx, gz)
				if gnode >= 0 and not occupied.has(gnode):
					var fall: int = map.node_level(path[i - 1]) - map.node_level(gnode)
					_place(u, gnode)
					steps.append({"node": gnode, "kind": "fall"})
					log_add("%s misjudges the jump (%d against I%d) and falls %d m." % [u.name, r, u.stat("I"), fall * 3])
					_falling(u, fall)
					stop_reason = "fell"
					break
				else:
					log_add("%s balks at the jump (%d)." % [u.name, r])
					stop_reason = "balked"
					break
		elif kind == "drop" and levels >= 1 and not (levels == 1 and map.is_wet(nd)):
			# flood water breaks a fall of one storey
			if map.is_wet(nd):
				levels -= 1
			var need := u.stat("I") + (1 if levels == 1 else 0) - slick
			var r := dice.d6()
			if r > need:
				_place(u, nd)
				steps.append({"node": nd, "kind": "fall"})
				log_add("%s lands badly from %d m up (%d against %d)." % [u.name, levels * 3, r, need])
				_falling(u, levels)
				stop_reason = "fell"
				break
		_place(u, nd)
		steps.append({"node": nd, "kind": kind})
		_pickup(u)
		var revealed := _spot_from(u)
		if not revealed.is_empty() and i < path.size() - 1:
			var names := ", ".join(revealed.map(func(x): return x.name))
			stop_reason = "%s spots %s and stops." % [u.name, names]
			break
	events.append({"type": "move", "unit": u.id, "steps": steps})
	if stop_reason != "" and stop_reason != "fell" and stop_reason != "balked":
		log_add(stop_reason)
	_check_cache_home(u)
	return {"ok": true, "msg": stop_reason}

func _check_cache_home(u: BUnit) -> void:
	if over or u.id != cache_holder or not u.standing() or not zones[u.side].has(u.node):
		return
	_set_winner(u.side, "%s carried the strongbox home." % u.name)

func _falling(u: BUnit, levels: int) -> void:
	var s := 2 + levels
	var need := Rules.to_wound(s, u.stat("T"))
	var r := dice.d6()
	if need > 0 and r >= need:
		log_add("The fall wounds %s (S%d, rolled %d)." % [u.name, s, r])
		_apply_wound(u, null, "")
	else:
		log_add("%s is shaken but unhurt." % u.name)
	if u.status == "ok":
		u.status = "down"
		events.append({"type": "status", "unit": u.id})
	u.mp = 0
	u.ap = 0

func _pickup(u: BUnit) -> void:
	if cache_node >= 0 and u.node == cache_node:
		cache_node = -1
		cache_holder = u.id
		log_add("[color=#e8c26a]%s takes up the strongbox.[/color]" % u.name)
		events.append({"type": "cache_take", "unit": u.id, "node": u.node})
	elif cache_spots.has(u.node):
		# dig: the box is in one of the spots left, so each dig may find it
		var left := cache_spots.size()
		cache_spots.erase(u.node)
		var hit := left == 1 or dice.randf() < 1.0 / float(left)
		if hit:
			cache_spots.clear()
			cache_holder = u.id
			log_add("[color=#e8c26a]%s digs and strikes iron: the strongbox! Now get it home.[/color]" % u.name)
			events.append({"type": "cache_found", "unit": u.id, "node": u.node})
		else:
			cache_dug[u.node] = true
			log_add("%s digs, and finds only bones and broken pots." % u.name)
			events.append({"type": "cache_empty", "unit": u.id, "node": u.node})
	if shard_nodes.has(u.node):
		shard_nodes.erase(u.node)
		u.carrying += 1
		log_add("[color=#5fe0c0]%s picks up a godshard.[/color]" % u.name)
		events.append({"type": "pickup", "unit": u.id, "node": u.node})

func dash(u: BUnit) -> Dictionary:
	if u.id == cache_holder:
		return {"ok": false, "msg": "Too laden with the strongbox to dash."}
	if not can_act(u) or u.ap < 1 or u.dashed or engaged(u):
		return {"ok": false, "msg": "Cannot dash now."}
	u.ap -= 1
	u.dashed = true
	u.mp += u.mp_full
	log_add("%s dashes." % u.name)
	changed.emit()
	return {"ok": true}

# ---------------------------------------------------------------- close combat

func charge_targets(u: BUnit) -> Dictionary:
	## enemy id -> destination node, for every known enemy this unit can charge.
	var out := {}
	if not can_act(u) or u.ap < 1 or u.moved or u.rose or engaged(u) or u.mp < u.mp_full - 0.01:
		return out
	for e in enemies_of(u):
		if not known(u.side, e):
			continue
		if dist(u, e) > u.mp_full * 2 + 4.0:
			continue
		var r := search(u, u.mp_full * 2, e)
		var best := -1
		var best_cost := INF
		for nd in map.adjacent.get(e.node, []):
			if r.has(nd) and r[nd]["cost"] < best_cost and nd != u.node:
				best = nd
				best_cost = r[nd]["cost"]
		if best >= 0:
			out[e.id] = best
	return out

func charge(u: BUnit, target: BUnit) -> Dictionary:
	var ct := charge_targets(u)
	if not ct.has(target.id):
		return {"ok": false, "msg": "Cannot reach them this turn."}
	var r := search(u, u.mp_full * 2, target)
	var path := path_to(r, ct[target.id])
	log_add("[b]%s charges %s![/b]" % [u.name, target.name])
	u.charged = true
	u.moved = true
	_walk(u, path, r)
	u.mp = 0
	var result := {"ok": true}
	if u.standing() and is_adjacent(u, target) and target.alive():
		u.ap -= 1
		_melee_round(u, target, true)
	refresh_spotting()
	check_wipe()
	changed.emit()
	return result

func melee(u: BUnit, target: BUnit) -> Dictionary:
	if not can_act(u) or u.ap < 1:
		return {"ok": false, "msg": "No actions left."}
	if not is_adjacent(u, target) or not target.alive() or target.side == u.side:
		return {"ok": false, "msg": "Not in reach."}
	u.ap -= 1
	_melee_round(u, target, false)
	refresh_spotting()
	check_wipe()
	changed.emit()
	return {"ok": true}

func attack_count(u: BUnit, charging: bool) -> int:
	var a := u.stat("A")
	if u.dual_wield():
		a += 1
	if u.has_skill("frenzy"):
		a += 1
	if charging and u.has_skill("brawler"):
		a += 1
	return a

func _melee_round(u: BUnit, target: BUnit, charging: bool) -> void:
	var weapon := u.best_melee_weapon()
	var n := attack_count(u, charging)
	spotted[1 - u.side][u.id] = true
	spotted[u.side][target.id] = true
	events.append({"type": "melee", "unit": u.id, "target": target.id})
	var parry_left := target.can_parry()
	for i in range(n):
		if not target.alive() or not u.standing():
			break
		var parried := _strike(u, target, weapon, charging, parry_left)
		if parried:
			parry_left = false

func _strike(u: BUnit, t: BUnit, weapon: String, charging: bool, parry_left := false) -> bool:
	## One attack. Returns true if it was parried.
	var wd := GameData.weapon(weapon)
	var wname: String = wd.get("name", weapon)
	var hit_roll := 0
	if t.status == "down" or t.status == "stunned":
		hit_roll = 6
	else:
		var need := Rules.melee_to_hit(u.stat("WS"), t.stat("WS"))
		if t.charged and wd.get("first_strike", false):
			need -= 1
		hit_roll = dice.d6()
		_roll_ev(u.id, "To hit", hit_roll, need, not (hit_roll == 1 or hit_roll < need))
		if hit_roll == 1 or hit_roll < need:
			log_add("%s swings at %s with %s and misses (%d, needed %d)." % [u.name, t.name, wname.to_lower(), hit_roll, need])
			events.append({"type": "miss", "unit": t.id})
			return false
		if parry_left and t.standing():
			var pr := dice.d6()
			_roll_ev(t.id, "Parry", pr, hit_roll + 1, pr > hit_roll)
			if pr > hit_roll or (t.has_skill("duellist") and pr == hit_roll):
				log_add("%s parries %s's blow (%d beats %d)." % [t.name, u.name, pr, hit_roll])
				events.append({"type": "parry", "unit": t.id})
				return true
	var s: int = u.stat("S") + int(wd.get("str", 0))
	_wound_roll(u, t, s, int(wd.get("save_mod", 0)), wd.get("concuss", false), true, wname)
	return false

func _wound_roll(src: BUnit, t: BUnit, s: int, save_mod: int, concuss: bool, melee_hit: bool, what: String, who_name := "") -> void:
	var need := Rules.to_wound(s, t.stat("T"))
	var who: String = src.name if src != null else (who_name if who_name != "" else "It")
	if need == 0:
		log_add("%s hits %s but cannot hurt them (S%d against T%d)." % [who, t.name, s, t.stat("T")])
		events.append({"type": "bounce", "unit": t.id})
		return
	var r := dice.d6()
	_roll_ev(src.id if src != null else t.id, "To wound", r, need, r >= need)
	if r < need:
		log_add("%s hits %s, but fails to wound (%d, needed %d)." % [who, t.name, r, need])
		events.append({"type": "bounce", "unit": t.id})
		return
	if t.status == "stunned":
		log_add("[color=#e06a50]%s finishes %s where they lie.[/color]" % [who, t.name])
		_take_out(t, src)
		return
	var crit := r == 6
	if crit and melee_hit and src != null and src.has_skill("killer"):
		log_add("[color=#e06a50]A killing blow from %s![/color]" % who)
		_take_out(t, src)
		return
	if not crit:
		var sv := Rules.save_needed(t.armour_save(), s, save_mod)
		if sv <= 6:
			var sr := dice.d6()
			_roll_ev(t.id, "Armour", sr, sv, sr >= sv)
			if sr >= sv:
				if src == null and who_name != "":
					log_add("%s hits %s, but armour turns it (save %d on %d+)." % [who, t.name, sr, sv])
				else:
					log_add("%s's %s lands on %s, but armour turns it (save %d on %d+)." % [who, what.to_lower(), t.name, sr, sv])
				events.append({"type": "saved", "unit": t.id})
				return
	else:
		log_add("[color=#f0c060]Critical hit! No armour can stop it.[/color]")
	log_add("%s wounds %s (%d)." % [who, t.name, r])
	_apply_wound(t, src, "concuss" if concuss else "")

func _apply_wound(t: BUnit, src: BUnit, flag: String) -> void:
	events.append({"type": "hurt", "unit": t.id})
	t.wounds -= 1
	if t.wounds > 0:
		log_add("%s has %d wound%s left." % [t.name, t.wounds, "" if t.wounds == 1 else "s"])
		return
	t.wounds = 0
	var r := dice.d6()
	_roll_ev(t.id, "Injury", r, 0, r <= 2)
	var result := ""
	if r <= 2:
		result = "stunned" if (flag == "concuss" and r == 2) else "down"
	elif r <= 4:
		result = "stunned"
	else:
		result = "ooa"
	if result == "ooa" and t.has_skill("lucky") and not t.lucky_used:
		t.lucky_used = true
		var r2 := dice.d6()
		log_add("Hood passes %s by (re-roll %d)." % [t.name, r2])
		r = r2
		result = "down" if r2 <= 2 else ("stunned" if r2 <= 4 else "ooa")
	if result == "stunned" and (t.gear.has("helm") or t.has_skill("tough") or t.has_skill("unliving")):
		var hr := dice.d6()
		if hr >= 4:
			if t.has_skill("unliving") and not t.gear.has("helm"):
				log_add("%s is already dead, and shrugs it off (%d)." % [t.name, hr])
			else:
				log_add("%s's helm takes the worst of it (%d)." % [t.name, hr])
			result = "down"
	if result == "down" and t.has_skill("giantkin"):
		var gr := dice.d6()
		if gr >= 5:
			log_add("%s staggers but stays up (%d)." % [t.name, gr])
			events.append({"type": "status", "unit": t.id})
			return
	if result == "down" and t.has_skill("painsworn"):
		log_add("%s laughs through the pain and stays standing." % t.name)
		events.append({"type": "status", "unit": t.id})
		return
	match result:
		"down":
			t.status = "down"
			log_add("Injury roll %d: [color=#f0c060]%s is knocked down.[/color]" % [r, t.name])
		"stunned":
			t.status = "stunned"
			log_add("Injury roll %d: [color=#f09050]%s is stunned.[/color]" % [r, t.name])
		"ooa":
			log_add("Injury roll %d:" % r)
			_take_out(t, src)
			return
	if t.side == side:
		t.mp = 0
		t.ap = 0
	events.append({"type": "status", "unit": t.id})

func _take_out(t: BUnit, src: BUnit) -> void:
	t.status = "ooa"
	t.wounds = 0
	if src != null:
		src.kills += 1
		t.ooa_by = src.id
	log_add("[color=#e06a50]%s is out of action.[/color]" % t.name)
	if t.id == cache_holder:
		cache_holder = -1
		cache_node = t.node
		log_add("[color=#e8c26a]%s drops the strongbox.[/color]" % t.name)
		events.append({"type": "cache_drop", "node": t.node})
	if t.carrying > 0:
		var drop_at := t.node
		if shard_nodes.has(drop_at):
			for nd in map.adjacent.get(t.node, []):
				if not shard_nodes.has(nd):
					drop_at = nd
					break
		shard_nodes[drop_at] = true
		log_add("%s drops the godshard%s." % [t.name, "s" if t.carrying > 1 else ""])
		t.carrying = 0
		events.append({"type": "drop", "node": drop_at})
	occupied.erase(t.node)
	events.append({"type": "status", "unit": t.id})

# ---------------------------------------------------------------- shooting

func shot_info(u: BUnit, t: BUnit) -> Dictionary:
	## Whether `u` may shoot `t` now, and the odds. Keys: ok, why, need, p, mods.
	var wpn := u.missile()
	if wpn == "":
		return {"ok": false, "why": "No missile weapon."}
	var wd := GameData.weapon(wpn)
	if not can_act(u):
		return {"ok": false, "why": "Cannot act."}
	if u.shot:
		return {"ok": false, "why": "Already shot this turn."}
	if u.ap < int(wd.get("ap", 1)):
		return {"ok": false, "why": "Needs %d actions." % int(wd.get("ap", 1))}
	if engaged(u):
		return {"ok": false, "why": "Locked in close combat."}
	if u.has_fx("blind"):
		return {"ok": false, "why": "Blinded by darkness."}
	if not t.alive() or t.side == u.side or not known(u.side, t):
		return {"ok": false, "why": "No target."}
	if t.has_fx("shroud"):
		return {"ok": false, "why": "Shrouded in shadow."}
	for o in adjacent_enemies(t, true):
		if o.side == u.side:
			return {"ok": false, "why": "Fighting your own; you might hit them."}
	var dd := eye(u).distance_to(pos(t) + Vector3(0, 1.1, 0))
	var rng: float = wd.get("range", 20)
	if dd > rng:
		return {"ok": false, "why": "Out of range (%d m of %d)." % [int(dd), int(rng)]}
	var vis := map.visibility(eye(u), pos(t))
	if vis <= 0.0:
		return {"ok": false, "why": "No line of sight."}
	var need := Rules.ranged_to_hit(u.stat("BS"))
	var mods: Array = []
	if dd > rng * 0.5 and not wd.get("no_long_range", false):
		need += 1
		mods.append("long range")
	var in_cover := vis < 0.8 or t.has_fx("veil") or t.has_skill("shadowborn")
	if in_cover and not u.has_skill("deadeye"):
		need += 1
		mods.append("cover")
	if weather == "rain" and not wd.get("thrown", false):
		need += 1
		mods.append("rain")
	if u.has_skill("steady"):
		need -= 1
		mods.append("steady hand")
	if map.node_level(u.node) > map.node_level(t.node):
		mods.append("from above")
	var s: int = wd.get("str", 3)
	var p_hit := Rules.p_ranged_hit(need)
	var p_wound := Rules.p_success(Rules.to_wound(s, t.stat("T")))
	var sv := Rules.save_needed(t.armour_save(), s, 0)
	var p := p_hit * p_wound * Rules.p_unsaved(sv)
	return {"ok": need <= 7, "why": "" if need <= 7 else "Impossible shot.", "need": need, "p_hit": p_hit, "p": p, "mods": mods, "range": dd, "vis": vis, "weapon": wpn}

func shoot(u: BUnit, t: BUnit) -> Dictionary:
	var info := shot_info(u, t)
	if not info["ok"]:
		return {"ok": false, "msg": info["why"]}
	var wd := GameData.weapon(info["weapon"])
	u.ap -= int(wd.get("ap", 1))
	u.shot = true
	spotted[1 - u.side][u.id] = true
	var need: int = info["need"]
	var r := dice.d6()
	var hit := false
	if need <= 6:
		hit = r != 1 and r >= need
		_roll_ev(u.id, "To hit", r, need, hit)
	elif r == 6:
		var r2 := dice.d6()
		hit = r2 >= 4
		r = r2
	var wname: String = wd["name"]
	events.append({"type": "shot", "unit": u.id, "target": t.id, "hit": hit, "weapon": info["weapon"]})
	if not hit:
		var why := "" if info["mods"].is_empty() else " (%s)" % ", ".join(info["mods"])
		log_add("%s looses a %s at %s and misses (%d, needed %d%s)." % [u.name, wname.to_lower(), t.name, r, need, why])
	else:
		log_add("%s's %s strikes %s (%d)." % [u.name, wname.to_lower(), t.name, r])
		_wound_roll(u, t, int(wd.get("str", 3)), 0, false, false, wname)
	check_wipe()
	changed.emit()
	return {"ok": true, "hit": hit}

# ---------------------------------------------------------------- munitions

func throw_info(u: BUnit, mun: String, target_node: int) -> Dictionary:
	if not can_act(u) or u.ap < 1:
		return {"ok": false, "why": "No actions left."}
	if not u.has_skill("munitions") or int(u.munitions.get(mun, 0)) <= 0:
		return {"ok": false, "why": "None left."}
	if engaged(u):
		return {"ok": false, "why": "Locked in close combat."}
	var md := GameData.munition(mun)
	var tp := map.node_pos(target_node)
	var dd := eye(u).distance_to(tp + Vector3(0, 0.3, 0))
	if dd > float(md["range"]):
		return {"ok": false, "why": "Too far to throw (%d m of %d)." % [int(dd), int(md["range"])]}
	if not map.line_clear(eye(u), tp + Vector3(0, 0.6, 0)) and not map.line_clear(eye(u), tp + Vector3(0, 1.4, 0)):
		return {"ok": false, "why": "No clear throw."}
	var need := Rules.ranged_to_hit(u.stat("BS"))
	if dd > float(md["range"]) * 0.5:
		need += 1
	return {"ok": true, "need": need, "range": dd}

func throw_munition(u: BUnit, mun: String, target_node: int) -> Dictionary:
	var info := throw_info(u, mun, target_node)
	if not info["ok"]:
		return {"ok": false, "msg": info["why"]}
	var md := GameData.munition(mun)
	u.ap -= 1
	u.munitions[mun] = int(u.munitions[mun]) - 1
	spotted[1 - u.side][u.id] = true
	var r := dice.d6()
	var land := target_node
	if r == 1 or r < int(info["need"]):
		var xz := map.node_xz(target_node)
		var dir := Vector2i([1, -1, 0][dice.rng.randi_range(0, 2)], [1, -1, 0][dice.rng.randi_range(0, 2)])
		var dist_c := dice.d3()
		var nx := clampi(xz.x + dir.x * dist_c, 0, map.w - 1)
		var nz := clampi(xz.y + dir.y * dist_c, 0, map.d - 1)
		var cand := map.top_node(nx, nz)
		if cand >= 0:
			land = cand
		log_add("%s throws a %s; it bounces wide (%d, needed %d)." % [u.name, md["name"].to_lower(), r, info["need"]])
	else:
		log_add("%s throws a %s right on target (%d)." % [u.name, md["name"].to_lower(), r])
	events.append({"type": "blast", "unit": u.id, "node": land, "radius": int(md.get("blast", 0)), "munition": mun})
	var centre := map.node_pos(land)
	var victims: Array = []
	for o in units:
		if not o.alive():
			continue
		if o.node == land:
			victims.append([o, int(md["str"])])
		elif int(md.get("blast", 0)) > 0:
			var p := pos(o)
			if abs(p.y - centre.y) < 2.0 and Vector2(p.x, p.z).distance_to(Vector2(centre.x, centre.z)) <= md["blast"] * map.cell * 1.45:
				victims.append([o, int(md.get("blast_str", 3))])
	if victims.is_empty():
		log_add("The blast catches no one.")
	for v in victims:
		var o: BUnit = v[0]
		if o.alive():
			_wound_roll(u, o, v[1], 0, false, false, md["name"])
	refresh_spotting()
	check_wipe()
	changed.emit()
	return {"ok": true}

# ---------------------------------------------------------------- magic

func spell_targets(u: BUnit, sp: String) -> Array:
	## Returns valid targets: units for unit spells, node ids for node spells.
	var sd := GameData.spell(sp)
	var out: Array = []
	var rng: float = sd["range"]
	match sd["target"]:
		"self":
			out.append(u)
		"ally":
			for o in units:
				if o.side == u.side and o.alive() and dist(u, o) <= rng:
					if sp == "knit" and o.standing() and o.wounds >= o.stat("W"):
						continue
					out.append(o)
		"enemy":
			for o in enemies_of(u):
				if known(u.side, o) and dist(u, o) <= rng and map.visibility(eye(u), pos(o)) > 0.0:
					out.append(o)
		"node":
			var zoc := _zoc_nodes(u, true)
			for nd in map.nodes:
				if occupied.has(nd) or zoc.has(nd) or shard_nodes.has(nd):
					continue
				var p := map.node_pos(nd)
				if p.distance_to(pos(u)) <= rng and map.can_see_any(eye(u), p):
					out.append(nd)
	return out

func can_cast(u: BUnit) -> bool:
	return can_act(u) and u.ap >= 1 and not u.cast and not u.spells.is_empty() and not u.has_fx("blind")

func cast(u: BUnit, sp: String, target) -> Dictionary:
	if not can_cast(u) or not u.spells.has(sp):
		return {"ok": false, "msg": "Cannot cast now."}
	var targets := spell_targets(u, sp)
	if not targets.has(target):
		return {"ok": false, "msg": "Not a valid target."}
	var sd := GameData.spell(sp)
	u.ap -= 1
	u.cast = true
	var a := dice.d6()
	var b := dice.d6()
	var total := a + b + (1 if u.has_skill("adept") else 0)
	var diff: int = sd["diff"]
	events.append({"type": "cast", "unit": u.id, "spell": sp, "ok": total >= diff, "target": (target.id if target is BUnit else int(target))})
	if a == 1 and b == 1:
		log_add("[color=#b08cff]%s reaches for %s and the warren bites back![/color]" % [u.name, sd["name"]])
		_wound_roll(null, u, 3, 7, false, false, "warren")
		changed.emit()
		return {"ok": true, "cast": false}
	if total < diff:
		log_add("%s tries %s but the warren slips away (%d, needed %d)." % [u.name, sd["name"], total, diff])
		changed.emit()
		return {"ok": true, "cast": false}
	log_add("[color=#b08cff]%s casts %s (%d).[/color]" % [u.name, sd["name"], total])
	var expire := turn_index + 2
	match sp:
		"shadowstep":
			_place(u, int(target))
			events.append({"type": "teleport", "unit": u.id, "node": int(target)})
			_pickup(u)
		"shroud":
			target.fx.append({"kind": "shroud", "value": 1, "expire": expire})
		"knit":
			if target.status == "down" or target.status == "stunned":
				target.status = "ok"
				log_add("%s is pulled back to their feet." % target.name)
			else:
				target.wounds = min(target.stat("W"), target.wounds + 1)
				log_add("%s's wound closes." % target.name)
			events.append({"type": "status", "unit": target.id})
		"ward":
			target.fx.append({"kind": "ward", "value": 1, "expire": expire})
		"skyfire":
			_wound_roll(u, target, 4, 0, false, false, "Skyfire")
		"thunderhead":
			for o in enemies_of(u):
				if o.standing() and dist(u, o) <= float(sd["range"]):
					var r := dice.d6()
					if r > o.stat("I"):
						o.status = "down"
						log_add("%s is thrown off their feet." % o.name)
						events.append({"type": "status", "unit": o.id})
		"scour":
			var centre := pos(target)
			for o in units:
				if o.alive() and pos(o).distance_to(centre) <= 2.9:
					_wound_roll(u, o, 3, 0, false, false, "Scouring Sand")
		"veil":
			for o in units:
				if o.side == u.side and o.alive() and dist(u, o) <= float(sd["range"]):
					o.fx.append({"kind": "veil", "value": 1, "expire": expire})
		"binding":
			target.fx.append({"kind": "bound", "value": 1, "expire": expire})
		"paingift":
			target.fx.append({"kind": "attack", "value": 1, "expire": expire})
		"nightedge":
			target.fx.append({"kind": "strength", "value": 1, "expire": expire})
		"ancestors":
			target.fx.append({"kind": "toughness", "value": 1, "expire": expire})
			log_add("The fathers stand round %s." % target.name)
		"howl":
			for o in enemies_of(u):
				if o.alive() and dist(u, o) <= float(sd["range"]):
					if o.has_skill("unliving"):
						log_add("%s does not flinch from the dead." % o.name)
						continue
					o.fx.append({"kind": "ws", "value": -1, "expire": expire})
					log_add("%s flinches from the howling dead." % o.name)
		"emberfall":
			var others: Array = []
			for o in enemies_of(u):
				if o != target and o.alive() and dist(o, target) <= 2.9:
					others.append(o)
			_wound_roll(u, target, 3, 0, false, false, "Ember Fall")
			for o in others:
				if o.alive():
					_wound_roll(u, o, 2, 0, false, false, "Ember Fall")
		"rise":
			for o in units:
				if o.side == u.side and o.alive() and dist(u, o) <= float(sd["range"]) and (o.status == "down" or o.status == "stunned"):
					o.status = "ok"
					log_add("%s rises from the dust." % o.name)
					events.append({"type": "status", "unit": o.id})
		"starless":
			target.fx.append({"kind": "blind", "value": 1, "expire": expire})
			log_add("Darkness swallows %s's sight." % target.name)
	refresh_spotting()
	check_wipe()
	changed.emit()
	return {"ok": true, "cast": true}

# ---------------------------------------------------------------- results

func summary() -> Dictionary:
	var out := {"winner": winner, "reason": end_reason, "rounds": round_num, "sides": [], "weather": weather}
	for s in range(2):
		var ooa: Array = []
		var standing: Array = []
		for u in side_units(s):
			if u.status == "ooa":
				ooa.append(u.name)
			else:
				standing.append(u.name)
		out["sides"].append({"name": sides[s]["wb"]["name"], "ooa": ooa, "standing": standing, "shards": shards_held(s), "cache": cache_side() == s})
	return out
