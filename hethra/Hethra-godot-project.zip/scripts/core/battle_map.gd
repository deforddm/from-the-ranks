class_name BattleMap
extends RefCounted
## The battlefield as data: a grid of 2 m cells with storey heights, props,
## ladders, stairs and bridges. Builds the movement graph (walk, climb, drop,
## jump edges) and answers 3D line-of-sight questions.

const PROP_HEIGHT := {"r": 0.9, "b": 1.25, "c": 1.35, "B": 1.1, "p": 4.6, "T": 7.0, "S": 3.6, "G": 2.2, "L": 2.6}
const PROP_RADIUS := {"r": 1.0, "b": 1.05, "c": 0.9, "B": 0.6, "p": 0.55, "T": 2.2, "S": 1.7, "G": 1.5, "L": 1.9}
const LOW_COVER := "rbcB"
const MAX_DIM := 64

var data: Dictionary
var w: int
var d: int
var cell: float
var storey: float
var heights: Array = []      # [z][x] int storeys
var props: Array = []        # [z][x] single-char String
var bridge_level: Dictionary = {}   # Vector2i -> int storey
var nodes: Dictionary = {}   # id -> {"x","z","l","pos"}
var edges: Dictionary = {}   # id -> Array of {"to","cost","kind","levels"}
var redges: Dictionary = {}  # reverse edges for distance-to maps
var adjacent: Dictionary = {} # id -> Array of ids that count as melee-adjacent (walk neighbours)
var ladders: Array = []
var stairs: Array = []
var water := -100.0          # flood water surface height, if the streets are drowned

const WADE_COST := 1.5       # moving through flood water costs half as much again

static func nid(x: int, z: int, l: int) -> int:
	return (l * MAX_DIM + z) * MAX_DIM + x

func load_map(map_id: String) -> void:
	data = GameData.map_data(map_id)
	w = int(data["width"])
	d = int(data["depth"])
	cell = float(data["cell"])
	storey = float(data["storey"])
	heights.clear()
	props.clear()
	for z in range(d):
		var hrow: Array = []
		var prow: Array = []
		var hs: String = data["heights"][z]
		var ps: String = data["props"][z]
		for x in range(w):
			hrow.append(int(hs[x]))
			prow.append(ps[x])
		heights.append(hrow)
		props.append(prow)
	for b in data["bridges"]:
		bridge_level[Vector2i(int(b["x"]), int(b["z"]))] = int(b["level"])
	ladders = data.get("ladders", [])
	stairs = data.get("stairs", [])
	water = float(data.get("water", -100.0))
	_build_nodes()
	_build_edges()

func is_wet(id: int) -> bool:
	## Standing in flood water: street level on a drowned battlefield.
	if water < 0.0 or not nodes.has(id):
		return false
	return float(nodes[id]["l"]) * storey < water

func h_at(x: int, z: int) -> int:
	if x < 0 or z < 0 or x >= w or z >= d:
		return 99
	return heights[z][x]

func prop_at(x: int, z: int) -> String:
	if x < 0 or z < 0 or x >= w or z >= d:
		return "#"
	return props[z][x]

func cell_center(x: int, z: int) -> Vector2:
	return Vector2((x + 0.5) * cell, (z + 0.5) * cell)

func node_pos(id: int) -> Vector3:
	return nodes[id]["pos"]

func node_level(id: int) -> int:
	return nodes[id]["l"]

func node_xz(id: int) -> Vector2i:
	return Vector2i(nodes[id]["x"], nodes[id]["z"])

func has_node(x: int, z: int, l: int) -> bool:
	return nodes.has(nid(x, z, l))

func top_node(x: int, z: int) -> int:
	## The ground-surface node of a cell (not a bridge), or -1.
	var id := nid(x, z, h_at(x, z))
	return id if nodes.has(id) else -1

func _add_node(x: int, z: int, l: int) -> void:
	var c := cell_center(x, z)
	nodes[nid(x, z, l)] = {"x": x, "z": z, "l": l, "pos": Vector3(c.x, l * storey, c.y)}

func _build_nodes() -> void:
	nodes.clear()
	for z in range(d):
		for x in range(w):
			if props[z][x] == ".":
				_add_node(x, z, heights[z][x])
	for k in bridge_level:
		var v: Vector2i = k
		_add_node(v.x, v.y, bridge_level[k])

func _link(a: int, b: int, cost: float, kind: String, levels: int = 0) -> void:
	if not edges.has(a):
		edges[a] = []
	edges[a].append({"to": b, "cost": cost, "kind": kind, "levels": levels})
	if not redges.has(b):
		redges[b] = []
	redges[b].append({"to": a, "cost": cost, "kind": kind, "levels": levels})

func _corner_clear(x: int, z: int, l: int) -> bool:
	## A diagonal step may pass a corner cell only if nothing stands taller there.
	if h_at(x, z) > l:
		return false
	if h_at(x, z) == l and PROP_HEIGHT.get(prop_at(x, z), 0.0) > 2.0:
		return false
	return true

func _build_edges() -> void:
	edges.clear()
	redges.clear()
	adjacent.clear()
	var dirs8 := [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1),
		Vector2i(1, 1), Vector2i(1, -1), Vector2i(-1, 1), Vector2i(-1, -1)]
	var dirs4 := [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
	for id in nodes:
		var n: Dictionary = nodes[id]
		var x: int = n["x"]
		var z: int = n["z"]
		var l: int = n["l"]
		adjacent[id] = []
		var on_bridge: bool = l != h_at(x, z)
		for dv in dirs8:
			var nx: int = x + dv.x
			var nz: int = z + dv.y
			var other := nid(nx, nz, l)
			if not nodes.has(other):
				continue
			if dv.x != 0 and dv.y != 0:
				if not (_corner_clear(x + dv.x, z, l) and _corner_clear(x, z + dv.y, l)):
					continue
				# no diagonal steps on or off narrow bridge planks
				if on_bridge or l != h_at(nx, nz):
					continue
			var cost := 2.0 if (dv.x == 0 or dv.y == 0) else 2.83
			if is_wet(other):
				cost *= WADE_COST
			_link(id, other, cost, "walk")
			adjacent[id].append(other)
		# drops and jumps go straight out (four directions)
		for dv in dirs4:
			var nx: int = x + dv.x
			var nz: int = z + dv.y
			if nx < 0 or nz < 0 or nx >= w or nz >= d:
				continue
			if nodes.has(nid(nx, nz, l)):
				continue
			var nh := h_at(nx, nz)
			if nh < l:
				# a gap at our level: jump across a single cell?
				var jx: int = x + dv.x * 2
				var jz: int = z + dv.y * 2
				if nodes.has(nid(jx, jz, l)) and PROP_HEIGHT.get(prop_at(nx, nz), 0.0) < 2.0:
					_link(id, nid(jx, jz, l), 4.5, "jump")
				# or drop down into it
				var below := nid(nx, nz, nh)
				if nodes.has(below):
					_link(id, below, 2.0, "drop", l - nh)
		# step off a bridge straight down
		if on_bridge:
			var ground := top_node(x, z)
			if ground >= 0:
				_link(id, ground, 1.0, "drop", l - h_at(x, z))
	for lad in ladders:
		_climb_link(lad, "climb", 3.0)
	for st in stairs:
		_climb_link(st, "stairs", 1.5)

func _climb_link(link: Dictionary, kind: String, per_level: float) -> void:
	var a := top_node(int(link["x"]), int(link["z"]))
	var b := top_node(int(link["tx"]), int(link["tz"]))
	if a < 0 or b < 0:
		return
	var levels: int = abs(node_level(b) - node_level(a))
	var cost := 2.0 + per_level * levels
	_link(a, b, cost, kind, levels)
	_link(b, a, cost, kind, levels)

# ---------------------------------------------------------------- sight

func solid_at(p: Vector3) -> bool:
	var x := int(floor(p.x / cell))
	var z := int(floor(p.z / cell))
	if x < 0 or z < 0 or x >= w or z >= d:
		return false
	var top: float = heights[z][x] * storey
	if p.y < top:
		return true
	var pr: String = props[z][x]
	if pr != ".":
		if p.y < top + PROP_HEIGHT.get(pr, 0.0):
			var c := cell_center(x, z)
			if Vector2(p.x, p.z).distance_to(c) < PROP_RADIUS.get(pr, 1.0):
				return true
	var key := Vector2i(x, z)
	if bridge_level.has(key):
		var by: float = bridge_level[key] * storey
		if p.y < by and p.y > by - 0.35:
			return true
	return false

func line_clear(a: Vector3, b: Vector3) -> bool:
	var dist := a.distance_to(b)
	var steps := int(dist / 0.25)
	if steps < 2:
		return true
	for i in range(1, steps):
		if solid_at(a.lerp(b, float(i) / steps)):
			return false
	return true

func visibility(eye: Vector3, feet: Vector3) -> float:
	## Fraction (0..1) of a standing figure at `feet` that can be seen from `eye`.
	var dir := feet - eye
	dir.y = 0.0
	if dir.length() < 0.01:
		return 1.0
	var side := Vector3(-dir.z, 0.0, dir.x).normalized() * 0.32
	var pts := [feet + Vector3(0, 1.65, 0), feet + Vector3(0, 1.15, 0), feet + Vector3(0, 0.5, 0),
		feet + Vector3(0, 1.25, 0) + side, feet + Vector3(0, 1.25, 0) - side]
	var seen := 0
	for p in pts:
		if line_clear(eye, p):
			seen += 1
	return seen / 5.0

func can_see_any(eye: Vector3, feet: Vector3) -> bool:
	## Cheap early-out version of visibility() > 0.
	if line_clear(eye, feet + Vector3(0, 1.6, 0)):
		return true
	if line_clear(eye, feet + Vector3(0, 1.1, 0)):
		return true
	return line_clear(eye, feet + Vector3(0, 0.5, 0))

# ---------------------------------------------------------------- graph helpers

func distance_map_to(targets: Array) -> Dictionary:
	## Movement cost from every node to the nearest of `targets` (ignoring units).
	var dist := {}
	var open: Array = []
	for t in targets:
		dist[t] = 0.0
		open.append(t)
	while not open.is_empty():
		var best_i := 0
		for i in range(1, open.size()):
			if dist[open[i]] < dist[open[best_i]]:
				best_i = i
		var cur: int = open[best_i]
		open.remove_at(best_i)
		for e in redges.get(cur, []):
			var nd: float = dist[cur] + e["cost"]
			if nd < dist.get(e["to"], INF):
				dist[e["to"]] = nd
				open.append(e["to"])
	return dist

func connected_count(start: int) -> int:
	var seen := {start: true}
	var stack := [start]
	while not stack.is_empty():
		var cur: int = stack.pop_back()
		for e in edges.get(cur, []):
			if not seen.has(e["to"]):
				seen[e["to"]] = true
				stack.append(e["to"])
	return seen.size()
