class_name WarbandAI
extends RefCounted
## Decides one action at a time for an AI-controlled warband. It only knows
## about enemies its own side has spotted, like a human player.
## next_action() returns a Dictionary the caller hands to execute().

var st: BattleState
var s: int

func _init(state: BattleState, side_index: int) -> void:
	st = state
	s = side_index

func known_enemies() -> Array:
	return st.units.filter(func(o): return o.side != s and o.alive() and st.known(s, o))

func next_action() -> Dictionary:
	if st.over or st.side != s:
		return {"type": "end"}
	var mine: Array = st.side_units(s).filter(func(u): return u.standing() and not u.ai_done)
	var foes := known_enemies()
	mine.sort_custom(func(a, b): return _nearest_dist(a, foes) < _nearest_dist(b, foes))
	for u in mine:
		u.ai_steps += 1
		if u.ai_steps > 8:
			u.ai_done = true
			continue
		var act := _decide(u, foes)
		if act.is_empty():
			u.ai_done = true
			continue
		return act
	return {"type": "end"}

func execute(act: Dictionary) -> Dictionary:
	var u: BUnit = act.get("unit")
	match act["type"]:
		"move":
			return st.move(u, act["node"])
		"dash":
			return st.dash(u)
		"watch":
			return st.watch(u)
		"charge":
			return st.charge(u, act["target"])
		"melee":
			return st.melee(u, act["target"])
		"shoot":
			return st.shoot(u, act["target"])
		"throw":
			return st.throw_munition(u, act["munition"], act["node"])
		"cast":
			return st.cast(u, act["spell"], act["target"])
		"end":
			st.end_turn()
			return {"ok": true}
	return {"ok": false}

func _nearest_dist(u: BUnit, foes: Array) -> float:
	var best := INF
	for e in foes:
		best = min(best, st.dist(u, e))
	return best

func _target_score(u: BUnit, e: BUnit) -> float:
	var sc := 10.0
	if e.status == "stunned":
		sc += 14.0
	elif e.status == "down":
		sc += 9.0
	sc += e.carrying * 6.0
	if e.is_leader():
		sc += 4.0
		if st.scenario.get("headhunt", false):
			sc += 18.0
	if e.id == st.cache_holder:
		# the strongbox walking away
		sc += 22.0
	if st.through_need > 0 and st.zones[s].has(e.node):
		# a raider standing on our ground
		sc += 10.0
	if st.standard_near(e.node) >= 0:
		# one standing at a cairn keeps our standard from going up there
		sc += 8.0
	if not e.spells.is_empty():
		sc += 2.0
	sc -= e.stat("WS") * 1.0
	sc -= (7 - e.armour_save()) * 1.5
	sc -= st.dist(u, e) * 0.05
	return sc

func _decide(u: BUnit, foes: Array) -> Dictionary:
	# 1. already in a fight: strike
	var adj := st.adjacent_enemies(u)
	if not adj.is_empty() and u.ap >= 1:
		var spell_act := _spell_choice(u, foes, true)
		if not spell_act.is_empty():
			return spell_act
		adj.sort_custom(func(a, b): return _target_score(u, a) > _target_score(u, b))
		return {"type": "melee", "unit": u, "target": adj[0]}
	if st.engaged(u):
		return {}
	# 2. magic
	var sp := _spell_choice(u, foes, false)
	if not sp.is_empty():
		return sp
	# 3. munitions
	var th := _throw_choice(u, foes)
	if not th.is_empty():
		return th
	var shooter := u.missile() != "" and u.stat("BS") >= 3
	# 4. charge (not the one carrying the strongbox home, unless the foe holds the way)
	var ct := st.charge_targets(u) if u.id != st.cache_holder else {}
	if not ct.is_empty():
		var best: BUnit = null
		var best_sc := -INF
		for id in ct:
			var e := st.unit_by_id(id)
			var sc := _target_score(u, e)
			if u.has_skill("frenzy"):
				sc = 100.0 - st.dist(u, e)
			if sc > best_sc:
				best_sc = sc
				best = e
		var easy := best.status != "ok"
		var good_shot := shooter and not u.shot and _best_shot(u, foes).size() > 0
		if u.has_skill("frenzy") or easy or not good_shot:
			if not (not u.spells.is_empty() and u.role != "leader" and not easy and st.dist(u, best) > 4.0):
				return {"type": "charge", "unit": u, "target": best}
	# 5. shoot from where we stand
	if shooter and not u.shot:
		var shot := _best_shot(u, foes)
		if not shot.is_empty():
			return shot
	# 6. move
	if u.mp > 0.5 and not u.moved:
		var mv := _move_choice(u, foes, shooter)
		if not mv.is_empty():
			return mv
	# 6b. a shooter with nothing to shoot watches the street instead
	if shooter and not u.shot and u.id != st.cache_holder and st.watch_info(u)["ok"] and not foes.is_empty():
		return {"type": "watch", "unit": u}
	# 7. dash to close distance if nobody can be fought yet
	if not u.dashed and u.ap >= 1 and u.moved and not shooter and u.spells.is_empty() and u.id != st.cache_holder:
		if _nearest_dist(u, foes) > u.mp_full * 1.2 or foes.is_empty():
			return {"type": "dash", "unit": u}
	if u.dashed and u.mp > 0.5 and u.moved:
		var mv2 := _move_choice(u, foes, shooter, true)
		if not mv2.is_empty():
			return mv2
	return {}

func _best_shot(u: BUnit, foes: Array) -> Dictionary:
	var best: BUnit = null
	var best_v := 0.0
	for e in foes:
		var info := st.shot_info(u, e)
		if not info["ok"]:
			continue
		var v: float = info["p"] * (1.5 if e.status != "ok" else 1.0) * (1.4 if e.is_leader() else 1.0) + e.carrying * 0.1
		if v > best_v:
			best_v = v
			best = e
	if best == null or best_v < 0.04:
		return {}
	return {"type": "shoot", "unit": u, "target": best}

func _spell_choice(u: BUnit, foes: Array, in_combat: bool) -> Dictionary:
	if not st.can_cast(u):
		return {}
	for sp in u.spells:
		var targets := st.spell_targets(u, sp)
		if targets.is_empty():
			continue
		match sp:
			"knit":
				for t in targets:
					if t.status == "down" or t.status == "stunned" or t.wounds < t.stat("W"):
						return {"type": "cast", "unit": u, "spell": sp, "target": t}
			"rise":
				var n := 0
				for o in st.units:
					if o.side == s and o.alive() and st.dist(u, o) <= 8.0 and (o.status == "down" or o.status == "stunned"):
						n += 1
				if n >= 1:
					return {"type": "cast", "unit": u, "spell": sp, "target": u}
			"skyfire", "scour", "binding", "starless", "emberfall":
				if in_combat and sp == "binding":
					continue
				var best: BUnit = null
				var bsc := -INF
				for t in targets:
					var sc := _target_score(u, t)
					if sp == "scour":
						for o in st.units:
							if o != t and o.alive() and st.dist(o, t) <= 2.9:
								sc += 6.0 if o.side != s else -12.0
					if sp == "emberfall":
						for o in st.units:
							if o != t and o.alive() and o.side != s and st.dist(o, t) <= 2.9:
								sc += 4.0
					if sp == "binding" and (t.has_fx("bound") or t.status != "ok"):
						sc -= 50.0
					if sp == "starless" and (t.has_fx("blind") or (t.missile() == "" and t.spells.is_empty())):
						sc -= 50.0
					if sc > bsc:
						bsc = sc
						best = t
				if best != null and bsc > -20.0:
					return {"type": "cast", "unit": u, "spell": sp, "target": best}
			"thunderhead", "howl":
				var n := 0
				for e in foes:
					if e.standing() and st.dist(u, e) <= 5.0:
						n += 1
				if n >= 2 or (n >= 1 and in_combat):
					return {"type": "cast", "unit": u, "spell": sp, "target": u}
			"ward", "paingift", "nightedge", "ancestors":
				var fxk := {"ward": "ward", "paingift": "attack", "nightedge": "strength", "ancestors": "toughness"}[sp] as String
				for t in targets:
					if not st.adjacent_enemies(t, true).is_empty() and not t.has_fx(fxk):
						return {"type": "cast", "unit": u, "spell": sp, "target": t}
				if sp == "paingift" and not in_combat:
					for t in targets:
						if not st.charge_targets(t).is_empty() and t.ap >= 1 and not t.has_fx("attack"):
							return {"type": "cast", "unit": u, "spell": sp, "target": t}
			"veil", "shroud":
				var shooters := foes.filter(func(e): return e.missile() != "")
				if not shooters.is_empty() and not in_combat:
					var t = targets[0]
					if sp == "shroud":
						t = null
						for cand in targets:
							if cand.is_leader():
								t = cand
						if t == null:
							continue
					if not t.has_fx(sp):
						return {"type": "cast", "unit": u, "spell": sp, "target": t}
	return {}

func _throw_choice(u: BUnit, foes: Array) -> Dictionary:
	if not u.has_munitions() or u.ap < 1 or st.engaged(u):
		return {}
	var best := {}
	var best_v := 0.9
	for mun in u.munitions:
		if int(u.munitions[mun]) <= 0:
			continue
		var md := GameData.munition(mun)
		for e in foes:
			var info := st.throw_info(u, mun, e.node)
			if not info["ok"]:
				continue
			var v := 1.0
			var centre := st.pos(e)
			if int(md.get("blast", 0)) > 0:
				for o in st.units:
					if o == e or not o.alive():
						continue
					if st.pos(o).distance_to(centre) <= md["blast"] * st.map.cell * 1.45:
						v += 1.0 if o.side != s else -2.0
			else:
				v += 0.3
			v *= Rules.p_success(info["need"])
			if mun == "cusser":
				v -= 0.4  # save the big one for a crowd
			if v > best_v:
				best_v = v
				best = {"type": "throw", "unit": u, "munition": mun, "node": e.node}
	return best

func _goal_nodes(u: BUnit, foes: Array) -> Array:
	var goals: Array = []
	if st.scenario.get("cache", false):
		if u.id == st.cache_holder:
			# home, with the box
			return st.zones[s].keys()
		for nd in st.cache_spots:
			goals.append(nd)
		if st.cache_node >= 0:
			goals.append(st.cache_node)
		var h := st.cache_holder_unit()
		if h != null:
			for nd in st.map.adjacent.get(h.node, []):
				goals.append(nd)
			if h.side != s:
				# cut them off on the way to their own ground
				for nd in st.zones[1 - s]:
					goals.append(nd)
	for e in foes:
		for nd in st.map.adjacent.get(e.node, []):
			goals.append(nd)
	for nd in st.shard_nodes:
		goals.append(nd)
	for c in st.standards:
		# the cairns: those without our standard, the way in from every side
		if st.standards[c] != s:
			goals.append(c)
			for nd in st.map.adjacent.get(c, []):
				goals.append(nd)
	if st.hold_radius > 0.0:
		# the ring: get into it, and more so as night comes on
		for nd in _ring_nodes():
			goals.append(nd)
	if st.through_need > 0:
		# through their lines: the enemy's starting ground
		for nd in st.zones[1 - s]:
			goals.append(nd)
	if goals.is_empty():
		# hunt: last known positions, then the middle of the square
		for id in st.last_seen[s]:
			goals.append(st.last_seen[s][id])
		if goals.is_empty():
			var c := st.map.top_node(st.map.w / 2, st.map.d / 2 - 2)
			for dz in range(-4, 5):
				for dx in range(-4, 5):
					var nd := st.map.top_node(st.map.w / 2 + dx, st.map.d / 2 + dz)
					if nd >= 0:
						goals.append(nd)
			if c >= 0:
				goals.append(c)
	return goals

var _ring_cache: Array = []

func _ring_nodes() -> Array:
	if _ring_cache.is_empty():
		for id in st.map.nodes:
			var p := st.map.node_pos(id)
			if Vector2(p.x, p.z).distance_to(Vector2(st.objective.x, st.objective.z)) <= st.hold_radius - 0.5:
				_ring_cache.append(id)
	return _ring_cache

func _in_ring_at(nd: int) -> bool:
	var p := st.map.node_pos(nd)
	return Vector2(p.x, p.z).distance_to(Vector2(st.objective.x, st.objective.z)) <= st.hold_radius - 0.3

func _move_choice(u: BUnit, foes: Array, shooter: bool, second := false) -> Dictionary:
	var reach := st.reachable(u)
	if reach.size() <= 1:
		return {}
	var goals := _goal_nodes(u, foes)
	var dmap := st.map.distance_map_to(goals)
	var here: float = dmap.get(u.node, 999.0)
	var best := -1
	var best_sc := -INF
	var enemy_shooters := foes.filter(func(e): return e.missile() != "" and e.standing())
	for nd in reach:
		if nd == u.node:
			continue
		var info: Dictionary = reach[nd]
		var dgoal: float = dmap.get(nd, 999.0)
		var sc := (here - dgoal) * 1.0
		if st.shard_nodes.has(nd):
			sc += 25.0
		if st.cache_spots.has(nd):
			sc += 34.0
		if st.omen_node >= 0:
			# keep out from under the falling shard
			if st.in_fall_zone(nd):
				sc -= 14.0
			elif st.in_fall_zone(u.node):
				sc += 10.0
		if nd == st.cache_node:
			sc += 40.0
		if u.id == st.cache_holder and st.zones[s].has(nd):
			sc += 60.0
		if st.through_need > 0:
			var late2 := float(st.round_num) / float(st.turn_limit)
			if st.zones[1 - s].has(nd):
				sc += 6.0 + late2 * 8.0
			elif st.zones[1 - s].has(u.node):
				sc -= 8.0 + late2 * 10.0
		if not st.standards.is_empty():
			var late3 := float(st.round_num) / float(st.turn_limit)
			var c_to := st.standard_near(nd)
			var c_at := st.standard_near(u.node)
			if c_at >= 0 and c_to != c_at and st.standards[c_at] != s:
				# about to raise it here: don't wander off
				sc -= 18.0
			elif c_to >= 0 and st.standards[c_to] != s:
				sc += 16.0 + late3 * 10.0
			elif c_at >= 0 and c_to != c_at and st.standards[c_at] == s and st.at_cairn(s, c_at).size() <= 1:
				# the last guard on our own standard stays put
				sc -= 7.0 + late3 * 6.0
		if st.hold_radius > 0.0:
			var late := float(st.round_num) / float(st.turn_limit)
			if _in_ring_at(nd):
				sc += 3.0 + late * 10.0
			elif _in_ring_at(u.node):
				sc -= 3.0 + late * 12.0
		var p := st.map.node_pos(nd)
		if shooter and not u.shot:
			var shots := 0
			for e in foes:
				var dd := (p + Vector3(0, 1.6, 0)).distance_to(st.pos(e) + Vector3(0, 1.1, 0))
				var wd := GameData.weapon(u.missile())
				if dd <= float(wd.get("range", 20)) and st.map.can_see_any(p + Vector3(0, 1.6, 0), st.pos(e)):
					shots += 1
			sc += min(shots, 2) * 9.0
			sc += st.map.node_level(nd) * 2.0
			if shots == 0:
				sc = sc * 1.0
		# exposure to enemy shooters
		var exposure := 0
		for e in enemy_shooters:
			if st.eye(e).distance_to(p) < 30.0 and st.map.can_see_any(st.eye(e), p):
				exposure += 1
		sc -= exposure * (1.5 if shooter else 0.8)
		if info["kind"] == "jump" or (info["kind"] == "drop" and not (int(info["levels"]) <= 1 and st.map.is_wet(nd))):
			sc -= 2.5
		if u.is_leader() and st.scenario.get("headhunt", false):
			# a leader whose fall loses the battle keeps out of reach
			sc -= exposure * 2.0
			var near := 999.0
			for e in foes:
				near = min(near, p.distance_to(st.pos(e)))
			if near < 9.0:
				sc -= (9.0 - near) * 0.8
		sc -= info["cost"] * 0.05
		if sc > best_sc:
			best_sc = sc
			best = nd
	if best < 0 or (best_sc <= 0.2 and not second and not foes.is_empty() and not shooter):
		if best < 0:
			return {}
	if best_sc < -5.0:
		return {}
	return {"type": "move", "unit": u, "node": best}
