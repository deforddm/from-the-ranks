class_name Rules
extends RefCounted
## The dice arithmetic of the stat-line engine: to-hit, to-wound, saves.
## Pure functions, so the AI and the interface can show odds.

static func melee_to_hit(ws_attacker: int, ws_defender: int) -> int:
	if ws_attacker > ws_defender:
		return 3
	if ws_defender > ws_attacker * 2:
		return 5
	return 4

static func ranged_to_hit(bs: int) -> int:
	return 7 - bs

static func to_wound(strength: int, toughness: int) -> int:
	## Roll needed on a D6 to wound, or 0 if it cannot be done.
	var diff := strength - toughness
	if diff >= 2:
		return 2
	match diff:
		1:
			return 3
		0:
			return 4
		-1:
			return 5
		-2:
			return 6
	return 0

static func p_success(needed: int) -> float:
	## Chance of rolling `needed` or more on a D6 (a 1 always fails).
	if needed <= 0:
		return 0.0
	if needed <= 2:
		return 5.0 / 6.0
	if needed > 6:
		return 0.0
	return (7 - needed) / 6.0

static func p_ranged_hit(needed: int) -> float:
	## A 7+ is still possible: roll a 6, then a 4+.
	if needed == 7:
		return 1.0 / 12.0
	return p_success(needed)

static func save_needed(armour_save: int, strength: int, weapon_save_mod: int) -> int:
	## armour_save is the unmodified save (7 = none). Returns 7+ when no save.
	var need: int = armour_save + maxi(0, strength - 3) + weapon_save_mod
	return clampi(need, 2, 7)

static func p_unsaved(save_need: int) -> float:
	if save_need >= 7:
		return 1.0
	return 1.0 - p_success(save_need)
