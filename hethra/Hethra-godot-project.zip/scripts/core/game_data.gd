class_name GameData
extends RefCounted
## Loads the JSON data files (rules, warbands, maps) once and caches them.

static var _rules: Dictionary = {}
static var _warbands: Dictionary = {}
static var _maps: Dictionary = {}

const WARBAND_IDS := ["marines", "chained", "whirlwind", "seguleh", "andii", "barghast", "imass"]
const MAP_IDS := ["hethra_square", "causeway", "tower_ward", "starfall", "sleeper", "drowned", "azath"]
const SCENARIO_IDS := ["shards", "brawl", "hold", "headhunt", "breakthrough", "cache"]
static var _scenarios: Dictionary = {}

static func scenario(id: String) -> Dictionary:
	if _scenarios.is_empty():
		_scenarios = load_json("res://data/scenarios.json")
	return _scenarios.get(id, _scenarios["shards"])

static func load_json(path: String) -> Variant:
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		push_error("Cannot open " + path)
		return null
	var txt := f.get_as_text()
	var data = JSON.parse_string(txt)
	if data == null:
		push_error("Bad JSON in " + path)
	return data

static func rules() -> Dictionary:
	if _rules.is_empty():
		_rules = load_json("res://data/rules.json")
	return _rules

static func warband(id: String) -> Dictionary:
	if not _warbands.has(id):
		_warbands[id] = load_json("res://data/warbands/%s.json" % id)
	return _warbands[id]

static func map_data(id: String) -> Dictionary:
	if not _maps.has(id):
		_maps[id] = load_json("res://data/maps/%s.json" % id)
	return _maps[id]

static func weapon(id: String) -> Dictionary:
	return rules()["weapons"].get(id, {})

static func armour(id: String) -> Dictionary:
	return rules()["armour"].get(id, {})

static func spell(id: String) -> Dictionary:
	return rules()["spells"].get(id, {})

static func munition(id: String) -> Dictionary:
	return rules()["munitions"].get(id, {})

static func skill_name(id: String) -> String:
	return rules()["skills"].get(id, {}).get("name", id)

static func item_name(id: String) -> String:
	var r := rules()
	if r["weapons"].has(id):
		return r["weapons"][id]["name"]
	if r["armour"].has(id):
		return r["armour"][id]["name"]
	if r["munitions"].has(id):
		return r["munitions"][id]["name"]
	return id
