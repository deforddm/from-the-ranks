class_name BUnit
extends RefCounted
## One fighter on the battlefield: stat line, kit, wounds and state for the turn.

var id: int = 0
var uid: int = -1                # the campaign fighter this is, or -1
var side: int = 0
var name: String = ""
var unit_type: String = ""
var type_name: String = ""
var role: String = "henchman"
var faction: String = ""
var body: String = "soldier"
var helm: String = "none"
var base: Dictionary = {}
var gear: Array = []
var skills: Array = []
var munitions: Dictionary = {}
var spells: Array = []
var warren: String = ""

var node: int = -1
var wounds: int = 1
var status: String = "ok"      # ok, down, stunned, ooa
var mp: float = 0.0
var mp_full: float = 0.0
var ap: int = 0
var moved := false
var charged := false
var shot := false
var cast := false
var dashed := false
var rose := false
var fx: Array = []             # [{"kind": String, "value": int, "expire": int}]
var carrying: int = 0
var kills: int = 0
var ooa_by: int = -1
var rival := false              # the enemy leader who remembers your band (campaign)
var lucky_used := false
var ai_done := false
var ai_steps := 0

func setup_from(def: Dictionary, wb: Dictionary, entry: Dictionary) -> void:
	unit_type = entry["unit"]
	name = entry.get("name", def["name"])
	rival = bool(entry.get("rival", false))
	type_name = def["name"]
	role = def.get("role", "henchman")
	faction = wb["id"]
	body = def.get("body", "soldier")
	helm = def.get("helm", "none")
	base = def["stats"].duplicate()
	for k in base:
		base[k] = int(base[k])
	gear = def.get("gear", []).duplicate()
	skills = def.get("skills", []).duplicate()
	munitions = {}
	for k in def.get("munitions", {}):
		munitions[k] = int(def["munitions"][k])
	var warrens: Array = def.get("warrens", [])
	if not warrens.is_empty():
		var w: String = entry.get("warren", "")
		warren = w if warrens.has(w) else warrens[0]
		spells = GameData.rules()["warrens"][warren]["spells"].duplicate()
	# a campaign fighter brings their own stat line, kit and skills
	uid = int(entry.get("uid", -1))
	if entry.has("stats"):
		for k in entry["stats"]:
			base[k] = int(entry["stats"][k])
	if entry.has("gear"):
		gear = (entry["gear"] as Array).duplicate()
	if entry.has("skills"):
		skills = (entry["skills"] as Array).duplicate()
	if entry.has("munitions"):
		munitions = {}
		for k in entry["munitions"]:
			munitions[k] = int(entry["munitions"][k])
	if entry.has("role"):
		role = entry["role"]
	wounds = base["W"]

func is_leader() -> bool:
	return role == "leader"

func is_hero() -> bool:
	return role == "leader" or role == "hero"

func has_skill(s: String) -> bool:
	return skills.has(s)

func fx_total(kind: String) -> int:
	var t := 0
	for f in fx:
		if f["kind"] == kind:
			t += int(f.get("value", 1))
	return t

func has_fx(kind: String) -> bool:
	for f in fx:
		if f["kind"] == kind:
			return true
	return false

func stat(k: String) -> int:
	var v: int = base.get(k, 0)
	if k == "M" and has_skill("fleet"):
		v += 1
	if k == "A":
		v += fx_total("attack")
	if k == "S":
		v += fx_total("strength")
	if k == "T":
		v += fx_total("toughness")
	if k == "WS":
		v = maxi(1, v + fx_total("ws"))
	return v

func standing() -> bool:
	return status == "ok"

func alive() -> bool:
	return status != "ooa"

func melee_weapons() -> Array:
	var out: Array = []
	for g in gear:
		var wd := GameData.weapon(g)
		if wd.get("kind", "") == "melee":
			out.append(g)
	if out.is_empty():
		out.append("fist")
	return out

func best_melee_weapon() -> String:
	var best := ""
	var best_score := -99
	for g in melee_weapons():
		var wd := GameData.weapon(g)
		var score: int = int(wd.get("str", 0)) * 3 + int(wd.get("save_mod", 0)) * 2 + (1 if wd.get("concuss", false) else 0)
		if score > best_score:
			best_score = score
			best = g
	return best

func can_parry() -> bool:
	for g in gear:
		if GameData.weapon(g).get("parry", false):
			return true
	return false

func dual_wield() -> bool:
	var count := 0
	for g in gear:
		var wd := GameData.weapon(g)
		if wd.get("kind", "") == "melee" and not wd.get("two_handed", false):
			count += 1
	return count >= 2 and not gear.has("shield")

func missile() -> String:
	for g in gear:
		if GameData.weapon(g).get("kind", "") == "missile":
			return g
	return ""

func armour_save() -> int:
	var s := 7
	if gear.has("heavy"):
		s = 5
	elif gear.has("light"):
		s = 6
	if gear.has("shield"):
		s -= 1
	s -= fx_total("ward")
	return s

func has_munitions() -> bool:
	if not has_skill("munitions"):
		return false
	for k in munitions:
		if munitions[k] > 0:
			return true
	return false

func eye_offset() -> Vector3:
	return Vector3(0, 1.6, 0)

func summary_stats() -> String:
	return "M%d WS%d BS%d S%d T%d W%d I%d A%d Ld%d" % [stat("M"), stat("WS"), stat("BS"), stat("S"), stat("T"), stat("W"), stat("I"), stat("A"), stat("Ld")]
