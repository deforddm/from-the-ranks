class_name Dice
extends RefCounted
## Seeded dice for the rules engine. Every roll in a battle goes through one
## Dice object, so a battle can be replayed from its seed.

var rng := RandomNumberGenerator.new()

func _init(seed_value: int = 0) -> void:
	if seed_value == 0:
		rng.randomize()
	else:
		rng.seed = seed_value

func d6() -> int:
	return rng.randi_range(1, 6)

func d3() -> int:
	return rng.randi_range(1, 3)

func roll2d6() -> int:
	return d6() + d6()

func d66() -> int:
	return d6() * 10 + d6()

func chance(p: float) -> bool:
	return rng.randf() < p

func randf() -> float:
	return rng.randf()

func pick(arr: Array):
	if arr.is_empty():
		return null
	return arr[rng.randi_range(0, arr.size() - 1)]

func shuffle(arr: Array) -> void:
	for i in range(arr.size() - 1, 0, -1):
		var j := rng.randi_range(0, i)
		var t = arr[i]
		arr[i] = arr[j]
		arr[j] = t
