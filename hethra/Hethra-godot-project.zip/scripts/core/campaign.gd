class_name Campaign
extends RefCounted
## A warband's life between battles: its fighters (with their experience,
## advances and scars), its purse and godshards, hiring, the armoury, and what
## happens after each fight. Pure data and rules, so it can be tested headless
## and saved as JSON.

const SAVE_DIR := "user://campaigns"

var id := ""                 # save file name
var faction := "marines"
var name := ""
var gold := 0
var shards := 0
var battles := 0
var wins := 0
var losses := 0
var fighters: Array = []     # Array of Dictionary, see _fighter_from_def
var fallen: Array = []       # [{"name", "type", "battle", "how"}]
var history: Array = []      # one line per battle
var next_uid := 1
var rng_state := 0
var last_report: Dictionary = {}
var sitting_out: Array = []  # uids kept out of the coming battle
var pending_event: Dictionary = {}  # the night after a battle, waiting for a choice
var recent_events: Array = []       # ids of the last few nights, so they don't repeat
var created := 0
var updated := 0

var rng := RandomNumberGenerator.new()

static var _data: Dictionary = {}

static func data() -> Dictionary:
	if _data.is_empty():
		_data = GameData.load_json("res://data/campaign.json")
	return _data

# ------------------------------------------------------------------ creation

static func create(faction_id: String, warband_name: String = "", seed_value := 0) -> Campaign:
	var c := Campaign.new()
	c.faction = faction_id
	var wb := GameData.warband(faction_id)
	c.rng.seed = seed_value if seed_value != 0 else int(Time.get_unix_time_from_system() * 1000.0) % 2147483647
	c.created = int(Time.get_unix_time_from_system())
	c.id = "%s_%d" % [faction_id, c.created % 10000000]
	var spent := 0
	for entry in wb["battle_roster"]:
		var def: Dictionary = wb["units"][entry["unit"]]
		var f := c._fighter_from_def(entry["unit"], def, entry.get("name", def["name"]))
		if entry.has("warren"):
			f["warren"] = entry["warren"]
		c.fighters.append(f)
		spent += int(def["cost"])
	var d := data()
	c.gold = maxi(int(d["min_purse"]), int(d["starting_purse"]) - spent)
	c.name = warband_name if warband_name != "" else c._default_name()
	return c

func _default_name() -> String:
	var leader = leader_fighter()
	var who: String = leader["name"].split(" ")[-1] if leader != null else "Nobody"
	match faction:
		"marines":
			return "%s's Squad" % who
		"chained":
			return "The Flock of %s" % who
		"whirlwind":
			return "%s's Sworn" % who
		"seguleh":
			return "The Blades of %s" % who
		"andii":
			return "%s's Night" % who
		"barghast":
			return "%s's Clan" % who
		"imass":
			return "The Dust of %s" % who
	return "%s's Band" % who

func _fighter_from_def(unit_type: String, def: Dictionary, fname: String) -> Dictionary:
	var stats := {}
	for k in def["stats"]:
		stats[k] = int(def["stats"][k])
	var mun := {}
	for k in def.get("munitions", {}):
		mun[k] = int(def["munitions"][k])
	var f := {
		"uid": next_uid,
		"unit": unit_type,
		"name": fname,
		"role": def.get("role", "henchman"),
		"warren": (def.get("warrens", [""]) as Array)[0] if def.has("warrens") else "",
		"stats": stats,
		"gear": (def.get("gear", []) as Array).duplicate(),
		"skills": (def.get("skills", []) as Array).duplicate(),
		"munitions": mun,
		"xp": int(def.get("xp", 0)),
		"injuries": [],
		"miss_next": false,
		"old_wound": false,
		"kills": 0,
		"battles": 0,
		"pending": [],
		"promoted": false,
	}
	next_uid += 1
	return f

# ------------------------------------------------------------------ queries

func warband() -> Dictionary:
	return GameData.warband(faction)

func unit_def(f: Dictionary) -> Dictionary:
	return warband()["units"][f["unit"]]

func type_name(f: Dictionary) -> String:
	var n: String = unit_def(f)["name"]
	if f.get("promoted", false):
		n += " (risen)"
	return n

func fighter(uid: int) -> Dictionary:
	for f in fighters:
		if int(f["uid"]) == uid:
			return f
	return {}

func leader_fighter():
	for f in fighters:
		if f["role"] == "leader":
			return f
	return null

func hero_count() -> int:
	return fighters.filter(func(f): return f["role"] != "henchman").size()

func is_caster(f: Dictionary) -> bool:
	return String(f.get("warren", "")) != ""

func rating() -> int:
	var per := int(data()["rating_per_fighter"])
	var r := 0
	for f in fighters:
		r += per + int(f["xp"])
	return r

func caps() -> Dictionary:
	return warband()["caps"]

func xp_track(f: Dictionary) -> Array:
	return data()["hero_xp"] if f["role"] != "henchman" else data()["henchman_xp"]

func next_advance_at(f: Dictionary) -> int:
	for t in xp_track(f):
		if int(t) > int(f["xp"]):
			return int(t)
	return -1

func prev_advance_at(f: Dictionary) -> int:
	var p := 0
	for t in xp_track(f):
		if int(t) <= int(f["xp"]):
			p = int(t)
	return p

func pending_count() -> int:
	var n := 0
	for f in fighters:
		n += (f["pending"] as Array).size()
	return n

func coin_word() -> String:
	return String(data()["currency"])

# ------------------------------------------------------------------ battle

func prepare_battle() -> Array:
	## Rolls for old wounds and works out who sits this one out. Returns lines to show.
	sitting_out.clear()
	var lines: Array = []
	for f in fighters:
		if f["miss_next"]:
			sitting_out.append(int(f["uid"]))
			lines.append("%s is still healing and sits this one out." % f["name"])
		elif f["old_wound"]:
			var r := rng.randi_range(1, 6)
			if r == 1:
				sitting_out.append(int(f["uid"]))
				lines.append("%s's old wound opens again (rolled 1). They stay behind." % f["name"])
	return lines

func battle_roster() -> Array:
	var out: Array = []
	for f in fighters:
		if sitting_out.has(int(f["uid"])):
			continue
		out.append(entry_for(f))
	if out.is_empty() and not fighters.is_empty():
		out.append(entry_for(fighters[0]))
	return out

func entry_for(f: Dictionary) -> Dictionary:
	return {
		"unit": f["unit"], "name": f["name"], "uid": int(f["uid"]), "warren": f["warren"],
		"role": f["role"], "stats": (f["stats"] as Dictionary).duplicate(),
		"gear": (f["gear"] as Array).duplicate(), "skills": (f["skills"] as Array).duplicate(),
		"munitions": (f["munitions"] as Dictionary).duplicate(),
	}

static func roster_rating(entries: Array, wb: Dictionary) -> int:
	var r := 0
	for e in entries:
		r += int(data()["rating_per_fighter"]) + int(e.get("xp", wb["units"][e["unit"]].get("xp", 0)))
	return r

func enemy_roster(enemy_id: String) -> Dictionary:
	## Builds a foe of about the same strength: their usual band, then more
	## fighters and veteran heroes until their rating matches ours.
	var wb := GameData.warband(enemy_id)
	var entries: Array = []
	var used: Dictionary = {}
	for e in wb["battle_roster"]:
		var def: Dictionary = wb["units"][e["unit"]]
		var en := {"unit": e["unit"], "name": e["name"], "xp": int(def.get("xp", 0)), "stats": (def["stats"] as Dictionary).duplicate()}
		if e.has("warren"):
			en["warren"] = e["warren"]
		entries.append(en)
		used[e["name"]] = true
	var target := rating()
	var henchmen: Array = []
	for k in wb["units"]:
		if wb["units"][k]["role"] == "henchman":
			henchmen.append(k)
	var guard := 0
	var heroes_raised := 0
	while roster_rating(entries, wb) < target - 6 and guard < 60:
		guard += 1
		var add_body := entries.size() < mini(int(wb["max_size"]), 14) and (heroes_raised >= 2 or rng.randf() < 0.45)
		if add_body and not henchmen.is_empty():
			var k: String = henchmen[rng.randi_range(0, henchmen.size() - 1)]
			var def: Dictionary = wb["units"][k]
			var nm := _fresh_name(wb, used)
			entries.append({"unit": k, "name": nm, "xp": 0, "stats": (def["stats"] as Dictionary).duplicate()})
			heroes_raised = 0
		else:
			# a veteran: one of their heroes has an advance
			var heroes: Array = entries.filter(func(e): return wb["units"][e["unit"]]["role"] != "henchman")
			var h: Dictionary = heroes[rng.randi_range(0, heroes.size() - 1)]
			var pairs: Array = [["WS", "BS"], ["S", "A"], ["I", "Ld"], ["W", "T"], ["WS", "A"]]
			var pick: Array = pairs[rng.randi_range(0, pairs.size() - 1)]
			var st: String = pick[rng.randi_range(0, pick.size() - 1)]
			if int(h["stats"][st]) < int(wb["caps"][st]):
				h["stats"][st] = int(h["stats"][st]) + 1
			h["xp"] = int(h["xp"]) + 5
			heroes_raised += 1
	return {"entries": entries, "rating": roster_rating(entries, wb)}

func _fresh_name(wb: Dictionary, used: Dictionary) -> String:
	## A name nobody in the band (or among the fallen) carries, ranks aside.
	var taken := {}
	for k in used:
		taken[String(k).get_slice(" ", String(k).get_slice_count(" ") - 1)] = true
	for f in fighters + fallen:
		var n := String(f["name"])
		taken[n.get_slice(" ", n.get_slice_count(" ") - 1)] = true
	var pool: Array = (wb.get("names", []) as Array).filter(func(n): return not taken.has(n) and not used.has(n))
	var nm := ""
	if not pool.is_empty():
		nm = pool[rng.randi_range(0, pool.size() - 1)]
	else:
		# the lists ran dry: stitch a new name from the front of one and the back of another
		var all: Array = wb.get("names", [])
		for _try in range(40):
			if all.size() < 2:
				break
			var a := String(all[rng.randi_range(0, all.size() - 1)]).get_slice(" ", 0).replace("'", "")
			var b := String(all[rng.randi_range(0, all.size() - 1)]).get_slice(" ", 0).replace("'", "")
			var cand := a.substr(0, maxi(2, ceili(a.length() * 0.5))) + b.substr(b.length() / 2).to_lower()
			if cand.length() >= 4 and not taken.has(cand) and not used.has(cand):
				nm = cand
				break
		if nm == "":
			nm = "%s %d" % [wb["short"], used.size() + 1]
	used[nm] = true
	return nm

# ------------------------------------------------------------------ aftermath

static func result_from_battle(st: BattleState, my_side: int, enemy_id: String, enemy_rating: int) -> Dictionary:
	## What a finished battle meant for the campaign side.
	var fs := {}
	for u in st.side_units(my_side):
		if u.uid < 0:
			continue
		fs[str(u.uid)] = {"status": u.status, "kills": u.kills, "carrying": u.carrying, "munitions": u.munitions.duplicate()}
	return {"won": st.winner == my_side, "draw": st.winner == -2, "enemy": enemy_id, "enemy_rating": enemy_rating,
		"field_shards": st.shard_nodes.size(), "fighters": fs, "rounds": st.round_num, "reason": st.end_reason,
		"strongbox": st.scenario.get("cache", false) and st.cache_side() == my_side}

func apply_result(res: Dictionary) -> Dictionary:
	## res: {"won": bool, "draw": bool, "enemy": id, "enemy_rating": int,
	##       "field_shards": int, "fighters": {uid(str): {"status", "kills", "carrying", "munitions"}}}
	var rep := {"won": res.get("won", false), "draw": res.get("draw", false), "enemy": res.get("enemy", ""),
		"injuries": [], "xp": [], "search": {}, "shards_found": 0, "coins_found": 0, "lines": [], "fallen": [], "leader": ""}
	battles += 1
	if rep["won"]:
		wins += 1
	elif not rep["draw"]:
		losses += 1
	var took: Dictionary = res.get("fighters", {})
	var underdog := 0
	var er := int(res.get("enemy_rating", 0))
	if er - rating() >= 20:
		underdog = 1 + (er - rating() - 20) / int(data()["underdog_per_rating"])
	# those who sat out are healed now
	for f in fighters:
		if not took.has(str(f["uid"])):
			f["miss_next"] = false
	# 1. the wounded
	var dead: Array = []
	for f in fighters:
		var r: Dictionary = took.get(str(f["uid"]), {})
		if r.is_empty():
			continue
		f["battles"] = int(f["battles"]) + 1
		f["kills"] = int(f["kills"]) + int(r.get("kills", 0))
		f["miss_next"] = false
		if r.has("munitions"):
			var m := {}
			for k in r["munitions"]:
				m[k] = int(r["munitions"][k])
			f["munitions"] = m
		if r.get("status", "ok") != "ooa":
			continue
		var inj := _roll_injury(f)
		rep["injuries"].append(inj)
		if inj["id"] == "dead":
			dead.append(f)
	# 2. experience for those who walked away
	for f in fighters:
		var r: Dictionary = took.get(str(f["uid"]), {})
		if r.is_empty() or dead.has(f):
			continue
		var gain := 1
		var why: Array = ["survived"]
		var k := int(r.get("kills", 0))
		if k > 0:
			gain += k
			why.append("%d out of action" % k)
		if f["role"] == "leader" and rep["won"]:
			gain += 1
			why.append("led the win")
		if int(r.get("carrying", 0)) > 0 and r.get("status", "ok") != "ooa":
			gain += 1
			why.append("brought back a shard")
		if underdog > 0:
			gain += underdog
			why.append("faced stronger foes")
		var before := int(f["xp"])
		f["xp"] = before + gain
		var adv := _check_advances(f, before)
		rep["xp"].append({"uid": f["uid"], "name": f["name"], "gain": gain, "why": why, "xp": f["xp"], "advances": adv})
	# 3. the dead
	for f in dead:
		fallen.append({"name": f["name"], "type": type_name(f), "battle": battles, "kills": f["kills"]})
		rep["fallen"].append(f["name"])
		fighters.erase(f)
	# 4. a new leader if needed
	if leader_fighter() == null and not fighters.is_empty():
		var best = null
		for f in fighters:
			if best == null or _lead_score(f) > _lead_score(best):
				best = f
		best["role"] = "leader"
		if not (best["skills"] as Array).has("nerve"):
			pass
		rep["leader"] = best["name"]
		rep["lines"].append("%s takes command of the warband." % best["name"])
	# 5. spoils
	var sh := 0
	for f in fighters:
		var r: Dictionary = took.get(str(f["uid"]), {})
		if not r.is_empty() and r.get("status", "ok") != "ooa":
			sh += int(r.get("carrying", 0))
	if rep["won"]:
		var extra := int(res.get("field_shards", 0)) / 2
		if extra > 0:
			rep["lines"].append("With the field yours, you gather %d more godshard%s from the rubble." % [extra, "" if extra == 1 else "s"])
		sh += extra
	var searchers: Array = fighters.filter(func(f): return f["role"] != "henchman" and took.has(str(f["uid"])) and took[str(f["uid"])].get("status", "ok") != "ooa")
	var dice: Array = []
	for f in searchers:
		dice.append(rng.randi_range(1, 6))
	var counts := {}
	var pips := 0
	for d in dice:
		counts[d] = int(counts.get(d, 0)) + 1
		pips += int(d)
	var found := 0
	for face in counts:
		if counts[face] >= 2:
			found += counts[face] - 1
	var coins := pips * int(data()["search_coin_per_pip"])
	rep["search"] = {"dice": dice, "who": searchers.map(func(f): return f["name"]), "coins": coins, "shards": found}
	shards += sh + found
	gold += coins
	rep["shards_found"] = sh + found
	if res.get("strongbox", false):
		var box := 60 + rng.randi_range(0, 4) * 10
		rep["lines"].append("The paymaster's strongbox is yours. Prised open, it holds %d jakatas." % box)
		gold += box
		coins += box
	rep["coins_found"] = coins
	# 6. stragglers: a band down to a handful draws in hungry blades who
	# will fight for a share, so a run of bad nights never ends the story
	var wbd := warband()
	var cheapest := ""
	for ut in wbd["units"]:
		var ud: Dictionary = wbd["units"][ut]
		if ud["role"] == "henchman" and (cheapest == "" or int(ud["cost"]) < int(wbd["units"][cheapest]["cost"])):
			cheapest = ut
	var joined: Array = []
	while cheapest != "" and fighters.size() < int(data().get("straggler_floor", 5)) and fighters.size() < int(wbd["max_size"]):
		var nf := _fighter_from_def(cheapest, wbd["units"][cheapest], _fresh_name(wbd, {}))
		nf["xp"] = 0
		fighters.append(nf)
		joined.append(nf["name"])
	if not joined.is_empty():
		rep["lines"].append("Word goes round the ruins that your band pays in shards. %s join%s you for a share." % [" and ".join(joined) if joined.size() <= 2 else ", ".join(joined.slice(0, joined.size() - 1)) + " and " + joined[-1], "s" if joined.size() == 1 else ""])
	var res_word := "won" if rep["won"] else ("drew" if rep["draw"] else "lost")
	history.append("Battle %d: %s against the %s. %s" % [battles, res_word, GameData.warband(rep["enemy"])["name"] if rep["enemy"] != "" else "foe",
		("Lost " + ", ".join(rep["fallen"]) + ".") if not rep["fallen"].is_empty() else "No one lost."])
	sitting_out.clear()
	pending_event = _draw_event() if not fighters.is_empty() else {}
	rep["event"] = not pending_event.is_empty()
	last_report = rep
	return rep

# ------------------------------------------------------------------ the night after

static var _events: Array = []

static func events() -> Array:
	if _events.is_empty():
		_events = GameData.load_json("res://data/events.json")["events"]
	return _events

static func event_def(eid: String) -> Dictionary:
	for e in events():
		if e["id"] == eid:
			return e
	return {}

func _room() -> bool:
	return fighters.size() < int(warband()["max_size"])

func _draw_event() -> Dictionary:
	var pool: Array = []
	for e in events():
		if recent_events.has(e["id"]):
			continue
		var needs: Dictionary = e.get("needs", {})
		if needs.get("room", false) and not _room():
			continue
		if shards < int(needs.get("shards_min", 0)):
			continue
		pool.append(e)
	if pool.is_empty():
		return {}
	var e: Dictionary = pool[rng.randi_range(0, pool.size() - 1)]
	recent_events.append(e["id"])
	while recent_events.size() > 4:
		recent_events.remove_at(0)
	var who = null
	var want: String = e.get("who", "")
	if want != "":
		var cands: Array = fighters.filter(func(f): return want == "any" \
			or (want == "hero" and f["role"] != "henchman") or (want == "henchman" and f["role"] == "henchman"))
		if cands.is_empty():
			cands = fighters
		who = cands[rng.randi_range(0, cands.size() - 1)]
	return {"id": e["id"], "who_uid": int(who["uid"]) if who != null else -1}

func event_text(s: String, extra := {}) -> String:
	var who := fighter(int(pending_event.get("who_uid", -1)))
	var lname := "the band"
	for f in fighters:
		if f["role"] == "leader":
			lname = f["name"]
	s = s.replace("{who}", String(who.get("name", "the watch")))
	s = s.replace("{leader}", lname)
	for k in extra:
		s = s.replace("{%s}" % k, str(extra[k]))
	return s

func event_choice_problem(i: int) -> String:
	## "" if choice i can be taken now, else why not.
	var e := event_def(pending_event.get("id", ""))
	if e.is_empty() or i < 0 or i >= (e["choices"] as Array).size():
		return "No such choice."
	var ch: Dictionary = e["choices"][i]
	if gold < int(ch.get("cost_gold", 0)):
		return "You need %d %s." % [int(ch["cost_gold"]), coin_word()]
	if shards < int(ch.get("cost_shards", 0)):
		return "You need %d godshard%s." % [int(ch["cost_shards"]), "" if int(ch["cost_shards"]) == 1 else "s"]
	var fx: Dictionary = ch.get("effects", {})
	if fx.get("recruit", false) and not _room():
		return "The warband is full."
	return ""

func _cheapest_henchman() -> String:
	var wbd := warband()
	var cheapest := ""
	for ut in wbd["units"]:
		var ud: Dictionary = wbd["units"][ut]
		if ud["role"] == "henchman" and (cheapest == "" or int(ud["cost"]) < int(wbd["units"][cheapest]["cost"])):
			cheapest = ut
	return cheapest

func resolve_event(i: int) -> Dictionary:
	## Takes choice i of the waiting night. Returns {"title", "text", "roll", "lines", "advances"}.
	if event_choice_problem(i) != "":
		return {}
	var e := event_def(pending_event["id"])
	var ch: Dictionary = e["choices"][i]
	var out := {"id": e["id"], "title": e["title"], "choice": event_text(ch["label"]), "roll": 0, "lines": [], "advances": []}
	gold -= int(ch.get("cost_gold", 0))
	shards -= int(ch.get("cost_shards", 0))
	var text: String = ch.get("text", "")
	var fx: Dictionary = ch.get("effects", {})
	if ch.has("roll"):
		var r := rng.randi_range(1, 6)
		out["roll"] = r
		for band in ch["roll"]:
			if r <= int(band["to"]):
				text = band["text"]
				fx = band.get("effects", {})
				break
	var extra := {"roll": out["roll"]}
	var who := fighter(int(pending_event.get("who_uid", -1)))
	var target: Dictionary = who
	if fx.get("on", "") == "leader" and leader_fighter() != null:
		target = leader_fighter()
	if fx.has("gold"):
		var g := int(fx["gold"])
		var before := gold
		gold = maxi(0, gold + g)
		out["lines"].append(("+%d %s" % [g, coin_word()]) if g > 0 else ("-%d %s" % [before - gold, coin_word()]))
	if fx.has("shards"):
		shards += int(fx["shards"])
		out["lines"].append("+%d godshard%s" % [int(fx["shards"]), "" if int(fx["shards"]) == 1 else "s"])
	if fx.has("xp") and not target.is_empty():
		var b := int(target["xp"])
		target["xp"] = b + int(fx["xp"])
		out["lines"].append("%s +%d experience" % [target["name"], int(fx["xp"])])
		for adv in _check_advances(target, b):
			out["advances"].append(target["name"])
	if fx.has("xp_henchmen"):
		for f in fighters:
			if f["role"] == "henchman":
				var b := int(f["xp"])
				f["xp"] = b + int(fx["xp_henchmen"])
				for adv in _check_advances(f, b):
					out["advances"].append(f["name"])
		out["lines"].append("Every henchman +%d experience" % int(fx["xp_henchmen"]))
	if fx.get("sick", false) and not who.is_empty():
		who["miss_next"] = true
		out["lines"].append("%s sits out the next battle" % who["name"])
	if fx.get("recruit", false):
		var ut := _cheapest_henchman()
		if ut != "" and _room():
			var nf := _fighter_from_def(ut, warband()["units"][ut], _fresh_name(warband(), {}))
			nf["xp"] = 0
			if fx.get("recruit_sick", false):
				nf["miss_next"] = true
			fighters.append(nf)
			extra["recruit"] = nf["name"]
			out["lines"].append("%s joins as a %s" % [nf["name"], type_name(nf)])
	out["text"] = event_text(text, extra)
	history.append("  The night after: %s. %s" % [e["title"], out["text"]])
	pending_event = {}
	return out

func _lead_score(f: Dictionary) -> int:
	return (100 if f["role"] == "hero" else 0) + int(f["stats"]["Ld"]) * 10 + int(f["xp"])

func _d66() -> Array:
	return [rng.randi_range(1, 6), rng.randi_range(1, 6)]

func _roll_injury(f: Dictionary) -> Dictionary:
	if f["role"] == "henchman":
		var r := rng.randi_range(1, 6)
		var out := {"uid": f["uid"], "name": f["name"], "dice": [r], "id": "dead" if r <= 2 else "fine"}
		out["title"] = "Hood's due" if r <= 2 else "Back on their feet"
		out["text"] = "Dead." if r <= 2 else "Bruised, but fit to fight."
		return out
	var d := _d66()
	var idx := (int(d[0]) - 1) * 6 + (int(d[1]) - 1)
	var row: Dictionary = {}
	for t in data()["injuries"]:
		if idx <= int(t["to"]):
			row = t
			break
	var out := {"uid": f["uid"], "name": f["name"], "dice": d, "id": row["id"], "title": row["name"], "text": row["text"]}
	match row["id"]:
		"deep":
			f["miss_next"] = true
		"robbed":
			f["gear"] = ["dagger"]
			f["munitions"] = {}
		"old":
			f["old_wound"] = true
		"touched":
			var before := int(f["xp"])
			f["xp"] = before + 3
			_check_advances(f, before)
		"captured":
			if gold >= 50:
				gold -= 50
				out["text"] = "Taken by the enemy; the warband paid a 50 jakata ransom to get them back."
			else:
				out["id"] = "dead"
				out["text"] = "Taken by the enemy, and the warband could not pay the ransom. Lost."
	if row.has("stat"):
		var s: String = row["stat"]
		if row.get("plus", false):
			f["stats"][s] = mini(int(f["stats"][s]) + 1, int(caps()[s]))
		else:
			f["stats"][s] = maxi(1, int(f["stats"][s]) - 1)
	if row["id"] != "fine" and row["id"] != "dead" and row["id"] != "touched":
		(f["injuries"] as Array).append(row["name"])
	return out

func _check_advances(f: Dictionary, before: int) -> Array:
	var got: Array = []
	for t in xp_track(f):
		if int(t) > before and int(t) <= int(f["xp"]):
			got.append(_roll_advance(f))
	return got

func _roll_advance(f: Dictionary) -> Dictionary:
	var d := [rng.randi_range(1, 6), rng.randi_range(1, 6)]
	var total: int = d[0] + d[1]
	var table: Array = data()["hero_advances"] if f["role"] != "henchman" else data()["henchman_advances"]
	var row: Dictionary = table[-1]
	for t in table:
		if total <= int(t["to"]):
			row = t
			break
	var adv := {"dice": d, "kind": row["kind"], "pick": []}
	if row["kind"] == "talent":
		if hero_count() < int(data()["max_heroes"]):
			f["role"] = "hero"
			f["promoted"] = true
			adv["kind"] = "skill"
			adv["talent"] = true
		else:
			adv["kind"] = "stat"
			row = {"pick": ["WS", "BS"]}
	if adv["kind"] == "stat":
		var opts: Array = (row["pick"] as Array).filter(func(s): return int(f["stats"][s]) < int(caps()[s]))
		if opts.is_empty():
			adv["kind"] = "skill"
		else:
			adv["pick"] = opts
	if adv["kind"] == "skill":
		adv["pick"] = _skill_choices(f)
		if adv["pick"].is_empty():
			adv["kind"] = "stat"
			adv["pick"] = ["Ld"] if int(f["stats"]["Ld"]) < int(caps()["Ld"]) else []
	if (adv["pick"] as Array).size() == 1:
		_apply_advance(f, adv["kind"], adv["pick"][0])
		adv["chosen"] = adv["pick"][0]
	elif not (adv["pick"] as Array).is_empty():
		(f["pending"] as Array).append(adv)
	return adv

func _skill_choices(f: Dictionary) -> Array:
	var pool: Dictionary = data()["skill_pool"]
	var opts: Array = (pool["any"] as Array).duplicate()
	if f["role"] == "leader":
		opts += pool["leader"]
	if is_caster(f):
		opts += pool["caster"]
	opts += pool.get(faction, [])
	opts = opts.filter(func(s): return not (f["skills"] as Array).has(s))
	var out: Array = []
	while out.size() < 3 and not opts.is_empty():
		var s: String = opts[rng.randi_range(0, opts.size() - 1)]
		opts.erase(s)
		out.append(s)
	return out

func _apply_advance(f: Dictionary, kind: String, what: String) -> void:
	if kind == "stat":
		f["stats"][what] = mini(int(f["stats"][what]) + 1, int(caps()[what]))
	else:
		if not (f["skills"] as Array).has(what):
			(f["skills"] as Array).append(what)

func choose_advance(uid: int, which: String) -> bool:
	## Settles the first open advance of this fighter with the given stat or skill.
	var f := fighter(uid)
	if f.is_empty() or (f["pending"] as Array).is_empty():
		return false
	var adv: Dictionary = f["pending"][0]
	if not (adv["pick"] as Array).has(which):
		return false
	_apply_advance(f, adv["kind"], which)
	(f["pending"] as Array).remove_at(0)
	return true

func auto_choose_all() -> void:
	for f in fighters:
		while not (f["pending"] as Array).is_empty():
			choose_advance(int(f["uid"]), f["pending"][0]["pick"][0])

# ------------------------------------------------------------------ the market

static func shard_price(n_sold: int) -> int:
	var t: Array = data()["shard_price"]
	return int(t[clampi(n_sold, 0, t.size() - 1)])

func sell_shards(n: int) -> int:
	n = clampi(n, 0, shards)
	if n == 0:
		return 0
	var coin := shard_price(n) * n
	shards -= n
	gold += coin
	return coin

func armoury() -> Array:
	return data()["armoury"].get(faction, [])

static func item_cost(item: String) -> int:
	var r := GameData.rules()
	for group in ["weapons", "armour", "munitions"]:
		if r[group].has(item):
			return int(r[group][item].get("cost", 0))
	return 0

static func item_kind(item: String) -> String:
	var r := GameData.rules()
	if r["weapons"].has(item):
		return r["weapons"][item]["kind"]
	if r["munitions"].has(item):
		return "munition"
	if item == "light" or item == "heavy":
		return "armour"
	return item  # shield, helm

func can_buy(uid: int, item: String) -> String:
	## "" if allowed, otherwise the reason.
	var f := fighter(uid)
	if f.is_empty():
		return "No such fighter."
	var cost := item_cost(item)
	if cost > gold:
		return "Costs %d; you have %d." % [cost, gold]
	var gear: Array = f["gear"]
	var kind := item_kind(item)
	match kind:
		"melee":
			var n := 0
			var two := false
			for g in gear:
				var wd := GameData.weapon(g)
				if wd.get("kind", "") == "melee":
					n += 1
					two = two or wd.get("two_handed", false)
			if two:
				return "Their two-hand weapon leaves no hand free."
			if n >= 2:
				return "Already carries two hand weapons."
			if GameData.weapon(item).get("two_handed", false) and gear.has("shield"):
				return "Needs both hands: sell the shield first."
		"missile":
			for g in gear:
				if GameData.weapon(g).get("kind", "") == "missile":
					return "Already carries a missile weapon."
		"armour":
			if gear.has("light") or gear.has("heavy"):
				return "Already wears armour: sell it first."
			if is_caster(f) and item == "heavy":
				return "Heavy plate smothers a mage's warren."
		"shield":
			if gear.has("shield"):
				return "Already has a shield."
			for g in gear:
				if GameData.weapon(g).get("two_handed", false):
					return "Their two-hand weapon leaves no hand free."
		"helm":
			if gear.has("helm"):
				return "Already has a helm."
		"munition":
			if not (f["skills"] as Array).has("munitions"):
				return "Only a fighter with a sapper's kit can carry munitions."
			if int(f["munitions"].get(item, 0)) >= 3:
				return "Carries as many as they can."
	return ""

func buy(uid: int, item: String) -> String:
	var why := can_buy(uid, item)
	if why != "":
		return why
	var f := fighter(uid)
	gold -= item_cost(item)
	if item_kind(item) == "munition":
		f["munitions"][item] = int(f["munitions"].get(item, 0)) + 1
	else:
		(f["gear"] as Array).append(item)
	return ""

static func sell_price(item: String) -> int:
	return item_cost(item) / 2

func sell(uid: int, item: String) -> bool:
	var f := fighter(uid)
	if f.is_empty():
		return false
	if item_kind(item) == "munition":
		if int(f["munitions"].get(item, 0)) <= 0:
			return false
		f["munitions"][item] = int(f["munitions"][item]) - 1
	else:
		if not (f["gear"] as Array).has(item):
			return false
		(f["gear"] as Array).erase(item)
	gold += sell_price(item)
	return true

func can_hire(unit_type: String) -> String:
	var wb := warband()
	var def: Dictionary = wb["units"].get(unit_type, {})
	if def.is_empty():
		return "Unknown fighter."
	if fighters.size() >= int(wb["max_size"]):
		return "The warband is full (%d)." % int(wb["max_size"])
	var mx := int(def.get("max", 0))
	if mx > 0:
		var have := fighters.filter(func(f): return f["unit"] == unit_type).size()
		if have >= mx:
			return "No more than %d." % mx
	if def["role"] == "leader":
		return "A warband has one leader."
	if def["role"] == "hero" and hero_count() >= int(data()["max_heroes"]):
		return "No more than %d heroes." % int(data()["max_heroes"])
	if int(def["cost"]) > gold:
		return "Costs %d; you have %d." % [int(def["cost"]), gold]
	return ""

func hire(unit_type: String, fname := "") -> Dictionary:
	if can_hire(unit_type) != "":
		return {}
	var wb := warband()
	var def: Dictionary = wb["units"][unit_type]
	if fname == "":
		fname = _fresh_name(wb, {})
	var f := _fighter_from_def(unit_type, def, fname)
	# new recruits arrive green
	if f["role"] == "henchman":
		f["xp"] = 0
	fighters.append(f)
	gold -= int(def["cost"])
	return f

func dismiss(uid: int) -> bool:
	var f := fighter(uid)
	if f.is_empty() or f["role"] == "leader" or fighters.size() <= 1:
		return false
	fighters.erase(f)
	return true

# ------------------------------------------------------------------ saving

func to_dict() -> Dictionary:
	return {
		"version": 1, "id": id, "faction": faction, "name": name, "gold": gold, "shards": shards,
		"battles": battles, "wins": wins, "losses": losses, "fighters": fighters, "fallen": fallen,
		"history": history, "next_uid": next_uid, "rng_state": str(rng.state), "rng_seed": str(rng.seed),
		"last_report": last_report, "sitting_out": sitting_out, "created": created,
		"pending_event": pending_event, "recent_events": recent_events,
		"updated": int(Time.get_unix_time_from_system()),
	}

static func from_dict(d: Dictionary) -> Campaign:
	var c := Campaign.new()
	c.id = d.get("id", "")
	c.faction = d.get("faction", "marines")
	c.name = d.get("name", "")
	c.gold = int(d.get("gold", 0))
	c.shards = int(d.get("shards", 0))
	c.battles = int(d.get("battles", 0))
	c.wins = int(d.get("wins", 0))
	c.losses = int(d.get("losses", 0))
	c.fighters = _ints(d.get("fighters", []))
	c.fallen = d.get("fallen", [])
	c.history = d.get("history", [])
	c.next_uid = int(d.get("next_uid", 1))
	# 64-bit dice state kept as text, since JSON numbers lose the low bits
	c.rng.seed = String(d.get("rng_seed", "1")).to_int()
	c.rng.state = String(d.get("rng_state", "1")).to_int()
	c.last_report = d.get("last_report", {})
	c.sitting_out = (d.get("sitting_out", []) as Array).map(func(x): return int(x))
	c.pending_event = d.get("pending_event", {})
	if c.pending_event.has("who_uid"):
		c.pending_event["who_uid"] = int(c.pending_event["who_uid"])
	c.recent_events = d.get("recent_events", [])
	c.created = int(d.get("created", 0))
	c.updated = int(d.get("updated", 0))
	return c

static func _ints(fs: Array) -> Array:
	## JSON turns every number into a float; put the counts back to ints.
	for f in fs:
		f["uid"] = int(f["uid"])
		f["xp"] = int(f["xp"])
		f["kills"] = int(f.get("kills", 0))
		f["battles"] = int(f.get("battles", 0))
		for k in f["stats"]:
			f["stats"][k] = int(f["stats"][k])
		for k in f["munitions"]:
			f["munitions"][k] = int(f["munitions"][k])
		for a in f.get("pending", []):
			a["dice"] = (a.get("dice", []) as Array).map(func(x): return int(x))
	return fs

func save() -> bool:
	DirAccess.make_dir_recursive_absolute(SAVE_DIR)
	updated = int(Time.get_unix_time_from_system())
	var f := FileAccess.open("%s/%s.json" % [SAVE_DIR, id], FileAccess.WRITE)
	if f == null:
		push_error("Cannot save campaign " + id)
		return false
	f.store_string(JSON.stringify(to_dict(), "\t"))
	f.close()
	return true

static func load_file(file_id: String) -> Campaign:
	var path := "%s/%s.json" % [SAVE_DIR, file_id]
	if not FileAccess.file_exists(path):
		return null
	var d = GameData.load_json(path)
	if d == null or not d is Dictionary:
		return null
	return from_dict(d)

static func list_saves() -> Array:
	## [{"id", "name", "faction", "battles", "updated"}], newest first.
	var out: Array = []
	var dir := DirAccess.open(SAVE_DIR)
	if dir == null:
		return out
	for fn in dir.get_files():
		if not fn.ends_with(".json"):
			continue
		var d = GameData.load_json("%s/%s" % [SAVE_DIR, fn])
		if d is Dictionary:
			var rt := 0
			for f in d.get("fighters", []):
				rt += int(data()["rating_per_fighter"]) + int(f.get("xp", 0))
			out.append({"id": fn.get_basename(), "name": d.get("name", "?"), "faction": d.get("faction", ""),
				"battles": int(d.get("battles", 0)), "wins": int(d.get("wins", 0)), "updated": int(d.get("updated", 0)),
				"fighters": (d.get("fighters", []) as Array).size(), "rating": rt})
	out.sort_custom(func(a, b): return a["updated"] > b["updated"])
	return out

static func delete_save(file_id: String) -> void:
	DirAccess.remove_absolute("%s/%s.json" % [SAVE_DIR, file_id])
