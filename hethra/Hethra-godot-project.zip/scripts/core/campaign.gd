class_name Campaign
extends RefCounted
## A warband's life between battles: its fighters (with their experience,
## advances and scars), its purse and godshards, hiring, the armoury, and what
## happens after each fight. Pure data and rules, so it can be tested headless
## and saved as JSON.

const SAVE_DIR := "user://campaigns"

var id := ""                 # save file name
var faction := "marines"
var name := ""
var gold := 0
var shards := 0
var battles := 0
var wins := 0
var losses := 0
var fighters: Array = []     # Array of Dictionary, see _fighter_from_def
var fallen: Array = []       # [{"name", "type", "battle", "how"}]
var history: Array = []      # one line per battle
var next_uid := 1
var rng_state := 0
var last_report: Dictionary = {}
var sitting_out: Array = []  # uids kept out of the coming battle
var pending_event: Dictionary = {}  # the night after a battle, waiting for a choice
var recent_events: Array = []       # ids of the last few nights, so they don't repeat
var wards: Dictionary = {}          # map id -> {"fought": n, "won": n}: where the band has fought
var rivals: Dictionary = {}         # foe id -> their leader and your history with them (see _rival)
var crowned := 0                    # the battle that won the last night (0: Hethra is not yet yours)
var created := 0
var updated := 0

var rng := RandomNumberGenerator.new()

static var _data: Dictionary = {}

static func data() -> Dictionary:
	if _data.is_empty():
		_data = GameData.load_json("res://data/campaign.json")
	return _data

# ------------------------------------------------------------------ creation

static func create(faction_id: String, warband_name: String = "", seed_value := 0) -> Campaign:
	var c := Campaign.new()
	c.faction = faction_id
	var wb := GameData.warband(faction_id)
	c.rng.seed = seed_value if seed_value != 0 else int(Time.get_unix_time_from_system() * 1000.0) % 2147483647
	c.created = int(Time.get_unix_time_from_system())
	c.id = "%s_%d" % [faction_id, c.created % 10000000]
	var spent := 0
	for entry in wb["battle_roster"]:
		var def: Dictionary = wb["units"][entry["unit"]]
		var f := c._fighter_from_def(entry["unit"], def, entry.get("name", def["name"]))
		if entry.has("warren"):
			f["warren"] = entry["warren"]
		c.fighters.append(f)
		spent += int(def["cost"])
	var d := data()
	c.gold = maxi(int(d["min_purse"]), int(d["starting_purse"]) - spent)
	c.name = warband_name if warband_name != "" else c._default_name()
	return c

func _default_name() -> String:
	var leader = leader_fighter()
	var who: String = leader["name"].split(" ")[-1] if leader != null else "Nobody"
	match faction:
		"marines":
			return "%s's Squad" % who
		"chained":
			return "The Flock of %s" % who
		"whirlwind":
			return "%s's Sworn" % who
		"seguleh":
			return "The Blades of %s" % who
		"andii":
			return "%s's Night" % who
		"barghast":
			return "%s's Clan" % who
		"imass":
			return "The Dust of %s" % who
		"teblor":
			return "%s's Raid" % who
	return "%s's Band" % who

func _fighter_from_def(unit_type: String, def: Dictionary, fname: String) -> Dictionary:
	var stats := {}
	for k in def["stats"]:
		stats[k] = int(def["stats"][k])
	var mun := {}
	for k in def.get("munitions", {}):
		mun[k] = int(def["munitions"][k])
	var f := {
		"uid": next_uid,
		"unit": unit_type,
		"name": fname,
		"role": def.get("role", "henchman"),
		"warren": (def.get("warrens", [""]) as Array)[0] if def.has("warrens") else "",
		"stats": stats,
		"gear": (def.get("gear", []) as Array).duplicate(),
		"skills": (def.get("skills", []) as Array).duplicate(),
		"munitions": mun,
		"xp": int(def.get("xp", 0)),
		"injuries": [],
		"miss_next": false,
		"old_wound": false,
		"kills": 0,
		"battles": 0,
		"pending": [],
		"promoted": false,
	}
	next_uid += 1
	return f

# ------------------------------------------------------------------ queries

func warband() -> Dictionary:
	return GameData.warband(faction)

func unit_def(f: Dictionary) -> Dictionary:
	return warband()["units"][f["unit"]]

func type_name(f: Dictionary) -> String:
	var n: String = unit_def(f)["name"]
	if f.get("promoted", false):
		n += " (risen)"
	return n

func fighter(uid: int) -> Dictionary:
	for f in fighters:
		if int(f["uid"]) == uid:
			return f
	return {}

func leader_fighter():
	for f in fighters:
		if f["role"] == "leader":
			return f
	return null

func hero_count() -> int:
	return fighters.filter(func(f): return f["role"] == "hero" or f["role"] == "leader").size()

func is_caster(f: Dictionary) -> bool:
	return String(f.get("warren", "")) != ""

func rating() -> int:
	var per := int(data()["rating_per_fighter"])
	var r := 0
	for f in fighters:
		r += per + int(f["xp"])
	return r

func caps() -> Dictionary:
	return warband()["caps"]

func xp_track(f: Dictionary) -> Array:
	return data()["hero_xp"] if f["role"] != "henchman" else data()["henchman_xp"]

func next_advance_at(f: Dictionary) -> int:
	for t in xp_track(f):
		if int(t) > int(f["xp"]):
			return int(t)
	return -1

func prev_advance_at(f: Dictionary) -> int:
	var p := 0
	for t in xp_track(f):
		if int(t) <= int(f["xp"]):
			p = int(t)
	return p

func pending_count() -> int:
	var n := 0
	for f in fighters:
		n += (f["pending"] as Array).size()
	return n

func coin_word() -> String:
	return String(data()["currency"])

# ------------------------------------------------------------------ battle

func prepare_battle() -> Array:
	## Rolls for old wounds and works out who sits this one out. Returns lines to show.
	sitting_out.clear()
	var lines: Array = []
	for f in fighters:
		if f["miss_next"]:
			sitting_out.append(int(f["uid"]))
			lines.append("%s is still healing and sits this one out." % f["name"])
		elif f["old_wound"]:
			var r := rng.randi_range(1, 6)
			if r == 1:
				sitting_out.append(int(f["uid"]))
				lines.append("%s's old wound opens again (rolled 1). They stay behind." % f["name"])
	return lines

func battle_roster() -> Array:
	var out: Array = []
	for f in fighters:
		if sitting_out.has(int(f["uid"])):
			continue
		out.append(entry_for(f))
	if out.is_empty() and not fighters.is_empty():
		out.append(entry_for(fighters[0]))
	return out

func entry_for(f: Dictionary) -> Dictionary:
	return {
		"unit": f["unit"], "name": f["name"], "uid": int(f["uid"]), "warren": f["warren"],
		"role": f["role"], "stats": (f["stats"] as Dictionary).duplicate(),
		"gear": (f["gear"] as Array).duplicate(), "skills": (f["skills"] as Array).duplicate(),
		"munitions": (f["munitions"] as Dictionary).duplicate(),
	}

static func roster_rating(entries: Array, wb: Dictionary) -> int:
	var r := 0
	for e in entries:
		r += int(data()["rating_per_fighter"]) + int(e.get("xp", wb["units"][e["unit"]].get("xp", 0)))
	return r

func enemy_roster(enemy_id: String, boost := 1.0) -> Dictionary:
	## Builds a foe of about the same strength: their usual band, then more
	## fighters and veteran heroes until their rating matches ours (times boost).
	var wb := GameData.warband(enemy_id)
	var entries: Array = []
	var used: Dictionary = {}
	for e in wb["battle_roster"]:
		var def: Dictionary = wb["units"][e["unit"]]
		var en := {"unit": e["unit"], "name": e["name"], "xp": int(def.get("xp", 0)), "stats": (def["stats"] as Dictionary).duplicate()}
		if e.has("warren"):
			en["warren"] = e["warren"]
		if def["role"] == "leader" and rivals.has(enemy_id):
			# the band you have met before comes under the same leader, hardened
			var rv: Dictionary = rivals[enemy_id]
			en["name"] = String(rv["leader"])
			en["rival"] = true
			var steps: Array = ["WS", "S", "I", "W", "A", "Ld", "T", "BS"]
			for i in range(int(rv.get("adv", 0))):
				var stt: String = steps[i % steps.size()]
				if int(en["stats"][stt]) < int(wb["caps"][stt]):
					en["stats"][stt] = int(en["stats"][stt]) + 1
				en["xp"] = int(en["xp"]) + 5
		entries.append(en)
		used[en["name"]] = true
	var target := int(rating() * boost)
	var henchmen: Array = []
	for k in wb["units"]:
		if wb["units"][k]["role"] == "henchman":
			henchmen.append(k)
	var guard := 0
	var heroes_raised := 0
	while roster_rating(entries, wb) < target - 6 and guard < 60:
		guard += 1
		var add_body := entries.size() < mini(int(wb["max_size"]), 14) and (heroes_raised >= 2 or rng.randf() < 0.45)
		if add_body and not henchmen.is_empty():
			var k: String = henchmen[rng.randi_range(0, henchmen.size() - 1)]
			var def: Dictionary = wb["units"][k]
			var nm := _fresh_name(wb, used)
			entries.append({"unit": k, "name": nm, "xp": 0, "stats": (def["stats"] as Dictionary).duplicate()})
			heroes_raised = 0
		else:
			# a veteran: one of their heroes has an advance
			var heroes: Array = entries.filter(func(e): return wb["units"][e["unit"]]["role"] != "henchman")
			var h: Dictionary = heroes[rng.randi_range(0, heroes.size() - 1)]
			var pairs: Array = [["WS", "BS"], ["S", "A"], ["I", "Ld"], ["W", "T"], ["WS", "A"]]
			var pick: Array = pairs[rng.randi_range(0, pairs.size() - 1)]
			var st: String = pick[rng.randi_range(0, pick.size() - 1)]
			if int(h["stats"][st]) < int(wb["caps"][st]):
				h["stats"][st] = int(h["stats"][st]) + 1
			h["xp"] = int(h["xp"]) + 5
			heroes_raised += 1
	return {"entries": entries, "rating": roster_rating(entries, wb)}

func _fresh_name(wb: Dictionary, used: Dictionary) -> String:
	## A name nobody in the band (or among the fallen) carries, ranks aside.
	var taken := {}
	for k in used:
		taken[String(k).get_slice(" ", String(k).get_slice_count(" ") - 1)] = true
	for f in fighters + fallen:
		var n := String(f["name"])
		taken[n.get_slice(" ", n.get_slice_count(" ") - 1)] = true
	var pool: Array = (wb.get("names", []) as Array).filter(func(n): return not taken.has(n) and not used.has(n))
	var nm := ""
	if not pool.is_empty():
		nm = pool[rng.randi_range(0, pool.size() - 1)]
	else:
		# the lists ran dry: stitch a new name from the front of one and the back of another
		var all: Array = wb.get("names", [])
		for _try in range(40):
			if all.size() < 2:
				break
			var a := String(all[rng.randi_range(0, all.size() - 1)]).get_slice(" ", 0).replace("'", "")
			var b := String(all[rng.randi_range(0, all.size() - 1)]).get_slice(" ", 0).replace("'", "")
			var cand := a.substr(0, maxi(2, ceili(a.length() * 0.5))) + b.substr(b.length() / 2).to_lower()
			if cand.length() >= 4 and not taken.has(cand) and not used.has(cand):
				nm = cand
				break
		if nm == "":
			nm = "%s %d" % [wb["short"], used.size() + 1]
	used[nm] = true
	return nm

# ------------------------------------------------------------------ aftermath

static func result_from_battle(st: BattleState, my_side: int, enemy_id: String, enemy_rating: int) -> Dictionary:
	## What a finished battle meant for the campaign side.
	var fs := {}
	for u in st.side_units(my_side):
		if u.uid < 0:
			continue
		fs[str(u.uid)] = {"status": u.status, "kills": u.kills, "carrying": u.carrying, "munitions": u.munitions.duplicate()}
	var foe_leader := {}
	var foe_kills := 0
	for u in st.side_units(1 - my_side):
		if u.role == "leader" and foe_leader.is_empty():
			foe_leader = {"name": u.name, "status": u.status, "kills": u.kills, "by": ""}
			var by := st.unit_by_id(u.ooa_by) if u.status == "ooa" and u.ooa_by >= 0 else null
			if by != null and by.side == my_side:
				foe_leader["by"] = by.name
		foe_kills += u.kills
	return {"won": st.winner == my_side, "draw": st.winner == -2, "enemy": enemy_id, "enemy_rating": enemy_rating, "map": st.map_id,
		"foe_leader": foe_leader, "foe_kills": foe_kills,
		"field_shards": st.shard_nodes.size(), "fighters": fs, "rounds": st.round_num, "reason": st.end_reason,
		"strongbox": st.scenario.get("cache", false) and st.cache_side() == my_side}

func apply_result(res: Dictionary) -> Dictionary:
	## res: {"won": bool, "draw": bool, "enemy": id, "enemy_rating": int,
	##       "field_shards": int, "fighters": {uid(str): {"status", "kills", "carrying", "munitions"}}}
	var rep := {"won": res.get("won", false), "draw": res.get("draw", false), "enemy": res.get("enemy", ""),
		"injuries": [], "xp": [], "search": {}, "shards_found": 0, "coins_found": 0, "lines": [], "fallen": [], "leader": ""}
	battles += 1
	if rep["won"]:
		wins += 1
	elif not rep["draw"]:
		losses += 1
	var took: Dictionary = res.get("fighters", {})
	var underdog := 0
	var er := int(res.get("enemy_rating", 0))
	if er - rating() >= 20:
		underdog = 1 + (er - rating() - 20) / int(data()["underdog_per_rating"])
	# those who sat out are healed now
	for f in fighters:
		if not took.has(str(f["uid"])):
			f["miss_next"] = false
	# 1. the wounded
	var dead: Array = []
	for f in fighters:
		var r: Dictionary = took.get(str(f["uid"]), {})
		if r.is_empty():
			continue
		f["battles"] = int(f["battles"]) + 1
		f["kills"] = int(f["kills"]) + int(r.get("kills", 0))
		f["miss_next"] = false
		if r.has("munitions"):
			var m := {}
			for k in r["munitions"]:
				m[k] = int(r["munitions"][k])
			f["munitions"] = m
		if r.get("status", "ok") != "ooa":
			continue
		var inj := _roll_injury(f)
		rep["injuries"].append(inj)
		if inj["id"] == "dead":
			dead.append(f)
	# 2. experience for those who walked away
	for f in fighters:
		var r: Dictionary = took.get(str(f["uid"]), {})
		if r.is_empty() or dead.has(f) or f["role"] == "sword":
			continue
		var gain := 1
		var why: Array = ["survived"]
		var k := int(r.get("kills", 0))
		if k > 0:
			gain += k
			why.append("%d out of action" % k)
		if f["role"] == "leader" and rep["won"]:
			gain += 1
			why.append("led the win")
		if int(r.get("carrying", 0)) > 0 and r.get("status", "ok") != "ooa":
			gain += 1
			why.append("brought back a shard")
		if underdog > 0:
			gain += underdog
			why.append("faced stronger foes")
		var before := int(f["xp"])
		f["xp"] = before + gain
		var adv := _check_advances(f, before)
		rep["xp"].append({"uid": f["uid"], "name": f["name"], "gain": gain, "why": why, "xp": f["xp"], "advances": adv})
	# 3. the dead
	for f in dead:
		fallen.append({"name": f["name"], "type": type_name(f), "battle": battles, "kills": f["kills"]})
		rep["fallen"].append(f["name"])
		fighters.erase(f)
	# 4. a new leader if needed
	if leader_fighter() == null and not fighters.is_empty():
		var best = null
		for f in fighters:
			if f["role"] == "sword" and fighters.any(func(o): return o["role"] != "sword"):
				continue
			if best == null or _lead_score(f) > _lead_score(best):
				best = f
		best["role"] = "leader"
		if not (best["skills"] as Array).has("nerve"):
			pass
		rep["leader"] = best["name"]
		rep["lines"].append("%s takes command of the warband." % best["name"])
	# 5. spoils
	var sh := 0
	for f in fighters:
		var r: Dictionary = took.get(str(f["uid"]), {})
		if not r.is_empty() and r.get("status", "ok") != "ooa":
			sh += int(r.get("carrying", 0))
	if rep["won"]:
		var extra := int(res.get("field_shards", 0)) / 2
		if extra > 0:
			rep["lines"].append("With the field yours, you gather %d more godshard%s from the rubble." % [extra, "" if extra == 1 else "s"])
		sh += extra
	var searchers: Array = fighters.filter(func(f): return (f["role"] == "hero" or f["role"] == "leader") and took.has(str(f["uid"])) and took[str(f["uid"])].get("status", "ok") != "ooa")
	var dice: Array = []
	for f in searchers:
		dice.append(rng.randi_range(1, 6))
	var counts := {}
	var pips := 0
	for d in dice:
		counts[d] = int(counts.get(d, 0)) + 1
		pips += int(d)
	var found := 0
	for face in counts:
		if counts[face] >= 2:
			found += counts[face] - 1
	var coins := pips * int(data()["search_coin_per_pip"])
	rep["search"] = {"dice": dice, "who": searchers.map(func(f): return f["name"]), "coins": coins, "shards": found}
	shards += sh + found
	gold += coins
	rep["shards_found"] = sh + found
	if res.get("strongbox", false):
		var box := 60 + rng.randi_range(0, 4) * 10
		rep["lines"].append("The paymaster's strongbox is yours. Prised open, it holds %d jakatas." % box)
		gold += box
		coins += box
	rep["coins_found"] = coins
	# 5a. the ward: win there often enough and the band holds it; lose there
	# and the hold is gone. Every ward held pays its dues after each battle.
	var ward := String(res.get("map", ""))
	record_ward(ward, rep)
	var held := held_wards()
	var dues := held.size() * ward_tribute()
	rep["tribute"] = dues
	if dues > 0:
		gold += dues
		rep["lines"].append("Your ward%s pay%s dues: %d jakatas." % ["s" if held.size() > 1 else "", "" if held.size() > 1 else "s", dues])
	# 5b. the sellswords want paying, win or lose
	var paid := 0
	var gone: Array = []
	for f in fighters.duplicate():
		if f["role"] != "sword":
			continue
		var up := int(unit_def(f).get("upkeep", 0))
		if gold >= up:
			gold -= up
			paid += up
		else:
			gone.append(f["name"])
			fighters.erase(f)
	rep["upkeep"] = paid
	if paid > 0:
		rep["lines"].append("Your sellswords take their pay: %d jakatas." % paid)
	for n in gone:
		rep["lines"].append("%s finds your purse empty and walks off into the ruins." % n)
	# 6. stragglers: a band down to a handful draws in hungry blades who
	# will fight for a share, so a run of bad nights never ends the story
	var wbd := warband()
	var cheapest := ""
	for ut in wbd["units"]:
		var ud: Dictionary = wbd["units"][ut]
		if ud["role"] == "henchman" and (cheapest == "" or int(ud["cost"]) < int(wbd["units"][cheapest]["cost"])):
			cheapest = ut
	var joined: Array = []
	while cheapest != "" and fighters.size() < int(data().get("straggler_floor", 5)) and fighters.size() < int(wbd["max_size"]):
		var nf := _fighter_from_def(cheapest, wbd["units"][cheapest], _fresh_name(wbd, {}))
		nf["xp"] = 0
		fighters.append(nf)
		joined.append(nf["name"])
	if not joined.is_empty():
		rep["lines"].append("Word goes round the ruins that your band pays in shards. %s join%s you for a share." % [" and ".join(joined) if joined.size() <= 2 else ", ".join(joined.slice(0, joined.size() - 1)) + " and " + joined[-1], "s" if joined.size() == 1 else ""])
	var res_word := "won" if rep["won"] else ("drew" if rep["draw"] else "lost")
	history.append("Battle %d: %s against the %s%s. %s" % [battles, res_word, GameData.warband(rep["enemy"])["name"] if rep["enemy"] != "" else "foe",
		(" in " + String(GameData.map_data(ward)["name"])) if ward != "" else "",
		("Lost " + ", ".join(rep["fallen"]) + ".") if not rep["fallen"].is_empty() else "No one lost."])
	if rep["ward_taken"] != "":
		history[-1] += " Took the ward."
	elif rep["ward_lost"] != "":
		history[-1] += " Lost the ward."
	# 6b. the rival: the band you fought remembers you, and so does its leader
	_rival(res, rep)
	# 7. the last night: hold the Idol Square till dawn and Hethra is yours;
	# fail and the alliance pries a ward out of your hands
	rep["crowned"] = false
	rep["last_night"] = bool(res.get("last_night", false))
	if rep["last_night"]:
		if rep["won"]:
			crowned = battles
			rep["crowned"] = true
			var prize := int(data().get("last_night_prize", 150))
			gold += prize
			rep["lines"].append("The alliance breaks on the Idol Square. Hethra is yours, and its fences pay a crown's tribute: %d jakatas." % prize)
			history[-1] += " The last night: Hethra is yours."
		elif not rep["draw"]:
			var weakest := ""
			for k in held_wards():
				if weakest == "" or int(wards[k]["won"]) < int(wards[weakest]["won"]):
					weakest = k
			if weakest != "" and rep["ward_lost"] == "":
				wards[weakest]["held"] = false
				rep["ward_lost"] = weakest
				rep["lines"].append("The alliance follows up its win and drives you out of %s." % GameData.map_data(weakest)["name"])
			history[-1] += " The last night was lost."
		else:
			history[-1] += " The last night ended with nothing settled."
	sitting_out.clear()
	pending_event = _draw_event() if not fighters.is_empty() else {}
	rep["event"] = not pending_event.is_empty()
	last_report = rep
	return rep

# ------------------------------------------------------------------ the night after

static var _events: Array = []

const WARD_HOLD_MAX := 4

func record_ward(ward: String, rep: Dictionary) -> void:
	## Count the fight in its ward. Win there often enough and the band holds
	## the ward; lose a fight there and the hold is gone.
	rep["ward_taken"] = ""
	rep["ward_lost"] = ""
	if ward == "":
		return
	if not rep.has("lines"):
		rep["lines"] = []
	var wr: Dictionary = wards.get(ward, {"fought": 0, "won": 0, "held": false})
	wr["fought"] = int(wr["fought"]) + 1
	if rep["won"]:
		wr["won"] = int(wr["won"]) + 1
	var wname: String = GameData.map_data(ward)["name"]
	if bool(wr.get("held", false)) and not rep["won"] and not rep.get("draw", false) and bool(wr.get("guard", false)):
		# its people stood with you once: the ward holds through this loss
		wr["guard"] = false
		rep["lines"].append("You lose the fight, but the folk of %s hide your people and bar the streets. The ward is still yours." % wname)
	elif bool(wr.get("held", false)) and not rep["won"] and not rep.get("draw", false):
		wr["held"] = false
		rep["ward_lost"] = ward
		rep["lines"].append("The enemy drives you out of %s. The ward is no longer yours." % wname)
	elif not bool(wr.get("held", false)) and rep["won"] and held_wards().size() < WARD_HOLD_MAX and int(wr["won"]) >= 2 and int(wr["won"]) * 2 > int(wr["fought"]):
		wr["held"] = true
		rep["ward_taken"] = ward
		rep["lines"].append("Your band now holds %s. Its scavengers and squatters will pay you dues." % wname)
	wards[ward] = wr

const RIVAL_ADV_MAX := 6
const RIVAL_BOUNTY := 10          # jakatas for putting a known rival leader out of action
const RIVAL_BOUNTY_ADV := 5       # and this much more for each fight they had walked away from

func _rival(res: Dictionary, rep: Dictionary) -> void:
	## Every band you fight becomes a rival with a leader who remembers you.
	## A leader who walks away grows harder; one taken out of action may die,
	## and a new one takes their place.
	var foe := String(res.get("enemy", ""))
	var fl: Dictionary = res.get("foe_leader", {})
	rep["rival_line"] = ""
	if foe == "" or fl.is_empty():
		return
	var wb := GameData.warband(foe)
	var rv: Dictionary = rivals.get(foe, {"leader": fl["name"], "adv": 0, "fought": 0, "you_won": 0, "they_won": 0, "felled": 0, "leaders_lost": 0, "met": 0})
	rv["leader"] = fl["name"]
	rv["fought"] = int(rv["fought"]) + 1
	if rep["won"]:
		rv["you_won"] = int(rv["you_won"]) + 1
	elif not rep["draw"]:
		rv["they_won"] = int(rv["they_won"]) + 1
	rv["felled"] = int(rv["felled"]) + int(res.get("foe_kills", 0))
	var line := ""
	var was_rival := rivals.has(foe)
	if String(fl["status"]) == "ooa" and was_rival:
		# a price on a known rival's head, paid by the fences who are sick of them
		var bounty := RIVAL_BOUNTY + RIVAL_BOUNTY_ADV * int(rv["adv"])
		gold += bounty
		rep["rival_bounty"] = bounty
		var who := String(fl.get("by", ""))
		rep["lines"].append(("%s put down %s, and the fences pay the price on their head: %d jakatas." % [who, fl["name"], bounty]) if who != "" else ("%s is down, and the fences pay the price on their head: %d jakatas." % [fl["name"], bounty]))
	if String(fl["status"]) == "ooa":
		var r := rng.randi_range(1, 6)
		if r <= 2:
			var old := String(fl["name"])
			var lead_def := ""
			for e in wb["battle_roster"]:
				if wb["units"][e["unit"]]["role"] == "leader":
					lead_def = e["unit"]
					break
			var rank := ""
			if lead_def != "":
				var dn := String(wb["units"][lead_def]["name"])
				var first := String(wb["battle_roster"][0]["name"])
				if first.begins_with(dn + " "):
					rank = dn + " "
			var nm := rank + _fresh_name(wb, {old: true})
			rv["leader"] = nm
			rv["adv"] = 0
			rv["met"] = 0
			rv["leaders_lost"] = int(rv["leaders_lost"]) + 1
			line = "%s, who led the %s, never gets up (rolled %d). %s takes their place, and swears to settle the score." % [old, wb["name"], r, nm]
		else:
			rv["adv"] = maxi(0, int(rv["adv"]) - 1)
			rv["met"] = int(rv.get("met", 0)) + 1
			line = "%s, leader of the %s, is dragged off the field alive (rolled %d), and will remember who put them down." % [fl["name"], wb["name"], r]
	else:
		rv["adv"] = mini(RIVAL_ADV_MAX, int(rv["adv"]) + 1)
		rv["met"] = int(rv.get("met", 0)) + 1
		line = "%s, leader of the %s, walks away from the fight a little harder than before." % [fl["name"], wb["name"]]
	rivals[foe] = rv
	rep["rival_line"] = line
	rep["lines"].append(line)

func rival_text(foe: String) -> String:
	## One line on your history with a band, for the camp's pages.
	if not rivals.has(foe):
		return ""
	var rv: Dictionary = rivals[foe]
	var s := "Their leader is %s" % rv["leader"]
	if int(rv["adv"]) > 0:
		s += ", hardened by %d fight%s" % [int(rv["adv"]), "" if int(rv["adv"]) == 1 else "s"]
	s += ". You have met them %d time%s: you won %d, they won %d" % [int(rv["fought"]), "" if int(rv["fought"]) == 1 else "s", int(rv["you_won"]), int(rv["they_won"])]
	if int(rv["leaders_lost"]) > 0:
		s += ", and one of their leaders lies dead at your hands" if int(rv["leaders_lost"]) == 1 else ", and %d of their leaders lie dead at your hands" % int(rv["leaders_lost"])
	return s + "."

func last_night_ready() -> bool:
	## Hold as many wards as a band can and the others gather against you.
	return crowned == 0 and held_wards().size() >= WARD_HOLD_MAX

const LAST_NIGHT_MAP := "hethra_square"
const LAST_NIGHT_SCENARIO := "hold"
const LAST_NIGHT_BOOST := 1.3

func held_wards() -> Array:
	## The wards the band holds, in map order.
	var out: Array = []
	for k in wards:
		if bool(wards[k].get("held", false)):
			out.append(k)
	return out

static func ward_tribute() -> int:
	return int(data().get("ward_tribute", 8))

static func events() -> Array:
	if _events.is_empty():
		_events = GameData.load_json("res://data/events.json")["events"]
	return _events

static func event_def(eid: String) -> Dictionary:
	for e in events():
		if e["id"] == eid:
			return e
	return {}

func _room() -> bool:
	return fighters.size() < int(warband()["max_size"])

func _draw_event() -> Dictionary:
	var pool: Array = []
	for e in events():
		if recent_events.has(e["id"]):
			continue
		var needs: Dictionary = e.get("needs", {})
		if needs.get("room", false) and not _room():
			continue
		if shards < int(needs.get("shards_min", 0)):
			continue
		if needs.get("rival", false) and rivals.is_empty():
			continue
		if needs.get("held", false) and held_wards().is_empty():
			continue
		pool.append(e)
	if pool.is_empty():
		return {}
	var e: Dictionary = pool[rng.randi_range(0, pool.size() - 1)]
	recent_events.append(e["id"])
	while recent_events.size() > 4:
		recent_events.remove_at(0)
	var who = null
	var want: String = e.get("who", "")
	if want != "":
		var cands: Array = fighters.filter(func(f): return want == "any" \
			or (want == "hero" and (f["role"] == "hero" or f["role"] == "leader")) or (want == "henchman" and f["role"] == "henchman"))
		if cands.is_empty():
			cands = fighters
		who = cands[rng.randi_range(0, cands.size() - 1)]
	var pe := {"id": e["id"], "who_uid": int(who["uid"]) if who != null else -1}
	var needs: Dictionary = e.get("needs", {})
	if needs.get("rival", false):
		var foes: Array = rivals.keys()
		pe["rival"] = foes[rng.randi_range(0, foes.size() - 1)]
	if needs.get("held", false):
		var hw := held_wards()
		pe["ward"] = hw[rng.randi_range(0, hw.size() - 1)]
	return pe

func event_text(s: String, extra := {}) -> String:
	var who := fighter(int(pending_event.get("who_uid", -1)))
	var lname := "the band"
	for f in fighters:
		if f["role"] == "leader":
			lname = f["name"]
	s = s.replace("{who}", String(who.get("name", "the watch")))
	s = s.replace("{leader}", lname)
	var rf := String(pending_event.get("rival", ""))
	if rf != "" and rivals.has(rf):
		s = s.replace("{rival}", String(rivals[rf]["leader"]))
		s = s.replace("{rival_band}", String(GameData.warband(rf)["name"]))
	var wk := String(pending_event.get("ward", ""))
	if wk != "":
		s = s.replace("{ward}", String(GameData.map_data(wk)["name"]))
	for k in extra:
		s = s.replace("{%s}" % k, str(extra[k]))
	return s

func event_choice_problem(i: int) -> String:
	## "" if choice i can be taken now, else why not.
	var e := event_def(pending_event.get("id", ""))
	if e.is_empty() or i < 0 or i >= (e["choices"] as Array).size():
		return "No such choice."
	var ch: Dictionary = e["choices"][i]
	if gold < int(ch.get("cost_gold", 0)):
		return "You need %d %s." % [int(ch["cost_gold"]), coin_word()]
	if shards < int(ch.get("cost_shards", 0)):
		return "You need %d godshard%s." % [int(ch["cost_shards"]), "" if int(ch["cost_shards"]) == 1 else "s"]
	var fx: Dictionary = ch.get("effects", {})
	if fx.get("recruit", false) and not _room():
		return "The warband is full."
	return ""

func _cheapest_henchman() -> String:
	var wbd := warband()
	var cheapest := ""
	for ut in wbd["units"]:
		var ud: Dictionary = wbd["units"][ut]
		if ud["role"] == "henchman" and (cheapest == "" or int(ud["cost"]) < int(wbd["units"][cheapest]["cost"])):
			cheapest = ut
	return cheapest

func resolve_event(i: int) -> Dictionary:
	## Takes choice i of the waiting night. Returns {"title", "text", "roll", "lines", "advances"}.
	if event_choice_problem(i) != "":
		return {}
	var e := event_def(pending_event["id"])
	var ch: Dictionary = e["choices"][i]
	var out := {"id": e["id"], "title": event_text(e["title"]), "choice": event_text(ch["label"]), "roll": 0, "lines": [], "advances": []}
	gold -= int(ch.get("cost_gold", 0))
	shards -= int(ch.get("cost_shards", 0))
	var text: String = ch.get("text", "")
	var fx: Dictionary = ch.get("effects", {})
	if ch.has("roll"):
		var r := rng.randi_range(1, 6)
		out["roll"] = r
		for band in ch["roll"]:
			if r <= int(band["to"]):
				text = band["text"]
				fx = band.get("effects", {})
				break
	var extra := {"roll": out["roll"]}
	var who := fighter(int(pending_event.get("who_uid", -1)))
	var target: Dictionary = who
	if fx.get("on", "") == "leader" and leader_fighter() != null:
		target = leader_fighter()
	if fx.has("gold"):
		var g := int(fx["gold"])
		var before := gold
		gold = maxi(0, gold + g)
		out["lines"].append(("+%d %s" % [g, coin_word()]) if g > 0 else ("-%d %s" % [before - gold, coin_word()]))
	if fx.has("shards"):
		shards += int(fx["shards"])
		out["lines"].append("+%d godshard%s" % [int(fx["shards"]), "" if int(fx["shards"]) == 1 else "s"])
	if fx.has("xp") and not target.is_empty():
		var b := int(target["xp"])
		target["xp"] = b + int(fx["xp"])
		out["lines"].append("%s +%d experience" % [target["name"], int(fx["xp"])])
		for adv in _check_advances(target, b):
			out["advances"].append(target["name"])
	if fx.has("xp_henchmen"):
		for f in fighters:
			if f["role"] == "henchman":
				var b := int(f["xp"])
				f["xp"] = b + int(fx["xp_henchmen"])
				for adv in _check_advances(f, b):
					out["advances"].append(f["name"])
		out["lines"].append("Every henchman +%d experience" % int(fx["xp_henchmen"]))
	if fx.has("rival_adv"):
		var rf := String(pending_event.get("rival", ""))
		if rivals.has(rf):
			var rv: Dictionary = rivals[rf]
			var a0 := int(rv["adv"])
			rv["adv"] = clampi(a0 + int(fx["rival_adv"]), 0, RIVAL_ADV_MAX)
			if int(rv["adv"]) > a0:
				out["lines"].append("%s grows bolder" % rv["leader"])
			elif int(rv["adv"]) < a0:
				out["lines"].append("%s is shaken" % rv["leader"])
	if fx.get("ward_guard", false):
		var wk := String(pending_event.get("ward", ""))
		if wards.has(wk):
			wards[wk]["guard"] = true
			out["lines"].append("%s will stand with you through one lost fight" % GameData.map_data(wk)["name"])
	if fx.get("sick", false) and not who.is_empty():
		who["miss_next"] = true
		out["lines"].append("%s sits out the next battle" % who["name"])
	if fx.get("recruit", false):
		var ut := _cheapest_henchman()
		if ut != "" and _room():
			var nf := _fighter_from_def(ut, warband()["units"][ut], _fresh_name(warband(), {}))
			nf["xp"] = 0
			if fx.get("recruit_sick", false):
				nf["miss_next"] = true
			fighters.append(nf)
			extra["recruit"] = nf["name"]
			out["lines"].append("%s joins as a %s" % [nf["name"], type_name(nf)])
	out["text"] = event_text(text, extra)
	history.append("  The night after: %s. %s" % [out["title"], out["text"]])
	pending_event = {}
	return out

func _lead_score(f: Dictionary) -> int:
	return (100 if f["role"] == "hero" else 0) + int(f["stats"]["Ld"]) * 10 + int(f["xp"])

func _d66() -> Array:
	return [rng.randi_range(1, 6), rng.randi_range(1, 6)]

func _roll_injury(f: Dictionary) -> Dictionary:
	if f["role"] == "henchman" or f["role"] == "sword":
		var r := rng.randi_range(1, 6)
		var out := {"uid": f["uid"], "name": f["name"], "dice": [r], "id": "dead" if r <= 2 else "fine"}
		out["title"] = "Hood's due" if r <= 2 else "Back on their feet"
		out["text"] = "Dead." if r <= 2 else "Bruised, but fit to fight."
		return out
	var d := _d66()
	var idx := (int(d[0]) - 1) * 6 + (int(d[1]) - 1)
	var row: Dictionary = {}
	for t in data()["injuries"]:
		if idx <= int(t["to"]):
			row = t
			break
	var out := {"uid": f["uid"], "name": f["name"], "dice": d, "id": row["id"], "title": row["name"], "text": row["text"]}
	match row["id"]:
		"deep":
			f["miss_next"] = true
		"robbed":
			f["gear"] = ["dagger"]
			f["munitions"] = {}
		"old":
			f["old_wound"] = true
		"touched":
			var before := int(f["xp"])
			f["xp"] = before + 3
			_check_advances(f, before)
		"captured":
			if gold >= 50:
				gold -= 50
				out["text"] = "Taken by the enemy; the warband paid a 50 jakata ransom to get them back."
			else:
				out["id"] = "dead"
				out["text"] = "Taken by the enemy, and the warband could not pay the ransom. Lost."
	if row.has("stat"):
		var s: String = row["stat"]
		if row.get("plus", false):
			f["stats"][s] = mini(int(f["stats"][s]) + 1, int(caps()[s]))
		else:
			f["stats"][s] = maxi(1, int(f["stats"][s]) - 1)
	if row["id"] != "fine" and row["id"] != "dead" and row["id"] != "touched":
		(f["injuries"] as Array).append(row["name"])
	return out

func _check_advances(f: Dictionary, before: int) -> Array:
	var got: Array = []
	for t in xp_track(f):
		if int(t) > before and int(t) <= int(f["xp"]):
			got.append(_roll_advance(f))
	return got

func _roll_advance(f: Dictionary) -> Dictionary:
	var d := [rng.randi_range(1, 6), rng.randi_range(1, 6)]
	var total: int = d[0] + d[1]
	var table: Array = data()["hero_advances"] if f["role"] != "henchman" else data()["henchman_advances"]
	var row: Dictionary = table[-1]
	for t in table:
		if total <= int(t["to"]):
			row = t
			break
	var adv := {"dice": d, "kind": row["kind"], "pick": []}
	if row["kind"] == "talent":
		if hero_count() < int(data()["max_heroes"]):
			f["role"] = "hero"
			f["promoted"] = true
			adv["kind"] = "skill"
			adv["talent"] = true
		else:
			adv["kind"] = "stat"
			row = {"pick": ["WS", "BS"]}
	if adv["kind"] == "stat":
		var opts: Array = (row["pick"] as Array).filter(func(s): return int(f["stats"][s]) < int(caps()[s]))
		if opts.is_empty():
			adv["kind"] = "skill"
		else:
			adv["pick"] = opts
	if adv["kind"] == "skill":
		adv["pick"] = _skill_choices(f)
		if adv["pick"].is_empty():
			adv["kind"] = "stat"
			adv["pick"] = ["Ld"] if int(f["stats"]["Ld"]) < int(caps()["Ld"]) else []
	if (adv["pick"] as Array).size() == 1:
		_apply_advance(f, adv["kind"], adv["pick"][0])
		adv["chosen"] = adv["pick"][0]
	elif not (adv["pick"] as Array).is_empty():
		(f["pending"] as Array).append(adv)
	return adv

func _skill_choices(f: Dictionary) -> Array:
	var pool: Dictionary = data()["skill_pool"]
	var opts: Array = (pool["any"] as Array).duplicate()
	if f["role"] == "leader":
		opts += pool["leader"]
	if is_caster(f):
		opts += pool["caster"]
	opts += pool.get(faction, [])
	opts = opts.filter(func(s): return not (f["skills"] as Array).has(s))
	var out: Array = []
	while out.size() < 3 and not opts.is_empty():
		var s: String = opts[rng.randi_range(0, opts.size() - 1)]
		opts.erase(s)
		out.append(s)
	return out

func _apply_advance(f: Dictionary, kind: String, what: String) -> void:
	if kind == "stat":
		f["stats"][what] = mini(int(f["stats"][what]) + 1, int(caps()[what]))
	else:
		if not (f["skills"] as Array).has(what):
			(f["skills"] as Array).append(what)

func choose_advance(uid: int, which: String) -> bool:
	## Settles the first open advance of this fighter with the given stat or skill.
	var f := fighter(uid)
	if f.is_empty() or (f["pending"] as Array).is_empty():
		return false
	var adv: Dictionary = f["pending"][0]
	if not (adv["pick"] as Array).has(which):
		return false
	_apply_advance(f, adv["kind"], which)
	(f["pending"] as Array).remove_at(0)
	return true

func auto_choose_all() -> void:
	for f in fighters:
		while not (f["pending"] as Array).is_empty():
			choose_advance(int(f["uid"]), f["pending"][0]["pick"][0])

# ------------------------------------------------------------------ the market

static func shard_price(n_sold: int) -> int:
	var t: Array = data()["shard_price"]
	return int(t[clampi(n_sold, 0, t.size() - 1)])

func sell_shards(n: int) -> int:
	n = clampi(n, 0, shards)
	if n == 0:
		return 0
	var coin := shard_price(n) * n
	shards -= n
	gold += coin
	return coin

func armoury() -> Array:
	return data()["armoury"].get(faction, [])

static func item_cost(item: String) -> int:
	var r := GameData.rules()
	for group in ["weapons", "armour", "munitions"]:
		if r[group].has(item):
			return int(r[group][item].get("cost", 0))
	return 0

static func item_kind(item: String) -> String:
	var r := GameData.rules()
	if r["weapons"].has(item):
		return r["weapons"][item]["kind"]
	if r["munitions"].has(item):
		return "munition"
	if item == "light" or item == "heavy":
		return "armour"
	return item  # shield, helm

func can_buy(uid: int, item: String) -> String:
	## "" if allowed, otherwise the reason.
	var f := fighter(uid)
	if f.is_empty():
		return "No such fighter."
	if f["role"] == "sword":
		return "Sellswords bring their own kit."
	var cost := item_cost(item)
	if cost > gold:
		return "Costs %d; you have %d." % [cost, gold]
	var gear: Array = f["gear"]
	var kind := item_kind(item)
	match kind:
		"melee":
			var n := 0
			var two := false
			for g in gear:
				var wd := GameData.weapon(g)
				if wd.get("kind", "") == "melee":
					n += 1
					two = two or wd.get("two_handed", false)
			if two:
				return "Their two-hand weapon leaves no hand free."
			if n >= 2:
				return "Already carries two hand weapons."
			if GameData.weapon(item).get("two_handed", false) and gear.has("shield"):
				return "Needs both hands: sell the shield first."
		"missile":
			for g in gear:
				if GameData.weapon(g).get("kind", "") == "missile":
					return "Already carries a missile weapon."
		"armour":
			if gear.has("light") or gear.has("heavy"):
				return "Already wears armour: sell it first."
			if is_caster(f) and item == "heavy":
				return "Heavy plate smothers a mage's warren."
		"shield":
			if gear.has("shield"):
				return "Already has a shield."
			for g in gear:
				if GameData.weapon(g).get("two_handed", false):
					return "Their two-hand weapon leaves no hand free."
		"helm":
			if gear.has("helm"):
				return "Already has a helm."
		"munition":
			if not (f["skills"] as Array).has("munitions"):
				return "Only a fighter with a sapper's kit can carry munitions."
			if int(f["munitions"].get(item, 0)) >= 3:
				return "Carries as many as they can."
	return ""

func buy(uid: int, item: String) -> String:
	var why := can_buy(uid, item)
	if why != "":
		return why
	var f := fighter(uid)
	gold -= item_cost(item)
	if item_kind(item) == "munition":
		f["munitions"][item] = int(f["munitions"].get(item, 0)) + 1
	else:
		(f["gear"] as Array).append(item)
	return ""

static func sell_price(item: String) -> int:
	return item_cost(item) / 2

func sell(uid: int, item: String) -> bool:
	var f := fighter(uid)
	if f.is_empty():
		return false
	if item_kind(item) == "munition":
		if int(f["munitions"].get(item, 0)) <= 0:
			return false
		f["munitions"][item] = int(f["munitions"][item]) - 1
	else:
		if not (f["gear"] as Array).has(item):
			return false
		(f["gear"] as Array).erase(item)
	gold += sell_price(item)
	return true

func can_hire(unit_type: String) -> String:
	var wb := warband()
	var def: Dictionary = wb["units"].get(unit_type, {})
	if def.is_empty():
		return "Unknown fighter."
	if fighters.size() >= int(wb["max_size"]):
		return "The warband is full (%d)." % int(wb["max_size"])
	var mx := int(def.get("max", 0))
	if mx > 0:
		var have := fighters.filter(func(f): return f["unit"] == unit_type).size()
		if have >= mx:
			return "No more than %d." % mx
	if def["role"] == "leader":
		return "A warband has one leader."
	if def["role"] == "hero" and hero_count() >= int(data()["max_heroes"]):
		return "No more than %d heroes." % int(data()["max_heroes"])
	if int(def["cost"]) > gold:
		return "Costs %d; you have %d." % [int(def["cost"]), gold]
	return ""

func hire(unit_type: String, fname := "") -> Dictionary:
	if can_hire(unit_type) != "":
		return {}
	var wb := warband()
	var def: Dictionary = wb["units"][unit_type]
	if fname == "":
		fname = _fresh_name(wb, {})
	var f := _fighter_from_def(unit_type, def, fname)
	# new recruits arrive green
	if f["role"] == "henchman":
		f["xp"] = 0
	fighters.append(f)
	gold -= int(def["cost"])
	return f

func dismiss(uid: int) -> bool:
	var f := fighter(uid)
	if f.is_empty() or f["role"] == "leader" or fighters.size() <= 1:
		return false
	fighters.erase(f)
	return true

# ------------------------------------------------------------------ saving

func to_dict() -> Dictionary:
	return {
		"version": 1, "id": id, "faction": faction, "name": name, "gold": gold, "shards": shards,
		"battles": battles, "wins": wins, "losses": losses, "fighters": fighters, "fallen": fallen,
		"history": history, "next_uid": next_uid, "rng_state": str(rng.state), "rng_seed": str(rng.seed),
		"last_report": last_report, "sitting_out": sitting_out, "created": created,
		"pending_event": pending_event, "recent_events": recent_events, "wards": wards, "crowned": crowned, "rivals": rivals,
		"updated": int(Time.get_unix_time_from_system()),
	}

static func from_dict(d: Dictionary) -> Campaign:
	var c := Campaign.new()
	c.id = d.get("id", "")
	c.faction = d.get("faction", "marines")
	c.name = d.get("name", "")
	c.gold = int(d.get("gold", 0))
	c.shards = int(d.get("shards", 0))
	c.battles = int(d.get("battles", 0))
	c.wins = int(d.get("wins", 0))
	c.losses = int(d.get("losses", 0))
	c.fighters = _ints(d.get("fighters", []))
	c.fallen = d.get("fallen", [])
	c.history = d.get("history", [])
	for k in d.get("wards", {}):
		var w: Dictionary = d["wards"][k]
		c.wards[k] = {"fought": int(w.get("fought", 0)), "won": int(w.get("won", 0)), "held": bool(w.get("held", false)), "guard": bool(w.get("guard", false))}
	c.crowned = int(d.get("crowned", 0))
	for k in d.get("rivals", {}):
		var rv: Dictionary = d["rivals"][k]
		var nr := {"leader": String(rv.get("leader", ""))}
		for f in ["adv", "fought", "you_won", "they_won", "felled", "leaders_lost", "met"]:
			nr[f] = int(rv.get(f, 0))
		c.rivals[k] = nr
	c.next_uid = int(d.get("next_uid", 1))
	# 64-bit dice state kept as text, since JSON numbers lose the low bits
	c.rng.seed = String(d.get("rng_seed", "1")).to_int()
	c.rng.state = String(d.get("rng_state", "1")).to_int()
	c.last_report = d.get("last_report", {})
	c.sitting_out = (d.get("sitting_out", []) as Array).map(func(x): return int(x))
	c.pending_event = d.get("pending_event", {})
	if c.pending_event.has("who_uid"):
		c.pending_event["who_uid"] = int(c.pending_event["who_uid"])
	c.recent_events = d.get("recent_events", [])
	c.created = int(d.get("created", 0))
	c.updated = int(d.get("updated", 0))
	return c

static func _ints(fs: Array) -> Array:
	## JSON turns every number into a float; put the counts back to ints.
	for f in fs:
		f["uid"] = int(f["uid"])
		f["xp"] = int(f["xp"])
		f["kills"] = int(f.get("kills", 0))
		f["battles"] = int(f.get("battles", 0))
		for k in f["stats"]:
			f["stats"][k] = int(f["stats"][k])
		for k in f["munitions"]:
			f["munitions"][k] = int(f["munitions"][k])
		for a in f.get("pending", []):
			a["dice"] = (a.get("dice", []) as Array).map(func(x): return int(x))
	return fs

func save() -> bool:
	DirAccess.make_dir_recursive_absolute(SAVE_DIR)
	updated = int(Time.get_unix_time_from_system())
	var f := FileAccess.open("%s/%s.json" % [SAVE_DIR, id], FileAccess.WRITE)
	if f == null:
		push_error("Cannot save campaign " + id)
		return false
	f.store_string(JSON.stringify(to_dict(), "\t"))
	f.close()
	return true

static func load_file(file_id: String) -> Campaign:
	var path := "%s/%s.json" % [SAVE_DIR, file_id]
	if not FileAccess.file_exists(path):
		return null
	var d = GameData.load_json(path)
	if d == null or not d is Dictionary:
		return null
	return from_dict(d)

static func list_saves() -> Array:
	## [{"id", "name", "faction", "battles", "updated"}], newest first.
	var out: Array = []
	var dir := DirAccess.open(SAVE_DIR)
	if dir == null:
		return out
	for fn in dir.get_files():
		if not fn.ends_with(".json"):
			continue
		var d = GameData.load_json("%s/%s" % [SAVE_DIR, fn])
		if d is Dictionary:
			var rt := 0
			for f in d.get("fighters", []):
				rt += int(data()["rating_per_fighter"]) + int(f.get("xp", 0))
			out.append({"id": fn.get_basename(), "name": d.get("name", "?"), "faction": d.get("faction", ""),
				"battles": int(d.get("battles", 0)), "wins": int(d.get("wins", 0)), "updated": int(d.get("updated", 0)),
				"fighters": (d.get("fighters", []) as Array).size(), "rating": rt})
	out.sort_custom(func(a, b): return a["updated"] > b["updated"])
	return out

static func delete_save(file_id: String) -> void:
	DirAccess.remove_absolute("%s/%s.json" % [SAVE_DIR, file_id])
