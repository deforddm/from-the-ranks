extends Node
## Root of the game: shows the main menu or a battle, depending on Game.mode.

func _ready() -> void:
	get_window().title = "Hethra, City of the Fallen"
	if Game.mode == "battle":
		add_child(Battle.new())
	elif Game.mode == "camp" or Game.mode == "aftermath":
		add_child(CampScreen.new())
	else:
		add_child(MainMenu.new())
