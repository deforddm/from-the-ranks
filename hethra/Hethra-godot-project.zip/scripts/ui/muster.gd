class_name Muster
extends SubViewportContainer
## The title screen's muster: the warband you have picked, standing round a
## brazier on a slab of broken paving, each kind of fighter once, alive and
## restless. Pick another warband and the new one takes its place.

var vp: SubViewport
var world: Node3D
var cam: Camera3D
var stage: Node3D
var fire: OmniLight3D
var figs: Array = []
var shown := ""
var t := 0.0
var _next_act := 2.5
var rng := RandomNumberGenerator.new()

func _ready() -> void:
	Figure.water_y = -100.0
	stretch = true
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	vp = SubViewport.new()
	vp.own_world_3d = true
	vp.transparent_bg = true
	vp.msaa_3d = Viewport.MSAA_4X
	vp.positional_shadow_atlas_size = 2048
	add_child(vp)
	world = Node3D.new()
	vp.add_child(world)
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_CLEAR_COLOR
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.32, 0.4, 0.46)
	env.ambient_light_energy = 0.3
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.05
	env.glow_enabled = true
	env.glow_intensity = 0.6
	env.glow_bloom = 0.08
	we.environment = env
	world.add_child(we)
	# cold moonlight from behind for a rim, warm fire from in front
	var moon := DirectionalLight3D.new()
	moon.rotation = Vector3(-0.55, PI * 0.82, 0)
	moon.light_color = Color(0.55, 0.7, 0.85)
	moon.light_energy = 1.6
	moon.shadow_enabled = true
	world.add_child(moon)
	var key := DirectionalLight3D.new()
	key.rotation = Vector3(-0.5, 0.35, 0)
	key.light_color = Color(0.9, 0.85, 0.8)
	key.light_energy = 0.2
	world.add_child(key)
	fire = OmniLight3D.new()
	fire.position = Vector3(-1.9, 1.15, 0.75)
	fire.light_color = Color(1.0, 0.58, 0.28)
	fire.light_energy = 1.5
	fire.omni_range = 6.5
	fire.shadow_enabled = true
	world.add_child(fire)
	_build_ground()
	stage = Node3D.new()
	world.add_child(stage)
	cam = Camera3D.new()
	cam.fov = 34.0
	world.add_child(cam)
	cam.current = true
	_place_cam()

func _mat(c: Color, rough := 0.9, metal := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	return m

func _build_ground() -> void:
	# a raised slab of cracked paving, the edges broken away
	var stone := _mat(Color(0.2, 0.19, 0.18), 0.95)
	var dark := _mat(Color(0.12, 0.115, 0.11), 0.95)
	var r := RandomNumberGenerator.new()
	r.seed = 77
	for gx in range(-5, 6):
		for gz in range(-3, 3):
			var p := Vector3(gx * 0.62, 0, gz * 0.62 - 0.4)
			var edge := absf(gx) / 5.0 + absf(gz + 0.5) / 3.0
			if edge > 1.25 and r.randf() < 0.6:
				continue
			var mi := MeshInstance3D.new()
			var bm := BoxMesh.new()
			bm.size = Vector3(0.6, 0.22 + r.randf() * 0.05, 0.6)
			mi.mesh = bm
			mi.material_override = stone if r.randf() < 0.7 else dark
			mi.position = p + Vector3(0, -0.11 + r.randf_range(-0.03, 0.015), 0)
			mi.rotation = Vector3(r.randf_range(-0.04, 0.04), r.randf_range(-0.06, 0.06), r.randf_range(-0.04, 0.04))
			world.add_child(mi)
	# rubble at the edges
	for i in range(18):
		var mi := MeshInstance3D.new()
		var bm := BoxMesh.new()
		var s := r.randf_range(0.12, 0.34)
		bm.size = Vector3(s, s * 0.7, s * r.randf_range(0.8, 1.4))
		mi.mesh = bm
		mi.material_override = stone
		var a := r.randf_range(-PI, 0.2)
		var rad := r.randf_range(2.6, 3.4)
		mi.position = Vector3(cos(a) * rad, s * 0.2, sin(a) * rad * 0.55 - 0.6)
		mi.rotation = Vector3(r.randf(), r.randf() * 3.0, r.randf())
		world.add_child(mi)
	# a broken column behind the warband
	var col := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.26
	cm.bottom_radius = 0.3
	cm.height = 2.6
	col.mesh = cm
	col.material_override = stone
	col.position = Vector3(-2.3, 1.2, -1.9)
	col.rotation.z = 0.06
	world.add_child(col)
	var cap := MeshInstance3D.new()
	var capm := BoxMesh.new()
	capm.size = Vector3(0.8, 0.22, 0.8)
	cap.mesh = capm
	cap.material_override = dark
	cap.position = Vector3(-2.25, 2.55, -1.9)
	cap.rotation = Vector3(0.1, 0.4, 0.08)
	world.add_child(cap)
	# the brazier: an iron bowl on three legs, coals and a flame
	var iron := _mat(Color(0.1, 0.1, 0.1), 0.5, 0.7)
	var bowl := MeshInstance3D.new()
	var bwm := CylinderMesh.new()
	bwm.top_radius = 0.3
	bwm.bottom_radius = 0.14
	bwm.height = 0.2
	bowl.mesh = bwm
	bowl.material_override = iron
	bowl.position = Vector3(-1.9, 0.72, 0.75)
	world.add_child(bowl)
	for i in range(3):
		var leg := MeshInstance3D.new()
		var lm := BoxMesh.new()
		lm.size = Vector3(0.04, 0.72, 0.04)
		leg.mesh = lm
		leg.material_override = iron
		var a := i * TAU / 3.0
		leg.position = Vector3(-1.9 + cos(a) * 0.16, 0.34, 0.75 + sin(a) * 0.16)
		leg.rotation = Vector3(sin(a) * 0.3, 0, -cos(a) * 0.3)
		world.add_child(leg)
	var coals := MeshInstance3D.new()
	var com := SphereMesh.new()
	com.radius = 0.25
	com.height = 0.16
	coals.mesh = com
	coals.material_override = Mats.glow(Color(1.0, 0.35, 0.08), 3.0)
	coals.position = Vector3(-1.9, 0.82, 0.75)
	world.add_child(coals)
	var flame := GPUParticles3D.new()
	flame.amount = 40
	flame.lifetime = 0.9
	var pm := ParticleProcessMaterial.new()
	pm.direction = Vector3.UP
	pm.spread = 12.0
	pm.initial_velocity_min = 0.5
	pm.initial_velocity_max = 1.1
	pm.gravity = Vector3(0, 0.6, 0)
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	pm.emission_sphere_radius = 0.15
	pm.scale_min = 0.6
	pm.scale_max = 1.2
	var grad := Gradient.new()
	grad.set_color(0, Color(1.0, 0.75, 0.3, 1.0))
	grad.set_color(1, Color(0.8, 0.15, 0.02, 0.0))
	var gt := GradientTexture1D.new()
	gt.gradient = grad
	pm.color_ramp = gt
	flame.process_material = pm
	var q := QuadMesh.new()
	q.size = Vector2(0.22, 0.3)
	var fm := StandardMaterial3D.new()
	var soft := GradientTexture2D.new()
	soft.fill = GradientTexture2D.FILL_RADIAL
	soft.fill_from = Vector2(0.5, 0.5)
	soft.fill_to = Vector2(1.0, 0.5)
	var sg := Gradient.new()
	sg.set_color(0, Color(1, 1, 1, 1))
	sg.set_color(1, Color(1, 1, 1, 0))
	soft.gradient = sg
	fm.albedo_texture = soft
	fm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	fm.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	fm.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	fm.vertex_color_use_as_albedo = true
	fm.albedo_color = Color(1, 1, 1)
	q.material = fm
	flame.draw_pass_1 = q
	flame.position = Vector3(-1.9, 0.86, 0.75)
	world.add_child(flame)

func show_warband(id: String) -> void:
	if id == shown:
		return
	shown = id
	for f in figs:
		f.queue_free()
	figs.clear()
	var wb := GameData.warband(id)
	var keys: Array = wb["units"].keys()
	keys = keys.slice(0, 6)
	# the leader stands in the middle, the rest fan out to either side
	var order: Array = []
	for i in range(keys.size()):
		if i % 2 == 0:
			order.append(keys[i])
		else:
			order.push_front(keys[i])
	var n := order.size()
	var uid := 900
	for i in range(n):
		var key: String = order[i]
		var u := BUnit.new()
		u.id = uid
		uid += 1
		u.setup_from(wb["units"][key], wb, {"unit": key})
		var f := Figure.new()
		stage.add_child(f)
		f.setup(u, wb)
		f.label.visible = false
		var off := i - (n - 1) * 0.5
		f.position = Vector3(off * 0.95, 0, -absf(off) * 0.32 - 0.3)
		f.rotation.y = -off * 0.13
		figs.append(f)
	# they step in out of the dark
	for f in figs:
		var target: Vector3 = f.position
		f.position = target + Vector3(0, 0, -1.4)
		f.moving = true
		var tw: Tween = f.create_tween()
		tw.tween_property(f, "position", target, 0.9 + rng.randf() * 0.4).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
		tw.tween_callback(func(): f.moving = false)
	_next_act = 2.2

func _place_cam() -> void:
	var a := sin(t * 0.18) * 0.16
	cam.position = Vector3(sin(a) * 6.8 + 0.6, 2.5, cos(a) * 6.8 + 0.4)
	cam.look_at(Vector3(0.6, 0.85, -0.4), Vector3.UP)

func _process(delta: float) -> void:
	t += delta
	_place_cam()
	fire.light_energy = 1.45 + sin(t * 9.0) * 0.12 + sin(t * 23.0) * 0.08
	_next_act -= delta
	if _next_act <= 0.0 and not figs.is_empty():
		_next_act = rng.randf_range(2.2, 4.0)
		var f: Figure = figs[rng.randi() % figs.size()]
		var front: Vector3 = f.global_position + Vector3(rng.randf_range(-1.5, 1.5), 0, 4.0)
		var r0 := f.rotation.y
		get_tree().create_timer(1.6).timeout.connect(func():
			if is_instance_valid(f):
				create_tween().tween_property(f, "rotation:y", r0, 0.5))
		match rng.randi() % 3:
			0:
				f.lunge(front, 0.8)
			1:
				f.aim(front, 0.8)
			_:
				f.cast_anim(0.8)
