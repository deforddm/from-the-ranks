class_name CampScreen
extends Node3D
## The warband's camp between battles: the fighters stand round a fire in the
## ruins, and the screen around them is the warband's ledger. Choose a fighter
## to see their sheet, settle advances, buy and sell kit; hire, sell godshards,
## read the chronicle, and pick the next fight. After a battle the aftermath
## (wounds, experience, spoils) plays first.

var c: Campaign
var atm: Atmosphere
var city: CityBuilder
var cam: Camera3D
var map: BattleMap
var fire_at := Vector3.ZERO
var figs: Dictionary = {}       # uid -> Figure
var spots: Array = []
var t := 0.0
var sel_uid := -1
var _cam_pos := Vector3.ZERO
var _cam_look := Vector3.ZERO
var view_angle := 0.0           # the most open direction to look at the fire from

var ui: CanvasLayer
var root: Control
var head_name: Label
var head_sub: Label
var head_stats: HBoxContainer
var roster_box: VBoxContainer
var sheet: PanelContainer
var sheet_box: VBoxContainer
var overlay: PanelContainer
var overlay_box: VBoxContainer
var toast: Label
var _dismiss_armed := -1

const STATS := ["M", "WS", "BS", "S", "T", "W", "I", "A", "Ld"]

func _ready() -> void:
	Figure.water_y = -100.0
	Sfx.music("music_camp")
	Sfx.ambience("amb_fire", 2.0, -2.0)
	c = Game.campaign
	if c == null and Game.camp_shots != "":
		c = _demo_campaign()
		Game.campaign = c
	if c == null:
		Game.mode = "menu"
		get_tree().reload_current_scene()
		return
	map = BattleMap.new()
	map.load_map("hethra_square")   # the camp is always in the square's south street
	var centre := Vector3(map.w * map.cell * 0.5, 0, map.d * map.cell * 0.5)
	atm = Atmosphere.new()
	add_child(atm)
	atm.build(centre, Game.graphics)
	city = CityBuilder.new()
	add_child(city)
	city.build(map, {})
	_make_camp()
	cam = Camera3D.new()
	cam.fov = 46.0
	cam.far = 900.0
	add_child(cam)
	cam.current = true
	_build_ui()
	_refresh()
	if Game.mode == "aftermath" and not c.last_report.is_empty():
		_show_aftermath(0)
	elif not c.pending_event.is_empty() and Game.camp_shots == "":
		_show_night()
	if Game.camp_shots != "":
		_shots()

# ------------------------------------------------------------------ the camp in 3D

func _make_camp() -> void:
	## A fire in the south street where the warband deploys, the fighters round it.
	var cells: Array = map.data["deploy"]["0"]
	var nodes: Array = []
	for cl in cells:
		var nd := map.top_node(int(cl[0]), int(cl[1]))
		if nd >= 0:
			nodes.append(map.node_pos(nd))
	var mid := Vector3.ZERO
	for p in nodes:
		mid += p
	mid /= maxf(1.0, nodes.size())
	# the fire on the open spot nearest the middle of the zone
	nodes.sort_custom(func(a, b): return a.distance_to(mid) < b.distance_to(mid))
	fire_at = nodes[0]
	# the street fires of the battle map would blaze beside the camp: put out any close by
	for ch in city.get_children():
		var near := false
		if ch is GPUParticles3D or ch is OmniLight3D:
			near = (ch as Node3D).position.distance_to(fire_at) < 9.0
		elif ch is MeshInstance3D:
			# braziers and burnt wreckage are small batches built in world space
			var bb: AABB = (ch as MeshInstance3D).get_aabb()
			near = bb.size.length() < 4.0 and ((ch as Node3D).transform * bb.get_center()).distance_to(fire_at) < 9.0
		if near:
			ch.visible = false
			if ch is OmniLight3D:
				city.flicker_lights = city.flicker_lights.filter(func(f): return f["light"] != ch)
	# a small cooking fire: lower flames than the street fires, but a warm light
	var fp := city._fire_particles(14, 0.34, 0.6)
	fp.position = fire_at + Vector3(0, 0.12, 0)
	add_child(fp)
	var em := city._embers(6)
	em.position = fire_at + Vector3(0, 0.2, 0)
	add_child(em)
	var fl := OmniLight3D.new()
	fl.light_color = Color(1.0, 0.55, 0.22)
	fl.light_energy = 3.4
	fl.omni_range = 11.0
	fl.omni_attenuation = 1.2
	fl.shadow_enabled = true
	fl.position = fire_at + Vector3(0, 0.9, 0)
	add_child(fl)
	city.flicker_lights.append({"light": fl, "base": fl.light_energy, "seed": 3.0})
	_pick_view()
	var logs := MeshBatch.new()
	var wood := Mats.flat(Color(0.16, 0.1, 0.06), 0.9)
	for i in range(5):
		var a := i * TAU / 5.0
		var xf := Transform3D(Basis(Vector3.UP, a) * Basis(Vector3.RIGHT, PI * 0.5 - 0.35), fire_at + Vector3(cos(a), 0, sin(a)) * 0.22 + Vector3(0, 0.12, 0))
		logs.add_cyl(wood, xf, 0.06, 0.05, 0.75, 6)
	for i in range(10):
		var a := i * TAU / 10.0
		logs.add_box(Mats.flat(Color(0.22, 0.21, 0.2), 0.95), Transform3D(Basis(Vector3.UP, a), fire_at + Vector3(cos(a), 0, sin(a)) * 0.62 + Vector3(0, 0.07, 0)), Vector3(0.22, 0.14, 0.18))
	add_child(logs.build(true))
	# places to stand: a loose ring, nearest first
	spots = nodes.filter(func(p): return p.distance_to(fire_at) > 1.6 and p.distance_to(fire_at) < 9.0)
	spots.sort_custom(func(a, b): return a.distance_to(fire_at) < b.distance_to(fire_at))
	_place_figures()

func _pick_view() -> void:
	## Find the widest clear arc round the fire, so the camera never sits in a
	## wall or out among the backdrop ruins beyond the map's edge.
	var eye := fire_at + Vector3(0, 1.2, 0)
	var ok: Array = []
	for i in range(32):
		var a := i * TAU / 32.0
		var good := true
		for r in [6.0, 9.0]:
			for y in [2.2, 4.2]:
				if not _cam_clear(eye, fire_at + Vector3(sin(a) * r, y, cos(a) * r)):
					good = false
		ok.append(good)
	var best := -1
	var best_i := 0
	for i in range(32):
		var run := 0
		for k in range(-4, 5):
			if ok[(i + k + 32) % 32]:
				run += 1
		if run > best:
			best = run
			best_i = i
	view_angle = best_i * TAU / 32.0

func _cam_clear(from: Vector3, to: Vector3) -> bool:
	## Clear of walls, and inside the battle map (the backdrop is solid too).
	var steps := int(from.distance_to(to) / 0.25) + 2
	for i in range(1, steps + 1):
		var p := from.lerp(to, float(i) / steps)
		if p.x < 0.6 or p.z < 0.6 or p.x > map.w * map.cell - 0.6 or p.z > map.d * map.cell - 0.6:
			return false
		if map.solid_at(p):
			return false
	return true

func _place_figures() -> void:
	for k in figs:
		figs[k].queue_free()
	figs.clear()
	var wb := c.warband()
	var taken: Array = []
	var i := 0
	for f in c.fighters:
		var u := BUnit.new()
		u.id = int(f["uid"])
		u.side = 0
		u.setup_from(c.unit_def(f), wb, c.entry_for(f))
		var fig := Figure.new()
		add_child(fig)
		fig.setup(u, wb)
		# spread out: skip spots too close to someone already standing
		var p: Vector3 = fire_at + Vector3(2, 0, 0)
		while i < spots.size():
			var q: Vector3 = spots[i]
			i += 1
			var ok := true
			for o in taken:
				if (o as Vector3).distance_to(q) < 1.25:
					ok = false
					break
			if ok:
				p = q
				break
		taken.append(p)
		fig.position = p
		fig.face_point(fire_at)
		fig.xray.visible = false
		fig.ring.visible = false
		fig.label.visible = false
		if f["miss_next"]:
			fig.set_status("stunned")
		figs[int(f["uid"])] = fig

func _process(delta: float) -> void:
	t += delta
	var want_pos: Vector3
	var want_look: Vector3
	if sel_uid >= 0 and figs.has(sel_uid):
		var fp: Vector3 = figs[sel_uid].position
		var out := (fp - fire_at)
		out.y = 0
		out = out.normalized() if out.length() > 0.1 else Vector3(0, 0, 1)
		# stand in front of them, a little to the side, at chest height
		# come in from the open side of the camp, where the overview camera sits
		var cd := Vector3(sin(view_angle), 0, cos(view_angle))
		var head := fp + Vector3(0, 1.4, 0)
		want_pos = fire_at + cd * 9.0 + Vector3(0, 4.2, 0)
		for k in [4.2, 5.2, 6.5]:
			var cp: Vector3 = fp + cd * k + Vector3(0, 1.9 + k * 0.15, 0)
			if _cam_clear(head, cp):
				want_pos = cp
				break
		# keep them left of centre, clear of the sheet on the right
		var fwd := (fp - want_pos)
		fwd.y = 0
		var right := fwd.normalized().cross(Vector3.UP).normalized()
		want_look = fp + Vector3(0, 1.2, 0) + right * 0.9
	else:
		var a := view_angle + sin(t * 0.07) * 0.25
		want_pos = fire_at + Vector3(sin(a) * 9.0, 4.2 + sin(t * 0.13) * 0.4, cos(a) * 9.0)
		want_look = fire_at + Vector3(0, 0.9, 0)
	var k := 1.0 - exp(-delta * 2.2)
	if _cam_pos == Vector3.ZERO:
		k = 1.0
	_cam_pos = _cam_pos.lerp(want_pos, k)
	_cam_look = _cam_look.lerp(want_look, k)
	cam.position = _cam_pos
	cam.look_at(_cam_look, Vector3.UP)
	# a fighter standing between the camera and the one you chose steps out of the shot
	for uid in figs:
		var fg: Node3D = figs[uid]
		var blocked := false
		if sel_uid >= 0 and uid != sel_uid and figs.has(sel_uid):
			var a3: Vector3 = _cam_pos
			var b3: Vector3 = figs[sel_uid].position + Vector3(0, 1.1, 0)
			var p3: Vector3 = fg.position + Vector3(0, 1.0, 0)
			# anyone nearer the camera than the chosen fighter, and in view, steps aside
			var ahead := (p3 - a3).dot(-cam.global_transform.basis.z) > 0.0
			blocked = ahead and a3.distance_to(p3) < a3.distance_to(b3) - 0.6
		fg.visible = not blocked

# ------------------------------------------------------------------ interface

func _build_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)
	root = Control.new()
	root.theme = UIStyle.theme()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(root)
	# vignette for legibility at the edges
	var vg := TextureRect.new()
	vg.set_anchors_preset(Control.PRESET_FULL_RECT)
	vg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var gt := GradientTexture2D.new()
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.45)
	gt.fill_to = Vector2(1.05, 1.05)
	var gr := Gradient.new()
	gr.set_color(0, Color(0, 0, 0, 0))
	gr.set_color(1, Color(0, 0, 0, 0.78))
	gt.gradient = gr
	vg.texture = gt
	vg.stretch_mode = TextureRect.STRETCH_SCALE
	root.add_child(vg)
	# header
	var head := VBoxContainer.new()
	head.position = Vector2(40, 26)
	head.add_theme_constant_override("separation", 0)
	root.add_child(head)
	head_name = UIStyle.title("", 50, UIStyle.BONE)
	head.add_child(head_name)
	head_sub = UIStyle.label("", 17, UIStyle.DIM)
	head.add_child(head_sub)
	head_stats = HBoxContainer.new()
	head_stats.add_theme_constant_override("separation", 10)
	head_stats.anchor_left = 1.0
	head_stats.anchor_right = 1.0
	head_stats.offset_left = -900
	head_stats.offset_right = -40
	head_stats.offset_top = 34
	head_stats.alignment = BoxContainer.ALIGNMENT_END
	root.add_child(head_stats)
	# roster on the left
	var lp := PanelContainer.new()
	lp.position = Vector2(40, 150)
	lp.size = Vector2(430, 760)
	root.add_child(lp)
	var lv := VBoxContainer.new()
	lv.add_theme_constant_override("separation", 6)
	lp.add_child(lv)
	lv.add_child(UIStyle.label("The warband", 20, UIStyle.GOLD, UIStyle.bold_font()))
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(400, 700)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	lv.add_child(sc)
	roster_box = VBoxContainer.new()
	roster_box.add_theme_constant_override("separation", 5)
	roster_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(roster_box)
	# fighter sheet on the right
	sheet = PanelContainer.new()
	sheet.anchor_left = 1.0
	sheet.anchor_right = 1.0
	sheet.offset_left = -600
	sheet.offset_right = -40
	sheet.offset_top = 150
	sheet.offset_bottom = 910
	root.add_child(sheet)
	var ss := ScrollContainer.new()
	ss.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	sheet.add_child(ss)
	sheet_box = VBoxContainer.new()
	sheet_box.add_theme_constant_override("separation", 8)
	sheet_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ss.add_child(sheet_box)
	# the camp's own actions along the bottom
	var bar := HBoxContainer.new()
	bar.anchor_top = 1.0
	bar.anchor_bottom = 1.0
	bar.anchor_left = 0.5
	bar.anchor_right = 0.5
	bar.offset_left = -560
	bar.offset_right = 560
	bar.offset_top = -132
	bar.offset_bottom = -76
	bar.alignment = BoxContainer.ALIGNMENT_CENTER
	bar.add_theme_constant_override("separation", 10)
	root.add_child(bar)
	bar.add_child(_btn("Hire", func(): _show_hire(), Vector2(150, 54)))
	bar.add_child(_btn("Sell godshards", func(): _show_sell(), Vector2(190, 54)))
	bar.add_child(_btn("Chronicle", func(): _show_chronicle(), Vector2(160, 54)))
	var go := _btn("Into the ruins", func(): _show_next(), Vector2(250, 54))
	go.add_theme_font_override("font", UIStyle.title_font())
	go.add_theme_font_size_override("font_size", 28)
	go.add_theme_color_override("font_color", UIStyle.JADE)
	bar.add_child(go)
	bar.add_child(_btn("Save and leave", func(): _leave(), Vector2(180, 54)))
	toast = UIStyle.label("", 19, UIStyle.GOLD, UIStyle.bold_font())
	toast.anchor_left = 0.5
	toast.anchor_right = 0.5
	toast.anchor_top = 1.0
	toast.anchor_bottom = 1.0
	toast.offset_left = -500
	toast.offset_right = 500
	toast.offset_top = -176
	toast.offset_bottom = -146
	toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	toast.add_theme_constant_override("outline_size", 6)
	root.add_child(toast)
	# a centred overlay for hiring, selling, the chronicle, the next fight and the aftermath
	overlay = PanelContainer.new()
	overlay.anchor_left = 0.5
	overlay.anchor_right = 0.5
	overlay.anchor_top = 0.5
	overlay.anchor_bottom = 0.5
	overlay.offset_left = -470
	overlay.offset_right = 470
	overlay.offset_top = -380
	overlay.offset_bottom = 360
	overlay.add_theme_stylebox_override("panel", UIStyle.panel_box(0.96, UIStyle.GOLD))
	var os := ScrollContainer.new()
	os.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	overlay.add_child(os)
	overlay_box = VBoxContainer.new()
	overlay_box.add_theme_constant_override("separation", 10)
	overlay_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	os.add_child(overlay_box)
	overlay.visible = false
	root.add_child(overlay)

func _btn(text: String, cb: Callable, min_size := Vector2.ZERO) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	b.pressed.connect(cb)
	return b

func _say(text: String, col := UIStyle.GOLD) -> void:
	toast.text = text
	toast.add_theme_color_override("font_color", col)
	toast.modulate.a = 1.0
	var tw := toast.create_tween()
	tw.tween_interval(2.6)
	tw.tween_property(toast, "modulate:a", 0.0, 0.8)

func _chip(label: String, value: String, col := UIStyle.BONE) -> PanelContainer:
	var p := PanelContainer.new()
	var sb := UIStyle.panel_box(0.8, col)
	sb.content_margin_top = 6
	sb.content_margin_bottom = 6
	p.add_theme_stylebox_override("panel", sb)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", -2)
	p.add_child(v)
	var a := UIStyle.label(label, 13, UIStyle.DIM)
	a.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(a)
	var b := UIStyle.label(value, 24, col, UIStyle.bold_font())
	b.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(b)
	p.custom_minimum_size = Vector2(118, 0)
	return p

func _wb_color() -> Color:
	var wc: Array = c.warband()["color"]
	return Color(wc[0], wc[1], wc[2])

func _refresh() -> void:
	var wb := c.warband()
	head_name.text = c.name
	head_name.add_theme_color_override("font_color", _wb_color().lightened(0.5))
	head_sub.text = "%s  ·  %d battle%s fought, %d won, %d lost" % [wb["name"], c.battles, "" if c.battles == 1 else "s", c.wins, c.losses]
	for ch in head_stats.get_children():
		ch.queue_free()
	head_stats.add_child(_chip("Jakatas", str(c.gold), UIStyle.GOLD))
	head_stats.add_child(_chip("Godshards", str(c.shards), UIStyle.JADE))
	head_stats.add_child(_chip("Rating", str(c.rating()), UIStyle.BONE))
	head_stats.add_child(_chip("Fighters", "%d / %d" % [c.fighters.size(), int(wb["max_size"])], UIStyle.BONE))
	# roster rows
	for ch in roster_box.get_children():
		ch.queue_free()
	for f in c.fighters:
		roster_box.add_child(_roster_row(f))
	if sel_uid >= 0 and c.fighter(sel_uid).is_empty():
		sel_uid = -1
	_refresh_sheet()

func _roster_row(f: Dictionary) -> Button:
	var b := Button.new()
	b.toggle_mode = true
	b.button_pressed = int(f["uid"]) == sel_uid
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.custom_minimum_size = Vector2(390, 58)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var role: String = {"leader": "Leader", "hero": "Hero", "henchman": "", "sword": "Sellsword"}.get(f["role"], "")
	var nxt := c.next_advance_at(f)
	var tags: Array = []
	if not (f["pending"] as Array).is_empty():
		tags.append("ADVANCE!")
	if f["miss_next"]:
		tags.append("healing")
	if f["old_wound"]:
		tags.append("old wound")
	var line2 := "%s%s  ·  XP %d%s" % [c.type_name(f), (" · " + role) if role != "" else "", int(f["xp"]), (" / %d" % nxt) if nxt > 0 else ""]
	if f["role"] == "sword":
		line2 = "%s · Sellsword  ·  upkeep %d" % [c.type_name(f), int(c.unit_def(f).get("upkeep", 0))]
	if not tags.is_empty():
		line2 += "  ·  " + ", ".join(tags)
	b.text = "%s\n%s" % [f["name"], line2]
	b.add_theme_font_size_override("font_size", 16)
	if not (f["pending"] as Array).is_empty():
		b.add_theme_color_override("font_color", UIStyle.JADE)
	elif f["miss_next"]:
		b.add_theme_color_override("font_color", Color(0.85, 0.6, 0.45))
	var uid := int(f["uid"])
	b.pressed.connect(func(): _select(uid))
	return b

func _select(uid: int) -> void:
	sel_uid = -1 if sel_uid == uid else uid
	_dismiss_armed = -1
	for k in figs:
		figs[k].set_selected("active" if k == sel_uid else "")
		figs[k].label.visible = k == sel_uid
		figs[k].ring.visible = false
		# the chosen fighter turns to face you; the rest watch the fire
		if k == sel_uid:
			figs[k].face_point(figs[k].position + Vector3(sin(view_angle), 0, cos(view_angle)))
		else:
			figs[k].face_point(fire_at)
	_refresh()

func _refresh_sheet() -> void:
	for ch in sheet_box.get_children():
		ch.queue_free()
	if sel_uid < 0:
		sheet_box.add_child(UIStyle.title("The camp", 34, UIStyle.BONE))
		var tx := RichTextLabel.new()
		tx.bbcode_enabled = true
		tx.fit_content = true
		tx.custom_minimum_size = Vector2(500, 0)
		tx.add_theme_font_size_override("normal_font_size", 17)
		tx.add_theme_font_size_override("bold_font_size", 17)
		var pend := c.pending_count()
		var s := "Choose a fighter on the left to see their sheet, buy or sell their kit, or settle an advance.\n\n"
		if pend > 0:
			s += "[color=#5fe0c0][b]%d advance%s waiting.[/b] Fighters marked ADVANCE! have earned them.[/color]\n\n" % [pend, "" if pend == 1 else "s"]
		s += "[b]Hire[/b] new fighters with your jakatas. [b]Sell godshards[/b] to the dealers in the outer city: the more you sell at once, the lower the price.\n\n"
		s += "[b]Rating[/b] is how dangerous the warband is. Foes are matched to it, and fighting a stronger band earns extra experience."
		if not c.history.is_empty():
			s += "\n\n[color=#9a9a9a]Last: %s[/color]" % c.history[-1]
		tx.text = s
		sheet_box.add_child(tx)
		return
	var f := c.fighter(sel_uid)
	var col := _wb_color().lightened(0.5)
	sheet_box.add_child(UIStyle.title(f["name"], 40, col))
	var role: String = {"leader": "Leader", "hero": "Hero", "henchman": "Henchman", "sword": "Sellsword, %d jakatas a battle" % int(c.unit_def(f).get("upkeep", 0))}.get(f["role"], "")
	sheet_box.add_child(UIStyle.label("%s  ·  %s  ·  %d battle%s, %d taken out of action" % [c.type_name(f), role, int(f["battles"]), "" if int(f["battles"]) == 1 else "s", int(f["kills"])], 16, UIStyle.DIM))
	# stat boxes, coloured against the type's own line
	var base: Dictionary = c.unit_def(f)["stats"]
	var grid := HBoxContainer.new()
	grid.add_theme_constant_override("separation", 4)
	for s in STATS:
		var v := VBoxContainer.new()
		v.add_theme_constant_override("separation", 0)
		var h := UIStyle.label(s, 12, UIStyle.DIM)
		h.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		v.add_child(h)
		var p := PanelContainer.new()
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(0.09, 0.1, 0.11)
		sb.border_color = Color(1, 1, 1, 0.12)
		sb.set_border_width_all(1)
		sb.set_corner_radius_all(3)
		p.add_theme_stylebox_override("panel", sb)
		p.custom_minimum_size = Vector2(52, 44)
		var val := int(f["stats"][s])
		var l := UIStyle.label(str(val), 24, UIStyle.JADE if val > int(base[s]) else (UIStyle.BLOOD if val < int(base[s]) else UIStyle.BONE), UIStyle.bold_font())
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		p.add_child(l)
		v.add_child(p)
		grid.add_child(v)
	sheet_box.add_child(grid)
	# experience
	var nxt := c.next_advance_at(f)
	var prv := c.prev_advance_at(f)
	var xb := ProgressBar.new()
	xb.custom_minimum_size = Vector2(500, 16)
	xb.show_percentage = false
	xb.min_value = prv
	xb.max_value = nxt if nxt > 0 else prv + 1
	xb.value = int(f["xp"]) if nxt > 0 else xb.max_value
	var fill := StyleBoxFlat.new()
	fill.bg_color = UIStyle.JADE.darkened(0.2)
	fill.set_corner_radius_all(3)
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0.08, 0.09, 0.1)
	bg.border_color = Color(1, 1, 1, 0.15)
	bg.set_border_width_all(1)
	bg.set_corner_radius_all(3)
	xb.add_theme_stylebox_override("fill", fill)
	xb.add_theme_stylebox_override("background", bg)
	sheet_box.add_child(UIStyle.label("Experience %d%s" % [int(f["xp"]), ("   ·   next advance at %d" % nxt) if nxt > 0 else "   ·   no more advances"], 16, UIStyle.BONE))
	sheet_box.add_child(xb)
	# advances waiting
	for adv in f["pending"]:
		var ap := PanelContainer.new()
		ap.add_theme_stylebox_override("panel", UIStyle.panel_box(0.9, UIStyle.JADE))
		var av := VBoxContainer.new()
		ap.add_child(av)
		var d: Array = adv["dice"]
		var what := "a new skill" if adv["kind"] == "skill" else "a better stat"
		if adv.get("talent", false):
			what = "talent: they rise to be a hero, and learn a skill"
		av.add_child(UIStyle.label("Advance!  Rolled %d + %d: %s. Choose one:" % [int(d[0]), int(d[1]), what], 17, UIStyle.JADE, UIStyle.bold_font()))
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)
		for opt in adv["pick"]:
			var label := ""
			if adv["kind"] == "stat":
				label = "+1 %s" % Campaign.data()["stat_names"][opt]
			else:
				label = GameData.skill_name(opt)
			var b := _btn(label, func(): _advance(opt), Vector2(150, 44))
			if adv["kind"] == "skill":
				b.tooltip_text = GameData.rules()["skills"][opt]["desc"]
			row.add_child(b)
		av.add_child(row)
		if adv["kind"] == "skill":
			var descs: Array = []
			for opt in adv["pick"]:
				descs.append("[b]%s[/b]: %s" % [GameData.skill_name(opt), GameData.rules()["skills"][opt]["desc"]])
			var dl := RichTextLabel.new()
			dl.bbcode_enabled = true
			dl.fit_content = true
			dl.custom_minimum_size = Vector2(480, 0)
			dl.add_theme_font_size_override("normal_font_size", 15)
			dl.add_theme_font_size_override("bold_font_size", 15)
			dl.text = "\n".join(descs)
			av.add_child(dl)
		sheet_box.add_child(ap)
		break
	# skills, scars, warren
	var info := RichTextLabel.new()
	info.bbcode_enabled = true
	info.fit_content = true
	info.custom_minimum_size = Vector2(500, 0)
	info.add_theme_font_size_override("normal_font_size", 16)
	info.add_theme_font_size_override("bold_font_size", 16)
	var tx := ""
	if not (f["skills"] as Array).is_empty():
		var sk: Array = []
		for s in f["skills"]:
			sk.append("[b]%s[/b] (%s)" % [GameData.skill_name(s), GameData.rules()["skills"].get(s, {}).get("desc", "")])
		tx += "[color=#e2c06a]Skills[/color]  " + "; ".join(sk) + "\n"
	if String(f["warren"]) != "":
		tx += "[color=#e2c06a]Warren[/color]  %s\n" % GameData.rules()["warrens"][f["warren"]]["name"]
	if not (f["injuries"] as Array).is_empty():
		tx += "[color=#e06a50]Scars[/color]  %s\n" % ", ".join(f["injuries"])
	if f["miss_next"]:
		tx += "[color=#e09a60]Healing: sits out the next battle.[/color]\n"
	info.text = tx
	sheet_box.add_child(info)
	# kit with sell buttons
	sheet_box.add_child(UIStyle.label("Kit   (save %s)" % _save_text(f), 18, UIStyle.GOLD, UIStyle.bold_font()))
	var items: Array = (f["gear"] as Array).duplicate()
	for m in f["munitions"]:
		for i in range(int(f["munitions"][m])):
			items.append(m)
	if items.is_empty():
		sheet_box.add_child(UIStyle.label("Nothing but their fists.", 16, UIStyle.DIM))
	for it in items:
		var r := HBoxContainer.new()
		var nl := UIStyle.label(GameData.item_name(it), 17, UIStyle.BONE)
		nl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		nl.tooltip_text = _item_desc(it)
		nl.mouse_filter = Control.MOUSE_FILTER_STOP
		r.add_child(nl)
		var price := Campaign.sell_price(it)
		var sbt := _btn("Sell  +%d" % price, func(): _sell_item(it), Vector2(120, 34))
		sbt.add_theme_font_size_override("font_size", 15)
		r.add_child(sbt)
		sheet_box.add_child(r)
	# the armoury
	sheet_box.add_child(UIStyle.label("Buy from the armoury", 18, UIStyle.GOLD, UIStyle.bold_font()))
	var gf := GridContainer.new()
	gf.columns = 3
	gf.add_theme_constant_override("h_separation", 6)
	gf.add_theme_constant_override("v_separation", 6)
	for it in c.armoury():
		var why := c.can_buy(sel_uid, it)
		var b := _btn("%s  %d" % [GameData.item_name(it), Campaign.item_cost(it)], func(): _buy_item(it), Vector2(164, 38))
		b.add_theme_font_size_override("font_size", 15)
		b.disabled = why != ""
		b.tooltip_text = _item_desc(it) + (("\n" + why) if why != "" else "")
		gf.add_child(b)
	sheet_box.add_child(gf)
	if f["role"] != "leader":
		var dm := _btn("Dismiss %s" % f["name"] if _dismiss_armed != sel_uid else "Really dismiss? Their kit goes with them", func(): _dismiss(), Vector2(0, 38))
		dm.add_theme_color_override("font_color", UIStyle.BLOOD)
		sheet_box.add_child(dm)

func _save_text(f: Dictionary) -> String:
	var s := 7
	var g: Array = f["gear"]
	if g.has("heavy"):
		s = 5
	elif g.has("light"):
		s = 6
	if g.has("shield"):
		s -= 1
	return "%d+" % s if s <= 6 else "none"

func _item_desc(it: String) -> String:
	var r := GameData.rules()
	for grp in ["weapons", "armour", "munitions"]:
		if r[grp].has(it):
			return r[grp][it].get("desc", "")
	return ""

func _advance(opt: String) -> void:
	var f := c.fighter(sel_uid)
	var kind: String = f["pending"][0]["kind"]
	if c.choose_advance(sel_uid, opt):
		var what: String = ("+1 " + Campaign.data()["stat_names"][opt]) if kind == "stat" else GameData.skill_name(opt)
		_say("%s gains %s." % [f["name"], what], UIStyle.JADE)
		c.save()
		_refresh_figure(sel_uid)
		_refresh()

func _buy_item(it: String) -> void:
	var why := c.buy(sel_uid, it)
	if why != "":
		_say(why, UIStyle.BLOOD)
		return
	_say("Bought a %s for %s." % [GameData.item_name(it).to_lower(), c.fighter(sel_uid)["name"]])
	Sfx.play("ui_coins", null, -2.0)
	c.save()
	_refresh_figure(sel_uid)
	_refresh()

func _sell_item(it: String) -> void:
	if c.sell(sel_uid, it):
		_say("Sold the %s for %d jakatas." % [GameData.item_name(it).to_lower(), Campaign.sell_price(it)])
		Sfx.play("ui_coins", null, -2.0)
		c.save()
		_refresh_figure(sel_uid)
		_refresh()

func _dismiss() -> void:
	if _dismiss_armed != sel_uid:
		_dismiss_armed = sel_uid
		_refresh()
		return
	var nm: String = c.fighter(sel_uid)["name"]
	if c.dismiss(sel_uid):
		_say("%s leaves the warband." % nm)
		sel_uid = -1
		_dismiss_armed = -1
		c.save()
		_place_figures()
		_refresh()

func _refresh_figure(uid: int) -> void:
	## Rebuild one figure so new kit shows on them.
	if not figs.has(uid):
		return
	var old: Figure = figs[uid]
	var f := c.fighter(uid)
	var u := BUnit.new()
	u.id = uid
	u.setup_from(c.unit_def(f), c.warband(), c.entry_for(f))
	var fig := Figure.new()
	add_child(fig)
	fig.setup(u, c.warband())
	fig.position = old.position
	fig.rotation = old.rotation
	fig.xray.visible = false
	fig.ring.visible = false
	fig.label.visible = false
	fig.set_selected("active" if uid == sel_uid else "")
	fig.label.visible = uid == sel_uid
	old.queue_free()
	figs[uid] = fig

# ------------------------------------------------------------------ overlays

func _open_overlay(title: String, col := UIStyle.GOLD) -> void:
	for ch in overlay_box.get_children():
		ch.queue_free()
	var t := UIStyle.title(title, 42, col)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	overlay_box.add_child(t)
	overlay.visible = true
	sheet.visible = false
	overlay.modulate.a = 0.0
	overlay.create_tween().tween_property(overlay, "modulate:a", 1.0, 0.25)

func _close_overlay() -> void:
	overlay.visible = false
	sheet.visible = true
	_refresh()

func _rich(text: String, size := 17, width := 860) -> RichTextLabel:
	var r := RichTextLabel.new()
	r.bbcode_enabled = true
	r.fit_content = true
	r.custom_minimum_size = Vector2(width, 0)
	r.add_theme_font_size_override("normal_font_size", size)
	r.add_theme_font_size_override("bold_font_size", size)
	r.text = text
	return r

func _footer(buttons: Array) -> void:
	var h := HBoxContainer.new()
	h.alignment = BoxContainer.ALIGNMENT_CENTER
	h.add_theme_constant_override("separation", 12)
	for b in buttons:
		h.add_child(b)
	overlay_box.add_child(h)

var _hire_swords := false

func _show_hire(swords := false) -> void:
	_hire_swords = swords
	_open_overlay("Sellswords" if swords else "Hire fighters")
	var wb := c.warband()
	if swords:
		overlay_box.add_child(_rich("Hired blades fight for coin, not for the band. Each wants paying after every battle, win or lose, and walks off if the purse is empty. They bring their own kit, never search the ruins and learn nothing from the fighting.\n\nYou have [color=#f2c76b][b]%d jakatas[/b][/color] and %d of %d places filled." % [c.gold, c.fighters.size(), int(wb["max_size"])]))
	else:
		overlay_box.add_child(_rich("You have [color=#f2c76b][b]%d jakatas[/b][/color] and %d of %d places filled. New henchmen arrive green; new heroes bring their own experience." % [c.gold, c.fighters.size(), int(wb["max_size"])]))
	var any_swords := false
	for k in wb["units"]:
		var def: Dictionary = wb["units"][k]
		if def["role"] == "leader":
			continue
		if (def["role"] == "sword") != swords:
			any_swords = any_swords or def["role"] == "sword"
			continue
		var p := PanelContainer.new()
		p.add_theme_stylebox_override("panel", UIStyle.panel_box(0.6))
		var h := HBoxContainer.new()
		h.add_theme_constant_override("separation", 14)
		p.add_child(h)
		var st: Dictionary = def["stats"]
		var gear: Array = []
		for g in def.get("gear", []):
			gear.append(GameData.item_name(g))
		var have := c.fighters.filter(func(f): return f["unit"] == k).size()
		var mx := int(def.get("max", 0))
		var txt := "[b]%s[/b]  [color=#9a9a9a]%s · %s[/color]\nM%d WS%d BS%d S%d T%d W%d I%d A%d Ld%d\n[color=#b8b0a0]%s[/color]" % [
			def["name"], {"hero": "Hero", "henchman": "Henchman", "sword": "Sellsword, upkeep %d" % int(def.get("upkeep", 0))}.get(def["role"], ""), ("%d of %d" % [have, mx]) if mx > 0 else "%d in the band" % have,
			st["M"], st["WS"], st["BS"], st["S"], st["T"], st["W"], st["I"], st["A"], st["Ld"], ", ".join(gear)]
		if def.has("warrens"):
			txt += "[color=#b8b0a0] · %s warren[/color]" % String(def["warrens"][0]).capitalize()
		if def.has("blurb"):
			txt += "\n[i][color=#8f8a80]%s[/color][/i]" % def["blurb"]
		var r := _rich(txt, 16, 640)
		h.add_child(r)
		var why := c.can_hire(k)
		var b := _btn("Hire  %d" % int(def["cost"]), func(): _hire(k), Vector2(150, 50))
		b.disabled = why != ""
		b.tooltip_text = why
		h.add_child(b)
		overlay_box.add_child(p)
	if swords:
		_footer([_btn("Back", func(): _show_hire(false), Vector2(160, 46)), _btn("Done", func(): _close_overlay(), Vector2(160, 46))])
	elif any_swords:
		_footer([_btn("Sellswords", func(): _show_hire(true), Vector2(180, 46)), _btn("Done", func(): _close_overlay(), Vector2(160, 46))])
	else:
		_footer([_btn("Done", func(): _close_overlay(), Vector2(160, 46))])

func _hire(k: String) -> void:
	var f := c.hire(k)
	if f.is_empty():
		return
	c.save()
	_place_figures()
	_say("%s joins the warband." % f["name"], UIStyle.JADE)
	Sfx.play("ui_coins", null, -2.0)
	_show_hire(_hire_swords)

func _show_sell() -> void:
	_open_overlay("Sell godshards", UIStyle.JADE)
	overlay_box.add_child(_rich("The dealers in the outer city pay well for shards of the fallen god, but the more they see at once, the less they offer for each.\n\nYou hold [color=#5fe0c0][b]%d godshard%s[/b][/color]." % [c.shards, "" if c.shards == 1 else "s"]))
	var g := GridContainer.new()
	g.columns = 4
	g.add_theme_constant_override("h_separation", 10)
	g.add_theme_constant_override("v_separation", 10)
	for n in range(1, mini(c.shards, 8) + 1):
		var each := Campaign.shard_price(n)
		var b := _btn("Sell %d\n%d jakatas (%d each)" % [n, each * n, each], func(): _sell_shards(n), Vector2(200, 66))
		g.add_child(b)
	overlay_box.add_child(g)
	if c.shards == 0:
		overlay_box.add_child(_rich("[color=#9a9a9a]Bring some back from the ruins first.[/color]"))
	_footer([_btn("Done", func(): _close_overlay(), Vector2(160, 46))])

func _sell_shards(n: int) -> void:
	var got := c.sell_shards(n)
	c.save()
	_say("Sold %d godshard%s for %d jakatas." % [n, "" if n == 1 else "s", got], UIStyle.GOLD)
	Sfx.play("ui_coins", null, 0.0)
	_show_sell()

func _show_chronicle() -> void:
	_open_overlay("Chronicle")
	var s := ""
	if c.history.is_empty():
		s = "[color=#9a9a9a]No battles fought yet.[/color]"
	for h in c.history:
		s += "%s\n" % h
	if not c.fallen.is_empty():
		s += "\n[b][color=#e06a50]The fallen[/color][/b]\n"
		for f in c.fallen:
			s += "%s, %s, fell in battle %d%s.\n" % [f["name"], f["type"], int(f["battle"]), (", having taken %d out of action" % int(f["kills"])) if int(f.get("kills", 0)) > 0 else ""]
	overlay_box.add_child(_rich(s))
	_footer([_btn("Close", func(): _close_overlay(), Vector2(160, 46))])

var _foe := ""
var _foe_roster: Dictionary = {}
var _out_lines: Array = []

var _map := "hethra_square"
var _scen := "shards"

func _show_next() -> void:
	if not c.pending_event.is_empty():
		_show_night()
		return
	if c.pending_count() > 0:
		_say("Settle your advances first: choose the fighters marked ADVANCE!", UIStyle.JADE)
		return
	_out_lines = c.prepare_battle()
	# word comes of a fight: a foe, a place and a reason, all of which you can change
	var foes: Array = GameData.WARBAND_IDS.filter(func(x): return x != c.faction)
	_foe = foes[c.rng.randi_range(0, foes.size() - 1)]
	_foe_roster = c.enemy_roster(_foe)
	_map = GameData.MAP_IDS[c.rng.randi_range(0, GameData.MAP_IDS.size() - 1)]
	_scen = GameData.SCENARIO_IDS[c.rng.randi_range(0, GameData.SCENARIO_IDS.size() - 1)]
	_draw_next()

func _pick_foe(id: String) -> void:
	_foe = id
	_foe_roster = c.enemy_roster(id)
	_draw_next()

func _choice_row(ids: Array, current: String, label: Callable, cb: Callable, w := 270) -> Control:
	var row: Container
	if ids.size() >= 6:
		# six or more choices go in two rows of three
		var g := GridContainer.new()
		g.columns = 3
		g.add_theme_constant_override("h_separation", 10)
		g.add_theme_constant_override("v_separation", 8)
		g.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		row = g
	else:
		var hb := HBoxContainer.new()
		hb.alignment = BoxContainer.ALIGNMENT_CENTER
		hb.add_theme_constant_override("separation", 10)
		row = hb
	for id in ids:
		var b := _btn(label.call(id), func(): cb.call(id), Vector2(w, 44))
		b.toggle_mode = true
		b.button_pressed = id == current
		row.add_child(b)
	return row

func _draw_next() -> void:
	_open_overlay("Into the ruins", UIStyle.JADE)
	var foes: Array = GameData.WARBAND_IDS.filter(func(x): return x != c.faction)
	overlay_box.add_child(UIStyle.label("Who you go up against", 17, UIStyle.GOLD, UIStyle.bold_font()))
	overlay_box.add_child(_choice_row(foes, _foe, func(id): return GameData.warband(id)["short"], func(id): _pick_foe(id), 140))
	overlay_box.add_child(UIStyle.label("Where", 17, UIStyle.GOLD, UIStyle.bold_font()))
	overlay_box.add_child(_choice_row(GameData.MAP_IDS, _map, func(id): return GameData.map_data(id)["name"], func(id): _map = id; _draw_next(), 190))
	overlay_box.add_child(UIStyle.label("What for", 17, UIStyle.GOLD, UIStyle.bold_font()))
	overlay_box.add_child(_choice_row(GameData.SCENARIO_IDS, _scen, func(id): return GameData.scenario(id)["name"], func(id): _scen = id; _draw_next(), 190))
	var wb := GameData.warband(_foe)
	var names: Array = []
	for e in _foe_roster["entries"]:
		names.append(e["name"])
	var mine := c.battle_roster()
	var sc := GameData.scenario(_scen)
	var s := "[b]%s[/b], %s.\n[color=#b8b0a0]%s[/color]\n\n" % [GameData.map_data(_map)["name"], sc["name"].to_lower(), sc["desc"]]
	s += "[b]%s[/b] field %d (rating about %d against your %d): %s.\n" % [wb["name"], names.size(), int(_foe_roster["rating"]), c.rating(), ", ".join(names)]
	if int(_foe_roster["rating"]) - c.rating() >= 20:
		s += "[color=#5fe0c0]They are stronger than you: everyone who walks away earns extra experience.[/color]\n"
	s += "You take [b]%d[/b] fighter%s into the ruins." % [mine.size(), "" if mine.size() == 1 else "s"]
	for l in _out_lines:
		s += "\n[color=#e09a60]%s[/color]" % l
	overlay_box.add_child(_rich(s, 16))
	var go := _btn("Into the ruins", func(): _begin_battle(), Vector2(260, 54))
	go.add_theme_font_override("font", UIStyle.title_font())
	go.add_theme_font_size_override("font_size", 28)
	go.add_theme_color_override("font_color", UIStyle.JADE)
	_footer([_btn("Not yet", func(): _close_overlay(), Vector2(160, 54)), go])

func _begin_battle() -> void:
	Game.player_warband = c.faction
	Game.enemy_warband = _foe
	Game.battle_rosters = [c.battle_roster(), _foe_roster["entries"]]
	Game.campaign_enemy_rating = int(_foe_roster["rating"])
	Game.autoplay = false
	Game.seed_value = c.rng.randi_range(1, 99999)
	Game.map_id = _map
	Game.scenario = _scen
	c.save()
	Game.mode = "battle"
	get_tree().reload_current_scene()

func _leave() -> void:
	c.save()
	Game.campaign = null
	Game.mode = "menu"
	get_tree().reload_current_scene()

# ------------------------------------------------------------------ the aftermath

func _die_face(v: int, col: Color, size := 46) -> PanelContainer:
	var p := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.9, 0.86, 0.76)
	sb.border_color = col
	sb.set_border_width_all(3)
	sb.set_corner_radius_all(6)
	p.add_theme_stylebox_override("panel", sb)
	p.custom_minimum_size = Vector2(size, size)
	var l := UIStyle.label(str(v), int(size * 0.55), Color(0.12, 0.08, 0.06), UIStyle.bold_font())
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	p.add_child(l)
	return p

func _reveal(n: Control, i: int) -> void:
	n.modulate.a = 0.0
	var tw := n.create_tween()
	tw.tween_interval(0.18 + i * 0.32)
	tw.tween_property(n, "modulate:a", 1.0, 0.3)

func _show_aftermath(page: int) -> void:
	var rep := c.last_report
	var won: bool = rep.get("won", false)
	var draw: bool = rep.get("draw", false)
	var pages := ["The wounded", "Experience", "Spoils"]
	_open_overlay("%s  ·  %s" % ["Victory" if won else ("A draw" if draw else "Defeat"), pages[page]], UIStyle.JADE if won else (UIStyle.BONE if draw else UIStyle.BLOOD))
	var i := 0
	match page:
		0:
			if rep["injuries"].is_empty():
				overlay_box.add_child(_rich("Everyone walked out of the ruins on their own feet."))
			for inj in rep["injuries"]:
				var row := HBoxContainer.new()
				row.add_theme_constant_override("separation", 14)
				var bad: bool = inj["id"] == "dead"
				var ok: bool = inj["id"] == "fine" or inj["id"] == "touched" or inj["id"] == "hardened"
				var dc := UIStyle.BLOOD if bad else (UIStyle.JADE if ok else Color(0.95, 0.7, 0.3))
				for d in inj["dice"]:
					row.add_child(_die_face(int(d), dc))
				var tx := _rich("[b]%s[/b]   [color=#%s]%s[/color]\n%s" % [inj["name"], UIStyle.col_hex(dc), inj["title"], inj["text"]], 17, 700)
				row.add_child(tx)
				overlay_box.add_child(row)
				_reveal(row, i)
				i += 1
			if not rep["fallen"].is_empty():
				overlay_box.add_child(_rich("[color=#e06a50]Fallen: %s. Their names go in the chronicle.[/color]" % ", ".join(rep["fallen"])))
			if rep.get("leader", "") != "":
				overlay_box.add_child(_rich("[color=#f2c76b]%s takes command of the warband.[/color]" % rep["leader"]))
		1:
			if rep["xp"].is_empty():
				overlay_box.add_child(_rich("No one came back to learn from it."))
			for x in rep["xp"]:
				var row := HBoxContainer.new()
				row.add_theme_constant_override("separation", 14)
				var gl := UIStyle.label("+%d" % int(x["gain"]), 30, UIStyle.JADE, UIStyle.bold_font())
				gl.custom_minimum_size = Vector2(60, 0)
				row.add_child(gl)
				var s := "[b]%s[/b]  ·  %s  ·  now %d" % [x["name"], ", ".join(x["why"]), int(x["xp"])]
				for adv in x["advances"]:
					var d: Array = adv["dice"]
					if adv.has("chosen"):
						var what: String = ("+1 " + Campaign.data()["stat_names"][adv["chosen"]]) if adv["kind"] == "stat" else GameData.skill_name(adv["chosen"])
						s += "\n[color=#5fe0c0]Advance! Rolled %d + %d: %s.[/color]" % [int(d[0]), int(d[1]), what]
					elif adv.get("talent", false):
						s += "\n[color=#5fe0c0]Advance! Rolled %d + %d: real talent. They rise to be a hero and choose a skill.[/color]" % [int(d[0]), int(d[1])]
					else:
						s += "\n[color=#5fe0c0]Advance! Rolled %d + %d: choose %s in the camp.[/color]" % [int(d[0]), int(d[1]), "a skill" if adv["kind"] == "skill" else "a stat"]
				row.add_child(_rich(s, 17, 760))
				overlay_box.add_child(row)
				_reveal(row, i)
				i += 1
		2:
			var srch: Dictionary = rep.get("search", {})
			var s := ""
			var held := int(rep["shards_found"]) - int(srch.get("shards", 0))
			s += "Your fighters carried back [color=#5fe0c0][b]%d godshard%s[/b][/color].\n" % [held, "" if held == 1 else "s"]
			for l in rep.get("lines", []):
				s += "%s\n" % l
			overlay_box.add_child(_rich(s))
			var dice: Array = srch.get("dice", [])
			if not dice.is_empty():
				overlay_box.add_child(_rich("[b]Searching the ruins[/b]  Each hero who stayed on their feet searches the rubble: every pip is %d jakatas, and dice that match turn up godshards." % int(Campaign.data()["search_coin_per_pip"]), 17))
				var row := HBoxContainer.new()
				row.alignment = BoxContainer.ALIGNMENT_CENTER
				row.add_theme_constant_override("separation", 12)
				var counts := {}
				for d in dice:
					counts[d] = int(counts.get(d, 0)) + 1
				var who: Array = srch.get("who", [])
				for j in range(dice.size()):
					var v := VBoxContainer.new()
					v.add_child(_die_face(int(dice[j]), UIStyle.JADE if counts[dice[j]] > 1 else UIStyle.GOLD, 58))
					var nl := UIStyle.label(who[j] if j < who.size() else "", 13, UIStyle.DIM)
					nl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
					v.add_child(nl)
					row.add_child(v)
					_reveal(v, j)
				overlay_box.add_child(row)
				overlay_box.add_child(_rich("Found [color=#f2c76b][b]%d jakatas[/b][/color]%s." % [int(srch.get("coins", 0)), (" and [color=#5fe0c0][b]%d godshard%s[/b][/color]" % [int(srch["shards"]), "" if int(srch["shards"]) == 1 else "s"]) if int(srch.get("shards", 0)) > 0 else ""]))
			overlay_box.add_child(_rich("\nThe warband now holds [color=#f2c76b][b]%d jakatas[/b][/color] and [color=#5fe0c0][b]%d godshard%s[/b][/color]." % [c.gold, c.shards, "" if c.shards == 1 else "s"]))
	var nxt := _btn("Next" if page < 2 else "To the camp", func(): _aftermath_next(page), Vector2(200, 50))
	_footer([nxt])

func _aftermath_next(page: int) -> void:
	if page < 2:
		_show_aftermath(page + 1)
	elif not c.pending_event.is_empty():
		_show_night()
	else:
		Game.mode = "camp"
		_close_overlay()
		if c.pending_count() > 0:
			_say("Advances are waiting: choose the fighters marked ADVANCE!", UIStyle.JADE)

# ------------------------------------------------------------------ the night after

func _show_night() -> void:
	var e := Campaign.event_def(c.pending_event.get("id", ""))
	if e.is_empty():
		c.pending_event = {}
		_night_done()
		return
	_open_overlay("The night after  ·  %s" % e["title"], UIStyle.BONE)
	var art := NightArt.new()
	art.clip_contents = true
	art.seed_text = e["id"]
	art.custom_minimum_size = Vector2(860, 190)
	overlay_box.add_child(art)
	var body := _rich("[i]%s[/i]" % c.event_text(e["text"]), 20, 860)
	overlay_box.add_child(body)
	_reveal(body, 0)
	var i := 0
	for ch in e["choices"]:
		var why := c.event_choice_problem(i)
		var cost := ""
		if int(ch.get("cost_gold", 0)) > 0:
			cost = "   ·   %d %s" % [int(ch["cost_gold"]), c.coin_word()]
		elif int(ch.get("cost_shards", 0)) > 0:
			cost = "   ·   %d godshard%s" % [int(ch["cost_shards"]), "" if int(ch["cost_shards"]) == 1 else "s"]
		if ch.has("roll"):
			cost += "   ·   roll a die"
		var idx := i
		var b := _btn(c.event_text(ch["label"]) + cost, func(): _night_choice(idx), Vector2(620, 56))
		b.add_theme_font_size_override("font_size", 21)
		b.disabled = why != ""
		b.tooltip_text = why
		var row := VBoxContainer.new()
		row.alignment = BoxContainer.ALIGNMENT_CENTER
		var hb := HBoxContainer.new()
		hb.alignment = BoxContainer.ALIGNMENT_CENTER
		hb.add_child(b)
		row.add_child(hb)
		if why != "":
			var wl := UIStyle.label(why, 14, UIStyle.DIM)
			wl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			row.add_child(wl)
		overlay_box.add_child(row)
		_reveal(row, i + 1)
		i += 1
	overlay_box.add_child(_rich("[color=#8a8070]You hold %d %s and %d godshard%s.[/color]" % [c.gold, c.coin_word(), c.shards, "" if c.shards == 1 else "s"], 15))

func _night_choice(i: int) -> void:
	var title: String = Campaign.event_def(c.pending_event.get("id", ""))["title"]
	var out := c.resolve_event(i)
	if out.is_empty():
		return
	c.save()
	_show_night_result(out, title)

func _show_night_result(out: Dictionary, title: String) -> void:
	_open_overlay("The night after  ·  %s" % title, UIStyle.BONE)
	var art := NightArt.new()
	art.clip_contents = true
	art.seed_text = String(out.get("id", title))
	art.dawn = true
	art.custom_minimum_size = Vector2(860, 120)
	overlay_box.add_child(art)
	overlay_box.add_child(_rich("[color=#c9b48a]%s[/color]" % out["choice"], 17))
	var i := 0
	if int(out.get("roll", 0)) > 0:
		var r := int(out["roll"])
		var dc := UIStyle.BLOOD if r <= 2 else (UIStyle.JADE if r >= 5 else UIStyle.GOLD)
		var hb := HBoxContainer.new()
		hb.alignment = BoxContainer.ALIGNMENT_CENTER
		hb.add_child(_die_face(r, dc, 72))
		overlay_box.add_child(hb)
		_reveal(hb, i)
		i += 1
		Sfx.play("ui_coins", null, -6.0, 0.2)
	var t := _rich(out["text"], 20)
	overlay_box.add_child(t)
	_reveal(t, i)
	i += 1
	if not (out["lines"] as Array).is_empty():
		var l := _rich("[color=#5fe0c0][b]%s[/b][/color]" % "   ·   ".join(out["lines"]), 17)
		overlay_box.add_child(l)
		_reveal(l, i)
		i += 1
	if not (out["advances"] as Array).is_empty():
		overlay_box.add_child(_rich("[color=#f2c76b]Advance! %s can choose in the camp.[/color]" % ", ".join(out["advances"]), 17))
	_footer([_btn("To the camp", func(): _night_done(), Vector2(200, 50))])

func _night_done() -> void:
	Game.mode = "camp"
	_close_overlay()
	_refresh()
	_place_figures()
	if c.pending_count() > 0:
		_say("Advances are waiting: choose the fighters marked ADVANCE!", UIStyle.JADE)

# ------------------------------------------------------------------ screenshots

func _demo_campaign() -> Campaign:
	## A warband a few battles in, for screenshots: fought headless, quickly.
	var cached := Campaign.load_file("screenshot_demo")
	if cached != null and not cached.last_report.is_empty():
		return cached
	var cc := Campaign.create("marines", "", 777)
	cc.id = "screenshot_demo"
	for b in range(5):
		cc.prepare_battle()
		var foe: String = ["chained", "whirlwind"][b % 2]
		var er := cc.enemy_roster(foe)
		var st := BattleState.new()
		st.setup("hethra_square", "marines", foe, 500 + b, true, true, [cc.battle_roster(), er["entries"]])
		var ais := [WarbandAI.new(st, 0), WarbandAI.new(st, 1)]
		st.begin()
		var guard := 0
		while not st.over and guard < 4000:
			guard += 1
			var ai: WarbandAI = ais[st.side]
			var act := ai.next_action()
			var res := ai.execute(act)
			if act["type"] != "end" and not res.get("ok", false):
				act["unit"].ai_done = true
		var rep := cc.apply_result(Campaign.result_from_battle(st, 0, foe, er["rating"]))
		if b >= 2 and rep["won"]:
			break
		if true:
			cc.auto_choose_all()
			cc.sell_shards(cc.shards)
			for k in ["sw_trell", "marine", "heavy"]:
				if cc.can_hire(k) == "":
					cc.hire(k)
	cc.save()
	return cc

func _shots() -> void:
	DirAccess.make_dir_recursive_absolute(Game.camp_shots)
	Game.mode = "aftermath"
	_show_aftermath(0)
	await _cap("10_aftermath_wounds", 40)
	_show_aftermath(1)
	await _cap("11_aftermath_xp", 20)
	_show_aftermath(2)
	await _cap("12_aftermath_spoils", 25)
	if not c.pending_event.is_empty():
		var heroes: Array = c.fighters.filter(func(f): return f["role"] == "hero")
		if not heroes.is_empty():
			c.pending_event = {"id": "tomb", "who_uid": int(heroes[0]["uid"])}
		_show_night()
		await _cap("12b_night", 30)
		var pick_i := 0
		var ev := Campaign.event_def(c.pending_event["id"])
		for j in range((ev["choices"] as Array).size()):
			if ev["choices"][j].has("roll") and c.event_choice_problem(j) == "":
				pick_i = j
				break
		_night_choice(pick_i)
		await _cap("12c_night_result", 30)
	_close_overlay()
	await _cap("13_camp", 30)
	# a fighter's sheet, preferring one with an advance to choose
	var pick := -1
	for f in c.fighters:
		if not (f["pending"] as Array).is_empty():
			pick = int(f["uid"])
			break
	if pick < 0:
		pick = int(c.fighters[0]["uid"])
	_select(pick)
	await _cap("14_fighter", 35)
	_select(pick)
	for i in range(20):
		await get_tree().process_frame
	_show_hire()
	await _cap("15_hire", 12)
	_show_hire(true)
	await _cap("15b_sellswords", 12)
	_close_overlay()
	c.auto_choose_all()
	_refresh()
	_show_next()
	if overlay.visible:
		await _cap("16_next_battle", 12)
	get_tree().quit()

func _cap(nm: String, frames: int) -> void:
	for i in range(frames):
		await get_tree().process_frame
	get_viewport().get_texture().get_image().save_png("%s/%s.png" % [Game.camp_shots, nm])
	print("shot ", nm)


class NightArt extends Control:
	## A painted strip of night over the ruins: sky, moon, broken roofs, embers.
	var seed_text := ""
	var dawn := false

	func _draw() -> void:
		var w := size.x
		var h := size.y
		var rng := RandomNumberGenerator.new()
		rng.seed = hash(seed_text)
		var red: bool = seed_text in ["fever", "fever_priest", "quake", "tomb", "raid"]
		var top := Color(0.03, 0.04, 0.08) if not dawn else Color(0.12, 0.09, 0.12)
		var low := Color(0.16, 0.08, 0.06) if not dawn else Color(0.42, 0.24, 0.14)
		var bands := 24
		for i in range(bands):
			draw_rect(Rect2(0, h * i / bands, w, h / bands + 1), top.lerp(low, float(i) / bands))
		for i in range(70):
			var p := Vector2(rng.randf() * w, rng.randf() * h * 0.6)
			draw_circle(p, rng.randf_range(0.6, 1.5), Color(0.9, 0.88, 0.8, rng.randf_range(0.2, 0.7) * (0.3 if dawn else 1.0)))
		var mp := Vector2(w * rng.randf_range(0.6, 0.85), h * rng.randf_range(0.22, 0.35))
		var mr := h * 0.16
		var mc := Color(0.95, 0.42, 0.3) if red else Color(0.92, 0.88, 0.74)
		for k in range(6):
			draw_circle(mp, mr * (1.0 + k * 0.35), Color(mc.r, mc.g, mc.b, 0.05))
		draw_circle(mp, mr, mc)
		draw_circle(mp + Vector2(mr * 0.45, -mr * 0.2), mr * 0.92, top.lerp(low, 0.25))
		for layer in range(2):
			var base := h * (0.62 + layer * 0.14)
			var col := Color(0.07, 0.05, 0.05) if layer == 0 else Color(0.02, 0.015, 0.015)
			var pts := PackedVector2Array([Vector2(0, h)])
			var x := 0.0
			while x < w:
				var bw := rng.randf_range(30, 90)
				var bh := rng.randf_range(10, 55) * (1.3 if layer == 0 else 1.0)
				var y := base - bh
				pts.append(Vector2(x, y + rng.randf_range(0, 8)))
				if rng.randf() < 0.35:
					pts.append(Vector2(x + bw * 0.5, y - rng.randf_range(10, 28)))
				pts.append(Vector2(minf(x + bw, w), y + rng.randf_range(0, 14)))
				x += bw
			pts.append(Vector2(w, h))
			draw_colored_polygon(pts, col)
			if layer == 0:
				for i in range(10):
					var wp := Vector2(rng.randf() * w, base - rng.randf_range(6, 40))
					draw_rect(Rect2(wp, Vector2(3, 4)), Color(1.0, 0.6, 0.25, rng.randf_range(0.3, 0.8)))
		var fp := Vector2(w * rng.randf_range(0.2, 0.4), h - 6)
		for k in range(8):
			draw_circle(fp, 8 + k * 9, Color(1.0, 0.45, 0.15, 0.06))
		for i in range(26):
			var ep := fp + Vector2(rng.randf_range(-40, 40), -rng.randf_range(4, h * 0.8))
			draw_circle(ep, rng.randf_range(0.8, 2.0), Color(1.0, rng.randf_range(0.4, 0.75), 0.2, rng.randf_range(0.3, 0.9)))
		draw_rect(Rect2(0, 0, w, h), Color(0.75, 0.6, 0.4, 0.35), false, 1.0)
