extends Control
## The campaign map of Hethra: the wards drawn on a dark, stained chart, the
## river and the old wall, and marks for every fight the warband has had in
## each ward. Click a ward to fight there next. Drawn in code.

signal picked(map_id: String)

const W := 1000.0
const H := 380.0
# where each battlefield lies in the city, on a 1000 x 380 chart
const WARDS := {
	"azath": {"at": Vector2(185, 110), "size": Vector2(78, 50), "note": "A walled yard of barrows round one of the old houses."},
	"tower_ward": {"at": Vector2(450, 72), "size": Vector2(92, 46), "note": "Towers joined by ladders and planks, high over the streets."},
	"drowned": {"at": Vector2(150, 262), "size": Vector2(92, 56), "note": "Streets waist deep in black water round Mael's fallen bell."},
	"causeway": {"at": Vector2(335, 205), "size": Vector2(80, 44), "note": "A causeway over the canal, broken in the middle."},
	"hethra_square": {"at": Vector2(530, 200), "size": Vector2(88, 54), "note": "The old heart of the city, round the toppled idol."},
	"starfall": {"at": Vector2(735, 105), "size": Vector2(86, 54), "note": "A crater round a burning lump of the Fallen god."},
	"sleeper": {"at": Vector2(700, 300), "size": Vector2(84, 50), "note": "A stepped temple with the sleeping goddess on its top."},
	"jade": {"at": Vector2(880, 215), "size": Vector2(84, 66), "note": "A fallen giant of glowing jade lying across the ward."},
}

var selected := ""
var hovered := ""
var record := {}            # map id -> {"fought": n, "won": n}
var _polys := {}            # map id -> PackedVector2Array, in chart space
var _specks: Array = []
var _river := PackedVector2Array()
var _wall := PackedVector2Array()
var _blocks: Array = []     # [Rect2, angle]: the dead city's houses, between the wards

func _init() -> void:
	custom_minimum_size = Vector2(1130, 410)
	clip_contents = true
	mouse_filter = Control.MOUSE_FILTER_STOP
	var rng := RandomNumberGenerator.new()
	rng.seed = 7151
	for id in WARDS:
		var w: Dictionary = WARDS[id]
		var pts := PackedVector2Array()
		var n := 11
		for i in range(n):
			var a := TAU * float(i) / n + rng.randf_range(-0.12, 0.12)
			var r := rng.randf_range(0.78, 1.08)
			pts.append(w["at"] + Vector2(cos(a) * w["size"].x * r, sin(a) * w["size"].y * r))
		_polys[id] = pts
	for i in range(420):
		_specks.append([Vector2(rng.randf() * W, rng.randf() * H), rng.randf_range(0.5, 2.2), rng.randf()])
	# Mael's water: in from the west, past the Drowned Quarter, under the
	# causeway and out to the south
	for p in [Vector2(14, 204), Vector2(80, 215), Vector2(190, 200), Vector2(270, 225), Vector2(335, 228),
			Vector2(400, 250), Vector2(470, 300), Vector2(540, 340), Vector2(582, 368)]:
		_river.append(p)
	for i in range(28):
		var a := TAU * float(i) / 28.0
		_wall.append(Vector2(500, 190) + Vector2(cos(a) * (470 + rng.randf_range(-12, 8)), sin(a) * (178 + rng.randf_range(-8, 6))))
	_wall.append(_wall[0])
	# houses and rubble packed inside the wall, kept off the wards and the river
	var tries := 0
	while _blocks.size() < 260 and tries < 4000:
		tries += 1
		var c := Vector2(rng.randf_range(40, 960), rng.randf_range(20, 360))
		var e := (c - Vector2(500, 190)) / Vector2(450, 160)
		if e.length() > 1.0:
			continue
		var clear := true
		for id in _polys:
			if Geometry2D.is_point_in_polygon(c, _polys[id]) or c.distance_to(WARDS[id]["at"]) < 70.0:
				clear = false
				break
		for i in range(_river.size() - 1):
			if Geometry2D.get_closest_point_to_segment(c, _river[i], _river[i + 1]).distance_to(c) < 20.0:
				clear = false
				break
		if clear:
			var sz := Vector2(rng.randf_range(6, 16), rng.randf_range(5, 12))
			_blocks.append([Rect2(-sz * 0.5, sz), c, rng.randf_range(-0.4, 0.4), rng.randf()])

func _chart() -> Transform2D:
	var s := minf(size.x / W, size.y / H)
	var off := (size - Vector2(W, H) * s) * 0.5
	return Transform2D(0.0, Vector2(s, s), 0.0, off)

func _to_chart(p: Vector2) -> Vector2:
	return _chart().affine_inverse() * p

func _ward_at(p: Vector2) -> String:
	var c := _to_chart(p)
	for id in _polys:
		if Geometry2D.is_point_in_polygon(c, _polys[id]):
			return id
	return ""

func _gui_input(ev: InputEvent) -> void:
	if ev is InputEventMouseMotion:
		var h := _ward_at(ev.position)
		if h != hovered:
			hovered = h
			mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND if h != "" else Control.CURSOR_ARROW
			queue_redraw()
	elif ev is InputEventMouseButton and ev.pressed and ev.button_index == MOUSE_BUTTON_LEFT:
		var id := _ward_at(ev.position)
		if id != "":
			selected = id
			Sfx.play("ui_click")
			picked.emit(id)
			queue_redraw()

func _notification(what: int) -> void:
	if what == NOTIFICATION_MOUSE_EXIT and hovered != "":
		hovered = ""
		queue_redraw()

func _draw() -> void:
	draw_set_transform_matrix(_chart())
	var font := UIStyle.body_font()
	var bold := UIStyle.bold_font()
	# the chart: dark stained hide with a burnt edge
	draw_rect(Rect2(0, 0, W, H), Color(0.12, 0.1, 0.075))
	for s in _specks:
		var c := Color(0.2, 0.16, 0.1, 0.25) if s[2] > 0.5 else Color(0.05, 0.04, 0.03, 0.3)
		draw_circle(s[0], s[1], c)
	for i in range(14):
		var t := float(i) / 14.0
		draw_rect(Rect2(i * 1.5, i * 1.5, W - i * 3.0, H - i * 3.0), Color(0.03, 0.02, 0.01, 0.22 * (1.0 - t)), false, 2.0)
	# the old wall, then the river over it
	draw_polyline(_wall, Color(0.42, 0.34, 0.22, 0.55), 5.0, true)
	draw_polyline(_wall, Color(0.12, 0.1, 0.07, 0.8), 1.5, true)
	draw_polyline(_river, Color(0.08, 0.15, 0.18, 0.9), 26.0, true)
	draw_polyline(_river, Color(0.16, 0.3, 0.33, 0.55), 14.0, true)
	draw_polyline(_river, Color(0.3, 0.5, 0.52, 0.25), 3.0, true)
	draw_string(font, Vector2(26, 178), "Mael's water", HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color(0.45, 0.65, 0.68, 0.75))
	for b in _blocks:
		draw_set_transform_matrix(_chart() * Transform2D(b[2], b[1]))
		var shade: float = 0.16 + float(b[3]) * 0.08
		draw_rect(b[0], Color(shade, shade * 0.85, shade * 0.62, 0.75))
		draw_rect(b[0], Color(0.05, 0.04, 0.03, 0.6), false, 1.0)
	draw_set_transform_matrix(_chart())
	# streets between the wards
	var ids: Array = WARDS.keys()
	for i in range(ids.size()):
		for j in range(i + 1, ids.size()):
			var a: Vector2 = WARDS[ids[i]]["at"]
			var b: Vector2 = WARDS[ids[j]]["at"]
			if a.distance_to(b) < 300.0:
				draw_dashed_line(a, b, Color(0.5, 0.42, 0.3, 0.28), 1.5, 7.0)
	# the wards
	for id in WARDS:
		var w: Dictionary = WARDS[id]
		var rec: Dictionary = record.get(id, {})
		var fought := int(rec.get("fought", 0))
		var won := int(rec.get("won", 0))
		var fill := Color(0.2, 0.17, 0.13, 0.85)
		if fought > 0:
			fill = Color(0.27, 0.15, 0.1, 0.9) if won * 2 < fought else Color(0.13, 0.24, 0.2, 0.9)
		if id == hovered:
			fill = fill.lightened(0.18)
		var pts: PackedVector2Array = _polys[id]
		draw_colored_polygon(pts, fill)
		var loop := pts.duplicate()
		loop.append(pts[0])
		if id == selected:
			draw_polyline(loop, Color(UIStyle.JADE, 0.35), 9.0, true)
			draw_polyline(loop, UIStyle.JADE, 2.5, true)
		else:
			draw_polyline(loop, Color(0.6, 0.5, 0.34, 0.7 if id == hovered else 0.45), 1.6, true)
		_ward_mark(id, w["at"])
		var nm: String = GameData.map_data(id)["name"]
		var col := UIStyle.JADE if id == selected else (UIStyle.GOLD if id == hovered else UIStyle.BONE)
		var tw := bold.get_string_size(nm, HORIZONTAL_ALIGNMENT_LEFT, -1, 18).x
		var lp: Vector2 = w["at"] + Vector2(-tw * 0.5, w["size"].y + 19)
		draw_string(bold, lp + Vector2(1.5, 1.5), nm, HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color(0, 0, 0, 0.85))
		draw_string(bold, lp, nm, HORIZONTAL_ALIGNMENT_LEFT, -1, 18, col)
		if fought > 0:
			var line := "%d fought, %d won" % [fought, won]
			var lw := font.get_string_size(line, HORIZONTAL_ALIGNMENT_LEFT, -1, 14).x
			draw_string(font, w["at"] + Vector2(-lw * 0.5, w["size"].y + 35), line, HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color(0.8, 0.74, 0.62, 0.9))
	# what the hovered (or chosen) ward is
	var info := hovered if hovered != "" else selected
	if info != "":
		var note: String = WARDS[info]["note"]
		var nm2: String = GameData.map_data(info)["name"]
		draw_string(bold, Vector2(22, 26), nm2, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, UIStyle.GOLD)
		draw_string(font, Vector2(22, 45), note, HORIZONTAL_ALIGNMENT_LEFT, 330, 14, Color(0.82, 0.78, 0.68, 0.92))
	draw_string(bold, Vector2(W - 170, 26), "HETHRA", HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color(0.75, 0.62, 0.4, 0.75))
	draw_set_transform_matrix(Transform2D.IDENTITY)

func _ward_mark(id: String, at: Vector2) -> void:
	## A small picture of what stands in the ward.
	var ink := Color(0.78, 0.68, 0.5, 0.85)
	match id:
		"hethra_square":
			draw_rect(Rect2(at + Vector2(-5, -18), Vector2(10, 20)), ink)
			draw_rect(Rect2(at + Vector2(-12, 2), Vector2(24, 5)), ink)
		"tower_ward":
			for dx in [-16, 0, 16]:
				draw_rect(Rect2(at + Vector2(dx - 4, -20 + abs(dx) * 0.4), Vector2(8, 26 - abs(dx) * 0.4)), ink)
			draw_line(at + Vector2(-12, -8), at + Vector2(12, -8), ink, 1.5)
		"causeway":
			draw_line(at + Vector2(-26, 2), at + Vector2(-5, 2), ink, 4.0)
			draw_line(at + Vector2(6, 4), at + Vector2(26, 2), ink, 4.0)
		"starfall":
			draw_arc(at, 15.0, 0, TAU, 24, ink, 2.0)
			draw_circle(at, 6.0, Color(1.0, 0.55, 0.2, 0.9))
		"sleeper":
			for i in range(4):
				draw_rect(Rect2(at + Vector2(-20 + i * 5, 6 - i * 6), Vector2(40 - i * 10, 6)), ink)
		"drowned":
			draw_arc(at + Vector2(0, -2), 9.0, PI, TAU, 12, ink, 3.0)
			for i in range(3):
				draw_arc(at + Vector2(0, 8), 12.0 + i * 6, PI * 0.15, PI * 0.85, 10, Color(0.4, 0.6, 0.65, 0.6 - i * 0.15), 1.5)
		"azath":
			draw_rect(Rect2(at + Vector2(-10, -10), Vector2(20, 16)), ink)
			draw_rect(Rect2(at + Vector2(6, -22), Vector2(6, 14)), ink)
			draw_circle(at + Vector2(-2, -2), 2.5, Color(0.4, 1.0, 0.6, 0.9))
		"jade":
			var g := Color(0.35, 0.95, 0.75, 0.9)
			draw_line(at + Vector2(-26, 0), at + Vector2(22, 0), g, 6.0)
			draw_circle(at + Vector2(26, 0), 6.0, g)
			draw_line(at + Vector2(-4, 0), at + Vector2(-12, -16), g, 3.0)
			draw_line(at + Vector2(-4, 0), at + Vector2(-12, 16), g, 3.0)
