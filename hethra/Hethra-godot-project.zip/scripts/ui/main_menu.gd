class_name MainMenu
extends Node3D
## Title screen over the burning city: pick your warband and your foe,
## read how to play and the credits, then go into the ruins.

var atm: Atmosphere
var city: CityBuilder
var cam: Camera3D
var t := 0.0
var centre := Vector3.ZERO
var ui: CanvasLayer
var player_pick := ""
var enemy_pick := ""
var player_btns := {}
var enemy_btns := {}
var info: RichTextLabel
var overlay: PanelContainer
var overlay_text: RichTextLabel
var overlay_title: Label
var quality_btn: Button
var dialog: PanelContainer
var dialog_box: VBoxContainer
var name_edit: LineEdit
var muster: Muster

func _ready() -> void:
	Sfx.music("music_title")
	Sfx.ambience("amb_ruins", 2.0, -4.0)
	var map := BattleMap.new()
	map.load_map(Game.map_id)
	centre = Vector3(map.w * map.cell * 0.5, 0, map.d * map.cell * 0.5)
	atm = Atmosphere.new()
	add_child(atm)
	atm.build(centre, Game.graphics)
	city = CityBuilder.new()
	add_child(city)
	var shards := {}
	for sh in map.data["shards"]:
		shards[BattleMap.nid(int(sh[0]), int(sh[1]), int(sh[2]))] = true
	city.build(map, shards)
	cam = Camera3D.new()
	cam.fov = 50.0
	cam.far = 900.0
	add_child(cam)
	cam.current = true
	player_pick = Game.player_warband
	enemy_pick = Game.enemy_warband
	_build_ui()
	_refresh()
	if OS.get_cmdline_user_args().has("--menu-test"):
		_menu_test()
		return
	if Game.screenshot_path != "":
		t = 2.2
		if Game.shot_dialog == "skirmish":
			_skirmish_dialog()
		for i in range(30):
			await get_tree().process_frame
		get_viewport().get_texture().get_image().save_png(Game.screenshot_path)
		print("menu shot saved")
		get_tree().quit()

func _menu_test() -> void:
	## Click every warband button with the mouse, as a player would, and check
	## that each one picks its warband alone and shows it.
	for i in range(10):
		await get_tree().process_frame
	var fails := 0
	for id in GameData.WARBAND_IDS:
		var b: Button = player_btns[id]
		var at := b.get_global_rect().get_center()
		for down in [true, false]:
			var ev := InputEventMouseButton.new()
			ev.button_index = MOUSE_BUTTON_LEFT
			ev.pressed = down
			ev.position = at
			ev.global_position = at
			get_viewport().push_input(ev)
			await get_tree().process_frame
		await get_tree().process_frame
		var lit: Array = []
		for o in player_btns:
			if player_btns[o].button_pressed:
				lit.append(o)
		var ok: bool = player_pick == id and lit == [id] and enemy_pick != id and info.text.contains(GameData.warband(id)["name"]) and muster.shown == id
		print("menu test %s: pick=%s lit=%s foe=%s %s" % [id, player_pick, str(lit), enemy_pick, "ok" if ok else "FAIL"])
		if not ok:
			fails += 1
	# the skirmish dialog: every foe, battlefield, scenario and weather
	_skirmish_dialog()
	await get_tree().process_frame
	var rows := [
		["foe", GameData.WARBAND_IDS.filter(func(x): return x != player_pick), func(id): return GameData.warband(id)["short"], func(): return enemy_pick],
		["map", GameData.MAP_IDS, func(id): return GameData.map_data(id)["name"], func(): return Game.map_id],
		["scenario", GameData.SCENARIO_IDS, func(id): return GameData.scenario(id)["name"], func(): return Game.scenario],
		["weather", ["rain", "fog", "dawn", "still", "random"], func(id): return "Whatever comes" if id == "random" else BattleState.WEATHERS[id]["name"], func(): return Game.weather]]
	for row in rows:
		for id in row[1]:
			var want: String = row[2].call(id)
			for k in range(3):
				await get_tree().process_frame   # let the rebuilt dialog lay itself out
			var btn: Button = null
			for n in dialog_box.find_children("*", "Button", true, false):
				if (n as Button).text == want and not n.is_queued_for_deletion():
					btn = n
			if btn == null:
				print("menu test %s %s: no button FAIL" % [row[0], id])
				fails += 1
				continue
			var at := btn.get_global_rect().get_center()
			if not get_viewport().get_visible_rect().has_point(at):
				print("menu test %s %s: off screen at %s FAIL" % [row[0], id, at])
				fails += 1
				continue
			await _click(at)
			var got: String = row[3].call()
			print("menu test %s %s: %s" % [row[0], id, "ok" if got == id else "FAIL (got %s)" % got])
			if got != id:
				fails += 1
	print("menu test: FAILURES: ", fails)
	get_tree().quit(1 if fails > 0 else 0)

func _click(at: Vector2) -> void:
	for down in [true, false]:
		var ev := InputEventMouseButton.new()
		ev.button_index = MOUSE_BUTTON_LEFT
		ev.pressed = down
		ev.position = at
		ev.global_position = at
		get_viewport().push_input(ev)
		await get_tree().process_frame
	await get_tree().process_frame

func _process(delta: float) -> void:
	t += delta * 0.035
	var r := 40.0
	cam.position = centre + Vector3(sin(t) * r, 15.0 + sin(t * 0.7) * 2.0, cos(t) * r)
	cam.look_at(centre + Vector3(0, 3, 0), Vector3.UP)

func _build_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)
	var root := Control.new()
	root.theme = UIStyle.theme()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(root)
	# a dark band on the left for legibility
	var shade := ColorRect.new()
	shade.color = Color(0.02, 0.025, 0.03, 0.62)
	shade.anchor_bottom = 1.0
	shade.offset_right = 560
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(shade)
	# your warband, mustered round a brazier on the right of the screen
	muster = Muster.new()
	muster.anchor_left = 0.42
	muster.anchor_right = 1.0
	muster.anchor_top = 0.16
	muster.anchor_bottom = 1.0
	muster.offset_bottom = -30
	root.add_child(muster)
	var v := VBoxContainer.new()
	v.position = Vector2(56, 52)
	v.custom_minimum_size = Vector2(450, 0)
	v.add_theme_constant_override("separation", 10)
	root.add_child(v)
	v.add_child(UIStyle.title("Hethra", 86, UIStyle.BONE))
	var sub := UIStyle.title("City of the Fallen", 34, UIStyle.JADE)
	v.add_child(sub)
	var tag := UIStyle.label("Where the Crippled God's pain fell burning from the sky, the city died in a night. Its ruins are thick with godshards, and every faction wants them.", 17, UIStyle.DIM)
	tag.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tag.custom_minimum_size = Vector2(450, 0)
	v.add_child(tag)
	v.add_child(_spacer(10))
	v.add_child(UIStyle.label("Your warband", 20, UIStyle.GOLD, UIStyle.bold_font()))
	v.add_child(_choice_row(player_btns, _pick_player))
	info = RichTextLabel.new()
	info.bbcode_enabled = true
	info.fit_content = true
	info.custom_minimum_size = Vector2(450, 0)
	info.add_theme_font_size_override("normal_font_size", 16)
	info.add_theme_font_size_override("bold_font_size", 16)
	v.add_child(info)
	v.add_child(_spacer(6))
	# the campaign: a warband that lives from battle to battle
	var saves := Campaign.list_saves()
	if not saves.is_empty():
		var s0: Dictionary = saves[0]
		var cont := _button("Continue: %s" % s0["name"], func(): _load_campaign(s0["id"]))
		cont.add_theme_font_override("font", UIStyle.title_font())
		cont.add_theme_font_size_override("font_size", 28)
		cont.add_theme_color_override("font_color", UIStyle.JADE)
		cont.tooltip_text = "%s, %d battles, rating %d" % [GameData.warband(s0["faction"])["name"], int(s0["battles"]), int(s0["rating"])]
		v.add_child(cont)
	var crow := HBoxContainer.new()
	crow.add_theme_constant_override("separation", 8)
	var newc := _button("New campaign", func(): _new_campaign_dialog())
	newc.add_theme_font_override("font", UIStyle.title_font())
	newc.add_theme_font_size_override("font_size", 26)
	newc.add_theme_color_override("font_color", UIStyle.JADE if saves.is_empty() else UIStyle.BONE)
	newc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	crow.add_child(newc)
	if not saves.is_empty():
		var ld := _button("Load", func(): _load_dialog())
		ld.custom_minimum_size = Vector2(120, 0)
		crow.add_child(ld)
	v.add_child(crow)
	var begin := _button("Skirmish: one battle", func(): _skirmish_dialog())
	begin.add_theme_font_size_override("font_size", 20)
	begin.tooltip_text = "A single fight with the starting warbands: choose the foe, the battlefield and the scenario. Nothing carries over."
	v.add_child(begin)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	row.add_child(_button("How to play", func(): _show_overlay("How to play", _help_text())))
	row.add_child(_button("Credits", func(): _show_overlay("Credits", _credits_text())))
	quality_btn = _button("Settings", func(): _settings_dialog())
	row.add_child(quality_btn)
	row.add_child(_button("Quit", func(): get_tree().quit()))
	v.add_child(row)
	var foot := UIStyle.label("Version %s  ·  A free fan project set in the world of the Malazan Book of the Fallen by Steven Erikson and Ian C. Esslemont." % Game.VERSION, 13, Color(0.55, 0.55, 0.55))
	foot.anchor_top = 1.0
	foot.anchor_bottom = 1.0
	foot.offset_left = 56
	foot.offset_top = -40
	foot.offset_right = 1200
	root.add_child(foot)
	# what the updater is doing, just above the footer
	var upd := UIStyle.label(Updater.status, 15, UIStyle.GOLD)
	upd.anchor_top = 1.0
	upd.anchor_bottom = 1.0
	upd.offset_left = 56
	upd.offset_top = -66
	upd.offset_right = 1200
	root.add_child(upd)
	Updater.status_changed.connect(func(text: String): upd.text = text)
	# overlay for help and credits
	overlay = PanelContainer.new()
	overlay.anchor_left = 0.5
	overlay.anchor_right = 0.5
	overlay.anchor_top = 0.5
	overlay.anchor_bottom = 0.5
	overlay.offset_left = -400
	overlay.offset_right = 400
	overlay.offset_top = -320
	overlay.offset_bottom = 320
	var ov := VBoxContainer.new()
	overlay.add_child(ov)
	overlay_title = UIStyle.title("", 36, UIStyle.JADE)
	ov.add_child(overlay_title)
	overlay_text = RichTextLabel.new()
	overlay_text.bbcode_enabled = true
	overlay_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	overlay_text.add_theme_font_size_override("normal_font_size", 17)
	overlay_text.add_theme_font_size_override("bold_font_size", 17)
	ov.add_child(overlay_text)
	ov.add_child(_button("Close", func(): overlay.visible = false))
	overlay.visible = false
	root.add_child(overlay)
	# a second overlay, built on demand, for starting and loading campaigns
	dialog = PanelContainer.new()
	dialog.anchor_left = 0.5
	dialog.anchor_right = 0.5
	dialog.anchor_top = 0.5
	dialog.anchor_bottom = 0.5
	dialog.offset_left = -420
	dialog.offset_right = 420
	dialog.offset_top = -300
	dialog.offset_bottom = 300
	dialog.add_theme_stylebox_override("panel", UIStyle.panel_box(0.95, UIStyle.GOLD))
	dialog_box = VBoxContainer.new()
	dialog_box.add_theme_constant_override("separation", 12)
	dialog.add_child(dialog_box)
	dialog.visible = false
	root.add_child(dialog)

func _spacer(h: int) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(0, h)
	return c

func _button(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.pressed.connect(cb)
	return b

func _other(id: String) -> String:
	for w in GameData.WARBAND_IDS:
		if w != id:
			return w
	return id

func _choice_row(store: Dictionary, cb: Callable) -> GridContainer:
	var h := GridContainer.new()
	h.columns = 3
	h.add_theme_constant_override("h_separation", 6)
	h.add_theme_constant_override("v_separation", 6)
	for id in GameData.WARBAND_IDS:
		var wb := GameData.warband(id)
		var b := Button.new()
		b.text = wb["short"]
		b.toggle_mode = true
		b.custom_minimum_size = Vector2(146, 0)
		b.pressed.connect(cb.bind(id))
		h.add_child(b)
		store[id] = b
	return h

func _pick_player(id: String) -> void:
	## A warband button: lead that warband (the foe moves aside if it was the same).
	player_pick = id
	if enemy_pick == id:
		enemy_pick = _other(id)
	_refresh()

func _refresh() -> void:
	for id in player_btns:
		player_btns[id].button_pressed = id == player_pick
	if muster != null:
		muster.show_warband(player_pick)
	if enemy_pick == player_pick:
		enemy_pick = _other(player_pick)
	var a := GameData.warband(player_pick)
	var ca := Color(a["color"][0], a["color"][1], a["color"][2]).lightened(0.4)
	info.text = "[b][color=#%s]%s[/color][/b]\n%s" % [UIStyle.col_hex(ca), a["name"], a["desc"]]

func _begin() -> void:
	Game.player_warband = player_pick
	Game.enemy_warband = enemy_pick
	Game.campaign = null
	Game.mode = "battle"
	Game.autoplay = false
	get_tree().reload_current_scene()

func _pick_row(ids: Array, current: String, label: Callable, cb: Callable, w := 250) -> Control:
	var h: Container
	if ids.size() >= 6:
		# six or more choices go in two rows of three
		var g := GridContainer.new()
		g.columns = 3
		g.add_theme_constant_override("h_separation", 8)
		g.add_theme_constant_override("v_separation", 8)
		g.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		h = g
	else:
		var hb := HBoxContainer.new()
		hb.alignment = BoxContainer.ALIGNMENT_CENTER
		hb.add_theme_constant_override("separation", 8)
		h = hb
	for id in ids:
		var b := _button(label.call(id), func(): cb.call(id))
		b.toggle_mode = true
		b.button_pressed = id == current
		b.custom_minimum_size = Vector2(w, 44)
		h.add_child(b)
	return h

func _skirmish_dialog() -> void:
	_clear_dialog("Skirmish")
	if enemy_pick == player_pick:
		enemy_pick = _other(player_pick)
	var foes: Array = GameData.WARBAND_IDS.filter(func(x): return x != player_pick)
	dialog_box.add_child(UIStyle.label("Your foe", 18, UIStyle.GOLD, UIStyle.bold_font()))
	dialog_box.add_child(_pick_row(foes, enemy_pick, func(id): return GameData.warband(id)["short"], func(id): enemy_pick = id; _skirmish_dialog(), 140))
	dialog_box.add_child(UIStyle.label("Battlefield", 18, UIStyle.GOLD, UIStyle.bold_font()))
	dialog_box.add_child(_pick_row(GameData.MAP_IDS, Game.map_id, func(id): return GameData.map_data(id)["name"], func(id): Game.map_id = id; _skirmish_dialog(), 190))
	dialog_box.add_child(UIStyle.label("Scenario", 18, UIStyle.GOLD, UIStyle.bold_font()))
	dialog_box.add_child(_pick_row(GameData.SCENARIO_IDS, Game.scenario, func(id): return GameData.scenario(id)["name"], func(id): Game.scenario = id; _skirmish_dialog(), 190))
	dialog_box.add_child(UIStyle.label("Weather", 18, UIStyle.GOLD, UIStyle.bold_font()))
	dialog_box.add_child(_pick_row(["random", "still", "dawn", "rain", "fog"], Game.weather, func(id): return "Whatever comes" if id == "random" else BattleState.WEATHERS[id]["name"], func(id): Game.weather = id; _skirmish_dialog(), 170))
	var r := RichTextLabel.new()
	r.bbcode_enabled = true
	r.fit_content = true
	r.custom_minimum_size = Vector2(780, 0)
	r.add_theme_font_size_override("normal_font_size", 16)
	r.add_theme_font_size_override("bold_font_size", 16)
	var md := GameData.map_data(Game.map_id)
	var sc := GameData.scenario(Game.scenario)
	r.text = "[b]%s[/b]  %s\n\n[b]%s[/b]  %s" % [md["name"], md.get("desc", ""), sc["name"], sc["desc"]]
	if Game.weather != "random" and Game.weather != "still":
		r.text += "\n\n[b]%s[/b]  %s" % [BattleState.WEATHERS[Game.weather]["name"], BattleState.WEATHERS[Game.weather]["line"]]
	dialog_box.add_child(r)
	var h := HBoxContainer.new()
	h.alignment = BoxContainer.ALIGNMENT_CENTER
	h.add_theme_constant_override("separation", 12)
	h.add_child(_button("Back", func(): dialog.visible = false))
	var go := _button("Into the ruins", func(): _begin())
	go.add_theme_font_override("font", UIStyle.title_font())
	go.add_theme_font_size_override("font_size", 28)
	go.add_theme_color_override("font_color", UIStyle.JADE)
	h.add_child(go)
	dialog_box.add_child(h)

func _settings_dialog() -> void:
	_clear_dialog("Settings")
	var s: Dictionary = Game.settings
	var g := GridContainer.new()
	g.columns = 3
	g.add_theme_constant_override("h_separation", 18)
	g.add_theme_constant_override("v_separation", 10)
	for row in [["vol_master", "Volume"], ["vol_music", "Music"], ["vol_effects", "Effects"], ["vol_ambience", "Wind and fire"]]:
		var key: String = row[0]
		g.add_child(UIStyle.label(row[1], 18, UIStyle.BONE))
		var sl := HSlider.new()
		sl.min_value = 0.0
		sl.max_value = 1.0
		sl.step = 0.05
		sl.value = float(s[key])
		sl.custom_minimum_size = Vector2(420, 32)
		var pct := UIStyle.label("%d%%" % int(round(float(s[key]) * 100)), 16, UIStyle.GOLD)
		pct.custom_minimum_size = Vector2(60, 0)
		sl.value_changed.connect(func(v: float):
			Game.settings[key] = v
			pct.text = "%d%%" % int(round(v * 100))
			Sfx.apply_volumes())
		sl.drag_ended.connect(func(_c): Game.save_settings(); Sfx.play("ui_click"))
		g.add_child(sl)
		g.add_child(pct)
	dialog_box.add_child(g)
	dialog_box.add_child(UIStyle.label("Graphics", 18, UIStyle.GOLD, UIStyle.bold_font()))
	dialog_box.add_child(_pick_row(["high", "fast"], "high" if s["graphics_high"] else "fast",
		func(id): return "High: fog and shadows in every corner" if id == "high" else "Fast: for slower PCs",
		func(id): _set_graphics(id == "high"), 380))
	dialog_box.add_child(UIStyle.label("Window", 18, UIStyle.GOLD, UIStyle.bold_font()))
	dialog_box.add_child(_pick_row(["full", "window"], "full" if s["fullscreen"] else "window",
		func(id): return "Full screen" if id == "full" else "In a window",
		func(id): Game.settings["fullscreen"] = id == "full"; Game.save_settings(); Game.apply_window(); _settings_dialog(), 380))
	dialog_box.add_child(UIStyle.label("Battle animations", 18, UIStyle.GOLD, UIStyle.bold_font()))
	var cur := "1.0"
	if float(s["anim_speed"]) > 2.0:
		cur = "2.5"
	elif float(s["anim_speed"]) > 1.2:
		cur = "1.6"
	dialog_box.add_child(_pick_row(["1.0", "1.6", "2.5"], cur,
		func(id): return {"1.0": "Unhurried", "1.6": "Brisk", "2.5": "Quick"}[id],
		func(id): Game.settings["anim_speed"] = float(id); Game.anim_speed = float(id); Game.save_settings(); _settings_dialog(), 250))
	dialog_box.add_child(UIStyle.label("Cinematic camera", 18, UIStyle.GOLD, UIStyle.bold_font()))
	dialog_box.add_child(_pick_row(["on", "off"], "on" if s.get("cinematics", true) else "off",
		func(id): return "Opening flyover and slow motion when a fighter falls" if id == "on" else "Straight to the fighting",
		func(id): Game.settings["cinematics"] = id == "on"; Game.save_settings(); _settings_dialog(), 380))
	dialog_box.add_child(UIStyle.label("Updates", 18, UIStyle.GOLD, UIStyle.bold_font()))
	dialog_box.add_child(_pick_row(["auto", "ask"], "auto" if s.get("auto_update", true) else "ask",
		func(id): return "Update by itself" if id == "auto" else "Only when I say",
		func(id): Game.settings["auto_update"] = id == "auto"; Game.save_settings(); _settings_dialog(), 380))
	var h := HBoxContainer.new()
	h.alignment = BoxContainer.ALIGNMENT_CENTER
	if Updater.state == "available":
		h.add_child(_button("Update to %s" % str(Updater.info.get("version", "")), func(): dialog.visible = false; Updater.download()))
	h.add_child(_button("Done", func(): dialog.visible = false))
	dialog_box.add_child(h)

func _set_graphics(high: bool) -> void:
	if high == bool(Game.settings["graphics_high"]):
		return
	Game.settings["graphics_high"] = high
	Game.save_settings()
	Game._apply_graphics()
	Game.mode = "menu"
	get_tree().reload_current_scene()

func _clear_dialog(title: String) -> void:
	for ch in dialog_box.get_children():
		ch.queue_free()
	var t := UIStyle.title(title, 40, UIStyle.GOLD)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	dialog_box.add_child(t)
	overlay.visible = false
	dialog.visible = true

func _new_campaign_dialog() -> void:
	_clear_dialog("A new campaign")
	var wb := GameData.warband(player_pick)
	var col := Color(wb["color"][0], wb["color"][1], wb["color"][2]).lightened(0.4)
	var r := RichTextLabel.new()
	r.bbcode_enabled = true
	r.fit_content = true
	r.custom_minimum_size = Vector2(760, 0)
	r.add_theme_font_size_override("normal_font_size", 17)
	r.add_theme_font_size_override("bold_font_size", 17)
	r.text = "You lead [b][color=#%s]%s[/color][/b] into Hethra. The warband lives from battle to battle: fighters are wounded, scarred or killed, the survivors learn and grow, and the godshards you bring out buy weapons, armour and new blood.\n\nYou start with the standard warband and %d jakatas left over to spend in the camp. Change your warband with the buttons on the left.\n\nName your warband:" % [UIStyle.col_hex(col), wb["name"], maxi(int(Campaign.data()["min_purse"]), int(Campaign.data()["starting_purse"]) - _roster_cost(player_pick))]
	dialog_box.add_child(r)
	name_edit = LineEdit.new()
	name_edit.placeholder_text = "Leave empty for a name from the camp"
	name_edit.max_length = 40
	name_edit.custom_minimum_size = Vector2(760, 50)
	name_edit.add_theme_font_size_override("font_size", 22)
	dialog_box.add_child(name_edit)
	name_edit.grab_focus.call_deferred()
	name_edit.text_submitted.connect(func(_t): _start_campaign())
	var h := HBoxContainer.new()
	h.alignment = BoxContainer.ALIGNMENT_CENTER
	h.add_theme_constant_override("separation", 12)
	h.add_child(_button("Back", func(): dialog.visible = false))
	var go := _button("To the camp", func(): _start_campaign())
	go.add_theme_font_override("font", UIStyle.title_font())
	go.add_theme_font_size_override("font_size", 26)
	go.add_theme_color_override("font_color", UIStyle.JADE)
	h.add_child(go)
	dialog_box.add_child(h)

func _roster_cost(fid: String) -> int:
	var wb := GameData.warband(fid)
	var total := 0
	for e in wb["battle_roster"]:
		total += int(wb["units"][e["unit"]]["cost"])
	return total

func _start_campaign() -> void:
	var c := Campaign.create(player_pick, name_edit.text.strip_edges(), int(Time.get_unix_time_from_system()) % 1000000)
	c.save()
	Game.campaign = c
	Game.mode = "camp"
	get_tree().reload_current_scene()

func _load_campaign(id: String) -> void:
	var c := Campaign.load_file(id)
	if c == null:
		return
	Game.campaign = c
	Game.mode = "camp"
	get_tree().reload_current_scene()

func _load_dialog() -> void:
	_clear_dialog("Load a campaign")
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(780, 420)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	dialog_box.add_child(sc)
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 8)
	sc.add_child(list)
	for s in Campaign.list_saves():
		var h := HBoxContainer.new()
		h.add_theme_constant_override("separation", 8)
		var sid: String = s["id"]
		var b := _button("%s\n%s  ·  %d battles, %d won  ·  rating %d  ·  %s" % [s["name"], GameData.warband(s["faction"])["name"], int(s["battles"]), int(s["wins"]), int(s["rating"]), Time.get_datetime_string_from_unix_time(int(s["updated"]), true)], func(): _load_campaign(sid))
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.add_theme_font_size_override("font_size", 16)
		h.add_child(b)
		var del := _button("Delete", func(): pass)
		del.add_theme_color_override("font_color", UIStyle.BLOOD)
		del.pressed.connect(func():
			if del.text == "Delete":
				del.text = "Sure?"
			else:
				Campaign.delete_save(sid)
				_load_dialog())
		h.add_child(del)
		list.add_child(h)
	dialog_box.add_child(_button("Back", func(): dialog.visible = false))

func _show_overlay(title: String, text: String) -> void:
	dialog.visible = false
	overlay_title.text = title
	overlay_text.text = text
	overlay.visible = true

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		overlay.visible = false
		dialog.visible = false

func _help_text() -> String:
	return """[b]The aim[/b]  Two warbands meet in the ruins. Break the enemy's nerve, or win the scenario when twelve rounds are done: hold more godshards (Shard hunt), keep more fighters on their feet (Street fight), have more fighters inside the ring of witch-fire (Hold the ground), keep your leader alive while theirs falls (Take their leader), or get three fighters onto the enemy's starting ground (Through their lines: their ground glows jade, yours red).

[b]The campaign[/b]  Your warband lives from battle to battle. Afterwards the wounded roll for their fate, survivors gain experience and advances, and heroes search the ruins. In the camp, sell godshards, buy kit, hire fighters, and choose the next fight.

[b]Battlefields[/b]  The Idol Square, the Broken Causeway (a dry canal under the quays) and the Tower Ward (tall ruins, narrow alleys, plank walks between the roofs), the Starfall (a crater round a burning starstone) the Sleeper's Stair (a stepped temple with the sleeping goddess on top) and the Drowned Quarter (flooded streets: wading is slow, but the water breaks a short fall).

[b]Turns[/b]  Sides take turns. In yours, each fighter gets movement (Move × 2.5 m) and two actions: strike, charge, shoot, dash, throw a munition or cast a spell.

[b]The city[/b]  Climb ladders and stairs, cross plank bridges, jump gaps between roofs and drop down from ledges. Jumps and drops need an Initiative test, and a failed one is a fall that can wound.

[b]Sight[/b]  You only see enemies your fighters can see. Walls and pillars block sight and give cover. A ghost marks where an enemy was last seen.

[b]Wounds[/b]  A wound can knock a fighter down, stun them or take them out of action. A downed or stunned fighter is hit automatically in close combat.

[b]Controls[/b]  The camera rides with your fighter; V switches to the overhead view. Right-drag to look around, WASD pan, wheel zoom. Click a fighter to choose them, the glowing ground to move, an enemy to fight or shoot. Tab next fighter, Space back to the fighter, Enter end turn, F1 help in battle."""

func _credits_text() -> String:
	return """[b]Hethra, City of the Fallen[/b] is an unofficial, non-commercial fan project.

[b]The world[/b]  Inspired by the Malazan Book of the Fallen and the Malazan Empire novels by [b]Steven Erikson[/b] and [b]Ian C. Esslemont[/b]. The Malazan Empire, its marines, warrens, the Chained One, the Whirlwind, the Seguleh, the Tiste Andii, the Barghast and the T'lan Imass belong to them and their publishers. All rules text, places and characters in this game are written for it.

[b]Inspiration[/b]  The game is a turn-based warband skirmish in the tradition of tabletop skirmish games in ruined cities. It uses no art, names, text or rules text from any other game.

[b]Engine[/b]  Godot Engine 4, MIT licence, godotengine.org.

[b]Fonts[/b]  Grenze Gotisch and Alegreya Sans, SIL Open Font License 1.1 (licences in the fonts folder).

[b]Art[/b]  The city, figures, textures and effects are generated in code for this project.

Design and code: built with Claude."""
