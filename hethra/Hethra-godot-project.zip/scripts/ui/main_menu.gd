class_name MainMenu
extends Node3D
## Title screen over the burning city: pick your warband and your foe,
## read how to play and the credits, then go into the ruins.

var atm: Atmosphere
var city: CityBuilder
var cam: Camera3D
var t := 0.0
var centre := Vector3.ZERO
var ui: CanvasLayer
var player_pick := ""
var enemy_pick := ""
var player_btns := {}
var enemy_btns := {}
var info: RichTextLabel
var overlay: PanelContainer
var overlay_text: RichTextLabel
var overlay_title: Label
var quality_btn: Button

func _ready() -> void:
	var map := BattleMap.new()
	map.load_map(Game.map_id)
	centre = Vector3(map.w * map.cell * 0.5, 0, map.d * map.cell * 0.5)
	atm = Atmosphere.new()
	add_child(atm)
	atm.build(centre, Game.graphics)
	city = CityBuilder.new()
	add_child(city)
	var shards := {}
	for sh in map.data["shards"]:
		shards[BattleMap.nid(int(sh[0]), int(sh[1]), int(sh[2]))] = true
	city.build(map, shards)
	cam = Camera3D.new()
	cam.fov = 50.0
	cam.far = 900.0
	add_child(cam)
	cam.current = true
	player_pick = Game.player_warband
	enemy_pick = Game.enemy_warband
	_build_ui()
	_refresh()
	if Game.screenshot_path != "":
		t = 2.2
		for i in range(30):
			await get_tree().process_frame
		get_viewport().get_texture().get_image().save_png(Game.screenshot_path)
		print("menu shot saved")
		get_tree().quit()

func _process(delta: float) -> void:
	t += delta * 0.035
	var r := 40.0
	cam.position = centre + Vector3(sin(t) * r, 15.0 + sin(t * 0.7) * 2.0, cos(t) * r)
	cam.look_at(centre + Vector3(0, 3, 0), Vector3.UP)

func _build_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)
	var root := Control.new()
	root.theme = UIStyle.theme()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(root)
	# a dark band on the left for legibility
	var shade := ColorRect.new()
	shade.color = Color(0.02, 0.025, 0.03, 0.62)
	shade.anchor_bottom = 1.0
	shade.offset_right = 560
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(shade)
	var v := VBoxContainer.new()
	v.position = Vector2(56, 52)
	v.custom_minimum_size = Vector2(450, 0)
	v.add_theme_constant_override("separation", 10)
	root.add_child(v)
	v.add_child(UIStyle.title("Hethra", 86, UIStyle.BONE))
	var sub := UIStyle.title("City of the Fallen", 34, UIStyle.JADE)
	v.add_child(sub)
	var tag := UIStyle.label("Where the Crippled God's pain fell burning from the sky, the city died in a night. Its ruins are thick with godshards, and every faction wants them.", 17, UIStyle.DIM)
	tag.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tag.custom_minimum_size = Vector2(450, 0)
	v.add_child(tag)
	v.add_child(_spacer(10))
	v.add_child(UIStyle.label("Your warband", 20, UIStyle.GOLD, UIStyle.bold_font()))
	v.add_child(_choice_row(player_btns, func(id): player_pick = id; if enemy_pick == id: enemy_pick = _other(id); _refresh()))
	v.add_child(UIStyle.label("Your foe", 20, UIStyle.GOLD, UIStyle.bold_font()))
	v.add_child(_choice_row(enemy_btns, func(id): enemy_pick = id; if player_pick == id: player_pick = _other(id); _refresh()))
	info = RichTextLabel.new()
	info.bbcode_enabled = true
	info.fit_content = true
	info.custom_minimum_size = Vector2(450, 0)
	info.add_theme_font_size_override("normal_font_size", 16)
	info.add_theme_font_size_override("bold_font_size", 16)
	v.add_child(info)
	v.add_child(_spacer(6))
	var begin := _button("Into the ruins", func(): _begin())
	begin.add_theme_font_override("font", UIStyle.title_font())
	begin.add_theme_font_size_override("font_size", 30)
	begin.add_theme_color_override("font_color", UIStyle.JADE)
	v.add_child(begin)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	row.add_child(_button("How to play", func(): _show_overlay("How to play", _help_text())))
	row.add_child(_button("Credits", func(): _show_overlay("Credits", _credits_text())))
	quality_btn = _button("", func(): _toggle_quality())
	row.add_child(quality_btn)
	row.add_child(_button("Quit", func(): get_tree().quit()))
	v.add_child(row)
	var foot := UIStyle.label("A free fan project set in the world of the Malazan Book of the Fallen by Steven Erikson and Ian C. Esslemont.", 13, Color(0.55, 0.55, 0.55))
	foot.anchor_top = 1.0
	foot.anchor_bottom = 1.0
	foot.offset_left = 56
	foot.offset_top = -40
	foot.offset_right = 1200
	root.add_child(foot)
	# overlay for help and credits
	overlay = PanelContainer.new()
	overlay.anchor_left = 0.5
	overlay.anchor_right = 0.5
	overlay.anchor_top = 0.5
	overlay.anchor_bottom = 0.5
	overlay.offset_left = -400
	overlay.offset_right = 400
	overlay.offset_top = -320
	overlay.offset_bottom = 320
	var ov := VBoxContainer.new()
	overlay.add_child(ov)
	overlay_title = UIStyle.title("", 36, UIStyle.JADE)
	ov.add_child(overlay_title)
	overlay_text = RichTextLabel.new()
	overlay_text.bbcode_enabled = true
	overlay_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	overlay_text.add_theme_font_size_override("normal_font_size", 17)
	overlay_text.add_theme_font_size_override("bold_font_size", 17)
	ov.add_child(overlay_text)
	ov.add_child(_button("Close", func(): overlay.visible = false))
	overlay.visible = false
	root.add_child(overlay)

func _spacer(h: int) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(0, h)
	return c

func _button(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.pressed.connect(cb)
	return b

func _other(id: String) -> String:
	for w in GameData.WARBAND_IDS:
		if w != id:
			return w
	return id

func _choice_row(store: Dictionary, cb: Callable) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 6)
	for id in GameData.WARBAND_IDS:
		var wb := GameData.warband(id)
		var b := Button.new()
		b.text = wb["short"]
		b.toggle_mode = true
		b.custom_minimum_size = Vector2(140, 0)
		b.pressed.connect(cb.bind(id))
		h.add_child(b)
		store[id] = b
	return h

func _refresh() -> void:
	for id in player_btns:
		player_btns[id].button_pressed = id == player_pick
		enemy_btns[id].button_pressed = id == enemy_pick
	var a := GameData.warband(player_pick)
	var b := GameData.warband(enemy_pick)
	var ca := Color(a["color"][0], a["color"][1], a["color"][2]).lightened(0.4)
	var cb := Color(b["color"][0], b["color"][1], b["color"][2]).lightened(0.4)
	info.text = "[b][color=#%s]%s[/color][/b]\n%s\n\n[b]against [color=#%s]%s[/color][/b]\n%s" % [UIStyle.col_hex(ca), a["name"], a["desc"], UIStyle.col_hex(cb), b["name"], b["desc"]]
	quality_btn.text = "Graphics: " + ("high" if Game.graphics.get("fog", true) else "fast")

func _toggle_quality() -> void:
	var high: bool = not Game.graphics.get("fog", true)
	Game.graphics = {"fog": high, "ssao": high, "ssil": false, "glow": true, "shadows": true}
	_refresh()
	Game.mode = "menu"
	get_tree().reload_current_scene()

func _begin() -> void:
	Game.player_warband = player_pick
	Game.enemy_warband = enemy_pick
	Game.mode = "battle"
	Game.autoplay = false
	get_tree().reload_current_scene()

func _show_overlay(title: String, text: String) -> void:
	overlay_title.text = title
	overlay_text.text = text
	overlay.visible = true

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		overlay.visible = false

func _help_text() -> String:
	return """[b]The aim[/b]  Two warbands enter the square around the fallen idol. Godshards lie in the ruins; walk onto one to pick it up. Break the enemy's nerve, or hold more shards when twelve rounds are done.

[b]Turns[/b]  Sides take turns. In yours, each fighter gets movement (Move × 2.5 m) and two actions: strike, charge, shoot, dash, throw a munition or cast a spell.

[b]The city[/b]  Climb ladders and stairs, cross plank bridges, jump gaps between roofs and drop down from ledges. Jumps and drops need an Initiative test, and a failed one is a fall that can wound.

[b]Sight[/b]  You only see enemies your fighters can see. Walls and pillars block sight and give cover. A ghost marks where an enemy was last seen.

[b]Wounds[/b]  A wound can knock a fighter down, stun them or take them out of action. A downed or stunned fighter is hit automatically in close combat.

[b]Controls[/b]  WASD pan, Q/E turn, R/F tilt, wheel zoom, middle-drag orbit, right-drag pan. Click a fighter to choose them, a glowing disc to move, an enemy to fight or shoot. Tab next fighter, Space focus, Enter end turn, F1 help in battle."""

func _credits_text() -> String:
	return """[b]Hethra, City of the Fallen[/b] is an unofficial, non-commercial fan project.

[b]The world[/b]  Inspired by the Malazan Book of the Fallen and the Malazan Empire novels by [b]Steven Erikson[/b] and [b]Ian C. Esslemont[/b]. The Malazan Empire, its marines, warrens, the Chained One and the Whirlwind belong to them and their publishers. All rules text, places and characters in this game are written for it.

[b]Inspiration[/b]  The game is a turn-based warband skirmish in the tradition of tabletop skirmish games in ruined cities. It uses no art, names, text or rules text from any other game.

[b]Engine[/b]  Godot Engine 4, MIT licence, godotengine.org.

[b]Fonts[/b]  Grenze Gotisch and Alegreya Sans, SIL Open Font License 1.1 (licences in the fonts folder).

[b]Art[/b]  The city, figures, textures and effects are generated in code for this project.

Design and code: built with Claude."""
