class_name Hud
extends CanvasLayer
## The battle interface: turn banner, roster, fighter card, target card,
## action bar, combat log, hover odds, toasts, help and the result screen.

signal action(name: String, arg: String)
signal end_turn
signal pick_unit(id: int)
signal result_choice(name: String)

var root: Control
var banner_title: Label
var banner_sub: Label
var roster_box: VBoxContainer
var card: PanelContainer
var card_title: Label
var card_sub: Label
var card_stats: GridContainer
var card_extra: RichTextLabel
var mp_bar: ProgressBar
var ap_label: Label
var target_card: PanelContainer
var target_title: Label
var target_body: RichTextLabel
var log_text: RichTextLabel
var actions_box: HBoxContainer
var buttons: Dictionary = {}
var end_btn: Button
var tip: PanelContainer
var tip_text: RichTextLabel
var toast_label: Label
var help_panel: PanelContainer
var result_panel: PanelContainer
var throw_menu: PopupMenu
var cast_menu: PopupMenu
var mode_label: Label
var hint_label: Label
var bar: PanelContainer
var wound_box: HBoxContainer
var status_label: RichTextLabel
var portrait_vp: SubViewport
var portrait_cam: Camera3D
var portrait_box: PanelContainer
var portrait_target: Node3D = null
var dice_box: HBoxContainer
var flash_rect: ColorRect
var log_panel: PanelContainer

const STATS := ["M", "WS", "BS", "S", "T", "W", "I", "A", "Ld"]

func _ready() -> void:
	layer = 10
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = UIStyle.theme()
	add_child(root)
	_build_vignette()
	_build_banner()
	_build_roster()
	_build_target_card()
	_build_log()
	_build_bar()
	_build_dice()
	_build_tip()
	_build_toast()
	_build_help()

func _anchor(c: Control, preset: int, margin := Vector2(16, 16)) -> void:
	c.set_anchors_and_offsets_preset(preset, Control.PRESET_MODE_MINSIZE)
	match preset:
		Control.PRESET_TOP_LEFT:
			c.position = margin
		Control.PRESET_TOP_RIGHT:
			c.position.x -= margin.x
			c.position.y = margin.y
		Control.PRESET_BOTTOM_LEFT:
			c.position.x = margin.x
			c.position.y -= margin.y
		Control.PRESET_BOTTOM_RIGHT:
			c.position -= margin

func _build_banner() -> void:
	var p := PanelContainer.new()
	p.set_anchors_preset(Control.PRESET_CENTER_TOP)
	p.anchor_left = 0.5
	p.anchor_right = 0.5
	p.offset_left = -260
	p.offset_right = 260
	p.offset_top = 10
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 0)
	p.add_child(v)
	banner_title = UIStyle.title("Hethra", 30)
	banner_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(banner_title)
	banner_sub = UIStyle.label("", 16, UIStyle.DIM)
	banner_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(banner_sub)
	root.add_child(p)

func _build_roster() -> void:
	var p := PanelContainer.new()
	p.position = Vector2(16, 16)
	p.custom_minimum_size = Vector2(250, 0)
	var v := VBoxContainer.new()
	p.add_child(v)
	v.add_child(UIStyle.title("Your warband", 22, UIStyle.JADE))
	roster_box = VBoxContainer.new()
	roster_box.add_theme_constant_override("separation", 3)
	v.add_child(roster_box)
	var h := UIStyle.label("Tab: next fighter    F1: help", 13, UIStyle.DIM)
	v.add_child(h)
	root.add_child(p)

func _build_target_card() -> void:
	target_card = PanelContainer.new()
	target_card.custom_minimum_size = Vector2(380, 0)
	target_card.anchor_left = 1.0
	target_card.anchor_right = 1.0
	target_card.anchor_top = 1.0
	target_card.anchor_bottom = 1.0
	target_card.offset_right = -16
	target_card.offset_bottom = -484
	target_card.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	target_card.grow_vertical = Control.GROW_DIRECTION_BEGIN
	target_card.add_theme_stylebox_override("panel", UIStyle.panel_box(0.9, UIStyle.BLOOD))
	target_card.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var v := VBoxContainer.new()
	target_card.add_child(v)
	target_title = UIStyle.title("", 26, UIStyle.BONE)
	v.add_child(target_title)
	target_body = RichTextLabel.new()
	target_body.bbcode_enabled = true
	target_body.fit_content = true
	target_body.scroll_active = false
	target_body.custom_minimum_size = Vector2(360, 0)
	target_body.add_theme_font_size_override("normal_font_size", 15)
	target_body.add_theme_font_size_override("bold_font_size", 15)
	target_body.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(target_body)
	target_card.visible = false
	root.add_child(target_card)

func _build_log() -> void:
	var p := PanelContainer.new()
	p.anchor_left = 1.0
	p.anchor_right = 1.0
	p.anchor_top = 1.0
	p.anchor_bottom = 1.0
	p.offset_left = -470
	p.offset_right = -16
	p.offset_top = -470
	p.offset_bottom = -214
	p.add_theme_stylebox_override("panel", UIStyle.panel_box(0.7))
	log_panel = p
	var v := VBoxContainer.new()
	p.add_child(v)
	v.add_child(UIStyle.title("Chronicle", 20, UIStyle.JADE))
	log_text = RichTextLabel.new()
	log_text.bbcode_enabled = true
	log_text.scroll_following = true
	log_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	log_text.add_theme_font_size_override("normal_font_size", 15)
	log_text.add_theme_font_size_override("bold_font_size", 15)
	log_text.add_theme_constant_override("line_separation", 2)
	v.add_child(log_text)
	root.add_child(p)

const BRONZE := Color(0.62, 0.44, 0.24)

func _build_vignette() -> void:
	## Dark edges and a red flash when one of yours is hurt.
	var g := Gradient.new()
	g.set_color(0, Color(0, 0, 0, 0.0))
	g.set_color(1, Color(0, 0, 0, 0.62))
	g.add_point(0.55, Color(0, 0, 0, 0.0))
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.45)
	gt.fill_to = Vector2(1.08, 1.0)
	gt.width = 256
	gt.height = 256
	var v := TextureRect.new()
	v.texture = gt
	v.set_anchors_preset(Control.PRESET_FULL_RECT)
	v.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	v.stretch_mode = TextureRect.STRETCH_SCALE
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(v)
	flash_rect = ColorRect.new()
	flash_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	flash_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	flash_rect.color = Color(0.6, 0, 0, 0.0)
	root.add_child(flash_rect)

func flash(c: Color) -> void:
	flash_rect.color = c
	var tw := create_tween()
	tw.tween_property(flash_rect, "color:a", 0.0, 0.6)

func _bar_box() -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.035, 0.034, 0.036, 0.95)
	sb.border_color = Color(BRONZE.r, BRONZE.g, BRONZE.b, 0.7)
	sb.border_width_top = 2
	sb.content_margin_left = 14
	sb.content_margin_right = 18
	sb.content_margin_top = 12
	sb.content_margin_bottom = 12
	sb.shadow_color = Color(0, 0, 0, 0.6)
	sb.shadow_size = 18
	return sb

func _framed(inner: Control, border: Color, size: Vector2) -> PanelContainer:
	var f := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.02, 0.02, 0.022, 1.0)
	sb.border_color = border
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(2)
	sb.content_margin_left = 3
	sb.content_margin_right = 3
	sb.content_margin_top = 3
	sb.content_margin_bottom = 3
	f.add_theme_stylebox_override("panel", sb)
	f.custom_minimum_size = size
	f.add_child(inner)
	return f

func _build_bar() -> void:
	bar = PanelContainer.new()
	bar.anchor_left = 0.0
	bar.anchor_right = 1.0
	bar.anchor_top = 1.0
	bar.anchor_bottom = 1.0
	bar.offset_top = -198
	bar.add_theme_stylebox_override("panel", _bar_box())
	root.add_child(bar)
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 22)
	bar.add_child(h)

	# --- portrait: a live close-up of the fighter, drawn by its own camera
	var svc := SubViewportContainer.new()
	svc.stretch = true
	svc.custom_minimum_size = Vector2(164, 164)
	portrait_vp = SubViewport.new()
	portrait_vp.size = Vector2i(164, 164)
	portrait_vp.msaa_3d = Viewport.MSAA_4X
	portrait_vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	svc.add_child(portrait_vp)
	portrait_cam = Camera3D.new()
	portrait_cam.fov = 30.0
	portrait_cam.near = 0.05
	portrait_cam.cull_mask = 2
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.045, 0.04, 0.038)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.95, 0.78, 0.6)
	env.ambient_light_energy = 0.9
	env.tonemap_mode = Environment.TONE_MAPPER_AGX
	env.tonemap_exposure = 1.25
	portrait_cam.environment = env
	portrait_vp.add_child(portrait_cam)
	portrait_box = _framed(svc, BRONZE, Vector2(172, 172))
	h.add_child(portrait_box)

	# --- name, status, wounds and kit
	var nb := VBoxContainer.new()
	nb.custom_minimum_size = Vector2(380, 0)
	nb.add_theme_constant_override("separation", 2)
	h.add_child(nb)
	card_title = UIStyle.title("", 36)
	nb.add_child(card_title)
	card_sub = UIStyle.label("", 15, UIStyle.DIM)
	nb.add_child(card_sub)
	var wr := HBoxContainer.new()
	wr.add_theme_constant_override("separation", 6)
	nb.add_child(wr)
	wr.add_child(UIStyle.label("Wounds", 15, UIStyle.DIM, UIStyle.bold_font()))
	wound_box = HBoxContainer.new()
	wound_box.add_theme_constant_override("separation", 4)
	wr.add_child(wound_box)
	status_label = RichTextLabel.new()
	status_label.bbcode_enabled = true
	status_label.fit_content = true
	status_label.scroll_active = false
	status_label.custom_minimum_size = Vector2(380, 0)
	status_label.add_theme_font_size_override("normal_font_size", 15)
	status_label.add_theme_font_size_override("bold_font_size", 15)
	nb.add_child(status_label)
	card_extra = RichTextLabel.new()
	card_extra.bbcode_enabled = true
	card_extra.fit_content = true
	card_extra.scroll_active = false
	card_extra.custom_minimum_size = Vector2(380, 0)
	card_extra.add_theme_font_size_override("normal_font_size", 14)
	card_extra.add_theme_font_size_override("bold_font_size", 14)
	card_extra.add_theme_color_override("default_color", Color(0.75, 0.72, 0.66))
	nb.add_child(card_extra)

	# --- the stat line in boxes, and what is left of the turn
	var sv := VBoxContainer.new()
	sv.add_theme_constant_override("separation", 8)
	h.add_child(sv)
	card_stats = GridContainer.new()
	card_stats.columns = STATS.size()
	card_stats.add_theme_constant_override("h_separation", 4)
	card_stats.add_theme_constant_override("v_separation", 2)
	sv.add_child(card_stats)
	for s in STATS:
		var l := UIStyle.label(s, 13, UIStyle.DIM, UIStyle.bold_font())
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		l.custom_minimum_size = Vector2(46, 0)
		card_stats.add_child(l)
	for s in STATS:
		var l := UIStyle.label("-", 26, UIStyle.BONE, UIStyle.bold_font())
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		l.custom_minimum_size = Vector2(46, 44)
		l.name = "v_" + s
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(0.08, 0.075, 0.07)
		sb.border_color = Color(BRONZE.r, BRONZE.g, BRONZE.b, 0.35)
		sb.set_border_width_all(1)
		l.add_theme_stylebox_override("normal", sb)
		card_stats.add_child(l)
	var mr := HBoxContainer.new()
	mr.add_theme_constant_override("separation", 12)
	sv.add_child(mr)
	mp_bar = ProgressBar.new()
	mp_bar.custom_minimum_size = Vector2(250, 16)
	mp_bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	mp_bar.show_percentage = false
	var fill := StyleBoxFlat.new()
	fill.bg_color = Color(0.3, 0.85, 0.7, 0.85)
	fill.set_corner_radius_all(2)
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0.1, 0.1, 0.1)
	bg.set_corner_radius_all(2)
	mp_bar.add_theme_stylebox_override("fill", fill)
	mp_bar.add_theme_stylebox_override("background", bg)
	mr.add_child(mp_bar)
	ap_label = UIStyle.label("", 18, UIStyle.JADE, UIStyle.bold_font())
	mr.add_child(ap_label)

	# --- actions
	var av := VBoxContainer.new()
	av.add_theme_constant_override("separation", 6)
	av.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(av)
	mode_label = UIStyle.label("", 16, UIStyle.JADE)
	mode_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	av.add_child(mode_label)
	actions_box = HBoxContainer.new()
	actions_box.alignment = BoxContainer.ALIGNMENT_CENTER
	actions_box.add_theme_constant_override("separation", 6)
	av.add_child(actions_box)
	var defs := [["move", "Move", "1"], ["dash", "Dash", "2"], ["charge", "Charge", "3"], ["shoot", "Shoot", "4"], ["throw", "Throw", "5"], ["cast", "Cast", "6"]]
	for d in defs:
		var b := Button.new()
		b.text = "%s\n%s" % [d[1], d[2]]
		b.custom_minimum_size = Vector2(96, 70)
		b.add_theme_font_size_override("font_size", 18)
		var nm: String = d[0]
		b.pressed.connect(func(): _on_action_button(nm))
		actions_box.add_child(b)
		buttons[nm] = b
	end_btn = Button.new()
	end_btn.text = "End turn\n⏎"
	end_btn.custom_minimum_size = Vector2(140, 70)
	end_btn.add_theme_font_size_override("font_size", 18)
	end_btn.add_theme_color_override("font_color", UIStyle.GOLD)
	end_btn.pressed.connect(func(): end_turn.emit())
	actions_box.add_child(end_btn)
	hint_label = UIStyle.label("", 14, UIStyle.DIM)
	hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint_label.custom_minimum_size = Vector2(560, 0)
	av.add_child(hint_label)
	throw_menu = PopupMenu.new()
	throw_menu.id_pressed.connect(func(i): action.emit("throw", throw_menu.get_item_metadata(throw_menu.get_item_index(i))))
	root.add_child(throw_menu)
	cast_menu = PopupMenu.new()
	cast_menu.id_pressed.connect(func(i): action.emit("cast", cast_menu.get_item_metadata(cast_menu.get_item_index(i))))
	root.add_child(cast_menu)
	card = bar

func _process(_delta: float) -> void:
	if portrait_cam == null:
		return
	if portrait_target != null and is_instance_valid(portrait_target) and portrait_target.visible:
		var t := portrait_target.global_transform
		var head := t.origin + Vector3(0, 1.52, 0)
		var front := t.basis.z.normalized()
		front.y = 0
		front = front.normalized() if front.length() > 0.01 else Vector3(0, 0, 1)
		var side := front.cross(Vector3.UP).normalized()
		portrait_cam.global_position = head + front * 1.5 + side * 0.45 + Vector3(0, 0.12, 0)
		portrait_cam.look_at(head - Vector3(0, 0.08, 0), Vector3.UP)

# ------------------------------------------------------------------ dice tray

func _build_dice() -> void:
	dice_box = HBoxContainer.new()
	dice_box.anchor_left = 0.5
	dice_box.anchor_right = 0.5
	dice_box.anchor_top = 1.0
	dice_box.anchor_bottom = 1.0
	dice_box.offset_left = -400
	dice_box.offset_right = 400
	dice_box.offset_top = -380
	dice_box.offset_bottom = -212
	dice_box.alignment = BoxContainer.ALIGNMENT_CENTER
	dice_box.add_theme_constant_override("separation", 12)
	dice_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(dice_box)

func show_roll(label: String, value: int, need: int, ok: bool, sides_n: int, who: String, col: Color) -> void:
	## A die lands in the tray: what it was for, what it showed, what it needed.
	while dice_box.get_child_count() >= 5:
		var old := dice_box.get_child(0)
		dice_box.remove_child(old)
		old.queue_free()
	var holder := PanelContainer.new()
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var hb := StyleBoxFlat.new()
	hb.bg_color = Color(0.03, 0.025, 0.03, 0.82)
	hb.border_color = Color(col.r, col.g, col.b, 0.5)
	hb.border_width_top = 2
	hb.set_corner_radius_all(4)
	hb.content_margin_left = 12
	hb.content_margin_right = 12
	hb.content_margin_top = 6
	hb.content_margin_bottom = 6
	holder.add_theme_stylebox_override("panel", hb)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	holder.add_child(v)
	var top := UIStyle.label(label, 15, UIStyle.BONE, UIStyle.bold_font())
	top.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(top)
	var face := Label.new()
	face.custom_minimum_size = Vector2(62, 62)
	face.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	face.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	face.add_theme_font_override("font", UIStyle.bold_font())
	face.add_theme_font_size_override("font_size", 36)
	face.add_theme_color_override("font_color", Color(0.12, 0.08, 0.06))
	var good := Color(0.35, 0.85, 0.55)
	var bad := Color(0.9, 0.3, 0.22)
	var edge := good if ok else bad
	var verdict := ""
	if label == "Injury":
		edge = Color(0.95, 0.75, 0.3) if value <= 4 else bad
		verdict = "knocked down" if value <= 2 else ("stunned" if value <= 4 else "out of action")
	elif label.begins_with("Rout"):
		verdict = "needs %d or less" % need
	else:
		verdict = "needs %d+" % need
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.9, 0.86, 0.76)
	sb.border_color = edge
	sb.set_border_width_all(4)
	sb.set_corner_radius_all(8)
	sb.shadow_color = Color(edge.r, edge.g, edge.b, 0.55)
	sb.shadow_size = 6
	face.add_theme_stylebox_override("normal", sb)
	face.pivot_offset = Vector2(31, 31)
	v.add_child(face)
	var bot := UIStyle.label(verdict, 14, edge.lightened(0.2))
	bot.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(bot)
	var w := UIStyle.label(who, 12, UIStyle.DIM)
	w.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(w)
	dice_box.add_child(holder)
	# tumble: the face flickers through numbers, then lands with a pop
	face.scale = Vector2(0.5, 0.5)
	face.rotation = randf_range(-0.6, 0.6)
	var tw := holder.create_tween() # dies with the die if a newer roll pushes it out
	tw.tween_method(func(k: float): face.text = str(randi_range(1, sides_n)) if k < 0.95 else str(value), 0.0, 1.0, 0.22)
	tw.parallel().tween_property(face, "scale", Vector2(1.12, 1.12), 0.22).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.parallel().tween_property(face, "rotation", 0.0, 0.22)
	tw.tween_callback(func(): face.text = str(value))
	tw.tween_property(face, "scale", Vector2.ONE, 0.1)
	tw.tween_interval(2.6)
	tw.tween_property(holder, "modulate:a", 0.0, 0.6)
	tw.tween_callback(holder.queue_free)

func _on_action_button(nm: String) -> void:
	if nm == "throw":
		_popup(throw_menu, buttons["throw"])
	elif nm == "cast":
		_popup(cast_menu, buttons["cast"])
	else:
		action.emit(nm, "")

func _popup(m: PopupMenu, b: Button) -> void:
	if m.item_count == 0:
		return
	m.reset_size()
	var r := b.get_global_rect()
	m.position = Vector2i(int(r.position.x), int(r.position.y - m.size.y - 6))
	m.popup()

func open_menu(nm: String) -> void:
	_on_action_button(nm)

func _build_tip() -> void:
	tip = PanelContainer.new()
	tip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tip.add_theme_stylebox_override("panel", UIStyle.panel_box(0.94))
	tip_text = RichTextLabel.new()
	tip_text.bbcode_enabled = true
	tip_text.fit_content = true
	tip_text.scroll_active = false
	tip_text.autowrap_mode = TextServer.AUTOWRAP_OFF
	tip_text.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tip_text.add_theme_font_size_override("normal_font_size", 16)
	tip_text.add_theme_font_size_override("bold_font_size", 16)
	tip.add_child(tip_text)
	tip.visible = false
	root.add_child(tip)

func _build_toast() -> void:
	toast_label = UIStyle.title("", 54, UIStyle.BONE)
	toast_label.set_anchors_preset(Control.PRESET_CENTER)
	toast_label.anchor_left = 0.0
	toast_label.anchor_right = 1.0
	toast_label.anchor_top = 0.3
	toast_label.anchor_bottom = 0.3
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.modulate.a = 0.0
	toast_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_label.add_theme_constant_override("outline_size", 12)
	root.add_child(toast_label)

func _build_help() -> void:
	help_panel = PanelContainer.new()
	help_panel.anchor_left = 0.5
	help_panel.anchor_right = 0.5
	help_panel.anchor_top = 0.5
	help_panel.anchor_bottom = 0.5
	help_panel.offset_left = -380
	help_panel.offset_right = 380
	help_panel.offset_top = -300
	help_panel.offset_bottom = 300
	var v := VBoxContainer.new()
	help_panel.add_child(v)
	v.add_child(UIStyle.title("How to fight", 34, UIStyle.JADE))
	var t := RichTextLabel.new()
	t.bbcode_enabled = true
	t.size_flags_vertical = Control.SIZE_EXPAND_FILL
	t.add_theme_font_size_override("normal_font_size", 17)
	t.add_theme_font_size_override("bold_font_size", 17)
	t.text = """[b]Camera[/b]  It rides over the shoulder of the fighter you choose, and shows the enemy's turns from their side. V switches between that and an overhead view. Hold the right button to look around (to drag the map in the overhead view), the middle button to orbit. WASD or arrows pan, Q and E turn, R and F tilt, the mouse wheel zooms. Space takes you back to the active fighter.

[b]Your turn[/b]  Click one of your fighters (or press Tab). Each fighter has movement (their Move × 2.5 m) and two actions each turn. The glowing ground shows where they can still go (amber for a jump or drop); click inside it to walk there. Ladders, stairs, plank bridges, jumps and drops all cost movement. Jumps and drops call for an Initiative test, and a failed one means a fall.

[b]Fighting[/b]  Click an enemy you can see. Next to them you strike in close combat; within double your move you charge (only before moving); otherwise a fighter with a missile weapon shoots. Hover an enemy to see the odds. Dash (2) spends an action for another full move. Throw (5) and Cast (6) open a list of munitions or spells.

[b]Sight[/b]  Enemies stay hidden until one of your fighters can see them. Ghosts mark where an enemy was last seen. Walls and pillars block sight; half-hidden targets count as in cover.

[b]Winning[/b]  Fighters are knocked down, stunned or taken out of action. Once a quarter of a warband is out of action, its leader must pass a rout test each turn or the warband flees. If both stand at the end of round 12, the side holding more godshards wins.

Press F1 or Escape to close."""
	v.add_child(t)
	help_panel.visible = false
	root.add_child(help_panel)

func toggle_help() -> void:
	help_panel.visible = not help_panel.visible

# ------------------------------------------------------------------ updates

func set_turn(round_num: int, limit: int, wb_name: String, col: Color, player: bool, score: String) -> void:
	banner_title.text = ("Your turn" if player else wb_name) + "  ·  Round %d of %d" % [round_num, limit]
	banner_title.add_theme_color_override("font_color", UIStyle.BONE if player else col.lightened(0.35))
	banner_sub.text = score
	end_btn.disabled = not player

func toast(text: String, col := UIStyle.BONE) -> void:
	toast_label.text = text
	toast_label.add_theme_color_override("font_color", col)
	var tw := create_tween()
	tw.tween_property(toast_label, "modulate:a", 1.0, 0.25)
	tw.tween_interval(1.1)
	tw.tween_property(toast_label, "modulate:a", 0.0, 0.5)

func log_line(t: String) -> void:
	log_text.append_text(t + "\n")

func set_roster(units: Array, selected_id: int, st: BattleState) -> void:
	for c in roster_box.get_children():
		c.queue_free()
	for u in units:
		var b := Button.new()
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.custom_minimum_size = Vector2(230, 30)
		b.add_theme_font_size_override("font_size", 16)
		var state := ""
		match u.status:
			"down":
				state = "  (down)"
			"stunned":
				state = "  (stunned)"
			"ooa":
				state = "  (out)"
		var pips := ""
		if u.status == "ok":
			pips = "  " + "●".repeat(u.ap) + "○".repeat(max(0, 2 - u.ap))
		b.text = "%s%s%s" % [u.name, state, pips]
		if u.carrying > 0:
			b.text += "  ◆"
		if u.status == "ooa":
			b.disabled = true
		if u.id == selected_id:
			b.add_theme_color_override("font_color", UIStyle.JADE)
			b.add_theme_color_override("font_hover_color", UIStyle.JADE)
		elif not st.can_act(u) or (u.ap == 0 and u.mp < 0.5):
			b.add_theme_color_override("font_color", UIStyle.DIM)
		var id: int = u.id
		b.pressed.connect(func(): pick_unit.emit(id))
		roster_box.add_child(b)

func show_unit(u: BUnit, st: BattleState, fig: Node3D = null) -> void:
	if u == null:
		portrait_target = null
		portrait_box.modulate.a = 0.25
		card_title.text = ""
		card_sub.text = ""
		status_label.text = ""
		card_extra.text = ""
		ap_label.text = ""
		mp_bar.visible = false
		for c in wound_box.get_children():
			c.queue_free()
		for s in STATS:
			(card_stats.get_node("v_" + s) as Label).text = "-"
		wound_box.get_parent().visible = false
		card_title.text = "No fighter chosen"
		card_title.add_theme_color_override("font_color", UIStyle.DIM)
		card_sub.text = "Click one of your fighters, or press Tab."
		return
	wound_box.get_parent().visible = true
	if fig != null:
		portrait_target = fig
	portrait_box.modulate.a = 1.0
	var wbc: Array = st.sides[u.side]["wb"]["color"]
	var col := Color(wbc[0], wbc[1], wbc[2])
	(portrait_box.get_theme_stylebox("panel") as StyleBoxFlat).border_color = col.lightened(0.25)
	card_title.text = u.name
	card_title.add_theme_color_override("font_color", UIStyle.BONE if u.side == st.side else col.lightened(0.45))
	var role: String = {"leader": "Leader", "hero": "Hero", "henchman": "Henchman"}.get(u.role, "")
	card_sub.text = "%s  ·  %s  ·  %s" % [u.type_name, role, st.sides[u.side]["wb"]["name"]]
	for s in STATS:
		var l: Label = card_stats.get_node("v_" + s)
		var v := u.stat(s)
		l.text = str(v)
		l.add_theme_color_override("font_color", UIStyle.JADE if v > int(u.base.get(s, v)) else (UIStyle.BLOOD if v < int(u.base.get(s, v)) else UIStyle.BONE))
	for c in wound_box.get_children():
		c.queue_free()
	for i in range(u.stat("W")):
		var pip := Panel.new()
		pip.custom_minimum_size = Vector2(18, 18)
		var sb := StyleBoxFlat.new()
		var full := i < u.wounds
		sb.bg_color = Color(0.72, 0.08, 0.06) if full else Color(0.12, 0.05, 0.05)
		sb.border_color = Color(0.95, 0.35, 0.28, 0.9 if full else 0.35)
		sb.set_border_width_all(1)
		sb.set_corner_radius_all(9)
		sb.corner_radius_top_left = 2
		pip.add_theme_stylebox_override("panel", sb)
		wound_box.add_child(pip)
	var stx := ""
	match u.status:
		"down":
			stx = "[color=#f0c060]Knocked down[/color]: gets up next turn with half movement."
		"stunned":
			stx = "[color=#f09050]Stunned[/color]: helpless; a blow now takes them out of action."
		"ooa":
			stx = "[color=#e06a50]Out of action.[/color]"
	if u.carrying > 0:
		stx += ("  " if stx != "" else "") + "[color=#5fe0c0]Carrying %d godshard%s[/color]" % [u.carrying, "" if u.carrying == 1 else "s"]
	status_label.text = stx
	mp_bar.max_value = max(u.mp_full, 0.1)
	mp_bar.value = u.mp
	mp_bar.visible = u.side == st.side
	ap_label.text = "%.1f m   Actions %s" % [u.mp, "●".repeat(u.ap) + "○".repeat(max(0, 2 - u.ap))] if u.side == st.side else ""
	card_extra.text = _kit_line(u)

func _kit_line(u: BUnit) -> String:
	var gear: Array = []
	for g in u.gear:
		gear.append(GameData.item_name(g))
	var t := "[b]Gear[/b]  " + ", ".join(gear)
	t += "   [b]Save[/b]  %s" % ("%d+" % u.armour_save() if u.armour_save() <= 6 else "none")
	if not u.skills.is_empty():
		var sk: Array = []
		for s in u.skills:
			sk.append(GameData.skill_name(s))
		t += "\n[b]Skills[/b]  " + ", ".join(sk)
	if u.warren != "":
		t += "\n[b]Warren[/b]  " + String(GameData.rules()["warrens"][u.warren]["name"])
	if u.has_munitions():
		var mn: Array = []
		for m in u.munitions:
			mn.append("%s ×%d" % [GameData.munition(m)["name"], u.munitions[m]])
		t += "\n[b]Munitions[/b]  " + ", ".join(mn)
	return t

func _unit_details(u: BUnit) -> String:
	var lines: Array = []
	var st := ""
	match u.status:
		"down":
			st = "[color=#f0c060]Knocked down[/color]: gets up next turn with half movement."
		"stunned":
			st = "[color=#f09050]Stunned[/color]: helpless; a blow now takes them out of action."
		"ooa":
			st = "[color=#e06a50]Out of action.[/color]"
	if st != "":
		lines.append(st)
	var gear: Array = []
	for g in u.gear:
		gear.append(GameData.item_name(g))
	lines.append("[b]Gear[/b]  " + ", ".join(gear))
	if not u.skills.is_empty():
		var sk: Array = []
		for s in u.skills:
			sk.append(GameData.skill_name(s))
		lines.append("[b]Skills[/b]  " + ", ".join(sk))
	if u.warren != "":
		var spn: Array = []
		for s in u.spells:
			spn.append(GameData.spell(s)["name"])
		lines.append("[b]Warren[/b]  %s: %s" % [GameData.rules()["warrens"][u.warren]["name"], ", ".join(spn)])
	if u.has_munitions():
		var mn: Array = []
		for m in u.munitions:
			mn.append("%s ×%d" % [GameData.munition(m)["name"], u.munitions[m]])
		lines.append("[b]Munitions[/b]  " + ", ".join(mn))
	lines.append("[b]Armour save[/b]  %s" % ("%d+" % u.armour_save() if u.armour_save() <= 6 else "none"))
	if u.carrying > 0:
		lines.append("[color=#5fe0c0]Carrying %d godshard%s[/color]" % [u.carrying, "" if u.carrying == 1 else "s"])
	var fx: Array = []
	for f in u.fx:
		fx.append(str(f["kind"]))
	if not fx.is_empty():
		lines.append("[b]Under[/b]  " + ", ".join(fx))
	return "\n".join(lines)

func show_target(u: BUnit, st: BattleState, odds: String) -> void:
	if u == null:
		target_card.visible = false
		return
	target_card.visible = true
	target_title.text = u.name
	target_title.add_theme_color_override("font_color", Color(st.sides[u.side]["wb"]["color"][0], st.sides[u.side]["wb"]["color"][1], st.sides[u.side]["wb"]["color"][2]).lightened(0.45))
	var t := "%s · %s\n[b]%s[/b]   Wounds %d/%d\n" % [u.type_name, st.sides[u.side]["wb"]["name"], u.summary_stats(), u.wounds, u.stat("W")]
	t += _unit_details(u)
	if odds != "":
		t += "\n\n" + odds
	target_body.text = t

func set_actions(enabled: Dictionary, mode: String, hint: String) -> void:
	for k in buttons:
		var b: Button = buttons[k]
		b.disabled = not enabled.get(k, false)
		b.add_theme_color_override("font_color", UIStyle.JADE if k == mode else UIStyle.BONE)
	mode_label.text = {"move": "", "shoot": "Choose a target to shoot", "charge": "Choose an enemy to charge"}.get(mode, "")
	if mode.begins_with("throw:"):
		mode_label.text = "Throw %s: choose where it lands" % GameData.munition(mode.substr(6))["name"]
	elif mode.begins_with("cast:"):
		mode_label.text = "Cast %s: choose a target" % GameData.spell(mode.substr(5))["name"]
	hint_label.text = hint

func fill_menus(u: BUnit) -> void:
	throw_menu.clear()
	cast_menu.clear()
	if u == null:
		return
	var i := 0
	for m in u.munitions:
		var md := GameData.munition(m)
		throw_menu.add_item("%s ×%d  —  %s" % [md["name"], u.munitions[m], md["desc"]], i)
		throw_menu.set_item_metadata(i, m)
		throw_menu.set_item_disabled(i, int(u.munitions[m]) <= 0)
		i += 1
	i = 0
	for s in u.spells:
		var sd := GameData.spell(s)
		cast_menu.add_item("%s (%d+)  —  %s" % [sd["name"], sd["diff"], sd["desc"]], i)
		cast_menu.set_item_metadata(i, s)
		i += 1

func show_tip(text: String, at: Vector2) -> void:
	if text == "":
		tip.visible = false
		return
	tip_text.text = text
	tip.visible = true
	tip.reset_size()
	var vs := root.get_viewport_rect().size
	var p := at + Vector2(22, 18)
	if p.x + tip.size.x > vs.x - 8:
		p.x = at.x - tip.size.x - 16
	if p.y + tip.size.y > vs.y - 8:
		p.y = at.y - tip.size.y - 12
	tip.position = p

func show_result(title: String, sub: String, body: String, col: Color, choices: Array = [["again", "Fight again"], ["menu", "Main menu"], ["quit", "Quit"]]) -> void:
	bar.visible = false
	dice_box.visible = false
	log_panel.visible = false
	target_card.visible = false
	tip.visible = false
	if result_panel != null:
		result_panel.queue_free()
	result_panel = PanelContainer.new()
	result_panel.anchor_left = 0.5
	result_panel.anchor_right = 0.5
	result_panel.anchor_top = 0.5
	result_panel.anchor_bottom = 0.5
	result_panel.offset_left = -360
	result_panel.offset_right = 360
	result_panel.offset_top = -240
	result_panel.offset_bottom = 240
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	result_panel.add_child(v)
	var t := UIStyle.title(title, 56, col)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(t)
	var s := UIStyle.label(sub, 20, UIStyle.BONE)
	s.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	s.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(s)
	var b := RichTextLabel.new()
	b.bbcode_enabled = true
	b.size_flags_vertical = Control.SIZE_EXPAND_FILL
	b.add_theme_font_size_override("normal_font_size", 17)
	b.add_theme_font_size_override("bold_font_size", 17)
	b.text = body
	v.add_child(b)
	var h := HBoxContainer.new()
	h.alignment = BoxContainer.ALIGNMENT_CENTER
	h.add_theme_constant_override("separation", 12)
	v.add_child(h)
	for pair in choices:
		var bt := Button.new()
		bt.text = pair[1]
		bt.custom_minimum_size = Vector2(150, 44)
		var nm: String = pair[0]
		bt.pressed.connect(func(): result_choice.emit(nm))
		h.add_child(bt)
	root.add_child(result_panel)
