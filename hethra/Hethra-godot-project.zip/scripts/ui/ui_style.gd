class_name UIStyle
extends RefCounted
## Colours, fonts and panel styles for the interface: cold ash-grey glass
## with a jade accent taken from the godshards.

const BONE := Color(0.89, 0.86, 0.79)
const DIM := Color(0.6, 0.6, 0.6)
const JADE := Color(0.37, 0.9, 0.77)
const BLOOD := Color(0.9, 0.36, 0.3)
const GOLD := Color(0.95, 0.78, 0.42)
const PANEL := Color(0.055, 0.062, 0.07, 0.86)

static var _theme: Theme

static func title_font() -> Font:
	return load("res://fonts/GrenzeGotisch.ttf")

static func body_font() -> Font:
	return load("res://fonts/AlegreyaSans-Regular.ttf")

static func bold_font() -> Font:
	return load("res://fonts/AlegreyaSans-Bold.ttf")

static func panel_box(alpha := 0.86, border := JADE) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(PANEL.r, PANEL.g, PANEL.b, alpha)
	sb.border_color = Color(border.r, border.g, border.b, 0.35)
	sb.set_border_width_all(1)
	sb.border_width_top = 2
	sb.set_corner_radius_all(3)
	sb.content_margin_left = 14
	sb.content_margin_right = 14
	sb.content_margin_top = 10
	sb.content_margin_bottom = 10
	sb.shadow_color = Color(0, 0, 0, 0.45)
	sb.shadow_size = 8
	return sb

static func theme() -> Theme:
	if _theme != null:
		return _theme
	var t := Theme.new()
	t.default_font = body_font()
	t.default_font_size = 18
	t.set_color("font_color", "Label", BONE)
	t.set_color("default_color", "RichTextLabel", BONE)
	t.set_font("bold_font", "RichTextLabel", bold_font())
	t.set_stylebox("panel", "PanelContainer", panel_box())
	t.set_stylebox("panel", "Panel", panel_box())
	# buttons: dark slate with jade edge, brighter on hover
	var bn := StyleBoxFlat.new()
	bn.bg_color = Color(0.11, 0.125, 0.135, 0.95)
	bn.border_color = Color(JADE.r, JADE.g, JADE.b, 0.35)
	bn.set_border_width_all(1)
	bn.set_corner_radius_all(3)
	bn.content_margin_left = 14
	bn.content_margin_right = 14
	bn.content_margin_top = 7
	bn.content_margin_bottom = 7
	var bh := bn.duplicate()
	bh.bg_color = Color(0.16, 0.2, 0.2, 0.98)
	bh.border_color = JADE
	var bp := bn.duplicate()
	bp.bg_color = Color(0.2, 0.33, 0.3, 1.0)
	bp.border_color = JADE
	var bd := bn.duplicate()
	bd.bg_color = Color(0.08, 0.085, 0.09, 0.8)
	bd.border_color = Color(0.3, 0.3, 0.3, 0.3)
	t.set_stylebox("normal", "Button", bn)
	t.set_stylebox("hover", "Button", bh)
	t.set_stylebox("pressed", "Button", bp)
	t.set_stylebox("hover_pressed", "Button", bp)
	t.set_stylebox("disabled", "Button", bd)
	t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	t.set_color("font_color", "Button", BONE)
	t.set_color("font_hover_color", "Button", Color(1, 1, 1))
	t.set_color("font_pressed_color", "Button", JADE)
	t.set_color("font_disabled_color", "Button", Color(0.42, 0.42, 0.42))
	t.set_font_size("font_size", "Button", 18)
	# progress bars for movement
	var pb_bg := StyleBoxFlat.new()
	pb_bg.bg_color = Color(0.1, 0.1, 0.11)
	pb_bg.set_corner_radius_all(2)
	var pb_fg := StyleBoxFlat.new()
	pb_fg.bg_color = JADE.darkened(0.25)
	pb_fg.set_corner_radius_all(2)
	t.set_stylebox("background", "ProgressBar", pb_bg)
	t.set_stylebox("fill", "ProgressBar", pb_fg)
	t.set_color("font_color", "ProgressBar", BONE)
	t.set_font_size("font_size", "ProgressBar", 14)
	var pm := panel_box(0.97)
	t.set_stylebox("panel", "PopupMenu", pm)
	t.set_color("font_color", "PopupMenu", BONE)
	t.set_color("font_hover_color", "PopupMenu", JADE)
	var ph := StyleBoxFlat.new()
	ph.bg_color = Color(0.18, 0.24, 0.23)
	t.set_stylebox("hover", "PopupMenu", ph)
	t.set_font_size("font_size", "PopupMenu", 18)
	var tt := panel_box(0.95)
	t.set_stylebox("panel", "TooltipPanel", tt)
	t.set_color("font_color", "TooltipLabel", BONE)
	_theme = t
	return t

static func label(text: String, size := 18, color := BONE, font: Font = null) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	if font != null:
		l.add_theme_font_override("font", font)
	return l

static func title(text: String, size := 34, color := BONE) -> Label:
	var l := label(text, size, color, title_font())
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	l.add_theme_constant_override("outline_size", 6)
	return l

static func col_hex(c: Color) -> String:
	return c.to_html(false)
