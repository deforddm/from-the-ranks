extends Node
## Autoload: keeps an installed copy of Hethra current.
##
## On launch the Windows build reads version.json from the download page. If a
## newer version is listed it downloads that zip, checks its SHA-256 and writes
## the new exe beside the running one as Hethra-update.exe. A running exe can't
## be overwritten (Godot holds it open for its data), so the new exe finishes
## the job itself: started with --finish-update, it waits for the old one to
## close, copies itself over Hethra.exe and starts it. On the title screen that
## happens at once; mid-battle it waits for the next launch, when Hethra.exe
## sees the update waiting and hands over to it.
##
## Off in the editor, in tests and renders, on other systems, and with
## --no-update. --update-dry=DIR runs the check and download on any system but
## writes the new files into DIR instead of installing; --pretend-version=X
## makes it believe the running version is X; --update-info=FILE (dry only)
## reads version.json from a file.

signal status_changed(text: String)

const INFO_URLS := ["https://playfromtheranks.com/hethra/version.json",
	"https://raw.githubusercontent.com/deforddm/from-the-ranks/main/hethra/version.json"]
const URL_START := "https://raw.githubusercontent.com/deforddm/from-the-ranks/"
const URL_END := "/hethra/Hethra-windows.zip"
const ZIP_TMP := "user://update.zip"
const PENDING := "user://update_pending.cfg"
const UPDATE_EXE := "Hethra-update.exe"

var state := "idle"     # idle, checking, current, available, downloading, unpacking, ready, failed
var status := ""
var info: Dictionary = {}
var dry_dir := ""
var info_file := ""
var running_version := ""
var _http: HTTPRequest

func _ready() -> void:
	running_version = Game.VERSION
	var off := false
	var finish := false
	for a in OS.get_cmdline_user_args():
		if a == "--no-update":
			off = true
		elif a == "--finish-update":
			finish = true
		elif a.begins_with("--update-dry="):
			dry_dir = a.substr(13)
		elif a.begins_with("--update-info="):
			info_file = a.substr(14)
		elif a.begins_with("--pretend-version="):
			running_version = a.substr(18)
	var installed := OS.has_feature("windows") and OS.has_feature("template")
	if installed and finish:
		Game.mode = "updating"
		_finish.call_deferred()
		return
	if installed and _hand_over():
		return
	if off:
		return
	if dry_dir == "":
		if not installed:
			return
		if Game.selftest or Game.autoplay or Game.shots_dir != "" or Game.camp_shots != "" or Game.screenshot_path != "":
			return
	_http = HTTPRequest.new()
	_http.max_redirects = 8
	_http.timeout = 30.0
	add_child(_http)
	if dry_dir != "":
		_test_proxy()
	check.call_deferred()

func _test_proxy() -> void:
	## Dry runs only: go out through the build machine's proxy, if it has one.
	var px := OS.get_environment("HTTPS_PROXY")
	if px == "":
		return
	var hp := px.split("://")[-1].split("@")[-1].trim_suffix("/").split(":")
	_http.set_https_proxy(hp[0], int(hp[1]) if hp.size() > 1 else 80)
	var ca := X509Certificate.new()
	if FileAccess.file_exists("/root/.ccr/ca-bundle.crt") and ca.load("/root/.ccr/ca-bundle.crt") == OK:
		_http.set_tls_options(TLSOptions.client(ca))

func _say(st: String, text: String) -> void:
	state = st
	status = text
	status_changed.emit(text)
	if dry_dir != "":
		print("update: ", st, ": ", text)

static func newer(a: String, b: String) -> bool:
	## True when version a is later than version b ("0.16" > "0.15", "1.2" > "0.99").
	var pa := a.split(".")
	var pb := b.split(".")
	for i in range(maxi(pa.size(), pb.size())):
		var x := int(pa[i]) if i < pa.size() else 0
		var y := int(pb[i]) if i < pb.size() else 0
		if x != y:
			return x > y
	return false

# ---------------------------------------------------------------- checking

func check() -> void:
	_say("checking", "Checking for a new version…")
	var res: Array = []
	if dry_dir != "" and info_file != "":
		res = [HTTPRequest.RESULT_SUCCESS, 200, [], FileAccess.get_file_as_bytes(info_file)]
	for u in ([] if not res.is_empty() else INFO_URLS):
		if _http.request(str(u) + "?t=%d" % int(Time.get_unix_time_from_system())) != OK:
			continue
		res = await _http.request_completed
		if int(res[0]) == HTTPRequest.RESULT_SUCCESS and int(res[1]) == 200:
			break
		if dry_dir != "":
			print("update: ", u, " gave result %d, http %d" % [int(res[0]), int(res[1])])
		res = []
	if res.is_empty():
		_say("failed", "")
		return
	var parsed: Variant = JSON.parse_string((res[3] as PackedByteArray).get_string_from_utf8())
	if typeof(parsed) != TYPE_DICTIONARY or not parsed.has("version") or not parsed.has("url"):
		_say("failed", "")
		return
	info = parsed
	var v := str(info["version"])
	var url := str(info["url"])
	# only ever fetch our own builds, from the one place they are published
	if not url.begins_with(URL_START) or not url.ends_with(URL_END) or url.contains(".."):
		_say("failed", "")
		return
	if not newer(v, running_version):
		_say("current", "")
		return
	if not bool(Game.settings.get("auto_update", true)) and dry_dir == "":
		_say("available", "Version %s is out. Update in Settings." % v)
		return
	download()

func download() -> void:
	var v := str(info["version"])
	_say("downloading", "Downloading version %s…" % v)
	_http.download_file = ZIP_TMP
	_http.timeout = 0.0
	if _http.request(str(info["url"])) != OK:
		_fail(v)
		return
	_progress(v)
	var res: Array = await _http.request_completed
	state = "unpacking"
	_http.download_file = ""
	if int(res[0]) != HTTPRequest.RESULT_SUCCESS or int(res[1]) != 200:
		_fail(v)
		return
	_unpack(v)

func _progress(v: String) -> void:
	## Report the download's progress twice a second until it ends.
	while state == "downloading":
		await get_tree().create_timer(0.5).timeout
		var total := _http.get_body_size()
		if state == "downloading" and total > 0:
			_say("downloading", "Downloading version %s…  %d%%" % [v, int(100.0 * _http.get_downloaded_bytes() / total)])

func _fail(v: String) -> void:
	DirAccess.remove_absolute(ProjectSettings.globalize_path(ZIP_TMP))
	_say("failed", "Couldn't fetch version %s. Get it from the download page." % v)

func _unpack(v: String) -> void:
	var zip_path := ProjectSettings.globalize_path(ZIP_TMP)
	if info.has("zip_sha256") and FileAccess.get_sha256(zip_path) != str(info["zip_sha256"]):
		_fail(v)
		return
	var zr := ZIPReader.new()
	if zr.open(zip_path) != OK:
		_fail(v)
		return
	var exe := zr.read_file("Hethra/Hethra.exe")
	var extras := {}
	for f in ["README.md", "CREDITS.md"]:
		if zr.file_exists("Hethra/" + f):
			extras[f] = zr.read_file("Hethra/" + f)
	zr.close()
	DirAccess.remove_absolute(zip_path)
	if exe.size() < 1000000:
		_fail(v)
		return
	var dir := dry_dir if dry_dir != "" else OS.get_executable_path().get_base_dir()
	if dry_dir != "":
		DirAccess.make_dir_recursive_absolute(dir)
	var fresh := dir.path_join("Hethra.exe" if dry_dir != "" else UPDATE_EXE)
	var fa := FileAccess.open(fresh, FileAccess.WRITE)
	if fa == null:
		_say("failed", "Version %s is out, but this folder can't be written to. Get it from the download page." % v)
		return
	fa.store_buffer(exe)
	fa.close()
	for f in extras:
		var fe := FileAccess.open(dir.path_join(f), FileAccess.WRITE)
		if fe != null:
			fe.store_buffer(extras[f])
			fe.close()
	if dry_dir != "":
		_say("ready", "Version %s unpacked into %s (%d bytes)." % [v, dir, exe.size()])
		return
	var cf := ConfigFile.new()
	cf.set_value("update", "version", v)
	cf.save(PENDING)
	if Game.mode == "menu":
		_say("ready", "Version %s is in. Starting it…" % v)
		await get_tree().create_timer(1.0).timeout
		OS.create_process(fresh, ["--finish-update"])
		get_tree().quit()
	else:
		_say("ready", "Version %s is ready. It starts the next time you open Hethra." % v)

# ---------------------------------------------------------------- installing

func _pending_version() -> String:
	var cf := ConfigFile.new()
	if cf.load(PENDING) != OK:
		return ""
	return str(cf.get_value("update", "version", ""))

func _hand_over() -> bool:
	## Hethra.exe starting: if a newer update is waiting beside us, let it
	## install itself; otherwise tidy away what an earlier update left.
	if OS.get_executable_path().get_file() == UPDATE_EXE:
		return false
	var upd := OS.get_executable_path().get_base_dir().path_join(UPDATE_EXE)
	var pv := _pending_version()
	if FileAccess.file_exists(upd) and pv != "" and newer(pv, Game.VERSION):
		Game.mode = "updating"
		OS.create_process(upd, ["--finish-update"])
		get_tree().quit.call_deferred()
		return true
	if FileAccess.file_exists(upd):
		DirAccess.remove_absolute(upd)
	if pv != "":
		DirAccess.remove_absolute(ProjectSettings.globalize_path(PENDING))
	return false

func _finish() -> void:
	## Running as Hethra-update.exe: copy ourselves over Hethra.exe once the old
	## copy has closed, then start it and step aside.
	DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_MINIMIZED)
	var me := OS.get_executable_path()
	var target := me.get_base_dir().path_join("Hethra.exe")
	for i in range(120):
		await get_tree().create_timer(0.5).timeout
		if DirAccess.copy_absolute(me, target) == OK:
			break
	# whether or not it took, stop handing over, or a stuck copy would loop
	DirAccess.remove_absolute(ProjectSettings.globalize_path(PENDING))
	OS.create_process(target, [])
	get_tree().quit()
