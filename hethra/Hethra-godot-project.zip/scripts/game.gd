extends Node
## Autoload: settings carried between the menu and the battle.

var player_warband := "marines"
var enemy_warband := "chained"
var map_id := "hethra_square"
var scenario := "shards"
var weather := "random"          # random, still, rain or fog
var seed_value := 0
var mode := "menu"            # menu, battle, camp, aftermath
var autoplay := false         # both sides AI (testing)
var screenshot_path := ""
var shot_dialog := ""           # with --screenshot: open this title-screen dialog first (skirmish)
var quit_after_battle := false
var shots_dir := ""            # render README screenshots into this folder, then quit
var anim_speed := 1.0
var selftest := false          # drive the player's side through the real UI code paths
# campaign play
var campaign: Campaign = null
var battle_rosters: Array = [[], []]   # campaign rosters for the coming battle
var campaign_enemy_rating := 0
var home_ground := false              # --home: fight on home ground (screenshots and tests)
var camp_shots := ""                   # render camp-screen screenshots here, then quit
var graphics := {"fog": true, "ssao": true, "ssil": false, "glow": true, "shadows": true}
# player settings, kept in user://settings.cfg
var settings := {"vol_master": 0.85, "vol_music": 0.6, "vol_effects": 0.85, "vol_ambience": 0.6,
	"graphics_high": true, "fullscreen": true, "cam_speed": 1.0, "anim_speed": 1.0, "auto_update": true, "cinematics": true}
const VERSION := "0.26"
const SETTINGS_PATH := "user://settings.cfg"

func load_settings() -> void:
	var cf := ConfigFile.new()
	if cf.load(SETTINGS_PATH) == OK:
		for k in settings:
			settings[k] = cf.get_value("settings", k, settings[k])
	_apply_graphics()
	anim_speed = float(settings["anim_speed"])

func save_settings() -> void:
	var cf := ConfigFile.new()
	for k in settings:
		cf.set_value("settings", k, settings[k])
	cf.save(SETTINGS_PATH)

func apply_window() -> void:
	if DisplayServer.get_name() == "headless" or shots_dir != "" or camp_shots != "":
		return
	if settings["fullscreen"]:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_MAXIMIZED)

func _apply_graphics() -> void:
	var high: bool = settings["graphics_high"]
	graphics = {"fog": high, "ssao": high, "ssil": false, "glow": true, "shadows": true}
	Figure.hi_detail = high

func _ready() -> void:
	load_settings()
	for a in OS.get_cmdline_user_args():
		if a == "--autoplay":
			autoplay = true
			mode = "battle"
			quit_after_battle = true
		elif a.begins_with("--screenshot="):
			screenshot_path = a.substr(13)
		elif a.begins_with("--dialog="):
			shot_dialog = a.substr(9)
		elif a.begins_with("--seed="):
			seed_value = int(a.substr(7))
		elif a.begins_with("--player="):
			player_warband = a.substr(9)
		elif a.begins_with("--enemy="):
			enemy_warband = a.substr(8)
		elif a.begins_with("--map="):
			map_id = a.substr(6)
		elif a.begins_with("--scenario="):
			scenario = a.substr(11)
		elif a.begins_with("--weather="):
			weather = a.substr(10)
		elif a == "--battle":
			mode = "battle"
		elif a.begins_with("--shots="):
			shots_dir = a.substr(8)
			autoplay = true
			mode = "battle"
		elif a.begins_with("--speed="):
			anim_speed = float(a.substr(8))
		elif a == "--selftest":
			selftest = true
			mode = "battle"
			quit_after_battle = true
		elif a.begins_with("--camp-shots="):
			camp_shots = a.substr(13)
			mode = "camp"
		elif a == "--home":
			home_ground = true
		elif a == "--low":
			graphics = {"fog": false, "ssao": false, "ssil": false, "glow": true, "shadows": true}
	apply_window()
