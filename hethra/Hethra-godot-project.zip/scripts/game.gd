extends Node
## Autoload: settings carried between the menu and the battle.

var player_warband := "marines"
var enemy_warband := "chained"
var map_id := "hethra_square"
var seed_value := 0
var mode := "menu"            # menu, battle
var autoplay := false         # both sides AI (testing)
var screenshot_path := ""
var quit_after_battle := false
var shots_dir := ""            # render README screenshots into this folder, then quit
var anim_speed := 1.0
var selftest := false          # drive the player's side through the real UI code paths
var graphics := {"fog": true, "ssao": true, "ssil": false, "glow": true, "shadows": true}

func _ready() -> void:
	for a in OS.get_cmdline_user_args():
		if a == "--autoplay":
			autoplay = true
			mode = "battle"
			quit_after_battle = true
		elif a.begins_with("--screenshot="):
			screenshot_path = a.substr(13)
		elif a.begins_with("--seed="):
			seed_value = int(a.substr(7))
		elif a.begins_with("--player="):
			player_warband = a.substr(9)
		elif a.begins_with("--enemy="):
			enemy_warband = a.substr(8)
		elif a == "--battle":
			mode = "battle"
		elif a.begins_with("--shots="):
			shots_dir = a.substr(8)
			autoplay = true
			mode = "battle"
		elif a.begins_with("--speed="):
			anim_speed = float(a.substr(8))
		elif a == "--selftest":
			selftest = true
			mode = "battle"
			quit_after_battle = true
		elif a == "--low":
			graphics = {"fog": false, "ssao": false, "ssil": false, "glow": true, "shadows": true}
