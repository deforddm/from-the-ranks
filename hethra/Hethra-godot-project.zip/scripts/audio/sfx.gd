extends Node
## Autoload "Sfx": every sound in the game. The sounds and music are made by
## tools/make_audio.py (synthesized, no recordings) and live in res://audio.
##   Sfx.play("clash_*", position)   a random variant, placed in the 3D world
##   Sfx.play("ui_click")            a flat sound for the interface
##   Sfx.music("music_battle")       crossfades to a looping track ("" for silence)
##   Sfx.ambience("amb_ruins")       the looping bed of wind and fire
##   Sfx.sting("sting_victory")      a one-off phrase that ducks the music

const BUSES := ["Music", "Effects", "Ambience"]

var streams := {}
var variants := {}
var _last := {}
var pool3d: Array = []
var pool2d: Array = []
var music_a: AudioStreamPlayer
var music_b: AudioStreamPlayer
var amb_a: AudioStreamPlayer
var amb_b: AudioStreamPlayer
var sting_player: AudioStreamPlayer
var cur_music := ""
var cur_amb := ""
var enabled := true
var played := {}   # counts, for the sound test

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	enabled = DisplayServer.get_name() != "headless" or OS.get_environment("HETHRA_SFX_TEST") == "1"
	for b in BUSES:
		if AudioServer.get_bus_index(b) < 0:
			var idx := AudioServer.bus_count
			AudioServer.add_bus(idx)
			AudioServer.set_bus_name(idx, b)
			AudioServer.set_bus_send(idx, "Master")
	# a touch of stone room on the effects, so blows ring off the walls
	var fx_bus := AudioServer.get_bus_index("Effects")
	if AudioServer.get_bus_effect_count(fx_bus) == 0:
		var rv := AudioEffectReverb.new()
		rv.room_size = 0.55
		rv.damping = 0.6
		rv.wet = 0.12
		rv.dry = 1.0
		AudioServer.add_bus_effect(fx_bus, rv)
		var lim := AudioEffectLimiter.new()
		AudioServer.add_bus_effect(fx_bus, lim)
	music_a = _player("Music")
	music_b = _player("Music")
	amb_a = _player("Ambience")
	amb_b = _player("Ambience")
	sting_player = _player("Music")
	for i in range(16):
		var p := AudioStreamPlayer3D.new()
		p.bus = "Effects"
		p.unit_size = 9.0
		p.max_distance = 120.0
		p.attenuation_filter_cutoff_hz = 6000.0
		p.attenuation_filter_db = -12.0
		p.panning_strength = 0.8
		add_child(p)
		pool3d.append(p)
	for i in range(8):
		pool2d.append(_player("Effects"))
	apply_volumes()
	get_tree().node_added.connect(_on_node_added)

func _player(bus: String) -> AudioStreamPlayer:
	var p := AudioStreamPlayer.new()
	p.bus = bus
	add_child(p)
	return p

func apply_volumes() -> void:
	var s: Dictionary = Game.settings
	_set_bus("Master", float(s.get("vol_master", 0.85)))
	_set_bus("Music", float(s.get("vol_music", 0.6)))
	_set_bus("Effects", float(s.get("vol_effects", 0.85)))
	_set_bus("Ambience", float(s.get("vol_ambience", 0.6)))

func _set_bus(nm: String, lin: float) -> void:
	var idx := AudioServer.get_bus_index(nm)
	if idx < 0:
		return
	AudioServer.set_bus_volume_db(idx, linear_to_db(maxf(lin, 0.0001)))
	AudioServer.set_bus_mute(idx, lin <= 0.001)

# ------------------------------------------------------------------ streams

func _stream(nm: String) -> AudioStream:
	if streams.has(nm):
		return streams[nm]
	var path := "res://audio/%s.ogg" % nm
	var s: AudioStream = null
	if ResourceLoader.exists(path):
		s = load(path)
	streams[nm] = s
	return s

func _resolve(nm: String) -> String:
	## "clash_*" picks one of clash_0, clash_1, ... at random.
	if not nm.ends_with("*"):
		return nm
	var stem := nm.substr(0, nm.length() - 1)
	if not variants.has(stem):
		var n := 0
		while ResourceLoader.exists("res://audio/%s%d.ogg" % [stem, n]):
			n += 1
		variants[stem] = n
	var count: int = variants[stem]
	if count == 0:
		return ""
	return "%s%d" % [stem, randi() % count]

# ------------------------------------------------------------------ playing

func play(nm: String, at = null, db := 0.0, pitch_var := 0.06) -> void:
	if not enabled:
		return
	var real := _resolve(nm)
	if real == "":
		return
	var now := Time.get_ticks_msec()
	if now - int(_last.get(nm, -1000)) < 45:
		return  # the same sound twice in a heartbeat is just louder noise
	_last[nm] = now
	var s := _stream(real)
	if s == null:
		return
	played[nm] = int(played.get(nm, 0)) + 1
	var pitch := 1.0 + randf_range(-pitch_var, pitch_var)
	if at is Vector3:
		var p: AudioStreamPlayer3D = _free(pool3d)
		p.global_position = at
		p.stream = s
		p.volume_db = db
		p.pitch_scale = pitch
		p.play()
	else:
		var q: AudioStreamPlayer = _free(pool2d)
		q.stream = s
		q.volume_db = db
		q.pitch_scale = pitch
		q.play()

func _free(pool: Array) -> Node:
	for p in pool:
		if not p.playing:
			return p
	# all busy: take the one that started longest ago
	var best = pool[0]
	var best_pos := -1.0
	for p in pool:
		var pos: float = p.get_playback_position()
		if pos > best_pos:
			best_pos = pos
			best = p
	return best

func music(nm: String, fade := 2.5) -> void:
	if nm == cur_music:
		return
	cur_music = nm
	_crossfade(music_a, music_b, nm, fade, 0.0)
	var t := music_a
	music_a = music_b
	music_b = t

func ambience(nm: String, fade := 2.0, db := 0.0) -> void:
	if nm == cur_amb:
		return
	cur_amb = nm
	_crossfade(amb_a, amb_b, nm, fade, db)
	var t := amb_a
	amb_a = amb_b
	amb_b = t

func _crossfade(old: AudioStreamPlayer, new: AudioStreamPlayer, nm: String, fade: float, db: float) -> void:
	if not enabled:
		return
	if old.playing:
		var tw := create_tween()
		tw.tween_property(old, "volume_db", -60.0, fade)
		tw.tween_callback(old.stop)
	if nm == "":
		return
	var s := _stream(nm)
	if s == null:
		return
	if s is AudioStreamOggVorbis:
		(s as AudioStreamOggVorbis).loop = true
	new.stream = s
	new.volume_db = -50.0
	new.play()
	var tw2 := create_tween()
	tw2.tween_property(new, "volume_db", db, fade)

func sting(nm: String) -> void:
	## A short phrase over the music: the music dips under it and comes back.
	if not enabled:
		return
	var s := _stream(nm)
	if s == null:
		return
	sting_player.stream = s
	sting_player.volume_db = 0.0
	sting_player.play()
	for p in [music_a, music_b]:
		if p.playing:
			var tw := create_tween()
			tw.tween_property(p, "volume_db", -18.0, 0.6)
			tw.tween_interval(5.5)
			tw.tween_property(p, "volume_db", 0.0, 3.0)

func stop_all(fade := 1.0) -> void:
	music("", fade)
	ambience("", fade)

func _exit_tree() -> void:
	if OS.get_environment("HETHRA_SFX_TEST") == "1":
		print("SOUNDS PLAYED: ", played, "  music: ", cur_music, "  ambience: ", cur_amb)

# ------------------------------------------------------------------ the interface

func _on_node_added(n: Node) -> void:
	## Every button in the game clicks, and ticks softly under the mouse.
	if n is BaseButton:
		var b := n as BaseButton
		b.pressed.connect(func(): play("ui_click", null, -4.0, 0.03))
		b.mouse_entered.connect(func():
			if not b.disabled:
				play("ui_hover", null, -10.0, 0.02))
