extends Node3D
## Renders the city from a few angles to PNG files and quits (look-dev tool).
## godot --path . res://scenes/preview.tscn -- --out=/path/dir

var shots := [
	[Vector3(28, 7, 50), Vector3(28, 3, 28)],
	[Vector3(-4, 26, 62), Vector3(28, 0, 26)],
	[Vector3(21, 1.7, 40), Vector3(28, 3, 26)],
	[Vector3(4, 14, 4), Vector3(26, 3, 26)],
	[Vector3(28, 70, 29), Vector3(28, 0, 28)],
]

func _ready() -> void:
	var out := "/tmp/hethra_shots"
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--out="):
			out = a.substr(6)
		elif a == "--idol":
			shots = [[Vector3(31, 3.2, 36), Vector3(28, 3.4, 28)], [Vector3(22, 6, 33), Vector3(28, 3, 28)]]
	DirAccess.make_dir_recursive_absolute(out)
	var st := BattleState.new()
	st.setup("hethra_square", "marines", "chained", 3, true, true)
	var t0 := Time.get_ticks_msec()
	var atm := Atmosphere.new()
	add_child(atm)
	atm.build(Vector3(28, 0, 28), Game.graphics)
	var city := CityBuilder.new()
	add_child(city)
	city.build(st.map, st.shard_nodes)
	print("city built in ", Time.get_ticks_msec() - t0, " ms")
	var cam := Camera3D.new()
	cam.fov = 55
	cam.far = 900
	add_child(cam)
	cam.current = true
	for i in range(shots.size()):
		cam.position = shots[i][0]
		cam.look_at(shots[i][1], Vector3.UP)
		for f in range(12):
			await get_tree().process_frame
		var img := get_viewport().get_texture().get_image()
		img.save_png("%s/city_%d.png" % [out, i])
		print("saved ", i)
	get_tree().quit()
