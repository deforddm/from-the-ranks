extends RefCounted
## Shardfall look: the glowing ground where a burning godshard will come down,
## the shard itself streaking out of the sky, and the scorch it leaves.
## Everything is built from meshes and particles in code.

static func _glow_mat(c: Color, energy: float, alpha := 1.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = Color(c.r, c.g, c.b, alpha)
	if alpha < 1.0:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.emission_enabled = true
	m.emission = c
	m.emission_energy_multiplier = energy
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	return m

static func _soft_quad(size: float) -> QuadMesh:
	var q := QuadMesh.new()
	q.size = Vector2(size, size)
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.vertex_color_use_as_albedo = true
	m.albedo_texture = CityBuilder._soft_dot()
	q.material = m
	return q

static func _ramp(cols: Array) -> GradientTexture1D:
	var g := Gradient.new()
	g.set_color(0, cols[0])
	g.set_color(1, cols[-1])
	for i in range(1, cols.size() - 1):
		g.add_point(float(i) / float(cols.size() - 1), cols[i])
	var t := GradientTexture1D.new()
	t.gradient = g
	return t

static func make_omen(radius: float) -> Node3D:
	## The ground that will be struck: a burning ring, a hot glow within it, and
	## sparks rising. The caller pulses it.
	var root := Node3D.new()
	root.name = "ShardOmen"
	var ring := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = radius - 0.16
	tm.outer_radius = radius
	tm.rings = 48
	tm.ring_segments = 6
	ring.mesh = tm
	ring.scale = Vector3(1.0, 0.25, 1.0)
	ring.position.y = 0.06
	ring.material_override = _glow_mat(Color(1.0, 0.42, 0.12), 5.0)
	ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(ring)
	# an inner ring, thinner, so it reads as a target and not a puddle
	var ring2 := MeshInstance3D.new()
	var tm2 := TorusMesh.new()
	tm2.inner_radius = radius * 0.45 - 0.06
	tm2.outer_radius = radius * 0.45
	tm2.rings = 32
	tm2.ring_segments = 5
	ring2.mesh = tm2
	ring2.scale = Vector3(1.0, 0.25, 1.0)
	ring2.position.y = 0.06
	ring2.material_override = _glow_mat(Color(1.0, 0.55, 0.2), 3.0)
	ring2.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(ring2)
	var disc := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = 0.02
	cm.radial_segments = 40
	disc.mesh = cm
	disc.position.y = 0.05
	disc.material_override = _glow_mat(Color(1.0, 0.3, 0.06), 1.5, 0.16)
	disc.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(disc)
	# a faint column of heat over it, so it can be found from afar
	var col := MeshInstance3D.new()
	var cc := CylinderMesh.new()
	cc.top_radius = radius * 0.35
	cc.bottom_radius = radius * 0.9
	cc.height = 14.0
	cc.radial_segments = 24
	cc.cap_top = false
	cc.cap_bottom = false
	col.mesh = cc
	col.position.y = 7.0
	var cmat := _glow_mat(Color(1.0, 0.45, 0.15), 0.6, 0.03)
	col.material_override = cmat
	col.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(col)
	var l := OmniLight3D.new()
	l.name = "Glow"
	l.light_color = Color(1.0, 0.45, 0.15)
	l.light_energy = 2.5
	l.omni_range = radius * 2.4 + 2.0
	l.position.y = 0.8
	root.add_child(l)
	var sp := GPUParticles3D.new()
	sp.amount = 40
	sp.lifetime = 2.2
	sp.visibility_aabb = AABB(Vector3(-6, -1, -6), Vector3(12, 14, 12))
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_RING
	pm.emission_ring_axis = Vector3.UP
	pm.emission_ring_radius = radius * 0.95
	pm.emission_ring_inner_radius = radius * 0.2
	pm.emission_ring_height = 0.05
	pm.direction = Vector3(0, 1, 0)
	pm.spread = 12.0
	pm.initial_velocity_min = 1.2
	pm.initial_velocity_max = 3.0
	pm.gravity = Vector3(0, 0.4, 0)
	pm.turbulence_enabled = true
	pm.turbulence_noise_strength = 0.5
	pm.scale_min = 0.5
	pm.scale_max = 1.2
	pm.color_ramp = _ramp([Color(1.0, 0.8, 0.4, 1), Color(1.0, 0.35, 0.08, 0.8), Color(0.8, 0.1, 0.02, 0)])
	sp.process_material = pm
	sp.draw_pass_1 = _soft_quad(0.12)
	root.add_child(sp)
	return root

static func make_meteor() -> Node3D:
	## The falling shard: a white-hot core round a sea-green crystal, a halo,
	## its own light, and a long trail of fire and smoke (left in the world).
	var root := Node3D.new()
	root.name = "Meteor"
	var core := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.55
	sm.height = 1.1
	core.mesh = sm
	core.material_override = _glow_mat(Color(1.0, 0.85, 0.55), 9.0)
	root.add_child(core)
	var halo := MeshInstance3D.new()
	var hm := SphereMesh.new()
	hm.radius = 1.6
	hm.height = 3.2
	halo.mesh = hm
	halo.material_override = _glow_mat(Color(1.0, 0.5, 0.15), 3.0, 0.22)
	root.add_child(halo)
	var crystal := MeshInstance3D.new()
	var pr := PrismMesh.new()
	pr.size = Vector3(0.5, 1.5, 0.5)
	crystal.mesh = pr
	crystal.material_override = _glow_mat(Color(0.35, 1.0, 0.85), 6.0)
	root.add_child(crystal)
	var l := OmniLight3D.new()
	l.light_color = Color(1.0, 0.6, 0.25)
	l.light_energy = 10.0
	l.omni_range = 26.0
	root.add_child(l)
	# fire: short-lived, bright, big
	var fire := GPUParticles3D.new()
	fire.name = "Fire"
	fire.amount = 220
	fire.lifetime = 0.7
	fire.local_coords = false
	fire.visibility_aabb = AABB(Vector3(-80, -80, -80), Vector3(160, 160, 160))
	var fm := ParticleProcessMaterial.new()
	fm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	fm.emission_sphere_radius = 0.5
	fm.direction = Vector3(0, 1, 0)
	fm.spread = 180.0
	fm.initial_velocity_min = 0.2
	fm.initial_velocity_max = 1.5
	fm.gravity = Vector3.ZERO
	fm.scale_min = 2.0
	fm.scale_max = 3.6
	fm.color_ramp = _ramp([Color(1.0, 0.95, 0.7, 1), Color(1.0, 0.55, 0.15, 0.9), Color(0.6, 0.12, 0.03, 0)])
	fire.process_material = fm
	fire.draw_pass_1 = _soft_quad(1.0)
	root.add_child(fire)
	# smoke: long-lived, dark, the streak across the sky
	var smoke := GPUParticles3D.new()
	smoke.name = "Smoke"
	smoke.amount = 260
	smoke.lifetime = 3.2
	smoke.local_coords = false
	smoke.visibility_aabb = AABB(Vector3(-80, -80, -80), Vector3(160, 160, 160))
	var smm := ParticleProcessMaterial.new()
	smm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	smm.emission_sphere_radius = 0.6
	smm.direction = Vector3(0, 1, 0)
	smm.spread = 180.0
	smm.initial_velocity_min = 0.1
	smm.initial_velocity_max = 0.8
	smm.gravity = Vector3(0.4, 0.3, 0.0)
	smm.damping_min = 0.2
	smm.damping_max = 0.6
	smm.scale_min = 2.2
	smm.scale_max = 4.5
	smm.color_ramp = _ramp([Color(1.0, 0.5, 0.15, 0.7), Color(0.3, 0.24, 0.2, 0.55), Color(0.12, 0.11, 0.1, 0)])
	smoke.process_material = smm
	smoke.draw_pass_1 = _soft_quad(1.4)
	root.add_child(smoke)
	return root

static func make_scorch(radius: float) -> Node3D:
	## Blackened stone round the crater, with a few embers that die away.
	var root := Node3D.new()
	var d := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = 0.02
	cm.radial_segments = 28
	d.mesh = cm
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.03, 0.025, 0.02, 0.8)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.roughness = 1.0
	d.material_override = m
	d.position.y = 0.04
	d.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(d)
	var inner := MeshInstance3D.new()
	var ic := CylinderMesh.new()
	ic.top_radius = radius * 0.4
	ic.bottom_radius = radius * 0.4
	ic.height = 0.02
	inner.mesh = ic
	inner.material_override = _glow_mat(Color(1.0, 0.3, 0.05), 2.0, 0.5)
	inner.position.y = 0.05
	root.add_child(inner)
	return root

static func make_impact(radius: float) -> Node3D:
	## What the strike throws up: a ring of fire running out along the ground,
	## sparks and burning stone flung high, and a column of dust and smoke.
	## The caller grows the "Wave" ring and frees the whole after a few seconds.
	var root := Node3D.new()
	var wave := MeshInstance3D.new()
	wave.name = "Wave"
	var tm := TorusMesh.new()
	tm.inner_radius = 0.82
	tm.outer_radius = 1.0
	tm.rings = 48
	tm.ring_segments = 6
	wave.mesh = tm
	wave.scale = Vector3(0.3, 0.4, 0.3)
	wave.position.y = 0.2
	var wm := _glow_mat(Color(1.0, 0.6, 0.25), 6.0, 0.9)
	wave.material_override = wm
	root.add_child(wave)
	var sparks := GPUParticles3D.new()
	sparks.amount = 140
	sparks.lifetime = 1.8
	sparks.one_shot = true
	sparks.explosiveness = 0.95
	sparks.visibility_aabb = AABB(Vector3(-30, -5, -30), Vector3(60, 40, 60))
	var sm := ParticleProcessMaterial.new()
	sm.direction = Vector3(0, 1, 0)
	sm.spread = 60.0
	sm.initial_velocity_min = 6.0
	sm.initial_velocity_max = 16.0
	sm.gravity = Vector3(0, -14.0, 0)
	sm.scale_min = 0.4
	sm.scale_max = 1.0
	sm.color_ramp = _ramp([Color(1.0, 0.95, 0.7, 1), Color(1.0, 0.5, 0.1, 1), Color(0.6, 0.1, 0.02, 0)])
	sparks.process_material = sm
	sparks.draw_pass_1 = _soft_quad(0.22)
	root.add_child(sparks)
	var rocks := GPUParticles3D.new()
	rocks.amount = 36
	rocks.lifetime = 1.6
	rocks.one_shot = true
	rocks.explosiveness = 0.9
	rocks.visibility_aabb = AABB(Vector3(-30, -5, -30), Vector3(60, 40, 60))
	var rm := ParticleProcessMaterial.new()
	rm.direction = Vector3(0, 1, 0)
	rm.spread = 50.0
	rm.initial_velocity_min = 5.0
	rm.initial_velocity_max = 11.0
	rm.gravity = Vector3(0, -16.0, 0)
	rm.angular_velocity_min = -300.0
	rm.angular_velocity_max = 300.0
	rm.scale_min = 0.6
	rm.scale_max = 1.6
	rocks.process_material = rm
	var bm := BoxMesh.new()
	bm.size = Vector3(0.18, 0.14, 0.16)
	var stone := StandardMaterial3D.new()
	stone.albedo_color = Color(0.16, 0.13, 0.11)
	stone.emission_enabled = true
	stone.emission = Color(1.0, 0.35, 0.08)
	stone.emission_energy_multiplier = 1.5
	bm.material = stone
	rocks.draw_pass_1 = bm
	root.add_child(rocks)
	var dust := GPUParticles3D.new()
	dust.amount = 60
	dust.lifetime = 4.0
	dust.one_shot = true
	dust.explosiveness = 0.85
	dust.visibility_aabb = AABB(Vector3(-30, -5, -30), Vector3(60, 40, 60))
	var dm := ParticleProcessMaterial.new()
	dm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	dm.emission_sphere_radius = radius * 0.5
	dm.direction = Vector3(0, 1, 0)
	dm.spread = 35.0
	dm.initial_velocity_min = 2.0
	dm.initial_velocity_max = 7.0
	dm.gravity = Vector3(0.3, -0.6, 0)
	dm.damping_min = 1.5
	dm.damping_max = 2.5
	dm.scale_min = 2.5
	dm.scale_max = 5.0
	dm.color_ramp = _ramp([Color(1.0, 0.6, 0.25, 0.9), Color(0.35, 0.27, 0.22, 0.75), Color(0.16, 0.15, 0.14, 0)])
	dust.process_material = dm
	dust.draw_pass_1 = _soft_quad(1.6)
	root.add_child(dust)
	for g in [sparks, rocks, dust]:
		g.emitting = true
	return root
