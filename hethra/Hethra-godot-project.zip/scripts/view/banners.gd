extends Node3D
## Banners of a warband fighting on home ground: tall poles on the roofs and
## walls round its starting ground, each flying a long cloth in the band's
## colours that ripples in the wind.

const CLOTH_SHADER := """
shader_type spatial;
render_mode cull_disabled, depth_draw_opaque;
uniform vec3 base_col : source_color = vec3(0.2, 0.36, 0.62);
uniform vec3 trim_col : source_color = vec3(0.78, 0.66, 0.34);
uniform float phase = 0.0;
uniform float gust = 1.0;
uniform int device = 0;
//DEVICE_FN
varying float v_u;
varying float v_v;
void vertex() {
	// UV.x runs out from the pole, UV.y down the cloth: the free edge moves most
	float u = UV.x;
	float t = TIME * 2.3 + phase;
	float wave = sin(u * 7.0 - t * 2.0) * 0.16 + sin(u * 13.0 - t * 3.1 + UV.y * 3.0) * 0.05;
	VERTEX.z += wave * u * gust;
	VERTEX.y += sin(u * 5.0 - t * 1.6) * 0.05 * u * gust;
	v_u = u;
	v_v = UV.y;
	NORMAL = normalize(NORMAL + vec3(0.0, 0.0, -cos(u * 7.0 - t * 2.0) * 0.6 * u));
}
void fragment() {
	vec3 c = base_col;
	// a trim stripe down each long edge and along the swallow-tail
	float edge = step(v_v, 0.07) + step(0.93, v_v);
	// the band's mark near the pole
	vec2 q = vec2((v_u - 0.3) * 2.2, v_v - 0.42);
	float mark = device_mask(q, device);
	c = mix(c, trim_col, clamp(edge + mark, 0.0, 1.0));
	// a little weave and grime
	float weave = sin(UV.x * 380.0) * sin(UV.y * 260.0) * 0.04;
	c *= 0.82 + weave + v_v * 0.12;
	// cut the swallow-tail out of the free end
	if (v_u > 0.8 && abs(v_v - 0.5) < (v_u - 0.8) * 1.6) {
		discard;
	}
	ALBEDO = c;
	ROUGHNESS = 0.92;
	BACKLIGHT = c * 0.35;
}
"""

var spots: Array = []     # world positions of the poles' feet
var device := 0           # the mark on the cloth (see Heraldry.DEVICES)

func build(map: BattleMap, side_centre: Vector3, avoid: Array, col: Color, trim: Color, count := 5, rng_seed := 1) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = rng_seed
	# roofs and wall tops near the band's ground, highest first
	var cands: Array = []
	for z in range(map.d):
		for x in range(map.w):
			var c := map.cell_center(x, z)
			var flat := Vector2(side_centre.x, side_centre.z)
			var dist := c.distance_to(flat) / map.cell
			if dist < 2.0 or dist > 8.5:
				continue
			var nd := map.top_node(x, z)
			if nd < 0 or avoid.has(nd):
				continue
			var lvl := map.node_level(nd)
			cands.append([-(lvl * 3.0) + dist * 0.35 + rng.randf() * 1.5, nd])
	cands.sort_custom(func(a, b): return a[0] < b[0])
	for cd in cands:
		if spots.size() >= count:
			break
		var p := map.node_pos(cd[1])
		var ok := true
		for s in spots:
			if Vector2(s.x, s.z).distance_to(Vector2(p.x, p.z)) < map.cell * 2.6:
				ok = false
				break
		if not ok:
			continue
		# stand the pole at a corner of the cell, out of the fighters' way
		p += Vector3(map.cell * 0.38 * (1 if rng.randf() < 0.5 else -1), 0, map.cell * 0.38 * (1 if rng.randf() < 0.5 else -1))
		spots.append(p)
	var wind := Vector3(1, 0, 0.35).normalized()
	for i in range(spots.size()):
		_banner(spots[i], wind, col, trim, rng.randf() * TAU, rng.randf_range(3.2, 4.2))

func raise(at: Vector3, col: Color, trim: Color, phase: float, height: float, wind := Vector3(1, 0, 0.35)) -> Node3D:
	## One standard on its own, for a cairn: returns its root so it can be
	## torn down again.
	return _banner(at, wind.normalized(), col, trim, phase, height)

func _banner(at: Vector3, wind: Vector3, col: Color, trim: Color, phase: float, height: float) -> Node3D:
	var root := Node3D.new()
	add_child(root)
	root.position = at
	# face the cloth downwind
	root.rotation.y = atan2(-wind.z, wind.x)
	var wood := StandardMaterial3D.new()
	wood.albedo_color = Color(0.24, 0.17, 0.11)
	wood.roughness = 0.9
	var pole := MeshInstance3D.new()
	var pm := CylinderMesh.new()
	pm.top_radius = 0.035
	pm.bottom_radius = 0.05
	pm.height = height
	pm.radial_segments = 8
	pole.mesh = pm
	pole.material_override = wood
	pole.position.y = height * 0.5
	root.add_child(pole)
	# a crossbar the cloth hangs from, and an iron finial
	var bar := MeshInstance3D.new()
	var bm := CylinderMesh.new()
	bm.top_radius = 0.025
	bm.bottom_radius = 0.025
	bm.height = 1.35
	bm.radial_segments = 6
	bar.mesh = bm
	bar.material_override = wood
	bar.rotation.z = PI * 0.5
	bar.position = Vector3(0.62, height - 0.12, 0)
	root.add_child(bar)
	var iron := StandardMaterial3D.new()
	iron.albedo_color = trim.darkened(0.25)
	iron.metallic = 0.8
	iron.roughness = 0.4
	var tip := MeshInstance3D.new()
	var tm := PrismMesh.new()
	tm.size = Vector3(0.12, 0.28, 0.05)
	tip.mesh = tm
	tip.material_override = iron
	tip.position.y = height + 0.13
	root.add_child(tip)
	# the cloth: a long strip hanging from the bar, free end streaming
	var cloth := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(1.3, 1.7)
	plane.subdivide_width = 18
	plane.subdivide_depth = 14
	plane.orientation = PlaneMesh.FACE_Z
	cloth.mesh = plane
	var sm := ShaderMaterial.new()
	var sh := Shader.new()
	sh.code = CLOTH_SHADER.replace("//DEVICE_FN", Heraldry.GLSL)
	sm.shader = sh
	sm.set_shader_parameter("device", device)
	sm.set_shader_parameter("base_col", col)
	sm.set_shader_parameter("trim_col", trim)
	sm.set_shader_parameter("phase", phase)
	cloth.material_override = sm
	cloth.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	cloth.position = Vector3(0.66, height - 0.12 - 0.85, 0)
	root.add_child(cloth)
	# a small fire bowl at the foot of some poles
	if fmod(phase, 1.0) < 0.5:
		var glow := OmniLight3D.new()
		glow.light_color = Color(1.0, 0.62, 0.3)
		glow.light_energy = 1.2
		glow.omni_range = 3.2
		glow.position = Vector3(0.2, 0.5, 0.2)
		root.add_child(glow)
	return root
