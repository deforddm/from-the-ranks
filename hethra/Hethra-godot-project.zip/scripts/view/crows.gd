class_name Crows
extends Node3D
## Hood's crows: carrion birds that sit along the roofs and in the streets,
## burst up cawing when a fighter comes close, wheel over the field and settle
## again somewhere quieter, and come down beside the fallen.

const FLEE_DIST := 4.2        # a fighter this close puts a crow up
const PERCH_CLEAR := 7.0      # a crow lands only this far from every fighter

var map: BattleMap
var figs: Dictionary = {}
var perches: Array = []       # Vector3
var birds: Array = []
var bodies: Array = []        # fallen fighters' positions, for the crows to visit
var rng := RandomNumberGenerator.new()
var calm := false             # screenshots: crows stay put unless sent
var _mat: StandardMaterial3D
var _mat_beak: StandardMaterial3D
var _mat_eye: StandardMaterial3D
var _check := 0.0
var _caw_cool := 0.0
var _flock_caw := 0.0

class Bird:
	var node: Node3D
	var body: Node3D
	var head: Node3D
	var wing_l: Node3D
	var wing_r: Node3D
	var legs: Node3D
	var state := "perch"      # perch, fly, circle
	var t := 0.0              # time in the current state or leg
	var dur := 1.0
	var a := Vector3.ZERO     # flight leg: start, control, end
	var c := Vector3.ZERO
	var b := Vector3.ZERO
	var then := "circle"      # what follows the leg: circle or perch
	var centre := Vector3.ZERO
	var radius := 6.0
	var ang := 0.0
	var spin := 1.0
	var height := 10.0
	var circle_left := 6.0
	var flap := 0.0
	var idle := 1.0           # seconds to the next hop, peck or look round
	var peck := 0.0
	var hop := 0.0
	var hop_from := Vector3.ZERO
	var hop_to := Vector3.ZERO
	var yaw := 0.0
	var visit := -1           # index of the body this crow is going down to

func build(m: BattleMap, f: Dictionary, seed_v: int, count := 16) -> void:
	map = m
	figs = f
	rng.seed = seed_v * 7919 + 13
	_mat = StandardMaterial3D.new()
	_mat.albedo_color = Color(0.05, 0.05, 0.065)
	_mat.roughness = 0.6
	_mat.metallic_specular = 0.35
	_mat.rim_enabled = true
	_mat.rim = 0.5
	_mat.rim_tint = 0.6
	_mat_beak = StandardMaterial3D.new()
	_mat_beak.albedo_color = Color(0.08, 0.075, 0.08)
	_mat_beak.roughness = 0.3
	_mat_eye = StandardMaterial3D.new()
	_mat_eye.albedo_color = Color(0.02, 0.02, 0.02)
	_mat_eye.roughness = 0.05
	_mat_eye.metallic_specular = 1.0
	# perches: raised roofs and walls first, a few street corners after
	var high: Array = []
	var low: Array = []
	for id in map.nodes:
		if map.is_wet(id):
			continue
		var p: Vector3 = map.node_pos(id)
		if map.node_level(id) >= 1:
			high.append(p)
		else:
			low.append(p)
	high.shuffle()
	low.shuffle()
	perches = high.slice(0, 80) + low.slice(0, 30)
	if perches.is_empty():
		return
	# a few small flocks, each round one perch
	var made := 0
	while made < count:
		var home: Vector3 = _quiet_perch(Vector3(-999, 0, -999))
		var n := rng.randi_range(2, 4)
		for i in range(n):
			if made >= count:
				break
			var bd := _make_bird()
			bd.node.position = _near(home, 1.2)
			bd.yaw = rng.randf() * TAU
			bd.node.rotation.y = bd.yaw
			bd.idle = rng.randf_range(0.3, 3.0)
			birds.append(bd)
			made += 1

func _near(p: Vector3, r: float) -> Vector3:
	var o := Vector2(rng.randf_range(-r, r), rng.randf_range(-r, r))
	return p + Vector3(clampf(o.x, -0.8, 0.8), 0.0, clampf(o.y, -0.8, 0.8))

func _make_bird() -> Bird:
	var bd := Bird.new()
	bd.node = Node3D.new()
	add_child(bd.node)
	bd.body = Node3D.new()
	bd.node.add_child(bd.body)
	var s := 1.1 + rng.randf() * 0.25
	bd.body.scale = Vector3(s, s, s)
	# body: a long egg along +Z (the head end), tail behind
	var torso := _mesh(bd.body, _ellipsoid(0.075, 0.085, 0.16), _mat, Vector3(0, 0.18, 0))
	torso.rotation.x = -0.5
	var chest := _mesh(bd.body, _ellipsoid(0.07, 0.07, 0.07), _mat, Vector3(0, 0.23, 0.07))
	chest.rotation.x = -0.5
	# a long wedge of tail feathers, fanned a little
	for j in range(3):
		var tf := _mesh(bd.body, _box(0.035, 0.012, 0.19), _mat, Vector3((j - 1) * 0.022, 0.12, -0.19))
		tf.rotation = Vector3(-0.3, (j - 1) * 0.14, 0)
	bd.head = Node3D.new()
	bd.head.position = Vector3(0, 0.3, 0.12)
	bd.body.add_child(bd.head)
	_mesh(bd.head, _ellipsoid(0.05, 0.052, 0.062), _mat, Vector3.ZERO)
	_mesh(bd.head, _ellipsoid(0.04, 0.035, 0.05), _mat, Vector3(0, -0.035, -0.035))
	var beak := _mesh(bd.head, _cone(0.026, 0.095), _mat_beak, Vector3(0, -0.006, 0.09))
	beak.rotation.x = PI * 0.5
	for sd in [-1.0, 1.0]:
		_mesh(bd.head, _ellipsoid(0.01, 0.01, 0.01), _mat_eye, Vector3(sd * 0.042, 0.015, 0.03))
	# legs, tucked away in flight
	bd.legs = Node3D.new()
	bd.body.add_child(bd.legs)
	for sd in [-1.0, 1.0]:
		_mesh(bd.legs, _box(0.012, 0.11, 0.012), _mat_beak, Vector3(sd * 0.03, 0.055, 0.02))
		var toe := _mesh(bd.legs, _box(0.012, 0.008, 0.06), _mat_beak, Vector3(sd * 0.03, 0.004, 0.035))
		toe.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	# wings, hinged at the shoulder; the outer feathers fanned in slats
	bd.wing_l = Node3D.new()
	bd.wing_r = Node3D.new()
	for k in range(2):
		var wg: Node3D = bd.wing_l if k == 0 else bd.wing_r
		var sd := -1.0 if k == 0 else 1.0
		wg.position = Vector3(sd * 0.065, 0.26, 0.07)
		bd.body.add_child(wg)
		# the leading edge runs along the hinge; the feathers trail back from it
		_mesh(wg, _box(0.2, 0.012, 0.14), _mat, Vector3(sd * 0.1, 0, -0.07))
		for j in range(4):
			var fe := _mesh(wg, _box(0.14, 0.008, 0.034), _mat, Vector3(sd * (0.25 + j * 0.008), 0, -0.018 - j * 0.034))
			fe.rotation.y = sd * (0.12 - j * 0.1)
	_fold(bd)
	return bd

func _mesh(parent: Node3D, m: Mesh, mat: Material, pos: Vector3) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = m
	mi.material_override = mat
	mi.position = pos
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	parent.add_child(mi)
	return mi

var _cache := {}

func _ellipsoid(rx: float, ry: float, rz: float) -> Mesh:
	var k := "e%.3f%.3f%.3f" % [rx, ry, rz]
	if not _cache.has(k):
		var sm := SphereMesh.new()
		sm.radius = 1.0
		sm.height = 2.0
		sm.radial_segments = 10
		sm.rings = 6
		var st := SurfaceTool.new()
		st.create_from(sm, 0)
		var arr := st.commit_to_arrays()
		var v: PackedVector3Array = arr[Mesh.ARRAY_VERTEX]
		var nr: PackedVector3Array = arr[Mesh.ARRAY_NORMAL]
		for i in range(v.size()):
			v[i] = Vector3(v[i].x * rx, v[i].y * ry, v[i].z * rz)
			nr[i] = Vector3(nr[i].x / rx, nr[i].y / ry, nr[i].z / rz).normalized()
		arr[Mesh.ARRAY_VERTEX] = v
		arr[Mesh.ARRAY_NORMAL] = nr
		var am := ArrayMesh.new()
		am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
		_cache[k] = am
	return _cache[k]

func _box(x: float, y: float, z: float) -> Mesh:
	var k := "b%.3f%.3f%.3f" % [x, y, z]
	if not _cache.has(k):
		var bm := BoxMesh.new()
		bm.size = Vector3(x, y, z)
		_cache[k] = bm
	return _cache[k]

func _cone(r: float, h: float) -> Mesh:
	var k := "c%.3f%.3f" % [r, h]
	if not _cache.has(k):
		var cm := CylinderMesh.new()
		cm.top_radius = 0.0
		cm.bottom_radius = r
		cm.height = h
		cm.radial_segments = 6
		_cache[k] = cm
	return _cache[k]

func _fold(bd: Bird) -> void:
	# span laid back along the body, the feathers drooped over each flank,
	# the whole wing pitched down to follow the sloping back
	var pitch := Basis(Vector3.RIGHT, -0.42)
	var sc := Basis.from_scale(Vector3(0.64, 1.0, 0.8))
	bd.wing_l.basis = pitch * Basis.from_euler(Vector3(-1.15, -PI * 0.5 + 0.12, 0.0)) * sc
	bd.wing_r.basis = pitch * Basis.from_euler(Vector3(-1.15, PI * 0.5 - 0.12, 0.0)) * sc
	bd.legs.visible = true

# ------------------------------------------------------------------ behaviour

var fighters_fn: Callable      # -> Array of Vector3: where the fighters still standing are

func _fighters() -> Array:
	if fighters_fn.is_valid():
		return fighters_fn.call()
	var out: Array = []
	for k in figs:
		var f: Node3D = figs[k]
		if is_instance_valid(f) and f.visible:
			out.append(f.global_position)
	return out

func _quiet_perch(avoid: Vector3) -> Vector3:
	var fs := _fighters()
	var best := Vector3.ZERO
	var best_score := -1.0e9
	for i in range(14):
		var p: Vector3 = perches[rng.randi_range(0, perches.size() - 1)]
		var dmin := 99.0
		for q in fs:
			dmin = minf(dmin, Vector2(p.x - q.x, p.z - q.z).length())
		var score := minf(dmin, 16.0) + p.y * 0.4 - (6.0 if p.distance_to(avoid) < 3.0 else 0.0) + rng.randf() * 3.0
		if score > best_score:
			best_score = score
			best = p
	return best

func scare(p: Vector3, r: float) -> void:
	## Something loud happened at p: every perched crow within r goes up.
	for bd in birds:
		if bd.state == "perch" and bd.node.position.distance_to(p) < r:
			_take_off(bd, p)

func fallen(p: Vector3) -> void:
	## A fighter went down at p: in a while, a crow or two come to see.
	bodies.append(p)
	var idx := bodies.size() - 1
	var sent := 0
	var order := birds.duplicate()
	order.shuffle()
	for bd in order:
		if sent >= rng.randi_range(1, 3):
			break
		if bd.visit >= 0:
			continue
		bd.visit = idx
		sent += 1
		if bd.state == "perch":
			bd.idle = rng.randf_range(3.0, 7.0)
		else:
			bd.circle_left = minf(bd.circle_left, rng.randf_range(2.0, 5.0))

func _take_off(bd: Bird, from: Vector3) -> void:
	var p: Vector3 = bd.node.position
	var away := Vector3(p.x - from.x, 0, p.z - from.z)
	if away.length() < 0.1:
		away = Vector3(rng.randf_range(-1, 1), 0, rng.randf_range(-1, 1))
	away = away.normalized()
	bd.centre = Vector3(p.x, 0, p.z) + away * rng.randf_range(3.0, 7.0)
	bd.radius = rng.randf_range(4.0, 8.0)
	bd.height = p.y + rng.randf_range(6.0, 10.0)
	bd.spin = -1.0 if rng.randf() < 0.5 else 1.0
	bd.ang = atan2(p.z - bd.centre.z, p.x - bd.centre.x)
	var entry := bd.centre + Vector3(cos(bd.ang + bd.spin * 1.2) * bd.radius, bd.height, sin(bd.ang + bd.spin * 1.2) * bd.radius)
	bd.ang += bd.spin * 1.2
	_leg(bd, p, p + away * 2.0 + Vector3(0, 3.0, 0), entry, rng.randf_range(1.2, 1.8), "circle")
	bd.circle_left = rng.randf_range(4.0, 9.0)
	if _caw_cool <= 0.0:
		_caw_cool = 0.35
		_sfx("caw_*", p, -2.0, 0.12)
		_sfx("wings", p, -4.0, 0.15)

func _leg(bd: Bird, a: Vector3, c: Vector3, b: Vector3, dur: float, then: String) -> void:
	bd.state = "fly"
	bd.a = a
	bd.c = c
	bd.b = b
	bd.t = 0.0
	bd.dur = dur
	bd.then = then

func _land(bd: Bird) -> void:
	var target: Vector3
	if bd.visit >= 0 and bd.visit < bodies.size():
		var bp: Vector3 = bodies[bd.visit]
		var ang := rng.randf() * TAU
		target = bp + Vector3(cos(ang) * 0.75, 0.0, sin(ang) * 0.75)
		var near := false
		for q in _fighters():
			if Vector2(q.x - bp.x, q.z - bp.z).length() < FLEE_DIST:
				near = true
		if near:
			bd.circle_left = rng.randf_range(3.0, 6.0)
			return
		bd.visit = -2          # been once
	else:
		target = _near(_quiet_perch(bd.node.position), 0.7)
	var p: Vector3 = bd.node.position
	var mid := p.lerp(target, 0.6)
	mid.y = maxf(p.y, target.y) + 1.5
	_leg(bd, p, mid, target, clampf(p.distance_to(target) / 7.0, 1.2, 3.5), "perch")

func _process(delta: float) -> void:
	if birds.is_empty():
		return
	_caw_cool -= delta
	_check -= delta
	var fs: Array = []
	if _check <= 0.0 and not calm:
		_check = 0.2
		fs = _fighters()
	for bd in birds:
		_step(bd, delta, fs)
	# now and then one of the wheeling birds calls out
	_flock_caw -= delta
	if _flock_caw <= 0.0:
		_flock_caw = rng.randf_range(5.0, 12.0)
		for bd in birds:
			if bd.state == "circle" and rng.randf() < 0.5:
				_sfx("caw_*", bd.node.position, -8.0, 0.15)
				break

func _step(bd: Bird, delta: float, fs: Array) -> void:
	bd.t += delta
	match bd.state:
		"perch":
			if not fs.is_empty():
				var p: Vector3 = bd.node.position
				for q in fs:
					if absf(q.y - p.y) < 3.0 and Vector2(q.x - p.x, q.z - p.z).length() < FLEE_DIST:
						_take_off(bd, q)
						return
			if bd.visit >= 0 and not calm:
				bd.idle -= delta
				if bd.idle <= 0.0:
					_take_off(bd, bd.node.position + Vector3(rng.randf_range(-1, 1), 0, rng.randf_range(-1, 1)))
					bd.circle_left = rng.randf_range(1.0, 2.5)
				return
			_idle(bd, delta)
		"fly":
			var u := clampf(bd.t / bd.dur, 0.0, 1.0)
			var e := u * u * (3.0 - 2.0 * u) if bd.then == "perch" else u
			var p0 := bd.a.lerp(bd.c, e)
			var p1 := bd.c.lerp(bd.b, e)
			var np := p0.lerp(p1, e)
			_face(bd, np - bd.node.position, delta)
			bd.node.position = np
			var climbing := bd.then == "circle"
			bd.flap += delta * (22.0 if climbing or u < 0.75 else 30.0)
			var amp := 1.0 if climbing or u < 0.7 else 0.6
			_wings(bd, sin(bd.flap) * amp, 0.0)
			bd.body.rotation.x = (-0.35 if climbing else 0.15) * (1.0 - u) + (-0.5 * u if bd.then == "perch" else 0.0)
			if u >= 1.0:
				if bd.then == "circle":
					bd.state = "circle"
					bd.t = 0.0
				else:
					bd.state = "perch"
					bd.body.rotation = Vector3.ZERO
					_fold(bd)
					bd.idle = rng.randf_range(0.5, 2.0)
		"circle":
			bd.ang += bd.spin * delta * (7.5 / bd.radius)
			bd.height += sin(bd.t * 0.7 + bd.radius) * delta * 0.6
			var np := bd.centre + Vector3(cos(bd.ang) * bd.radius, bd.height, sin(bd.ang) * bd.radius)
			_face(bd, np - bd.node.position, delta)
			bd.node.position = np
			# mostly gliding, a few beats now and then
			var beat := fmod(bd.t + bd.radius, 3.2) < 0.9
			if beat:
				bd.flap += delta * 20.0
				_wings(bd, sin(bd.flap) * 0.8, 0.0)
			else:
				_wings(bd, 0.12, 0.0)
			bd.body.rotation = Vector3(0.0, 0.0, -bd.spin * 0.35)
			bd.circle_left -= delta
			if bd.circle_left <= 0.0:
				bd.body.rotation = Vector3.ZERO
				_land(bd)

func _idle(bd: Bird, delta: float) -> void:
	if bd.hop > 0.0:
		bd.hop -= delta * 3.0
		var u := 1.0 - maxf(bd.hop, 0.0)
		bd.node.position = bd.hop_from.lerp(bd.hop_to, u) + Vector3(0, sin(u * PI) * 0.12, 0)
		return
	if bd.peck > 0.0:
		bd.peck -= delta
		bd.head.rotation.x = 0.9 * absf(sin(bd.peck * 9.0))
		bd.body.rotation.x = 0.35 * absf(sin(bd.peck * 9.0))
		if bd.peck <= 0.0:
			bd.head.rotation.x = 0.0
			bd.body.rotation.x = 0.0
		return
	bd.idle -= delta
	if bd.idle > 0.0:
		return
	bd.idle = rng.randf_range(0.8, 3.5)
	var r := rng.randf()
	if r < 0.4:
		bd.head.rotation.y = rng.randf_range(-1.1, 1.1)
	elif r < 0.7:
		bd.peck = rng.randf_range(0.4, 1.0)
	else:
		bd.hop = 1.0
		bd.hop_from = bd.node.position
		var dir := Vector3(sin(bd.yaw), 0, cos(bd.yaw)).rotated(Vector3.UP, rng.randf_range(-1.2, 1.2))
		bd.hop_to = bd.hop_from + dir * rng.randf_range(0.15, 0.4)
		bd.hop_to.y = bd.hop_from.y
		bd.yaw = atan2(dir.x, dir.z)
		bd.node.rotation.y = bd.yaw
		bd.head.rotation.y = 0.0

func _face(bd: Bird, v: Vector3, delta: float) -> void:
	if Vector2(v.x, v.z).length() < 0.0005:
		return
	var want := atan2(v.x, v.z)
	bd.yaw = lerp_angle(bd.yaw, want, clampf(delta * 8.0, 0.0, 1.0))
	bd.node.rotation.y = bd.yaw

func _wings(bd: Bird, up: float, _sweep: float) -> void:
	# open the wings out to the sides, then beat them about the body's long axis
	bd.wing_l.rotation = Vector3(0, -0.15, -up)
	bd.wing_r.rotation = Vector3(0, 0.15, up)
	bd.wing_l.scale = Vector3.ONE
	bd.wing_r.scale = Vector3.ONE
	bd.legs.visible = bd.state == "perch"

func _sfx(nm: String, p: Vector3, db: float, pv: float) -> void:
	var sfx := get_node_or_null("/root/Sfx")
	if sfx != null:
		sfx.play(nm, p, db, pv)

# ------------------------------------------------------------------ screenshots

func gather_at(p: Vector3, n: int) -> void:
	## Put n crows straight down round p (for the screenshot of the fallen).
	var k := 0
	for bd in birds:
		if k >= n:
			break
		var ang := k * 2.1 + 0.4
		bd.state = "perch"
		bd.body.rotation = Vector3.ZERO
		_fold(bd)
		bd.node.position = p + Vector3(cos(ang) * (0.6 + k * 0.12), 0.0, sin(ang) * (0.6 + k * 0.12))
		bd.yaw = atan2(p.x - bd.node.position.x, p.z - bd.node.position.z) + rng.randf_range(-0.5, 0.5)
		bd.node.rotation.y = bd.yaw
		k += 1
