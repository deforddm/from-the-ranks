class_name Battle
extends Node3D
## Runs one battle on screen: builds the city and the figures, drives the
## turn loop (player or AI for each side), turns rules events into animation,
## and handles mouse and keyboard orders.

signal player_done

const UNIT_LAYER := 2
const WORLD_LAYER := 1

var st: BattleState
var ais: Array = [null, null]
var player_side := 0
var watch_all := false
var city: CityBuilder
var atm: Atmosphere
var rig: CameraRig
var hud: Hud
var figs: Dictionary = {}
var bodies: Dictionary = {}
var ghosts: Dictionary = {}
var units_root: Node3D
var fx_root: Node3D
var crows: Crows

var sel: BUnit = null
var mode := "move"
var reach: Dictionary = {}
var charge_cache: Dictionary = {}
var busy := true
var hover_node := -1
var hover_unit: BUnit = null
var target_fig: Figure = null
var speed := 1.0
var instant := false
var _muted := false
var _press := {}
var _last_side := -1

var zone: MoveZone
var prefer_close := true
var _last_attacker := -1
var _blood_tex: Texture2D
var reach_mm: MultiMeshInstance3D
var path_mm: MultiMeshInstance3D
var blast_preview: MeshInstance3D

# screenshot mode
var shots_dir := ""
var _want_fight_shot := false
var _kill_shot := -1            # screenshots: the first fighter taken out (-2 after)
# the cinematic camera: the opening flyover and the kill camera
var _intro_on := false
var _intro_skip := false
var _last_killcam := -100000
var _fight_focus: Array = []

func _ready() -> void:
	shots_dir = Game.shots_dir
	speed = Game.anim_speed
	watch_all = Game.autoplay
	st = BattleState.new()
	var seed_v: int = Game.seed_value if Game.seed_value != 0 else int(Time.get_unix_time_from_system()) % 100000
	st.setup(Game.map_id, Game.player_warband, Game.enemy_warband, seed_v, Game.autoplay, true, Game.battle_rosters if Game.campaign != null else [[], []], Game.scenario)
	st.set_weather(Game.weather if Game.campaign == null else "random", seed_v)
	if Game.selftest:
		instant = true
	for s in range(2):
		if st.sides[s]["ai"]:
			ais[s] = WarbandAI.new(st, s)
	var centre := Vector3(st.map.w * st.map.cell * 0.5, 0, st.map.d * st.map.cell * 0.5)
	atm = Atmosphere.new()
	add_child(atm)
	atm.build(centre, Game.graphics, st.weather, Vector3(st.map.w * st.map.cell, 0, st.map.d * st.map.cell))
	atm.calm = shots_dir != "" or Game.selftest
	city = CityBuilder.new()
	add_child(city)
	city.build(st.map, st.shard_nodes)
	for nd in st.cache_spots:
		city.add_dig_spot(nd)
	crows = Crows.new()
	add_child(crows)
	crows.fighters_fn = _standing_positions
	crows.build(st.map, figs, seed_v, 18)
	units_root = Node3D.new()
	add_child(units_root)
	fx_root = Node3D.new()
	add_child(fx_root)
	for u in st.units:
		_make_figure(u)
	_make_markers()
	if st.hold_radius > 0.0:
		_make_ring()
	if st.through_need > 0:
		_make_zones()
	rig = CameraRig.new()
	add_child(rig)
	rig.bounds = AABB(Vector3(-4, 0, -4), Vector3(st.map.w * st.map.cell + 8, 12, st.map.d * st.map.cell + 8))
	var start_focus := _side_centre(player_side)
	rig.set_view(0.0, 0.92, 28.0, true)
	rig.focus(start_focus.lerp(centre, 0.45), true)
	hud = Hud.new()
	hud.weather_short = "" if st.weather == "still" else BattleState.WEATHERS[st.weather]["short"]
	add_child(hud)
	hud.action.connect(_on_hud_action)
	hud.end_turn.connect(_on_end_turn)
	hud.pick_unit.connect(func(id): _select(st.unit_by_id(id)))
	hud.result_choice.connect(_on_result_choice)
	_refresh_all()
	hud.show_unit(null, st)
	if shots_dir != "":
		instant = true
	Sfx.music("music_battle", 3.0)
	Sfx.ambience("amb_ruins")
	await get_tree().process_frame
	st.begin()
	await _play_events()
	if shots_dir != "":
		await _opening_shots()
	elif _cinematic():
		await _intro()
	_run()

func _standing_positions() -> Array:
	var out: Array = []
	for u in st.units:
		if u.status != "ooa" and figs.has(u.id):
			out.append((figs[u.id] as Node3D).global_position)
	return out

func _side_centre(s: int) -> Vector3:
	var c := Vector3.ZERO
	var n := 0
	for u in st.side_units(s):
		c += st.pos(u)
		n += 1
	return c / max(n, 1)

# ------------------------------------------------------------------ figures and markers

func _make_figure(u: BUnit) -> void:
	var f := Figure.new()
	units_root.add_child(f)
	f.setup(u, st.sides[u.side]["wb"])
	f.position = st.pos(u)
	f.rotation.y = PI if u.side == 0 else 0.0
	figs[u.id] = f
	f.xray.visible = u.side == player_side
	var body := StaticBody3D.new()
	body.collision_layer = UNIT_LAYER
	body.collision_mask = 0
	body.set_meta("unit_id", u.id)
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.5
	cap.height = 2.0
	cs.shape = cap
	cs.position = Vector3(0, 1.0, 0)
	body.add_child(cs)
	f.add_child(body)
	bodies[u.id] = body

func _make_zones() -> void:
	## Through their lines: the enemy's starting ground glows jade (get
	## there), your own glows blood-red (keep them off it). The brighter
	## edge faces the middle of the field.
	for zs in range(2):
		var rows: Array = []
		for c in st.map.data["deploy"][str(zs)]:
			if not rows.has(int(c[1])):
				rows.append(int(c[1]))
		if rows.is_empty():
			continue
		var z0: int = rows.min()
		var z1: int = rows.max()
		var inner_low := z0 > st.map.d / 2     # the inner edge is the zone's low-z side
		var col := Color(0.4, 1.0, 0.6) if zs != player_side else Color(1.0, 0.25, 0.18)
		var n := 128
		var img := Image.create(8, n, false, Image.FORMAT_RGBA8)
		for y in range(n):
			var f := float(y) / float(n - 1)
			var d := f if inner_low else 1.0 - f
			var a := clampf(1.0 - d / 0.06, 0.0, 1.0) * 0.95 + 0.1
			for x in range(8):
				img.set_pixel(x, y, Color(col.r * a, col.g * a, col.b * a, a))
		var tex := ImageTexture.create_from_image(img)
		var dec := Decal.new()
		var depth := float(z1 - z0 + 1) * st.map.cell
		dec.size = Vector3(st.map.w * st.map.cell, 40.0, depth)
		dec.texture_albedo = tex
		dec.texture_emission = tex
		dec.emission_energy = 1.5
		dec.albedo_mix = 0.5
		dec.normal_fade = 0.55
		dec.upper_fade = 0.05
		dec.lower_fade = 0.05
		dec.position = Vector3(st.map.w * st.map.cell * 0.5, 15.0, z0 * st.map.cell + depth * 0.5)
		add_child(dec)

func _make_ring() -> void:
	## The ground to hold: a ring of witch-fire painted over stone and roof
	## alike, with a few green flames standing round its edge.
	var r := st.hold_radius
	var n := 256
	var img := Image.create(n, n, false, Image.FORMAT_RGBA8)
	var c := Color(0.45, 1.0, 0.6)
	for y in range(n):
		for x in range(n):
			var d := Vector2(x - n * 0.5 + 0.5, y - n * 0.5 + 0.5).length() / (n * 0.5)
			var rim := clampf(1.0 - absf(d - 0.95) / 0.04, 0.0, 1.0)
			var inside := 0.08 if d < 0.95 else 0.0
			var a := maxf(rim, inside) * (1.0 if d <= 1.0 else 0.0)
			img.set_pixel(x, y, Color(c.r * a, c.g * a, c.b * a, a))
	var tex := ImageTexture.create_from_image(img)
	var dec := Decal.new()
	dec.size = Vector3(r * 2.0, 40.0, r * 2.0)
	dec.texture_albedo = tex
	dec.texture_emission = tex
	dec.emission_energy = 2.5
	dec.albedo_mix = 0.6
	dec.normal_fade = 0.55
	dec.upper_fade = 0.05
	dec.lower_fade = 0.05
	dec.position = st.objective + Vector3(0, 15.0, 0)
	add_child(dec)
	var glow := Mats.glow(Color(0.4, 1.0, 0.55), 4.0, true)
	for i in range(8):
		var a := i * TAU / 8.0
		var p := st.objective + Vector3(cos(a), 0, sin(a)) * r
		var x := int(floor(p.x / st.map.cell))
		var z := int(floor(p.z / st.map.cell))
		if x < 0 or z < 0 or x >= st.map.w or z >= st.map.d:
			continue
		p.y = st.map.h_at(x, z) * st.map.storey
		var l := OmniLight3D.new()
		l.light_color = Color(0.4, 1.0, 0.6)
		l.light_energy = 1.2
		l.omni_range = 5.0
		l.position = p + Vector3(0, 0.8, 0)
		add_child(l)
		var mi := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = 0.12
		sm.height = 0.24
		mi.mesh = sm
		mi.material_override = glow
		mi.position = p + Vector3(0, 0.5, 0)
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(mi)

func _make_markers() -> void:
	var disc := CylinderMesh.new()
	disc.top_radius = 0.42
	disc.bottom_radius = 0.42
	disc.height = 0.04
	disc.radial_segments = 20
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.vertex_color_use_as_albedo = true
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.disable_fog = true
	disc.material = m
	reach_mm = MultiMeshInstance3D.new()
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	mm.mesh = disc
	reach_mm.multimesh = mm
	reach_mm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(reach_mm)
	var dot := SphereMesh.new()
	dot.radius = 0.09
	dot.height = 0.18
	dot.radial_segments = 8
	dot.rings = 4
	var dm := StandardMaterial3D.new()
	dm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	dm.vertex_color_use_as_albedo = true
	dm.disable_fog = true
	dot.material = dm
	path_mm = MultiMeshInstance3D.new()
	var pm := MultiMesh.new()
	pm.transform_format = MultiMesh.TRANSFORM_3D
	pm.use_colors = true
	pm.mesh = dot
	path_mm.multimesh = pm
	path_mm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(path_mm)
	blast_preview = MeshInstance3D.new()
	var bm := CylinderMesh.new()
	bm.top_radius = 1.0
	bm.bottom_radius = 1.0
	bm.height = 0.05
	bm.radial_segments = 32
	blast_preview.mesh = bm
	var bmat := StandardMaterial3D.new()
	bmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	bmat.albedo_color = Color(1.0, 0.45, 0.15, 0.3)
	bmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	bmat.disable_fog = true
	blast_preview.material_override = bmat
	blast_preview.visible = false
	add_child(blast_preview)
	zone = MoveZone.new()
	add_child(zone)

func _known(u: BUnit) -> bool:
	return watch_all or u.side == player_side or st.known(player_side, u)

func _refresh_visibility() -> void:
	for u in st.units:
		var f: Figure = figs[u.id]
		if u.status == "ooa":
			(bodies[u.id] as StaticBody3D).collision_layer = 0
			continue
		var k := _known(u)
		f.visible = k
		(bodies[u.id] as StaticBody3D).collision_layer = UNIT_LAYER if k else 0
	# ghosts where hidden enemies were last seen
	var want := {}
	for id in st.last_seen[player_side]:
		var u := st.unit_by_id(id)
		if u == null or not u.alive() or _known(u):
			continue
		want[id] = st.last_seen[player_side][id]
	for id in ghosts.keys():
		if not want.has(id):
			ghosts[id].queue_free()
			ghosts.erase(id)
	for id in want:
		if not ghosts.has(id):
			ghosts[id] = _make_ghost(st.unit_by_id(id))
		ghosts[id].position = st.map.node_pos(want[id])

func _make_ghost(u: BUnit) -> Node3D:
	var g := Node3D.new()
	var mi := MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = 0.3
	cm.height = 1.7
	mi.mesh = cm
	mi.position = Vector3(0, 0.85, 0)
	var wb: Dictionary = st.sides[u.side]["wb"]
	mi.material_override = Mats.ghost(Color(wb["color"][0], wb["color"][1], wb["color"][2], 0.28).lightened(0.2))
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	g.add_child(mi)
	var l := Label3D.new()
	l.text = "%s?\nlast seen here" % u.name
	l.font = Figure.font()
	l.font_size = 30
	l.pixel_size = 0.005
	l.outline_size = 8
	l.modulate = Color(1, 0.75, 0.7, 0.85)
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.no_depth_test = true
	l.position = Vector3(0, 2.2, 0)
	g.add_child(l)
	units_root.add_child(g)
	return g

var _want_box_shot := -1          # screenshots: the finder, once (-2 after)
var _box_on := -1                 # unit id whose figure carries the strongbox model
var _box_model: Node3D = null

func _sync_box() -> void:
	## Put the strongbox model on whoever holds it now.
	if _box_on == st.cache_holder:
		return
	if _box_model != null:
		_box_model.queue_free()
		_box_model = null
	_box_on = st.cache_holder
	if _box_on >= 0 and figs.has(_box_on):
		_box_model = CityBuilder.make_strongbox()
		_box_model.scale = Vector3.ONE * 0.62
		_box_model.position = Vector3(0, 1.02, -0.32)
		_box_model.rotation.x = -0.12
		var glint := OmniLight3D.new()       # a lantern's worth of light on the brass
		glint.light_color = Color(1.0, 0.78, 0.45)
		glint.light_energy = 0.9
		glint.omni_range = 2.2
		glint.position = Vector3(0, 0.6, -0.9)
		_box_model.add_child(glint)
		figs[_box_on].add_child(_box_model)

func _cache_event(ev: Dictionary, animate: bool) -> void:
	match ev["type"]:
		"cache_empty":
			city.set_dug(ev["node"], true)
			if animate:
				_sound_at("dig_*", ev["unit"], -2.0)
				_float(ev["unit"], "nothing but bones", Color(0.8, 0.75, 0.65))
		"cache_found":
			if _want_box_shot == -1:
				_want_box_shot = ev["unit"]
			city.clear_dig_spots()
			city.set_dug(ev["node"], false)
			if animate:
				_sound_at("dig_*", ev["unit"], -2.0)
				_float(ev["unit"], "the strongbox!", Color(1.0, 0.8, 0.4), 0.6)
				_sound_at("chest", ev["unit"], 0.0, 0.0)
		"cache_take":
			city.set_box_ground(-1)
			if animate:
				_float(ev["unit"], "strongbox taken", Color(1.0, 0.8, 0.4))
				_sound_at("chest", ev["unit"], -2.0, 0.0)
		"cache_drop":
			city.set_box_ground(ev["node"])
			if animate:
				Sfx.play("chest", st.map.node_pos(ev["node"]), -1.0)
	_sync_box()

func _refresh_all() -> void:
	_sync_box()
	for u in st.units:
		var f: Figure = figs[u.id]
		if u.alive():
			f.position = st.pos(u)
	_refresh_visibility()
	_update_hud()

func _update_hud() -> void:
	if hud == null:
		return
	var names := [st.sides[0]["wb"]["short"] if st.sides[0]["wb"].has("short") else st.sides[0]["wb"]["name"],
		st.sides[1]["wb"]["short"] if st.sides[1]["wb"].has("short") else st.sides[1]["wb"]["name"]]
	var wb: Dictionary = st.sides[st.side]["wb"]
	hud.set_turn(st.round_num, st.turn_limit, wb["name"], Color(wb["color"][0], wb["color"][1], wb["color"][2]), _is_player_turn(), st.score_line(names))
	hud.set_roster(st.side_units(player_side), sel.id if sel != null else -1, st)
	if sel != null:
		hud.show_unit(sel, st, figs[sel.id])
	var en := {}
	if sel != null and _is_player_turn() and not busy and sel.side == player_side:
		en["move"] = not reach.is_empty()
		en["dash"] = st.can_act(sel) and sel.ap >= 1 and not sel.dashed and not st.engaged(sel)
		en["charge"] = not charge_cache.is_empty()
		en["shoot"] = sel.missile() != "" and not sel.shot and st.can_act(sel) and not st.engaged(sel)
		en["throw"] = sel.has_munitions() and sel.ap >= 1 and st.can_act(sel) and not st.engaged(sel)
		en["cast"] = st.can_cast(sel)
	var hint := ""
	if _is_player_turn() and not busy:
		if sel == null or not st.can_act(sel):
			hint = "Choose a fighter who can still act, or press Enter to end the turn."
		elif mode == "move":
			hint = "Click the glowing ground to move, an enemy to fight or shoot. Right-click or Escape cancels."
	elif not _is_player_turn() and not st.over:
		hint = "The enemy is moving…"
	hud.set_actions(en, mode, hint)

func _is_player_turn() -> bool:
	return ais[st.side] == null and not st.over

# ------------------------------------------------------------------ turn loop

func _run() -> void:
	while not st.over:
		_announce_turn()
		if ais[st.side] != null:
			await _ai_turn()
		else:
			_begin_player_turn()
			await player_done
	await _show_result()

func _announce_turn() -> void:
	if _last_side == st.side:
		return
	_last_side = st.side
	if instant:
		return
	Sfx.play("bell", null, -8.0 if ais[st.side] != null else -3.0, 0.0)
	var wb: Dictionary = st.sides[st.side]["wb"]
	if ais[st.side] == null:
		hud.toast("Your turn", UIStyle.JADE)
	else:
		hud.toast(wb["name"], Color(wb["color"][0], wb["color"][1], wb["color"][2]).lightened(0.4))

func _ai_turn() -> void:
	busy = true
	_set_selection(null)
	_clear_markers()
	_update_hud()
	var ai: WarbandAI = ais[st.side]
	var me := st.side
	var guard := 0
	while not st.over and st.side == me and guard < 500:
		guard += 1
		var act := ai.next_action()
		if act["type"] == "end":
			ai.execute(act)
			await _play_events()
			break
		var u: BUnit = act["unit"]
		var seen_before := _known(u)
		if seen_before and not instant:
			_set_selection(u if watch_all else null)
			hud.show_unit(u, st, figs[u.id])
			rig.focus(st.pos(u))
			# the enemy's turn, seen from their side of the street
			_cam_follow(u, _ai_look(act))
			await _wait(0.45)
		var res := ai.execute(act)
		if not res.get("ok", false):
			u.ai_done = true
		_muted = not (seen_before or _known(u)) and not watch_all
		await _play_events()
		_muted = false
		if _want_fight_shot and shots_dir != "":
			_want_fight_shot = false
			await _fight_shot()
		if _want_box_shot >= 0 and shots_dir != "":
			await _box_shot(st.unit_by_id(_want_box_shot))
			_want_box_shot = -2
		if _kill_shot >= 0 and shots_dir != "" and _fight_focus.size() > 0 and not _want_fight_shot:
			await _kill_cam_shot(st.unit_by_id(_kill_shot))
			_kill_shot = -2
		if (seen_before or _known(u)) and not instant:
			await _wait(0.2)
	_set_selection(null)

func _ai_look(act: Dictionary):
	## Where an enemy fighter is looking as it acts: its target, else our nearest.
	var t = act.get("target", null)
	if t is BUnit:
		return st.pos(t)
	if act.has("node"):
		return st.map.node_pos(int(act["node"]))
	var u: BUnit = act["unit"]
	var best = null
	var bd := 1e9
	for o in st.side_units(player_side):
		if o.alive():
			var d := st.pos(o).distance_to(st.pos(u))
			if d < bd:
				bd = d
				best = st.pos(o)
	return best

func _begin_player_turn() -> void:
	busy = false
	mode = "move"
	var first := _next_actor(null)
	_select(first)
	if first != null:
		rig.focus(st.pos(first))
		if prefer_close and not rig.is_close() and shots_dir == "" and not Game.selftest:
			rig.toggle_tactical()
		_cam_follow(first)
	_update_hud()
	if Game.selftest:
		_selftest_turn.call_deferred()

func _selftest_turn() -> void:
	## Plays the player's side through the same calls the mouse and keys use.
	var guard := 0
	while not st.over and _is_player_turn() and guard < 40:
		guard += 1
		var u := _next_actor(null)
		if u == null:
			break
		_select(u)
		for m in ["move", "charge", "shoot"]:
			_on_hud_action(m, "")
			_update_hud()
		mode = "move"
		var did := false
		for e in st.units:
			if e.side != player_side and e.alive() and _known(e):
				var a := _enemy_action(e)
				hover_unit = e
				_show_hover(Vector2(400, 300))
				if a["kind"] in ["melee", "charge", "shoot"] and not did:
					await _order(a["kind"], [e])
					did = true
		for mun in u.munitions:
			if u.munitions[mun] > 0 and st.can_act(u):
				mode = "throw:" + mun
				for e in st.units:
					if e.side != player_side and e.alive() and _known(e):
						_throw_tip(e.node)
						if st.throw_info(u, mun, e.node)["ok"] and not did:
							await _order("throw", [mun, e.node])
							did = true
				mode = "move"
		for sp in u.spells:
			if not st.can_cast(u) or did:
				break
			mode = "cast:" + sp
			var ts: Array = st.spell_targets(u, sp)
			for tg in ts:
				_cast_tip(tg)
			if not ts.is_empty():
				await _order("cast", [sp, ts[0]])
				did = true
			mode = "move"
		if not did and u.alive() and st.can_act(u) and u.mp > 0.5:
			_recompute()
			var best := -1
			var bd := INF
			var goal := st.map.node_pos(st.shard_nodes.keys()[0]) if not st.shard_nodes.is_empty() else Vector3(st.map.w, 0, st.map.d)
			for nd in reach:
				if st.occupied.has(nd) or nd == u.node:
					continue
				var d := st.map.node_pos(nd).distance_to(goal)
				if d < bd:
					bd = d
					best = nd
			if best >= 0:
				hover_node = best
				_show_hover(Vector2(400, 300))
				await _order("move", [best])
				did = true
		if not did:
			u.ap = 0
			u.mp = 0
	if not st.over and _is_player_turn():
		_on_end_turn()

func _next_actor(after: BUnit) -> BUnit:
	var mine: Array = st.side_units(player_side).filter(func(u): return u.alive())
	if mine.is_empty():
		return null
	var start := 0
	if after != null:
		start = (mine.find(after) + 1) % mine.size()
	for i in range(mine.size()):
		var u: BUnit = mine[(start + i) % mine.size()]
		if st.can_act(u) and (u.ap > 0 or u.mp > 0.5):
			return u
	return null

func _wait(t: float) -> void:
	if instant:
		return
	await get_tree().create_timer(t / speed).timeout

# ------------------------------------------------------------------ selection and markers

func _set_selection(u: BUnit) -> void:
	if sel != null and figs.has(sel.id):
		figs[sel.id].set_selected("")
	sel = u
	if sel != null:
		figs[sel.id].set_selected("active")

func _select(u: BUnit) -> void:
	if u == null:
		_set_selection(null)
		reach = {}
		charge_cache = {}
		_clear_markers()
		hud.show_unit(null, st)
		_update_hud()
		return
	if busy and _is_player_turn():
		return
	_set_selection(u)
	mode = "move"
	hud.fill_menus(u)
	_recompute()
	_update_hud()
	if u.side == player_side and _is_player_turn():
		_cam_follow(u)

func _recompute() -> void:
	reach = {}
	charge_cache = {}
	if sel != null and sel.side == player_side and _is_player_turn():
		reach = st.reachable(sel)
		charge_cache = st.charge_targets(sel)
	_draw_reach()

func _clear_markers() -> void:
	zone.clear()
	reach_mm.multimesh.instance_count = 0
	path_mm.multimesh.instance_count = 0
	blast_preview.visible = false
	if target_fig != null:
		target_fig.set_selected("")
		target_fig = null

func _draw_reach() -> void:
	## The ground the fighter can still reach, as one glowing area.
	reach_mm.multimesh.instance_count = 0
	if mode == "move" and sel != null and not reach.is_empty():
		zone.show_reach(st.map, reach, sel.node)
	else:
		zone.clear()

func _snap_reach(p: Vector3) -> int:
	## The reachable spot nearest a point on the ground, so a click anywhere
	## inside the glowing area moves there.
	var best := -1
	var bd := 1.7
	for nd in reach:
		if nd == sel.node or st.occupied.has(nd):
			continue
		var q := st.map.node_pos(nd)
		if absf(q.y - p.y) > 1.2:
			continue
		var d := Vector2(q.x - p.x, q.z - p.z).length()
		if d < bd:
			bd = d
			best = nd
	return best

func _cam_follow(u: BUnit, look = null) -> void:
	## Over the shoulder of this fighter (or above them, in the tactical view).
	if u == null or not figs.has(u.id) or shots_dir != "" or Game.selftest:
		return
	rig.follow(figs[u.id], true, false, look)

func _draw_path(nd: int) -> void:
	var pts: Array = []
	var path := st.path_to(reach, nd)
	for i in range(1, path.size()):
		var a := st.map.node_pos(path[i - 1]) + Vector3(0, 0.15, 0)
		var b := st.map.node_pos(path[i]) + Vector3(0, 0.15, 0)
		var kind: String = reach[path[i]]["kind"]
		var segs := []
		if abs(a.y - b.y) > 0.5 and kind != "jump":
			var mid := Vector3(lerpf(a.x, b.x, 0.5), a.y, lerpf(a.z, b.z, 0.5))
			var mid2 := Vector3(mid.x, b.y, mid.z)
			segs = [[a, mid], [mid, mid2], [mid2, b]]
		else:
			segs = [[a, b]]
		for sgm in segs:
			var p0: Vector3 = sgm[0]
			var p1: Vector3 = sgm[1]
			var n := int(ceil(p0.distance_to(p1) / 0.45))
			for j in range(n):
				var t := float(j) / n
				var p := p0.lerp(p1, t)
				if kind == "jump":
					p.y += sin(t * PI) * 1.0
				pts.append(p)
	pts.append(st.map.node_pos(nd) + Vector3(0, 0.15, 0))
	var mm := path_mm.multimesh
	mm.instance_count = pts.size()
	for i in range(pts.size()):
		mm.set_instance_transform(i, Transform3D(Basis(), pts[i]))
		mm.set_instance_color(i, Color(0.55, 1.0, 0.9) if i < pts.size() - 1 else Color(1, 1, 1))

# ------------------------------------------------------------------ input

func _unhandled_input(event: InputEvent) -> void:
	if _intro_on:
		if (event is InputEventKey and event.pressed) or (event is InputEventMouseButton and event.pressed):
			_intro_skip = true
			get_viewport().set_input_as_handled()
		return
	if event is InputEventKey and event.pressed and not event.echo:
		_key(event as InputEventKey)
		return
	if event is InputEventMouseMotion:
		_hover((event as InputEventMouseMotion).position)
	elif event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.pressed:
			_press[mb.button_index] = mb.position
		else:
			var start: Vector2 = _press.get(mb.button_index, mb.position)
			if start.distance_to(mb.position) > 6.0:
				return
			if mb.button_index == MOUSE_BUTTON_LEFT:
				_click(mb.position)
			elif mb.button_index == MOUSE_BUTTON_RIGHT:
				_cancel_mode()

func _key(k: InputEventKey) -> void:
	match k.keycode:
		KEY_F1:
			hud.toggle_help()
		KEY_ESCAPE:
			if hud.help_panel.visible:
				hud.toggle_help()
			else:
				_cancel_mode()
		KEY_TAB:
			if _is_player_turn() and not busy:
				var n := _next_actor(sel)
				if n != null:
					_select(n)
					rig.focus(st.pos(n))
		KEY_SPACE:
			if sel != null:
				rig.focus(st.pos(sel))
				_cam_follow(sel)
		KEY_V:
			prefer_close = not rig.is_close()
			rig.toggle_tactical()
			prefer_close = rig.is_close()
			if sel != null:
				_cam_follow(sel)
			hud.toast("Close view" if prefer_close else "Tactical view", UIStyle.DIM)
		KEY_ENTER, KEY_KP_ENTER:
			_on_end_turn()
		KEY_1:
			_on_hud_action("move", "")
		KEY_2:
			_on_hud_action("dash", "")
		KEY_3:
			_on_hud_action("charge", "")
		KEY_4:
			_on_hud_action("shoot", "")
		KEY_5:
			if sel != null and sel.has_munitions():
				hud.open_menu("throw")
		KEY_6:
			if sel != null and not sel.spells.is_empty():
				hud.open_menu("cast")

func _raycast(mp: Vector2) -> Dictionary:
	var cam := rig.cam
	var from := cam.project_ray_origin(mp)
	var to := from + cam.project_ray_normal(mp) * 600.0
	var q := PhysicsRayQueryParameters3D.create(from, to, WORLD_LAYER | UNIT_LAYER)
	return get_world_3d().direct_space_state.intersect_ray(q)

func _hover(mp: Vector2) -> void:
	if hud.help_panel.visible:
		return
	var hit := _raycast(mp)
	var hu: BUnit = null
	var hn := -1
	if not hit.is_empty():
		var col: Object = hit["collider"]
		if col.has_meta("unit_id"):
			hu = st.unit_by_id(int(col.get_meta("unit_id")))
		else:
			hn = city.node_from_hit(hit["position"], hit["normal"])
			if mode == "move" and sel != null and not reach.is_empty() and (not reach.has(hn) or hn == sel.node or st.occupied.has(hn)):
				var sn := _snap_reach(hit["position"])
				if sn >= 0:
					hn = sn
	if hn >= 0 and st.occupied.has(hn) and _known(st.occupied[hn]):
		hu = st.occupied[hn]
	if hu != null and hu.alive():
		hn = hu.node
	hover_unit = hu
	hover_node = hn
	_show_hover(mp)

func _show_hover(mp: Vector2) -> void:
	path_mm.multimesh.instance_count = 0
	blast_preview.visible = false
	if target_fig != null:
		target_fig.set_selected("")
		target_fig = null
	var tip := ""
	var odds := ""
	var mine := sel != null and _is_player_turn() and not busy and sel.side == player_side
	if hover_unit != null and hover_unit != sel and hover_unit.alive():
		var f: Figure = figs[hover_unit.id]
		if hover_unit.side != player_side:
			target_fig = f
			f.set_selected("target")
			if mine:
				var a := _enemy_action(hover_unit)
				odds = a["text"]
				tip = a["text"]
		else:
			target_fig = f
			f.set_selected("ally")
			if mine and mode.begins_with("cast:"):
				tip = _cast_tip(hover_unit)
			else:
				tip = "Select [b]%s[/b]" % hover_unit.name
		hud.show_target(hover_unit if hover_unit.side != player_side else null, st, odds)
	else:
		hud.show_target(null, st, "")
		if mine and hover_node >= 0:
			if mode == "move" and reach.has(hover_node) and hover_node != sel.node and not st.occupied.has(hover_node):
				_draw_path(hover_node)
				tip = _move_tip(hover_node)
			elif mode.begins_with("throw:"):
				tip = _throw_tip(hover_node)
			elif mode.begins_with("cast:"):
				tip = _cast_tip(hover_node)
	hud.show_tip(tip, mp)

func _move_tip(nd: int) -> String:
	var info: Dictionary = reach[nd]
	var t := "[b]Move[/b]  %.1f m  ·  %.1f m left" % [info["cost"], sel.mp - info["cost"]]
	var path := st.path_to(reach, nd)
	var notes: Array = []
	for i in range(1, path.size()):
		var k: String = reach[path[i]]["kind"]
		var lv: int = reach[path[i]]["levels"]
		if k == "jump" and not notes.has("jump"):
			notes.append("jump")
		elif k == "drop" and lv >= 1 and not (lv == 1 and st.map.is_wet(path[i])) and not notes.has("drop"):
			notes.append("drop")
		if st.map.is_wet(path[i]) and not notes.has("wade"):
			notes.append("wade")
		elif (k == "climb" or k == "stairs") and not notes.has("climb"):
			notes.append("climb")
	if notes.has("jump"):
		t += "\n[color=#f0c060]Jump the gap: Initiative test (%d or less) or fall[/color]" % sel.stat("I")
	if notes.has("drop"):
		t += "\n[color=#f0c060]Drop down: Initiative test or land badly[/color]"
	if notes.has("climb"):
		t += "\nClimbs a ladder or stair"
	if notes.has("wade"):
		t += "\nWades through flood water, which slows the going"
	if st.engaged(sel):
		t += "\n[color=#e06a50]Breaking away costs an action, and each enemy gets a free strike[/color]"
	if st.shard_nodes.has(nd):
		t += "\n[color=#5fe0c0]Pick up the godshard[/color]"
	return t

func _pct(p: float) -> String:
	return "%d%%" % int(round(clampf(p, 0.0, 1.0) * 100.0))

func _melee_odds(u: BUnit, e: BUnit, charging: bool) -> String:
	var w := u.best_melee_weapon()
	var wd := GameData.weapon(w)
	var s: int = u.stat("S") + int(wd.get("str", 0))
	var auto := e.status == "down" or e.status == "stunned"
	var hit := Rules.melee_to_hit(u.stat("WS"), e.stat("WS"))
	var p_hit := 1.0 if auto else Rules.p_success(hit)
	var wound := Rules.to_wound(s, e.stat("T"))
	var sv := Rules.save_needed(e.armour_save(), s, int(wd.get("save_mod", 0)))
	var n := st.attack_count(u, charging)
	var p1 := p_hit * Rules.p_success(wound) * Rules.p_unsaved(sv)
	var p_any := 1.0 - pow(1.0 - p1, n)
	var hit_s := "hits automatically" if auto else "hit %d+" % hit
	var sv_s := "no save" if sv >= 7 else "save %d+" % sv
	var t := "%d attack%s with %s  ·  %s  ·  wound %s  ·  %s" % [n, "" if n == 1 else "s", String(wd.get("name", w)).to_lower(), hit_s, ("%d+" % wound) if wound <= 6 else "impossible", sv_s]
	if e.status == "stunned":
		t += "\n[color=#f09050]Stunned: any wound takes them out of action[/color]"
	if e.can_parry() and not auto:
		t += "\nThey can parry one blow"
	t += "\n[color=#5fe0c0]%s chance to wound at least once[/color]" % _pct(p_any)
	return t

func _enemy_action(e: BUnit) -> Dictionary:
	var u := sel
	if not st.can_act(u):
		return {"kind": "", "text": "[b]%s[/b]\n%s cannot act now." % [e.name, u.name]}
	if mode.begins_with("throw:"):
		return {"kind": "throw", "text": _throw_tip(e.node)}
	if mode.begins_with("cast:"):
		return {"kind": "cast", "text": _cast_tip(e)}
	if mode != "shoot" and st.is_adjacent(u, e) and u.ap >= 1:
		return {"kind": "melee", "text": "[b]Strike %s[/b]  (1 action)\n%s" % [e.name, _melee_odds(u, e, false)]}
	if mode != "shoot" and charge_cache.has(e.id):
		return {"kind": "charge", "text": "[b]Charge %s[/b]  (uses your move and 1 action)\n%s" % [e.name, _melee_odds(u, e, true)]}
	if u.missile() != "" and mode != "charge":
		var info := st.shot_info(u, e)
		if info["ok"]:
			var wd := GameData.weapon(info["weapon"])
			var mods: Array = info["mods"]
			var t := "[b]Shoot %s[/b] with %s  ·  %d m\nHit %d+%s  ·  %s chance to hit" % [e.name, String(wd["name"]).to_lower(), int(info["range"]), info["need"], ("  (" + ", ".join(mods) + ")") if not mods.is_empty() else "", _pct(info["p_hit"])]
			t += "\n[color=#5fe0c0]%s chance to wound[/color]" % _pct(info["p"])
			return {"kind": "shoot", "text": t}
		if mode == "shoot":
			return {"kind": "", "text": "[b]%s[/b]\n[color=#e06a50]%s[/color]" % [e.name, info["why"]]}
	var why := "Out of reach."
	if u.moved and not st.is_adjacent(u, e):
		why = "Too far to strike, and a charge must come before moving."
	elif u.ap < 1:
		why = "No actions left."
	return {"kind": "", "text": "[b]%s[/b]\n[color=#e06a50]%s[/color]" % [e.name, why]}

func _throw_tip(nd: int) -> String:
	var mun := mode.substr(6)
	if nd < 0:
		return ""
	var info := st.throw_info(sel, mun, nd)
	var md := GameData.munition(mun)
	var blast := int(md.get("blast", 0))
	if blast > 0:
		blast_preview.visible = true
		blast_preview.position = st.map.node_pos(nd) + Vector3(0, 0.08, 0)
		var r := blast * st.map.cell * 1.45
		blast_preview.scale = Vector3(r, 1, r)
	if not info["ok"]:
		return "[b]%s[/b]\n[color=#e06a50]%s[/color]" % [md.get("name", mun), info.get("why", info.get("msg", ""))]
	return "[b]Throw %s[/b]  ·  %d m\nOn target with %d+, otherwise it bounces up to 3 spaces\nStrength %d%s" % [md["name"], int(info["range"]), info["need"], md["str"], (", Strength %d to everyone within %d m" % [md.get("blast_str", 0), int(blast * st.map.cell * 1.45)]) if blast > 0 else ""]

func _cast_tip(target) -> String:
	var sp := mode.substr(5)
	var sd := GameData.spell(sp)
	var targets := st.spell_targets(sel, sp)
	var t: Variant = target
	if sd["target"] == "node":
		if typeof(target) != TYPE_INT:
			return ""
	elif typeof(target) == TYPE_INT:
		t = st.occupied.get(target, null)
		if t == null:
			if sd["target"] == "self":
				t = sel
			else:
				return ""
	if sd["target"] == "self":
		t = sel
	var ok := targets.has(t)
	var p := 0.0
	for a in range(1, 7):
		for b in range(1, 7):
			if a == 1 and b == 1:
				continue
			if a + b + (1 if sel.has_skill("adept") else 0) >= int(sd["diff"]):
				p += 1.0 / 36.0
	if not ok:
		return "[b]%s[/b]\n[color=#e06a50]Not a valid target (range %d m, must be seen).[/color]" % [sd["name"], sd["range"]]
	return "[b]Cast %s[/b]  ·  needs %d+ on two dice  ·  %s\n%s\nA double one wounds the caster." % [sd["name"], sd["diff"], _pct(p), sd["desc"]]

func _click(mp: Vector2) -> void:
	if hud.help_panel.visible:
		hud.toggle_help()
		return
	if busy or not _is_player_turn():
		return
	_hover(mp)
	if hover_unit != null and hover_unit.alive():
		if hover_unit.side == player_side:
			if mode.begins_with("cast:") and sel != null and st.spell_targets(sel, mode.substr(5)).has(hover_unit):
				_order("cast", [mode.substr(5), hover_unit])
				return
			_select(hover_unit)
			return
		if sel == null:
			return
		var a := _enemy_action(hover_unit)
		match a["kind"]:
			"melee":
				_order("melee", [hover_unit])
			"charge":
				_order("charge", [hover_unit])
			"shoot":
				_order("shoot", [hover_unit])
			"throw":
				_order("throw", [mode.substr(6), hover_unit.node])
			"cast":
				if st.spell_targets(sel, mode.substr(5)).has(hover_unit):
					_order("cast", [mode.substr(5), hover_unit])
			_:
				hud.toast("Cannot do that", UIStyle.BLOOD)
		return
	if sel == null or hover_node < 0:
		return
	if mode == "move" and reach.has(hover_node) and hover_node != sel.node and not st.occupied.has(hover_node):
		_order("move", [hover_node])
	elif mode.begins_with("throw:"):
		_order("throw", [mode.substr(6), hover_node])
	elif mode.begins_with("cast:"):
		var sp := mode.substr(5)
		var sd := GameData.spell(sp)
		if sd["target"] == "node" and st.spell_targets(sel, sp).has(hover_node):
			_order("cast", [sp, hover_node])
		elif sd["target"] == "self":
			_order("cast", [sp, sel])

func _cancel_mode() -> void:
	if mode != "move":
		mode = "move"
		_draw_reach()
		_update_hud()

func _on_hud_action(nm: String, arg: String) -> void:
	if busy or not _is_player_turn() or sel == null:
		return
	match nm:
		"move":
			mode = "move"
		"dash":
			_order("dash", [])
			return
		"charge":
			mode = "charge"
		"shoot":
			mode = "shoot"
		"throw":
			mode = "throw:" + arg
		"cast":
			var sd := GameData.spell(arg)
			if sd["target"] == "self":
				_order("cast", [arg, sel])
				return
			mode = "cast:" + arg
	_draw_reach()
	_update_hud()

func _order(kind: String, args: Array) -> void:
	if busy:
		return
	busy = true
	_clear_markers()
	hud.show_tip("", Vector2.ZERO)
	hud.show_target(null, st, "")
	var u := sel
	var res: Dictionary = {}
	match kind:
		"move":
			res = st.move(u, args[0])
		"dash":
			res = st.dash(u)
		"charge":
			res = st.charge(u, args[0])
		"melee":
			res = st.melee(u, args[0])
		"shoot":
			res = st.shoot(u, args[0])
		"throw":
			res = st.throw_munition(u, args[0], args[1])
		"cast":
			res = st.cast(u, args[0], args[1])
	if Game.selftest:
		print("order ", kind, " by ", u.name, ": ", "ok" if res.get("ok", false) else String(res.get("msg", "refused")))
	if not res.get("ok", false):
		hud.toast(String(res.get("msg", "Cannot do that.")), UIStyle.BLOOD)
	await _play_events()
	busy = false
	mode = "move"
	if st.over:
		player_done.emit()
		return
	if u.status == "ooa" or not st.can_act(u) or (u.ap == 0 and u.mp < 0.5):
		var n := _next_actor(u)
		if n != null:
			_select(n)
			rig.focus(st.pos(n))
		else:
			_select(u if u.alive() else null)
	else:
		_select(u)
	_update_hud()

func _on_end_turn() -> void:
	if busy or not _is_player_turn():
		return
	busy = true
	_set_selection(null)
	_clear_markers()
	hud.show_target(null, st, "")
	st.end_turn()
	await _play_events()
	player_done.emit()

# ------------------------------------------------------------------ playing back events

func _play_events() -> void:
	while not st.events.is_empty():
		var ev: Dictionary = st.events.pop_front()
		if instant:
			_apply_instant(ev)
		else:
			await _play(ev)
	_refresh_all()

func _apply_instant(ev: Dictionary) -> void:
	match ev["type"]:
		"log":
			if not _muted:
				hud.log_line(ev["text"])
		"status":
			var u := st.unit_by_id(ev["unit"])
			var f: Figure = figs[u.id]
			f.set_status(u.status)
			if u.status == "ooa":
				f.visible = false
				crows.fallen(st.pos(u))
				if shots_dir != "" and _kill_shot == -1 and st.round_num >= 2:
					_kill_shot = u.id
		"pickup":
			city.remove_shard(ev["node"])
		"drop":
			city.add_shard(ev["node"])
		"cache_empty", "cache_found", "cache_take", "cache_drop":
			_cache_event(ev, false)
		"melee":
			var u := st.unit_by_id(ev["unit"])
			var t := st.unit_by_id(ev["target"])
			figs[u.id].face_point(st.pos(t))
			figs[t.id].face_point(st.pos(u))
			_last_attacker = u.id
			if shots_dir != "" and st.round_num >= 2 and _fight_focus.is_empty():
				_want_fight_shot = true
				_fight_focus = [u.id, t.id]
		"move":
			var u := st.unit_by_id(ev["unit"])
			var steps: Array = ev["steps"]
			if steps.size() >= 2:
				figs[u.id].face_point(st.map.node_pos(steps[-1]["node"]))
				figs[u.id].rotation.y += 0.0

func _play(ev: Dictionary) -> void:
	var t: String = ev["type"]
	match t:
		"log":
			if not _muted:
				hud.log_line(ev["text"])
		"move":
			await _anim_move(st.unit_by_id(ev["unit"]), ev["steps"])
		"melee":
			var u := st.unit_by_id(ev["unit"])
			var tg := st.unit_by_id(ev["target"])
			if _muted:
				return
			_last_attacker = u.id
			if rig.is_close() and (u.side == player_side or _known(u)):
				_cam_follow(u, st.pos(tg))
			figs[tg.id].face_point(st.pos(u))
			figs[u.id].lunge(st.pos(tg), speed)
			if _known(u) or _known(tg):
				Sfx.play("swing_*", st.pos(u) + Vector3(0, 1.2, 0))
			await _wait(0.4)
		"miss":
			_float(ev["unit"], "miss", Color(0.75, 0.75, 0.75))
			_sound_at("whiff", ev["unit"])
			await _wait(0.25)
		"parry":
			_float(ev["unit"], "parried", Color(0.7, 0.9, 1.0))
			_sound_at("parry", ev["unit"])
			await _wait(0.3)
		"bounce":
			_float(ev["unit"], "no wound", Color(0.75, 0.75, 0.75))
			_sound_at("clash_*", ev["unit"], -3.0)
			await _wait(0.25)
		"saved":
			_float(ev["unit"], "armour saves", Color(0.6, 0.9, 1.0))
			_sound_at("clash_*", ev["unit"])
			await _wait(0.3)
		"hurt":
			var hu := st.unit_by_id(ev["unit"])
			_float(ev["unit"], "wounded", Color(1.0, 0.4, 0.3))
			_sound_at("hit_*", ev["unit"], 2.0)
			if figs.has(ev["unit"]) and _known(hu) and not _muted:
				var src := st.pos(st.unit_by_id(_last_attacker)) if _last_attacker >= 0 else Vector3.ZERO
				figs[ev["unit"]].flinch(src, true)
				_blood(st.pos(hu) + Vector3(0, 1.2, 0), st.pos(hu) - src if src != Vector3.ZERO else Vector3.UP, false)
				_blood_pool(st.pos(hu), 0.7)
				rig.punch(0.55, st.pos(hu) - src if src != Vector3.ZERO else Vector3.ZERO)
				if hu.side == player_side:
					hud.flash(Color(0.6, 0.0, 0.0, 0.32))
				await _hitstop(0.07)
			await _wait(0.3)
		"status":
			var u := st.unit_by_id(ev["unit"])
			figs[u.id].set_status(u.status)
			if (u.status == "down" or u.status == "stunned" or u.status == "ooa") and _known(u) and not _muted:
				rig.punch(0.8 if u.status == "ooa" else 0.6)
				_blood_pool(st.pos(u), 1.3 if u.status == "ooa" else 0.9)
				if u.status == "ooa":
					_blood(st.pos(u) + Vector3(0, 0.6, 0), Vector3.UP, true)
			if u.status == "down" or u.status == "stunned":
				_sound_at("groan_*", u.id, -2.0, 0.12)
			elif u.status == "ooa":
				_sound_at("groan_*", u.id, 1.0, 0.1)
				_sound_at("fall", u.id, -2.0)
				crows.fallen(st.pos(u))
			var txt := {"down": "knocked down", "stunned": "stunned", "ooa": "out of action", "ok": "back on their feet"}
			var col := {"down": Color(1.0, 0.8, 0.4), "stunned": Color(1.0, 0.55, 0.3), "ooa": Color(1.0, 0.3, 0.25), "ok": Color(0.6, 1.0, 0.8)}
			_float(u.id, txt.get(u.status, u.status), col.get(u.status, Color.WHITE), 1.0 if u.status == "ooa" else 0.0)
			if u.status == "ooa" and _known(u) and not _muted and not instant and _cinematic() and Time.get_ticks_msec() - _last_killcam > 6000:
				await _killcam(u)
			await _wait(0.45 if u.status != "ok" else 0.2)
		"roll":
			if not _muted and _known(st.unit_by_id(int(ev["unit"]))):
				var ru := st.unit_by_id(int(ev["unit"]))
				var wbc: Array = st.sides[ru.side]["wb"]["color"]
				hud.show_roll(String(ev["label"]), int(ev["value"]), int(ev["need"]), bool(ev["ok"]), int(ev.get("d", 6)), ru.name, Color(wbc[0], wbc[1], wbc[2]))
				await _wait(0.16)
		"pickup":
			city.remove_shard(ev["node"])
			_float(ev["unit"], "godshard taken", Color(0.4, 1.0, 0.85))
			_sound_at("shard", ev["unit"], -3.0, 0.0)
			await _wait(0.3)
		"drop":
			city.add_shard(ev["node"])
		"cache_empty", "cache_found", "cache_take", "cache_drop":
			_cache_event(ev, not _muted)
			await _wait(0.5 if ev["type"] == "cache_found" else 0.25)
		"shot":
			await _anim_shot(st.unit_by_id(ev["unit"]), st.unit_by_id(ev["target"]), ev["hit"])
		"blast":
			await _anim_blast(st.unit_by_id(ev["unit"]), ev["node"], int(ev["radius"]), String(ev["munition"]))
		"cast":
			await _anim_cast(st.unit_by_id(ev["unit"]), String(ev["spell"]), bool(ev["ok"]), ev.get("target", -1))
		"teleport":
			var u := st.unit_by_id(ev["unit"])
			var f: Figure = figs[u.id]
			_sound_at("shadow", u.id)
			var tw := create_tween()
			tw.tween_property(f, "scale", Vector3(0.05, 1.3, 0.05), 0.2 / speed)
			await tw.finished
			f.position = st.map.node_pos(ev["node"])
			var tw2 := create_tween()
			tw2.tween_property(f, "scale", Vector3.ONE, 0.25 / speed)
			await tw2.finished
		"spotting":
			_refresh_visibility()

func _anim_move(u: BUnit, steps: Array) -> void:
	var f: Figure = figs[u.id]
	var final := st.map.node_pos(steps[-1]["node"])
	if _muted or not _known(u):
		f.position = final
		return
	f.moving = true
	var prev: Vector3 = f.position
	for i in range(1, steps.size()):
		var nd: int = steps[i]["node"]
		var kind: String = steps[i]["kind"]
		var p := st.map.node_pos(nd)
		f.face_point(p)
		f.motion = "climb" if kind == "climb" else ("air" if kind == "jump" or kind == "fall" or kind == "drop" else "walk")
		var wet := st.map.is_wet(nd)
		if kind == "climb":
			Sfx.play("ladder", prev, -2.0, 0.15)
		elif kind == "fall" and not wet:
			Sfx.play("fall", p)
		elif wet and kind != "walk" and kind != "stairs":
			pass   # the plunge is played when the feet hit the water
		elif wet or st.map.is_wet(steps[i - 1]["node"]):
			Sfx.play("splash_*", prev, -7.0, 0.14)
		elif i % 2 == 1 or kind == "jump" or kind == "drop":
			Sfx.play("step_*", prev, -6.0 if kind == "walk" else -2.0, 0.12)
		var tw := create_tween()
		var walk_speed := 4.5 * speed
		match kind:
			"walk":
				tw.tween_property(f, "position", p, prev.distance_to(p) / walk_speed)
			"climb", "stairs":
				var frac := 0.45 if p.y > prev.y else 0.55
				var edge := Vector3(lerpf(prev.x, p.x, frac), prev.y, lerpf(prev.z, p.z, frac))
				var top := Vector3(edge.x, p.y, edge.z)
				var climb_t := absf(p.y - prev.y) / ((1.6 if kind == "climb" else 2.4) * speed)
				tw.tween_property(f, "position", edge, edge.distance_to(prev) / walk_speed)
				tw.tween_property(f, "position", top, climb_t)
				tw.tween_property(f, "position", p, top.distance_to(p) / walk_speed)
			"jump":
				var a := prev
				var dur := 0.6 / speed
				tw.tween_method(func(k: float): f.position = a.lerp(p, k) + Vector3(0, sin(k * PI) * 1.3, 0), 0.0, 1.0, dur)
				if wet:
					tw.tween_callback(func(): _plunge(p, false))
			"drop", "fall":
				var edge2 := Vector3(lerpf(prev.x, p.x, 0.5), prev.y, lerpf(prev.z, p.z, 0.5))
				if Vector2(prev.x, prev.z).distance_to(Vector2(p.x, p.z)) < 0.2:
					edge2 = prev
				tw.tween_property(f, "position", edge2, edge2.distance_to(prev) / walk_speed)
				tw.tween_property(f, "position", Vector3(edge2.x, p.y, edge2.z), sqrt(maxf(prev.y - p.y, 0.1) / 9.8 * 2.0) / speed).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_QUAD)
				if wet:
					tw.tween_callback(func(): _plunge(p, kind == "fall"))
				tw.tween_property(f, "position", p, 0.12 / speed)
				if kind == "fall":
					tw.tween_callback(func(): rig.shake = 0.6)
			_:
				tw.tween_property(f, "position", p, prev.distance_to(p) / walk_speed)
		if (sel == u or watch_all) and rig.follow_target != f:
			rig.focus(p)
		await tw.finished
		prev = p
	f.moving = false
	f.motion = "walk"
	f.position = final

func _plunge(p: Vector3, hard: bool) -> void:
	## Feet (or a whole body) going into the flood: a splash, a spray of drops
	## and rings racing out across the water.
	var wy := st.map.water
	var at := Vector3(p.x, wy + 0.015, p.z)
	Sfx.play("splash_*", at, 2.0 if hard else -1.0, 0.1)
	Figure.spawn_ripple(fx_root, at, 3.2 if hard else 2.4, 1.6)
	var tw := create_tween()
	tw.tween_interval(0.18)
	tw.tween_callback(func(): Figure.spawn_ripple(fx_root, at, 2.0 if hard else 1.5, 1.4))
	var g := GPUParticles3D.new()
	g.one_shot = true
	g.amount = 70 if hard else 45
	g.lifetime = 0.9
	g.explosiveness = 0.92
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_RING
	pm.emission_ring_axis = Vector3.UP
	pm.emission_ring_radius = 0.3
	pm.emission_ring_inner_radius = 0.1
	pm.emission_ring_height = 0.02
	pm.direction = Vector3(0, 1, 0)
	pm.spread = 28.0
	pm.initial_velocity_min = 2.0
	pm.initial_velocity_max = 4.6 if hard else 3.6
	pm.gravity = Vector3(0, -12.0, 0)
	pm.scale_min = 0.4
	pm.scale_max = 1.0
	var grad := Gradient.new()
	grad.set_color(0, Color(0.62, 0.68, 0.72, 0.55))
	grad.set_color(grad.get_point_count() - 1, Color(0.5, 0.56, 0.6, 0.0))
	var gt := GradientTexture1D.new()
	gt.gradient = grad
	pm.color_ramp = gt
	g.process_material = pm
	var q := QuadMesh.new()
	q.size = Vector2(0.08, 0.08)
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.vertex_color_use_as_albedo = true
	m.albedo_texture = CityBuilder._soft_dot()
	q.material = m
	g.draw_pass_1 = q
	g.position = at
	fx_root.add_child(g)
	g.emitting = true
	get_tree().create_timer(2.0).timeout.connect(g.queue_free)

func _sound_at(nm: String, uid: int, db := 0.0, pv := 0.06) -> void:
	var u := st.unit_by_id(uid)
	if u == null or _muted or not _known(u):
		return
	Sfx.play(nm, st.pos(u) + Vector3(0, 1.1, 0), db, pv)

func _hitstop(t: float) -> void:
	## A heartbeat of frozen time when a blow lands.
	if instant:
		return
	Engine.time_scale = 0.06
	await get_tree().create_timer(t, true, false, true).timeout
	Engine.time_scale = 1.0

func _blood(p: Vector3, dir: Vector3, big: bool) -> void:
	var g := GPUParticles3D.new()
	g.one_shot = true
	g.explosiveness = 0.92
	g.amount = 48 if big else 30
	g.lifetime = 0.9
	var pm := ParticleProcessMaterial.new()
	var d := dir
	d.y = 0
	d = (d.normalized() + Vector3(0, 0.55, 0)).normalized() if d.length() > 0.01 else Vector3.UP
	pm.direction = d
	pm.spread = 38.0
	pm.initial_velocity_min = 1.6
	pm.initial_velocity_max = 4.2 if big else 3.4
	pm.gravity = Vector3(0, -11.0, 0)
	pm.scale_min = 0.5
	pm.scale_max = 1.3
	pm.collision_mode = ParticleProcessMaterial.COLLISION_HIDE_ON_CONTACT
	g.process_material = pm
	var q := SphereMesh.new()
	q.radius = 0.035
	q.height = 0.07
	q.radial_segments = 6
	q.rings = 3
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.32, 0.015, 0.01)
	m.roughness = 0.15
	m.metallic_specular = 0.9
	q.material = m
	g.draw_pass_1 = q
	g.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	fx_root.add_child(g)
	g.global_position = p
	g.emitting = true
	get_tree().create_timer(2.0).timeout.connect(g.queue_free)

func _blood_pool(p: Vector3, size: float) -> void:
	if _blood_tex == null:
		_blood_tex = _make_blood_tex()
	var d := Decal.new()
	d.texture_albedo = _blood_tex
	d.albedo_mix = 1.0
	d.modulate = Color(0.55, 0.03, 0.02)
	d.cull_mask = 1
	d.normal_fade = 0.6
	d.size = Vector3(size, 1.2, size)
	fx_root.add_child(d)
	d.global_position = p + Vector3(randf_range(-0.25, 0.25), 0.3, randf_range(-0.25, 0.25))
	d.rotation.y = randf() * TAU
	d.scale = Vector3(0.2, 1, 0.2)
	var tw := create_tween()
	tw.tween_property(d, "scale", Vector3.ONE, 0.9 / maxf(speed, 0.1)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)

func _make_blood_tex() -> Texture2D:
	## A splash of blood: a dark pool with ragged edges and a few droplets.
	var n := 128
	var img := Image.create(n, n, false, Image.FORMAT_RGBA8)
	var rng := RandomNumberGenerator.new()
	rng.seed = 1337
	var blobs: Array = [[Vector2(64, 64), 30.0]]
	for i in range(9):
		var a := rng.randf() * TAU
		var r := rng.randf_range(18, 46)
		blobs.append([Vector2(64, 64) + Vector2(cos(a), sin(a)) * r, rng.randf_range(4, 13)])
	for y in range(n):
		for x in range(n):
			var p := Vector2(x, y)
			var v := 0.0
			for b in blobs:
				var c: Vector2 = b[0]
				var rr: float = b[1]
				var wob := 1.0 + 0.18 * sin(atan2(p.y - c.y, p.x - c.x) * 7.0 + rr)
				v = maxf(v, 1.0 - p.distance_to(c) / (rr * wob))
			if v <= 0.0:
				continue
			var al := clampf(v * 4.0, 0.0, 1.0)
			var dark := 0.55 + 0.45 * clampf(v * 2.0, 0.0, 1.0)
			img.set_pixel(x, y, Color(dark, dark, dark, al * 0.92))
	return ImageTexture.create_from_image(img)

func _float(unit_id: int, text: String, col: Color, extra := 0.0) -> void:
	if not figs.has(unit_id):
		return
	var u := st.unit_by_id(unit_id)
	if not _known(u) or _muted:
		return
	var l := Label3D.new()
	l.text = text
	l.font = Figure.font()
	l.font_size = 48
	l.outline_size = 12
	l.pixel_size = 0.006
	l.modulate = col
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.no_depth_test = true
	l.render_priority = 10
	l.position = figs[unit_id].position + Vector3(randf_range(-0.3, 0.3), 2.6, 0)
	fx_root.add_child(l)
	var tw := create_tween()
	tw.tween_property(l, "position:y", l.position.y + 1.2 + extra, (1.3 + extra) / speed)
	tw.parallel().tween_property(l, "modulate:a", 0.0, (1.3 + extra) / speed).set_delay(0.5 / speed)
	tw.tween_callback(l.queue_free)

func _anim_shot(u: BUnit, t: BUnit, hit: bool) -> void:
	_last_attacker = u.id
	if _muted or not (_known(u) or _known(t)):
		return
	if rig.is_close() and (u.side == player_side or _known(u)):
		_cam_follow(u, st.pos(t))
	var a := st.eye(u)
	var b := st.pos(t) + Vector3(0, 1.2, 0)
	if not hit:
		var off := Vector3(randf_range(-1, 1), randf_range(-0.3, 0.8), randf_range(-1, 1)).normalized() * 1.2
		b = b + off + (b - a).normalized() * 3.0
	if u.missile() == "sling" or u.missile() == "knives" or u.missile() == "javelins":
		figs[u.id].throw_at(st.pos(t), speed)
	else:
		figs[u.id].aim(st.pos(t), speed)
	figs[t.id].face_point(st.pos(u))
	await _wait(0.42)
	var wpn := u.missile()
	Sfx.play("crossbow" if wpn == "crossbow" else ("whiff" if wpn == "sling" or wpn == "knives" or wpn == "javelins" else "bow"), st.eye(u))
	var bolt := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.04, 0.04, 0.7)
	bolt.mesh = bm
	bolt.material_override = Mats.glow(Color(1.0, 0.9, 0.7), 2.0)
	fx_root.add_child(bolt)
	bolt.position = a
	bolt.look_at_from_position(a, b, Vector3.UP)
	var tw := create_tween()
	tw.tween_property(bolt, "position", b, maxf(0.12, a.distance_to(b) / 45.0) / speed)
	await tw.finished
	bolt.queue_free()
	if hit:
		Sfx.play("arrow_hit", b)

func _anim_blast(u: BUnit, nd: int, radius: int, mun: String) -> void:
	var p := st.map.node_pos(nd) + Vector3(0, 0.4, 0)
	if not _muted and _known(u):
		figs[u.id].throw_at(p, speed)
		await _wait(0.45)
		var ball := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = 0.12
		sm.height = 0.24
		ball.mesh = sm
		ball.material_override = Mats.flat(Color(0.55, 0.45, 0.3))
		fx_root.add_child(ball)
		var a := st.eye(u)
		var tw := create_tween()
		tw.tween_method(func(k: float): ball.position = a.lerp(p, k) + Vector3(0, sin(k * PI) * 2.0, 0), 0.0, 1.0, 0.5 / speed)
		await tw.finished
		ball.queue_free()
	var r := maxf(1.2, radius * st.map.cell * 1.45)
	if not _muted:
		Sfx.play("blast" if mun == "cusser" else "cracker", p, 2.0 if mun == "cusser" else 0.0, 0.08)
	crows.scare(p, 16.0 if mun == "cusser" else 10.0)
	var flash := OmniLight3D.new()
	flash.light_color = Color(1.0, 0.6, 0.25)
	flash.light_energy = 14.0
	flash.omni_range = r * 4.0 + 4.0
	flash.position = p + Vector3(0, 1.0, 0)
	fx_root.add_child(flash)
	var orb := MeshInstance3D.new()
	var om := SphereMesh.new()
	om.radius = 1.0
	om.height = 2.0
	orb.mesh = om
	var omat := StandardMaterial3D.new()
	omat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	omat.albedo_color = Color(1.0, 0.7, 0.3, 0.9)
	omat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	omat.emission_enabled = true
	omat.emission = Color(1.0, 0.5, 0.15)
	omat.emission_energy_multiplier = 6.0
	orb.material_override = omat
	orb.position = p
	orb.scale = Vector3.ONE * 0.2
	fx_root.add_child(orb)
	var smoke := _smoke_burst(p, r)
	rig.shake = 1.0 if mun == "cusser" else 0.6
	var tw2 := create_tween()
	tw2.tween_property(orb, "scale", Vector3.ONE * r, 0.18 / speed)
	tw2.parallel().tween_property(flash, "light_energy", 0.0, 0.7 / speed)
	tw2.tween_property(omat, "albedo_color:a", 0.0, 0.3 / speed)
	await tw2.finished
	orb.queue_free()
	flash.queue_free()
	get_tree().create_timer(3.0).timeout.connect(smoke.queue_free)

func _smoke_burst(p: Vector3, r: float) -> GPUParticles3D:
	var g := GPUParticles3D.new()
	g.one_shot = true
	g.amount = 40
	g.lifetime = 2.2
	g.explosiveness = 0.95
	var pm := ParticleProcessMaterial.new()
	pm.direction = Vector3(0, 1, 0)
	pm.spread = 80.0
	pm.initial_velocity_min = 1.5
	pm.initial_velocity_max = 4.0 + r
	pm.gravity = Vector3(0, -1.0, 0)
	pm.damping_min = 2.0
	pm.damping_max = 4.0
	pm.scale_min = 0.6
	pm.scale_max = 1.6
	var grad := Gradient.new()
	grad.set_color(0, Color(1.0, 0.7, 0.3, 0.9))
	grad.add_point(0.15, Color(0.35, 0.3, 0.28, 0.7))
	grad.set_color(grad.get_point_count() - 1, Color(0.2, 0.2, 0.2, 0.0))
	var gt := GradientTexture1D.new()
	gt.gradient = grad
	pm.color_ramp = gt
	g.process_material = pm
	var q := QuadMesh.new()
	q.size = Vector2(1.2, 1.2)
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.vertex_color_use_as_albedo = true
	m.albedo_texture = CityBuilder._soft_dot()
	q.material = m
	g.draw_pass_1 = q
	g.position = p
	fx_root.add_child(g)
	g.emitting = true
	return g

func _anim_cast(u: BUnit, sp: String, ok: bool, target) -> void:
	if _muted or not _known(u):
		return
	var f: Figure = figs[u.id]
	f.cast_anim(speed)
	var col := f._warren_color(u.warren)
	var halo := OmniLight3D.new()
	halo.light_color = col
	halo.light_energy = 0.0
	halo.omni_range = 7.0
	halo.position = st.pos(u) + Vector3(0, 1.8, 0)
	fx_root.add_child(halo)
	var tw := create_tween()
	tw.tween_property(halo, "light_energy", 6.0, 0.25 / speed)
	tw.tween_property(halo, "light_energy", 0.0, 0.5 / speed)
	_float(u.id, GameData.spell(sp)["name"] if ok else "the warren slips", col if ok else Color(0.6, 0.6, 0.6))
	Sfx.play("spell" if ok else "spell_fail", st.pos(u) + Vector3(0, 1.5, 0), -2.0, 0.1)
	await tw.finished
	halo.queue_free()
	if ok and sp == "skyfire" and typeof(target) == TYPE_INT and target > 0:
		var t := st.unit_by_id(target)
		if t != null:
			Sfx.play("lightning", st.pos(t), 3.0, 0.05)
			await _lightning(st.pos(t))
	if ok and sp == "emberfall" and typeof(target) == TYPE_INT and target > 0:
		var t2 := st.unit_by_id(target)
		if t2 != null:
			await _embers(st.pos(t2))

func _embers(p: Vector3) -> void:
	## Old hearth-fire falls out of the night as a shower of embers, then
	## bursts on the ground.
	var g := GPUParticles3D.new()
	g.one_shot = true
	g.amount = 70
	g.lifetime = 0.9
	g.explosiveness = 0.6
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(1.6, 0.3, 1.6)
	pm.direction = Vector3(0, -1, 0)
	pm.spread = 12.0
	pm.initial_velocity_min = 9.0
	pm.initial_velocity_max = 13.0
	pm.gravity = Vector3(0, -6.0, 0)
	pm.scale_min = 0.12
	pm.scale_max = 0.3
	var grad := Gradient.new()
	grad.set_color(0, Color(1.0, 0.85, 0.45, 1.0))
	grad.set_color(grad.get_point_count() - 1, Color(1.0, 0.3, 0.05, 0.0))
	var gt := GradientTexture1D.new()
	gt.gradient = grad
	pm.color_ramp = gt
	g.process_material = pm
	var q := QuadMesh.new()
	q.size = Vector2(0.5, 0.5)
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.vertex_color_use_as_albedo = true
	m.albedo_texture = CityBuilder._soft_dot()
	q.material = m
	g.draw_pass_1 = q
	g.position = p + Vector3(0, 10.0, 0)
	fx_root.add_child(g)
	g.emitting = true
	var l := OmniLight3D.new()
	l.light_color = Color(1.0, 0.55, 0.2)
	l.light_energy = 0.0
	l.omni_range = 12.0
	l.position = p + Vector3(0, 2.0, 0)
	fx_root.add_child(l)
	var tw := create_tween()
	tw.tween_property(l, "light_energy", 5.0, 0.6 / speed)
	await tw.finished
	Sfx.play("cracker", p, -2.0, 0.15)
	var smoke := _smoke_burst(p + Vector3(0, 0.3, 0), 1.0)
	rig.shake = 0.35
	var tw2 := create_tween()
	tw2.tween_property(l, "light_energy", 12.0, 0.08 / speed)
	tw2.tween_property(l, "light_energy", 0.0, 0.6 / speed)
	await tw2.finished
	l.queue_free()
	get_tree().create_timer(2.5).timeout.connect(g.queue_free)
	get_tree().create_timer(3.0).timeout.connect(smoke.queue_free)

func _lightning(p: Vector3) -> void:
	var b := MeshBatch.new()
	var m := Mats.glow(Color(0.7, 0.9, 1.0), 9.0, true)
	var top := p + Vector3(randf_range(-4, 4), 28, randf_range(-4, 4))
	var prev := top
	for i in range(1, 11):
		var k := float(i) / 10.0
		var q := top.lerp(p + Vector3(0, 1.0, 0), k) + Vector3(randf_range(-0.8, 0.8), 0, randf_range(-0.8, 0.8)) * (1.0 - k)
		var mid := (prev + q) * 0.5
		var dir := (q - prev)
		var bas := Basis.looking_at(dir.normalized(), Vector3.RIGHT if absf(dir.normalized().y) > 0.9 else Vector3.UP)
		b.add_box(m, Transform3D(bas, mid), Vector3(0.08, 0.08, dir.length()))
		prev = q
	var mi := b.build(false)
	fx_root.add_child(mi)
	var l := OmniLight3D.new()
	l.light_color = Color(0.7, 0.85, 1.0)
	l.light_energy = 16.0
	l.omni_range = 18.0
	l.position = p + Vector3(0, 3, 0)
	fx_root.add_child(l)
	rig.shake = 0.5
	var tw := create_tween()
	tw.tween_property(l, "light_energy", 0.0, 0.5 / speed)
	await tw.finished
	mi.queue_free()
	l.queue_free()

# ------------------------------------------------------------------ results

func _show_result() -> void:
	busy = true
	_clear_markers()
	_set_selection(null)
	var sm := st.summary()
	var title := "Draw"
	var col := UIStyle.BONE
	if sm["winner"] >= 0:
		var wb: Dictionary = st.sides[sm["winner"]]["wb"]
		if watch_all:
			title = "%s win" % wb["short"] if wb.has("short") else wb["name"]
			col = Color(wb["color"][0], wb["color"][1], wb["color"][2]).lightened(0.4)
		elif sm["winner"] == player_side:
			title = "Victory"
			col = UIStyle.JADE
		else:
			title = "Defeat"
			col = UIStyle.BLOOD
	var body := ""
	for s in range(2):
		var sd: Dictionary = sm["sides"][s]
		var extra := "godshards: %d" % sd["shards"]
		if st.scenario_id == "hold":
			extra = "in the ring: %d" % st.holding(s)
		elif st.scenario_id == "brawl":
			extra = ""
		elif st.scenario_id == "breakthrough":
			extra = "through their lines: %d" % st.through(s)
		body += "[b]%s[/b]   %s\n" % [sd["name"], extra]
		body += "Standing: %s\n" % (", ".join(sd["standing"]) if not sd["standing"].is_empty() else "none")
		body += "Out of action: %s\n\n" % (", ".join(sd["ooa"]) if not sd["ooa"].is_empty() else "none")
	var heroes: Array = st.units.filter(func(u): return u.kills > 0)
	heroes.sort_custom(func(a, b): return a.kills > b.kills)
	if not heroes.is_empty():
		body += "[color=#5fe0c0]Most feared: %s, who put %d out of action.[/color]" % [heroes[0].name, heroes[0].kills]
	var choices := [["again", "Fight again"], ["menu", "Main menu"], ["quit", "Quit"]]
	if Game.campaign != null:
		body += "\n\nYour fighters' wounds, experience and spoils are counted next."
		choices = [["aftermath", "The aftermath"]]
	hud.show_result(title, "%s  (round %d)" % [sm["reason"], sm["rounds"]], body, col, choices)
	if not instant:
		if String(sm["reason"]).contains("fled"):
			Sfx.play("horn", null, -4.0, 0.0)
		Sfx.music("", 2.0)
		if watch_all or sm["winner"] == player_side:
			Sfx.sting("sting_victory")
		else:
			Sfx.sting("sting_defeat")
	print("BATTLE OVER: winner=", sm["winner"], " reason=", sm["reason"], " rounds=", sm["rounds"])
	if shots_dir != "":
		instant = false
		rig.set_view(rig.yaw + 0.6, 0.6, 34.0)
		rig.focus(Vector3(st.map.w, 0, st.map.d))
		await _capture("06_result")
		get_tree().quit()
	elif Game.quit_after_battle:
		await get_tree().create_timer(0.5).timeout
		get_tree().quit()

func _on_result_choice(nm: String) -> void:
	match nm:
		"aftermath":
			var res := Campaign.result_from_battle(st, player_side, Game.enemy_warband, Game.campaign_enemy_rating)
			Game.campaign.apply_result(res)
			Game.campaign.save()
			Game.battle_rosters = [[], []]
			Game.mode = "aftermath"
			get_tree().reload_current_scene()
		"again":
			Game.mode = "battle"
			get_tree().reload_current_scene()
		"menu":
			Game.mode = "menu"
			get_tree().reload_current_scene()
		"quit":
			get_tree().quit()

# ------------------------------------------------------------------ screenshots (look-dev and README)

func _capture(name: String, frames := 14) -> void:
	for i in range(frames):
		await get_tree().process_frame
	if name == "_":
		return
	var img := get_viewport().get_texture().get_image()
	DirAccess.make_dir_recursive_absolute(shots_dir)
	img.save_png("%s/%s.png" % [shots_dir, name])
	print("shot ", name)

func _opening_shots() -> void:
	var centre := Vector3(st.map.w, 0, st.map.d)
	var ob: Array = st.map.data.get("objective", [st.map.w / 2 - 1, st.map.d / 2 - 1])
	centre.y = st.map.h_at(int(ob[0]), int(ob[1])) * st.map.storey
	rig.set_view(0.35, 0.7, 40.0, true)
	rig.focus(centre + Vector3(0, 0, 8), true)
	await _capture("01_overview", 20)
	if st.weather == "rain":
		# the same view in a lightning flash
		atm.light_up(3.0)
		await _capture("08_lightning", 6)
		atm.light_up(0.0)
	# the opening flyover's title card
	var t_text := _intro_text()
	rig.focus(_objective_point() + Vector3(0, 1.5, 0), true)
	rig.set_view(0.35 + 1.6, 0.55, 34.0, true)
	hud.cinema(true, 0.01, 0.11)
	hud.cinema_card(t_text[0], t_text[1], t_text[2], false)
	hud.cinema_now()
	await _capture("10_intro", 20)
	hud.cinema(false, 0.01)
	await _capture("_", 3)
	# the idol from street level, or for the strongbox a marked dig spot
	if not st.cache_spots.is_empty():
		var spot: Vector3 = st.map.node_pos(st.cache_spots.keys()[0])
		rig.focus(spot + Vector3(0, 0.6, 0), true)
		rig.set_view(rig.clear_view(-0.5, 0.3, 6.0), 0.3, 6.0, true)
	else:
		rig.focus(centre + Vector3(0, 1.5, 1), true)
		rig.set_view(rig.clear_view(-0.5, 0.2, 13.0), 0.2, 13.0, true)
	await _capture("02_idol")
	# the jade giant's face, from over its chest
	var head_cells: Array = []
	for z in range(st.map.d):
		for x in range(st.map.w):
			if st.map.prop_at(x, z) == "J":
				head_cells.append(Vector2(x + 0.5, z + 0.5) * st.map.cell)
	if not head_cells.is_empty():
		var hc := Vector2.ZERO
		for v in head_cells:
			hc += v
		hc /= head_cells.size()
		rig.focus(Vector3(hc.x + 0.8, st.map.storey + 3.4, hc.y + 3.0), true)
		rig.set_view(0.35, 0.3, 16.0, true)
		await _capture("09_giant", 8)
	# a player's view: the leader chosen, where they can go, and a planned path
	watch_all = false
	var saved_ai = ais[0]
	ais[0] = null
	var leader: BUnit = null
	for u in st.side_units(0):
		if u.is_leader():
			leader = u
	if st.side != 0:
		pass
	var real_side := st.side
	st.side = 0
	busy = false
	_select(leader)
	var far := -1
	var best := -1.0
	for nd in reach:
		var c: float = reach[nd]["cost"] if not st.occupied.has(nd) else -1.0
		if c > best:
			best = c
			far = nd
	if far >= 0:
		_draw_path(far)
		hud.show_tip(_move_tip(far), Vector2(820, 430))
	# over the leader's shoulder, looking where they could go
	rig.set_view(rig.yaw, CameraRig.CLOSE_PITCH + 0.04, CameraRig.CLOSE_DIST, true)
	rig.follow(figs[leader.id], true, true, st.map.node_pos(far) if far >= 0 else null)
	await _capture("03_orders")
	rig.follow(null)
	hud.show_tip("", Vector2.ZERO)
	_clear_markers()
	_set_selection(null)
	st.side = real_side
	ais[0] = saved_ai
	watch_all = true
	busy = true

func _clear_fight_yaw(mid: Vector3, pts: Array, yaw0: float) -> float:
	## A camera angle from which both fighters can be seen.
	var space := get_world_3d().direct_space_state
	for i in range(24):
		var y := yaw0 + (i / 2) * 0.27 * (1 if i % 2 == 0 else -1)
		var off := Vector3(sin(y) * cos(0.42), sin(0.42), cos(y) * cos(0.42)) * 8.0
		var cam_p := mid + Vector3(0, 1.2, 0) + off
		var ok := true
		for p in pts:
			var q := PhysicsRayQueryParameters3D.create(cam_p, (p as Vector3) + Vector3(0, 1.0, 0), 1)
			if not space.intersect_ray(q).is_empty():
				ok = false
				break
		if ok:
			return y
	return yaw0

func _box_shot(u: BUnit) -> void:
	## Screenshots: the fighter who struck iron, box on their back, by the pit.
	if u == null or not figs.has(u.id):
		return
	_refresh_all()
	figs[u.id].visible = true
	var p := st.pos(u)
	rig.focus(p + Vector3(0, 0.8, 0), true)
	var yaw := _clear_fight_yaw(p, [p], figs[u.id].rotation.y + PI)
	rig.set_view(yaw, 0.32, 5.5, true)
	_set_selection(u)
	hud.show_unit(u, st, figs[u.id])
	instant = false
	await _capture("07_strongbox")
	instant = true
	_set_selection(null)

func _fight_shot() -> void:
	var a := st.unit_by_id(_fight_focus[0])
	var b := st.unit_by_id(_fight_focus[1])
	_refresh_all()
	for u in [a, b]:
		figs[u.id].set_status(u.status)
		figs[u.id].visible = true
		figs[u.id].scale = Vector3.ONE
	var mid := (st.pos(a) + st.pos(b)) * 0.5
	var dir := st.pos(b) - st.pos(a)
	rig.focus(mid + Vector3(0, 0.4, 0), true)
	var yaw := _clear_fight_yaw(mid, [st.pos(a), st.pos(b)], atan2(dir.x, dir.z) + PI * 0.5)
	rig.set_view(yaw, 0.42, 8.0, true)
	_set_selection(a)
	hud.show_unit(a, st, figs[a.id])
	hud.show_target(b, st, _melee_odds(a, b, false) if a.standing() else "")
	instant = false
	# street level, over the attacker's shoulder, with the dice on screen
	rig.set_view(yaw, 0.22, 5.0, true)
	rig.follow(figs[a.id], true, true, st.pos(b))
	var wbc: Array = st.sides[a.side]["wb"]["color"]
	hud.show_roll("To hit", 5, 4, true, 6, a.name, Color(wbc[0], wbc[1], wbc[2]))
	await _capture("04_fight")
	rig.follow(null)
	rig.focus(mid + Vector3(0, 0.4, 0), true)
	rig.set_view(yaw + 1.2, 0.95, 26.0, true)
	await _capture("05_battle")
	hud.show_target(null, st, "")
	instant = true

func _cinematic() -> bool:
	return shots_dir == "" and not Game.selftest and bool(Game.settings.get("cinematics", true))

func _intro_text() -> Array:
	var wb0: Dictionary = st.sides[player_side]["wb"]
	var wb1: Dictionary = st.sides[1 - player_side]["wb"]
	var sub: String = String(st.scenario["name"]) + "  ·  " + String(BattleState.WEATHERS[st.weather]["name"])
	return [String(st.map.data.get("name", "The ruins")), sub, "%s against %s" % [wb0["name"], wb1["name"]]]

func _objective_point() -> Vector3:
	var ob: Array = st.map.data.get("objective", [st.map.w / 2 - 1, st.map.d / 2 - 1])
	return Vector3((float(ob[0]) + 1.0) * st.map.cell, st.map.h_at(int(ob[0]), int(ob[1])) * st.map.storey, (float(ob[1]) + 1.0) * st.map.cell)

func _intro() -> void:
	## The opening flyover: a slow sweep round the heart of the battlefield
	## under the battle's title, settling where the player's warband waits.
	_intro_on = true
	_intro_skip = false
	rig.input_enabled = false
	var end_focus := rig._goal
	var end_yaw := rig._yaw_goal
	var end_pitch := rig._pitch_goal
	var end_dist := rig._dist_goal
	var obj := _objective_point() + Vector3(0, 1.5, 0)
	var t_text := _intro_text()
	hud.cinema(true, 0.9, 0.11)
	hud.cinema_card(t_text[0], t_text[1], t_text[2], true)
	var dur := 10.0
	var t0 := Time.get_ticks_msec()
	while not _intro_skip:
		var k: float = (Time.get_ticks_msec() - t0) / 1000.0 / dur
		if k >= 1.0:
			break
		var e: float = k * k * (3.0 - 2.0 * k)
		var sweep: float = 1.0 - sin(e * PI * 0.5)       # fast early, gentle at the end
		var y: float = end_yaw + 2.6 * sweep
		var pt: float = lerpf(0.5, end_pitch, e)
		var d: float = lerpf(36.0, end_dist, e)
		var fp: Vector3 = obj.lerp(end_focus, smoothstep(0.35, 1.0, k))
		rig.focus(fp, true)
		rig.set_view(y, pt, d, true)
		await get_tree().process_frame
	rig.focus(end_focus, _intro_skip)
	rig.set_view(end_yaw, end_pitch, end_dist, _intro_skip)
	if not _intro_skip:
		await get_tree().create_timer(0.6).timeout
	hud.cinema(false, 0.7)
	_intro_on = false
	rig.input_enabled = true

func _killcam(u: BUnit) -> void:
	## A fighter taken out of action: cut in low beside them, slow time, and
	## hold there while they go down; then back to where the camera was.
	_last_killcam = Time.get_ticks_msec()
	var saved := {"yaw": rig.yaw, "pitch": rig.pitch, "dist": rig.dist, "target": rig.target,
		"follow": rig.follow_target, "yg": rig._yaw_goal, "pg": rig._pitch_goal, "dg": rig._dist_goal, "goal": rig._goal}
	var was_input := rig.input_enabled
	rig.input_enabled = false
	_kill_frame(u)
	rig.set_view(rig.yaw + 0.4, 0.5, 4.0)      # a slow push in while time crawls
	var wbc: Array = st.sides[u.side]["wb"]["color"]
	hud.cinema(true, 0.15, 0.085)
	hud.cinema_line("%s is out of action" % u.name, Color(wbc[0], wbc[1], wbc[2]).lightened(0.45))
	Sfx.play("bell", null, -14.0, 0.0)
	Engine.time_scale = 0.25
	await get_tree().create_timer(1.6, true, false, true).timeout
	Engine.time_scale = 1.0
	hud.cinema(false, 0.3)
	rig.follow_target = saved["follow"]
	rig._goal = saved["goal"]
	rig.target = saved["target"]
	rig._yaw_goal = saved["yg"]
	rig._pitch_goal = saved["pg"]
	rig._dist_goal = saved["dg"]
	rig.set_view(saved["yaw"], saved["pitch"], saved["dist"], true)
	rig.set_view(saved["yg"], saved["pg"], saved["dg"])
	rig.input_enabled = was_input

func _kill_frame(u: BUnit) -> void:
	var p := st.pos(u)
	var src: Vector3 = st.pos(st.unit_by_id(_last_attacker)) if _last_attacker >= 0 and st.unit_by_id(_last_attacker) != null else p + Vector3(0, 0, 1)
	var d := p - src
	var base: float = atan2(d.x, d.z) + PI * 0.5 if Vector2(d.x, d.z).length() > 0.2 else rig.yaw
	rig.follow(null)
	# the rig looks about 1.5 m over its focus when close: aim it at the body
	rig.focus(p + Vector3(0, -0.85, 0), true)
	var yaw := _clear_fight_yaw(p, [p, src], base)
	rig.set_view(yaw, 0.62, 5.2, true)

func _kill_cam_shot(u: BUnit) -> void:
	## Screenshots: the kill camera on the first fighter taken out.
	if u == null or not figs.has(u.id):
		return
	_refresh_all()
	var f: Figure = figs[u.id]
	f.visible = true
	f.scale = Vector3.ONE
	f.set_status("ooa")
	_blood_pool(st.pos(u), 1.3)
	_kill_frame(u)
	rig.set_view(rig.yaw + 0.25, 0.55, 4.4, true)
	var wbc: Array = st.sides[u.side]["wb"]["color"]
	hud.cinema(true, 0.01, 0.085)
	hud.cinema_line("%s is out of action" % u.name, Color(wbc[0], wbc[1], wbc[2]).lightened(0.45))
	hud.cinema_now()
	await _capture("11_killcam", 20)
	hud.cinema_line("", Color.WHITE)
	# then Hood's crows come down round the body
	crows.calm = true
	crows.gather_at(st.pos(u), 4)
	_kill_frame(u)
	rig.set_view(rig.yaw - 0.35, 0.36, 3.3, true)
	hud.cinema(true, 0.01, 0.0)
	await _capture("12_crows", 20)
	crows.calm = false
	hud.cinema(false, 0.01)
	await _capture("_", 3)
	f.visible = false

func _process(_delta: float) -> void:
	# a fighter's silhouette shows through walls from afar; close up it would
	# also show through the fighters standing in front, so it is hidden there
	if rig == null or rig.cam == null:
		return
	var cp := rig.cam.global_position
	# The see-through outline is for fighters hidden behind walls. Close to
	# the camera, or locked in a fight, it would only ghost through the foe.
	for id in figs:
		var f: Figure = figs[id]
		if f.side != player_side:
			continue
		var fu := st.unit_by_id(id)
		var show := f.visible and cp.distance_to(f.global_position) > 7.5 and fu != null and fu.status != "ooa"
		if show:
			for id2 in figs:
				var g: Figure = figs[id2]
				if g == f or not g.visible:
					continue
				if g.global_position.distance_to(f.global_position) < 2.2:
					show = false
					break
				# another fighter standing between the camera and this one hides
				# it, not a wall: the outline would only ghost through them
				var up := Vector3(0, 1.0, 0)
				var seg := f.global_position + up - cp
				var tt := (g.global_position + up - cp).dot(seg) / seg.length_squared()
				if tt > 0.0 and tt < 1.0 and (cp + seg * tt).distance_to(g.global_position + up) < 1.0:
					show = false
					break
		f.xray.visible = show
