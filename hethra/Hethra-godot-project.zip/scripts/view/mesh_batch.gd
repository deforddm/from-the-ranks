class_name MeshBatch
extends RefCounted
## Collects many boxes, quads and simple solids into one mesh with a surface
## per material, so a whole district renders in a handful of draw calls.

var _st: Dictionary = {}      # Material -> SurfaceTool
var _count: Dictionary = {}

func _tool(mat: Material) -> SurfaceTool:
	if not _st.has(mat):
		var st := SurfaceTool.new()
		st.begin(Mesh.PRIMITIVE_TRIANGLES)
		_st[mat] = st
		_count[mat] = 0
	return _st[mat]

func add_tri(mat: Material, a: Vector3, b: Vector3, c: Vector3, n := Vector3.ZERO) -> void:
	var st := _tool(mat)
	var cr := (b - a).cross(c - a)
	if n == Vector3.ZERO:
		n = -cr.normalized()
	# Godot treats clockwise triangles as front faces: the cross product of a
	# front face points away from the viewer, i.e. against the normal.
	if cr.dot(n) > 0.0:
		var t := b
		b = c
		c = t
	st.set_normal(n)
	st.add_vertex(a)
	st.set_normal(n)
	st.add_vertex(b)
	st.set_normal(n)
	st.add_vertex(c)
	_count[mat] += 3

func add_quad(mat: Material, a: Vector3, b: Vector3, c: Vector3, d: Vector3, n: Vector3) -> void:
	add_tri(mat, a, b, c, n)
	add_tri(mat, a, c, d, n)

func add_box(mat: Material, xf: Transform3D, size: Vector3, skip_bottom := false) -> void:
	var h := size * 0.5
	var corners := []
	for i in range(8):
		var p := Vector3(h.x if i & 1 else -h.x, h.y if i & 2 else -h.y, h.z if i & 4 else -h.z)
		corners.append(xf * p)
	var bs := xf.basis
	var faces := [
		[[1, 3, 7, 5], Vector3.RIGHT], [[0, 4, 6, 2], Vector3.LEFT],
		[[2, 6, 7, 3], Vector3.UP], [[0, 1, 5, 4], Vector3.DOWN],
		[[4, 5, 7, 6], Vector3.BACK], [[0, 2, 3, 1], Vector3.FORWARD]]
	for f in faces:
		if skip_bottom and f[1] == Vector3.DOWN:
			continue
		var n: Vector3 = (bs * f[1]).normalized()
		var ix: Array = f[0]
		add_quad(mat, corners[ix[0]], corners[ix[1]], corners[ix[2]], corners[ix[3]], n)

func box_at(mat: Material, center: Vector3, size: Vector3, yaw := 0.0, pitch := 0.0, roll := 0.0) -> void:
	var b := Basis.from_euler(Vector3(pitch, yaw, roll))
	add_box(mat, Transform3D(b, center), size)

func add_cyl(mat: Material, xf: Transform3D, r0: float, r1: float, h: float, segs := 10, caps := true) -> void:
	## Cylinder/cone along local +Y from y=0 to y=h.
	var bs := xf.basis
	for i in range(segs):
		var a0 := TAU * i / segs
		var a1 := TAU * (i + 1) / segs
		var d0 := Vector3(cos(a0), 0, sin(a0))
		var d1 := Vector3(cos(a1), 0, sin(a1))
		var p0 := xf * (d0 * r0)
		var p1 := xf * (d1 * r0)
		var q0 := xf * (d0 * r1 + Vector3(0, h, 0))
		var q1 := xf * (d1 * r1 + Vector3(0, h, 0))
		var slope := (r0 - r1) / maxf(h, 0.001)
		var n0 := (bs * (d0 + Vector3(0, slope, 0))).normalized()
		var n1 := (bs * (d1 + Vector3(0, slope, 0))).normalized()
		var st := _tool(mat)
		var tri := func(a: Vector3, an: Vector3, b: Vector3, bn: Vector3, c: Vector3, cn: Vector3) -> void:
			var cr := (b - a).cross(c - a)
			if cr.dot(an + bn + cn) > 0.0:
				var t := b; b = c; c = t
				var tn := bn; bn = cn; cn = tn
			st.set_normal(an); st.add_vertex(a)
			st.set_normal(bn); st.add_vertex(b)
			st.set_normal(cn); st.add_vertex(c)
			_count[mat] += 3
		tri.call(p0, n0, p1, n1, q1, n1)
		tri.call(p0, n0, q1, n1, q0, n0)
		if caps:
			var up := (bs * Vector3.UP).normalized()
			var ctop := xf * Vector3(0, h, 0)
			var cbot := xf.origin
			if r1 > 0.001:
				add_tri(mat, ctop, q0, q1, up)
			if r0 > 0.001:
				add_tri(mat, cbot, p1, p0, -up)

func add_gable(mat: Material, center: Vector3, size_x: float, size_z: float, rise: float, along_x: bool, holes: Array = []) -> void:
	## A pitched roof: two slopes meeting at a ridge. `holes` lists strip
	## indices (0..7) left open, for a broken roof.
	var strips := 4
	var ridge_len := size_x if along_x else size_z
	var half := (size_z if along_x else size_x) * 0.5
	for side in [-1, 1]:
		for i in range(strips):
			if holes.has(i + (0 if side < 0 else strips)):
				continue
			var t0 := -ridge_len * 0.5 + ridge_len * i / strips
			var t1 := -ridge_len * 0.5 + ridge_len * (i + 1) / strips
			var a: Vector3
			var b: Vector3
			var c: Vector3
			var d: Vector3
			if along_x:
				a = center + Vector3(t0, 0, side * half)
				b = center + Vector3(t1, 0, side * half)
				c = center + Vector3(t1, rise, 0)
				d = center + Vector3(t0, rise, 0)
			else:
				a = center + Vector3(side * half, 0, t0)
				b = center + Vector3(side * half, 0, t1)
				c = center + Vector3(0, rise, t1)
				d = center + Vector3(0, rise, t0)
			var n := (b - a).cross(d - a).normalized()
			if n.y < 0:
				n = -n
			add_quad(mat, a, b, c, d, n)
			# underside so holes do not show a see-through void
			add_quad(mat, a + Vector3(0, -0.12, 0), b + Vector3(0, -0.12, 0), c + Vector3(0, -0.12, 0), d + Vector3(0, -0.12, 0), -n)
	# gable ends
	for end in [-1, 1]:
		var e: float = ridge_len * 0.5 * end
		if along_x:
			add_tri(mat, center + Vector3(e, 0, -half), center + Vector3(e, 0, half), center + Vector3(e, rise, 0), Vector3(end, 0, 0))
		else:
			add_tri(mat, center + Vector3(-half, 0, e), center + Vector3(half, 0, e), center + Vector3(0, rise, e), Vector3(0, 0, end))

func build(shadows := true) -> MeshInstance3D:
	var mesh := ArrayMesh.new()
	for mat in _st:
		if _count[mat] == 0:
			continue
		var st: SurfaceTool = _st[mat]
		st.set_material(mat)
		st.commit(mesh)
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if shadows else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return mi

func vertex_count() -> int:
	var n := 0
	for k in _count:
		n += _count[k]
	return n
