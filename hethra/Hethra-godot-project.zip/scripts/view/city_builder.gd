class_name CityBuilder
extends Node3D
## Builds the 3D ruins of Hethra from a BattleMap: masonry blocks with
## jagged broken tops, windows and ledges, ladders, stairs, plank bridges,
## the chained idol, braziers, barricades, rubble and godshards, plus a ring
## of ruined streets and distant towers fading into the fog.

const RING := 12          # cells of backdrop city beyond the battle map

var map: BattleMap
var cell: float
var S: float
var ext_h: Dictionary = {}     # Vector2i -> storeys, for backdrop cells
var block_of: Dictionary = {}  # Vector2i -> block id (playable area)
var block_style: Dictionary = {}
var shard_nodes: Dictionary = {}   # node id -> Node3D
var flicker_lights: Array = []
var walk_body: StaticBody3D

var m_void: StandardMaterial3D
var m_glow_win: StandardMaterial3D
var m_char: StandardMaterial3D
var temple := Rect2i()          # the temple's cells, dressed as carved stone
var yard := Rect2i()            # the Azath yard: its wall runs round the edge of this

func build(battle_map: BattleMap, shards: Dictionary) -> void:
	map = battle_map
	cell = map.cell
	Figure.water_y = map.water if map.water > 0.0 else -100.0
	S = map.storey
	m_void = Mats.flat(Color(0.015, 0.014, 0.016), 1.0)
	m_glow_win = Mats.glow(Color(1.0, 0.42, 0.12), 1.6)
	m_char = Mats.pbr("wood", 0.5, Color(0.35, 0.3, 0.28))
	var tr: Array = map.data.get("temple", [])
	if tr.size() == 4:
		temple = Rect2i(int(tr[0]), int(tr[1]), int(tr[2]) - int(tr[0]) + 1, int(tr[3]) - int(tr[1]) + 1)
	var yr: Array = map.data.get("yard", [])
	if yr.size() == 4:
		yard = Rect2i(int(yr[0]), int(yr[1]), int(yr[2]) - int(yr[0]) + 1, int(yr[3]) - int(yr[1]) + 1)
	_make_backdrop_heights()
	_find_blocks()
	var batch := MeshBatch.new()
	var far_batch := MeshBatch.new()
	_ground(batch)
	_columns(batch, far_batch)
	_props(batch)
	_links(batch)
	_bridges(batch)
	_street_rubble(batch)
	_skyline(far_batch)
	var mi := batch.build(true)
	mi.name = "Ruins"
	add_child(mi)
	var fmi := far_batch.build(true)
	fmi.name = "Backdrop"
	add_child(fmi)
	_idol()
	_starstone()
	_sleeper()
	_bell()
	_azath()
	_water()
	_braziers()
	_fires()
	_sconces()
	for nd in shards:
		add_shard(nd)
	_grime_decals()
	_collision()

# ------------------------------------------------------------------ helpers

static func hashf(a: int, b: int, c: int = 0) -> float:
	var h := (a * 374761393 + b * 668265263 + c * 2147483647) & 0x7fffffff
	h = (h ^ (h >> 13)) * 1274126177
	h = h & 0x7fffffff
	h = h ^ (h >> 16)
	return float(h % 10007) / 10007.0

func H(x: int, z: int) -> int:
	## Storey height anywhere: battle map inside, backdrop outside.
	if x >= 0 and z >= 0 and x < map.w and z < map.d:
		return map.h_at(x, z)
	return ext_h.get(Vector2i(x, z), 0)

func inside(x: int, z: int) -> bool:
	return x >= 0 and z >= 0 and x < map.w and z < map.d

func _make_backdrop_heights() -> void:
	for z in range(-RING, map.d + RING):
		for x in range(-RING, map.w + RING):
			if inside(x, z):
				continue
			var gx := x + 100
			var gz := z + 100
			var street := (gx % 6 == 0) or (gz % 6 == 0)
			# keep the edge of the battle map walled in, with a few street mouths
			var edge := x == -1 or z == -1 or x == map.w or z == map.d
			# how many cells outside the battle map; nearby ruins stay low so
			# the camera can see over them into the streets
			var k: int = maxi(maxi(-x, x - (map.w - 1)), maxi(-z, z - (map.d - 1)))
			if edge:
				var ix := clampi(x, 0, map.w - 1)
				var iz := clampi(z, 0, map.d - 1)
				var mouth := map.h_at(ix, iz) == 0 and street and hashf(ix, iz, 3) < 0.7
				ext_h[Vector2i(x, z)] = 0 if mouth else 1
				continue
			if street:
				ext_h[Vector2i(x, z)] = 0
				continue
			var bx := int(floor(gx / 6.0))
			var bz := int(floor(gz / 6.0))
			var base := 2 + int(hashf(bx, bz, 1) * 3.2)
			if hashf(bx, bz, 2) < 0.15:
				base = 1   # a collapsed block
			if hashf(x, z, 7) < 0.18:
				base = max(1, base - 1)
			if k <= 3:
				base = mini(base, 1 if k <= 2 else 2)
			ext_h[Vector2i(x, z)] = base

func _find_blocks() -> void:
	var next := 0
	for z in range(map.d):
		for x in range(map.w):
			var k := Vector2i(x, z)
			if map.h_at(x, z) == 0 or block_of.has(k):
				continue
			var stack := [k]
			block_of[k] = next
			while not stack.is_empty():
				var c: Vector2i = stack.pop_back()
				for dv in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
					var n: Vector2i = c + dv
					if inside(n.x, n.y) and map.h_at(n.x, n.y) > 0 and not block_of.has(n):
						block_of[n] = next
						stack.append(n)
			var r := hashf(next, 11, 3)
			block_style[next] = "plaster" if r < 0.35 else ("dark" if r < 0.5 else "stone")
			next += 1

func _wall_mat(x: int, z: int, storey_index: int) -> StandardMaterial3D:
	var style := "stone"
	if inside(x, z):
		style = block_style.get(block_of.get(Vector2i(x, z), -1), "stone")
	else:
		var r := hashf(int(floor((x + 100) / 6.0)), int(floor((z + 100) / 6.0)), 9)
		style = "plaster" if r < 0.4 else ("dark" if r < 0.55 else "stone")
	if style == "dark":
		return Mats.darkstone()
	if style == "plaster" and storey_index >= 1:
		return Mats.pbr("plaster", 0.35, Color(0.82, 0.8, 0.78))
	return Mats.stone()

func _in_temple(x: int, z: int) -> bool:
	return temple.size.x > 0 and temple.has_point(Vector2i(x, z))

func _temple_mat() -> StandardMaterial3D:
	return Mats.pbr("plaster", 0.3, Color(0.95, 0.86, 0.7))

func _on_yard_wall(x: int, z: int) -> bool:
	if yard.size.x <= 0 or not yard.has_point(Vector2i(x, z)):
		return false
	return x == yard.position.x or z == yard.position.y or x == yard.end.x - 1 or z == yard.end.y - 1

func _in_yard(x: int, z: int) -> bool:
	return yard.size.x > 0 and yard.has_point(Vector2i(x, z)) and not _on_yard_wall(x, z)

func _yard_stone() -> StandardMaterial3D:
	return Mats.pbr("plaster", 0.22, Color(0.5, 0.54, 0.48))

func _top_mat(x: int, z: int) -> StandardMaterial3D:
	if _on_yard_wall(x, z) and map.h_at(x, z) >= 2:
		return _yard_stone()
	if _in_yard(x, z):
		return Mats.pbr("dirt", 0.18, Color(0.5, 0.47, 0.4))
	if _in_temple(x, z):
		return Mats.pbr("cobbles", 0.22, Color(0.95, 0.88, 0.76), 0.8) if hashf(x, z, 23) < 0.8 else Mats.pbr("stone", 0.6, Color(0.9, 0.84, 0.72))
	var r := hashf(x, z, 21)
	if r < 0.35:
		return Mats.pbr("wood", 0.5, Color(0.7, 0.66, 0.62))
	if r < 0.8:
		return Mats.darkstone()
	return Mats.pbr("cobbles", 0.3, Color(0.8, 0.8, 0.8))

# ------------------------------------------------------------------ ground

func _ground(b: MeshBatch) -> void:
	var x0 := -RING * cell
	var z0 := -RING * cell
	var x1 := (map.w + RING) * cell
	var z1 := (map.d + RING) * cell
	b.add_quad(Mats.cobbles(), Vector3(x0, 0, z0), Vector3(x1, 0, z0), Vector3(x1, 0, z1), Vector3(x0, 0, z1), Vector3.UP)
	# a dirt plain beyond the backdrop ring, under the far towers
	var big := 900.0
	var dm := Mats.pbr("dirt", 0.08, Color(0.45, 0.42, 0.4))
	b.add_quad(dm, Vector3(-big, -0.02, -big), Vector3(big, -0.02, -big), Vector3(big, -0.02, z0), Vector3(-big, -0.02, z0), Vector3.UP)
	b.add_quad(dm, Vector3(-big, -0.02, z1), Vector3(big, -0.02, z1), Vector3(big, -0.02, big), Vector3(-big, -0.02, big), Vector3.UP)
	b.add_quad(dm, Vector3(-big, -0.02, z0), Vector3(x0, -0.02, z0), Vector3(x0, -0.02, z1), Vector3(-big, -0.02, z1), Vector3.UP)
	b.add_quad(dm, Vector3(x1, -0.02, z0), Vector3(big, -0.02, z0), Vector3(big, -0.02, z1), Vector3(x1, -0.02, z1), Vector3.UP)

# ------------------------------------------------------------------ masonry

func _columns(b: MeshBatch, fb: MeshBatch) -> void:
	var dirs := [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
	for z in range(-RING, map.d + RING):
		for x in range(-RING, map.w + RING):
			var h := H(x, z)
			if h <= 0:
				continue
			var playable := inside(x, z)
			var tb: MeshBatch = b if playable or _near_map(x, z, 3) else fb
			var x0 := x * cell
			var z0 := z * cell
			var top := h * S
			# top surface (walkable roofs are broken upper floors)
			var tm := _top_mat(x, z)
			tb.add_quad(tm, Vector3(x0, top, z0), Vector3(x0 + cell, top, z0), Vector3(x0 + cell, top, z0 + cell), Vector3(x0, top, z0 + cell), Vector3.UP)
			for dv in dirs:
				var nh := H(x + dv.x, z + dv.y)
				if not playable and not inside(x + dv.x, z + dv.y) and abs(x + dv.x - map.w / 2) > map.w / 2 + RING - 1:
					nh = 0
				if nh >= h:
					continue
				_wall_face(tb, x, z, dv, nh, h, playable)

func _near_map(x: int, z: int, r: int) -> bool:
	return x >= -r and z >= -r and x < map.w + r and z < map.d + r

func _face_frame(x: int, z: int, dv: Vector2i) -> Array:
	## Returns [origin corner a, along-wall unit vector, outward normal] for a cell face.
	var x0 := x * cell
	var z0 := z * cell
	if dv == Vector2i(1, 0):
		return [Vector3(x0 + cell, 0, z0), Vector3(0, 0, 1), Vector3(1, 0, 0)]
	if dv == Vector2i(-1, 0):
		return [Vector3(x0, 0, z0 + cell), Vector3(0, 0, -1), Vector3(-1, 0, 0)]
	if dv == Vector2i(0, 1):
		return [Vector3(x0 + cell, 0, z0 + cell), Vector3(-1, 0, 0), Vector3(0, 0, 1)]
	return [Vector3(x0, 0, z0), Vector3(1, 0, 0), Vector3(0, 0, -1)]

func _temple_face(b: MeshBatch, x: int, z: int, dv: Vector2i, nh: int, h: int) -> void:
	## A face of the temple: dressed sandstone between pilasters, a carved
	## frieze and a cornice, and here and there a crack that glows like a
	## banked fire, for the sleeper under the stone runs hot since the fall.
	var fr := _face_frame(x, z, dv)
	var a: Vector3 = fr[0]
	var along: Vector3 = fr[1]
	var n: Vector3 = fr[2]
	var tm := _temple_mat()
	var dark := Mats.pbr("stone", 0.42, Color(0.62, 0.55, 0.47))
	var mid := a + along * (cell * 0.5)
	var y0 := nh * S
	var y1 := h * S
	for k in range(nh, h):
		b.add_quad(tm, a + Vector3(0, k * S, 0), a + along * cell + Vector3(0, k * S, 0), a + along * cell + Vector3(0, (k + 1) * S, 0), a + Vector3(0, (k + 1) * S, 0), n)
	b.box_at(dark, mid + Vector3(0, y0 + 0.22, 0) + n * 0.12, _oriented(cell + 0.02, 0.44, 0.24, along))
	b.box_at(tm, a + along * 0.2 + Vector3(0, (y0 + y1) * 0.5, 0) + n * 0.1, _oriented(0.4, y1 - y0, 0.2, along))
	b.box_at(tm, a + along * 0.2 + Vector3(0, y1 - 0.3, 0) + n * 0.16, _oriented(0.55, 0.3, 0.3, along))
	b.box_at(dark, mid + Vector3(0, y1 - 0.62, 0) + n * 0.06, _oriented(cell + 0.01, 0.56, 0.12, along))
	for i in range(3):
		var f := (i + 0.5) / 3.0
		var rh := 0.28 + hashf(x * 3 + i, z, 41) * 0.14
		b.box_at(tm, a + along * (cell * f) + Vector3(0, y1 - 0.62, 0) + n * 0.13, _oriented(0.34, rh, 0.08, along), 0, _tilt(along, (hashf(x, z * 3 + i, 42) - 0.5) * 0.5).x, _tilt(along, (hashf(x, z * 3 + i, 42) - 0.5) * 0.5).y)
	b.box_at(tm, mid + Vector3(0, y1 + 0.06, 0) + n * 0.16, _oriented(cell + 0.04, 0.24, 0.42, along))
	if hashf(x * 2 + dv.x, z * 2 + dv.y, 43) < 0.32:
		var hot := Mats.glow(Color(1.0, 0.34, 0.08), 2.4)
		var cx := 0.4 + hashf(x, z, 44) * 1.2
		var cy := y0 + 0.6 + hashf(x, z, 45) * (y1 - y0 - 1.4)
		var tilt := (hashf(x, z, 46) - 0.5) * 1.4
		var t1 := _tilt(along, tilt)
		var t2 := _tilt(along, tilt + 0.8)
		b.box_at(hot, a + along * cx + Vector3(0, cy, 0) + n * 0.015, _oriented(0.06, 1.1, 0.03, along), 0, t1.x, t1.y)
		b.box_at(hot, a + along * (cx + 0.2) + Vector3(0, cy - 0.5, 0) + n * 0.015, _oriented(0.05, 0.6, 0.03, along), 0, t2.x, t2.y)

func _yard_wall_face(b: MeshBatch, x: int, z: int, dv: Vector2i, nh: int, h: int) -> void:
	## The Azath yard wall: big rough stones without mortar, green with old
	## moss at the foot, capped with flat slabs. It has no windows and no doors.
	var fr := _face_frame(x, z, dv)
	var a: Vector3 = fr[0]
	var along: Vector3 = fr[1]
	var n: Vector3 = fr[2]
	var st := _yard_stone()
	var dk := Mats.pbr("plaster", 0.22, Color(0.22, 0.24, 0.22))
	var moss := Mats.flat(Color(0.16, 0.22, 0.12), 0.95)
	var y0 := nh * S
	var y1 := h * S
	b.add_quad(dk, a + Vector3(0, y0, 0), a + along * cell + Vector3(0, y0, 0), a + along * cell + Vector3(0, y1, 0), a + Vector3(0, y1, 0), n)
	var y := y0
	var row := 0
	while y < y1 - 0.05:
		var rh := minf(0.55 + hashf(x + row, z, 71) * 0.35, y1 - y)
		var off := 0.0 if row % 2 == 0 else 0.5
		var t := -off
		var k := 0
		while t < cell:
			var bl := 0.8 + hashf(x * 3 + k, z * 5 + row, 72) * 0.7
			var t0 := maxf(t, 0.0)
			var t1 := minf(t + bl, cell)
			if t1 - t0 > 0.08:
				var bulge := 0.04 + hashf(x + k, z + row * 3, 73) * 0.1
				var c := a + along * ((t0 + t1) * 0.5) + Vector3(0, y + rh * 0.5, 0) + n * bulge * 0.5
				b.box_at(st, c, _oriented(t1 - t0 - 0.05, rh - 0.05, bulge + 0.02, along), 0, _tilt(along, (hashf(x, k, row) - 0.5) * 0.06).x, _tilt(along, (hashf(x, k, row) - 0.5) * 0.06).y)
			t += bl
			k += 1
		y += rh
		row += 1
	# moss creeping up from the earth
	for i in range(3):
		var mh := 0.3 + hashf(x * 7 + i, z, 74) * 0.9
		var mx := hashf(x, z * 7 + i, 75) * cell
		b.box_at(moss, a + along * mx + Vector3(0, y0 + mh * 0.5, 0) + n * 0.12, _oriented(0.5 + hashf(i, x, z) * 0.6, mh, 0.03, along))
	# coping slabs along the top
	b.box_at(st, a + along * (cell * 0.5) - n * (cell * 0.5) + Vector3(0, y1 + 0.08, 0) + n * 0.12, _oriented(cell + 0.02, 0.16, cell + 0.24, along))

func _tilt(along: Vector3, ang: float) -> Vector2:
	## [pitch, roll] that lean a box sideways within a wall running along `along`.
	return Vector2(0.0, ang) if absf(along.x) > 0.5 else Vector2(ang, 0.0)

func _wall_face(b: MeshBatch, x: int, z: int, dv: Vector2i, nh: int, h: int, playable: bool) -> void:
	if playable and _in_temple(x, z):
		_temple_face(b, x, z, dv, nh, h)
		return
	if playable and h == 2 and _on_yard_wall(x, z):
		_yard_wall_face(b, x, z, dv, nh, h)
		return
	var fr := _face_frame(x, z, dv)
	var a: Vector3 = fr[0]
	var along: Vector3 = fr[1]
	var n: Vector3 = fr[2]
	var yaw := atan2(n.x, n.z)
	var near := playable or _near_map(x, z, 4)
	for k in range(nh, h):
		var y0 := k * S
		var y1 := (k + 1) * S
		var wm := _wall_mat(x, z, k)
		b.add_quad(wm, a + Vector3(0, y0, 0), a + along * cell + Vector3(0, y0, 0), a + along * cell + Vector3(0, y1, 0), a + Vector3(0, y1, 0), n)
		var mid := a + along * (cell * 0.5)
		# a ledge at each floor line
		if k > nh or k > 0:
			b.box_at(Mats.darkstone(), mid + Vector3(0, y0 + 0.05, 0) + n * 0.07, _oriented(cell + 0.02, 0.22, 0.14, along))
		if not near:
			if k >= 1 and hashf(x * 3 + dv.x, z * 3 + dv.y, k) < 0.35:
				b.box_at(m_void, mid + Vector3(0, y0 + 1.6, 0) + n * 0.03, _oriented(0.7, 1.2, 0.06, along))
			continue
		var r := hashf(x * 5 + dv.x * 2, z * 5 + dv.y * 2, k + 30)
		if k >= 1 and r < 0.5:
			var lit := hashf(x, z, k + 99) < 0.07
			var cy := y0 + 1.55
			b.box_at(m_glow_win if lit else m_void, mid + Vector3(0, cy, 0) + n * 0.02, _oriented(0.72, 1.25, 0.04, along))
			# jambs, sill and lintel make the window read as a recess
			b.box_at(wm, mid + along * 0.42 + Vector3(0, cy, 0) + n * 0.09, _oriented(0.14, 1.45, 0.18, along))
			b.box_at(wm, mid - along * 0.42 + Vector3(0, cy, 0) + n * 0.09, _oriented(0.14, 1.45, 0.18, along))
			b.box_at(Mats.darkstone(), mid + Vector3(0, cy - 0.7, 0) + n * 0.1, _oriented(1.0, 0.12, 0.2, along))
			b.box_at(Mats.darkstone(), mid + Vector3(0, cy + 0.68, 0) + n * 0.1, _oriented(1.0, 0.16, 0.2, along))
		elif k == 0 and nh == 0 and r < 0.16:
			b.box_at(m_void, mid + Vector3(0, 1.05, 0) + n * 0.02, _oriented(1.05, 2.1, 0.04, along))
			b.box_at(m_char, mid + Vector3(0, 2.18, 0) + n * 0.1, _oriented(1.5, 0.22, 0.22, along))
		elif k >= 1 and r > 0.93:
			# a charred beam jutting from a burnt-out floor
			var len := 1.0 + hashf(x, z, 77) * 0.8
			b.box_at(m_char, mid + Vector3(0, y0 + 0.2, 0) + n * (len * 0.5), _oriented(0.18, 0.18, len, along), 0, 0.15 * (hashf(x, z, 78) - 0.5))
	# broken parapet along the top edge (jagged ruin silhouette)
	var top := h * S
	var wm2 := _wall_mat(x, z, h - 1)
	var segs := 4
	for i in range(segs):
		var rr := hashf(x * 7 + i, z * 7 + dv.x * 3 + dv.y * 5, 55)
		var ph := 0.0
		if playable:
			ph = 0.0 if rr < 0.3 else 0.25 + rr * 0.75
		else:
			ph = 0.0 if rr < 0.2 else 0.4 + rr * 1.6
		if ph <= 0.0:
			continue
		var c := a + along * (cell * (i + 0.5) / segs) - n * 0.15 + Vector3(0, top + ph * 0.5, 0)
		b.box_at(wm2, c, _oriented(cell / segs + 0.01, ph, 0.3, along))
		# a few fallen blocks at the foot of the broken bits
		if not playable and rr > 0.9 and near:
			b.box_at(wm2, a + along * (cell * i / segs) + n * 0.6 + Vector3(0, nh * S + 0.15, 0), Vector3(0.4, 0.3, 0.35), rr * 6.0)

func _oriented(len_along: float, height: float, depth: float, along: Vector3) -> Vector3:
	## Box size for a box whose length runs `along` the wall (x or z).
	if abs(along.x) > 0.5:
		return Vector3(len_along, height, depth)
	return Vector3(depth, height, len_along)

# ------------------------------------------------------------------ skyline

func _skyline(b: MeshBatch) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 7741
	var cx := map.w * cell * 0.5
	var cz := map.d * cell * 0.5
	var dm := Mats.pbr("darkstone", 0.08, Color(0.55, 0.55, 0.6))
	var sm := Mats.pbr("stone", 0.08, Color(0.6, 0.58, 0.58))
	for i in range(46):
		var ang := rng.randf() * TAU
		var dist := rng.randf_range(95.0, 240.0)
		var p := Vector3(cx + cos(ang) * dist, 0, cz + sin(ang) * dist)
		var w := rng.randf_range(6.0, 16.0)
		var d := rng.randf_range(6.0, 16.0)
		var h := rng.randf_range(14.0, 34.0)
		if rng.randf() < 0.18:
			h = rng.randf_range(40.0, 70.0)   # a broken spire
			w = rng.randf_range(5.0, 8.0)
			d = w
		var mat := dm if rng.randf() < 0.6 else sm
		b.box_at(mat, p + Vector3(0, h * 0.5, 0), Vector3(w, h, d), ang)
		# jagged ruined crown
		for j in range(5):
			var jh := rng.randf_range(1.0, 6.0)
			var off := Vector3(rng.randf_range(-w, w) * 0.4, h + jh * 0.5, rng.randf_range(-d, d) * 0.4).rotated(Vector3.UP, ang)
			b.box_at(mat, p + off, Vector3(w * rng.randf_range(0.2, 0.4), jh, d * rng.randf_range(0.2, 0.4)), ang)
		if rng.randf() < 0.35:
			b.add_gable(Mats.pbr("roof", 0.1, Color(0.6, 0.6, 0.6)), p + Vector3(0, h, 0), w, d, rng.randf_range(3.0, 7.0), true, [rng.randi() % 8, rng.randi() % 8])
	# the old city wall, broken in places
	var ring_r := 300.0
	for i in range(64):
		if rng.randf() < 0.2:
			continue
		var a0 := TAU * i / 64.0
		var p := Vector3(cx + cos(a0) * ring_r, 0, cz + sin(a0) * ring_r)
		var h := rng.randf_range(10.0, 18.0)
		b.box_at(dm, p + Vector3(0, h * 0.5, 0), Vector3(8.0, h, 31.0), -a0)
		if i % 4 == 0:
			b.box_at(dm, p + Vector3(0, h * 0.75, 0), Vector3(12.0, h * 1.5, 12.0), -a0)

# ------------------------------------------------------------------ props

func _props(b: MeshBatch) -> void:
	for z in range(map.d):
		for x in range(map.w):
			var pr := map.prop_at(x, z)
			if pr == "." or pr == "T" or pr == "B" or pr == "S" or pr == "G" or pr == "L" or pr == "A" or pr == "t" or pr == "m":
				continue
			var c := map.cell_center(x, z)
			var base := Vector3(c.x, map.h_at(x, z) * S, c.y)
			match pr:
				"p":
					_pillar(b, base, x, z)
				"b":
					_barricade(b, base, x, z)
				"r":
					_rubble(b, base, x, z, 1.0)
				"c":
					_crates(b, base, x, z)

func _pillar(b: MeshBatch, base: Vector3, x: int, z: int) -> void:
	var sm := Mats.pbr("stone", 0.35, Color(0.85, 0.83, 0.8))
	b.box_at(sm, base + Vector3(0, 0.25, 0), Vector3(1.3, 0.5, 1.3))
	b.box_at(sm, base + Vector3(0, 0.6, 0), Vector3(1.1, 0.2, 1.1))
	var h := PROP_H("p") - 0.9 - hashf(x, z, 1) * 0.6
	b.add_cyl(sm, Transform3D(Basis(), base + Vector3(0, 0.7, 0)), 0.5, 0.44, h, 14)
	# broken jagged top: a tilted drum
	b.add_cyl(sm, Transform3D(Basis.from_euler(Vector3(0.2, hashf(x, z, 4) * 6.0, 0.15)), base + Vector3(0.02, 0.7 + h - 0.05, 0)), 0.43, 0.38, 0.35 + hashf(x, z, 5) * 0.5, 14)
	# a fallen drum on the ground beside it
	var ang := hashf(x, z, 2) * TAU
	var off := Vector3(cos(ang), 0, sin(ang)) * 0.95
	b.add_cyl(sm, Transform3D(Basis.from_euler(Vector3(0, ang, PI * 0.5)), base + off + Vector3(0, 0.42, 0)), 0.42, 0.42, 0.7, 12)

func PROP_H(p: String) -> float:
	return BattleMap.PROP_HEIGHT.get(p, 1.0)

func _barricade(b: MeshBatch, base: Vector3, x: int, z: int) -> void:
	var wm := Mats.pbr("wood", 0.6, Color(0.75, 0.68, 0.6))
	var yaw := (0.0 if hashf(x, z, 1) < 0.5 else PI * 0.5) + (hashf(x, z, 2) - 0.5) * 0.5
	var fwd := Vector3(cos(yaw), 0, -sin(yaw))
	# planks laid against cross-trestles
	for i in range(4):
		b.box_at(wm, base + Vector3(0, 0.25 + i * 0.27, 0), Vector3(1.9, 0.22, 0.08), yaw, 0, (hashf(x, z, i + 5) - 0.5) * 0.12)
	for s in [-0.75, 0.0, 0.75]:
		var p: Vector3 = base + fwd * s
		b.box_at(wm, p + Vector3(0, 0.6, 0), Vector3(0.1, 1.5, 0.1), yaw, 0.55, 0)
		b.box_at(wm, p + Vector3(0, 0.6, 0), Vector3(0.1, 1.5, 0.1), yaw, -0.55, 0)
	# sharpened stakes
	for i in range(3):
		var p := base + fwd * (-0.6 + i * 0.6) + Vector3(0, 0.9, 0)
		b.add_cyl(wm, Transform3D(Basis.from_euler(Vector3(0.6, yaw, 0)), p), 0.06, 0.0, 0.7, 6)
	_rubble(b, base + Vector3(0.5, 0, 0.6), x + 3, z + 7, 0.35)

func _rubble(b: MeshBatch, base: Vector3, x: int, z: int, scale: float) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = x * 1000 + z * 7 + 13
	var sm := Mats.stone()
	var dm := Mats.darkstone()
	var n := int(10 * scale) + 3
	for i in range(n):
		var r := rng.randf_range(0.0, 0.85) * scale
		var a := rng.randf() * TAU
		var hgt := (1.0 - r / maxf(scale, 0.01)) * 0.6 * scale + 0.1
		var sz := Vector3(rng.randf_range(0.25, 0.6), rng.randf_range(0.15, 0.35), rng.randf_range(0.2, 0.5)) * (0.6 + scale * 0.4)
		b.box_at(sm if rng.randf() < 0.6 else dm, base + Vector3(cos(a) * r, hgt * rng.randf_range(0.2, 1.0), sin(a) * r), sz, rng.randf() * TAU, rng.randf_range(-0.5, 0.5), rng.randf_range(-0.5, 0.5))
	if scale >= 1.0:
		b.box_at(m_char, base + Vector3(0, 0.45, 0), Vector3(2.0, 0.16, 0.16), rng.randf() * TAU, 0.0, 0.35)

func _crates(b: MeshBatch, base: Vector3, x: int, z: int) -> void:
	var wm := Mats.pbr("wood", 0.7, Color(0.85, 0.75, 0.62))
	var yaw := hashf(x, z, 1) * PI
	b.box_at(wm, base + Vector3(-0.35, 0.4, 0.1), Vector3(0.8, 0.8, 0.8), yaw)
	b.box_at(wm, base + Vector3(0.45, 0.3, -0.25), Vector3(0.6, 0.6, 0.6), yaw + 0.4)
	b.box_at(wm, base + Vector3(-0.3, 1.1, 0.05), Vector3(0.55, 0.55, 0.55), yaw + 0.2)
	b.add_cyl(wm, Transform3D(Basis(), base + Vector3(0.4, 0, 0.55)), 0.3, 0.3, 0.85, 10)
	b.add_cyl(Mats.iron(), Transform3D(Basis(), base + Vector3(0.4, 0.15, 0.55)), 0.31, 0.31, 0.05, 10, false)
	b.add_cyl(Mats.iron(), Transform3D(Basis(), base + Vector3(0.4, 0.65, 0.55)), 0.31, 0.31, 0.05, 10, false)

func _street_rubble(b: MeshBatch) -> void:
	## Small fallen stones at the foot of walls (visual only).
	var rng := RandomNumberGenerator.new()
	rng.seed = 991
	var sm := Mats.stone()
	for z in range(-4, map.d + 4):
		for x in range(-4, map.w + 4):
			if H(x, z) != 0:
				continue
			var wall_dir := Vector2i.ZERO
			for dv in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
				if H(x + dv.x, z + dv.y) > 0:
					wall_dir = dv
			if wall_dir == Vector2i.ZERO or hashf(x, z, 61) > 0.45:
				continue
			var c := Vector3((x + 0.5) * cell, 0, (z + 0.5) * cell) + Vector3(wall_dir.x, 0, wall_dir.y) * 0.7
			for i in range(rng.randi_range(2, 6)):
				var s := rng.randf_range(0.12, 0.32)
				b.box_at(sm, c + Vector3(rng.randf_range(-0.8, 0.8) * (1 - abs(wall_dir.x)) + rng.randf_range(-0.2, 0.2), s * 0.4, rng.randf_range(-0.8, 0.8) * (1 - abs(wall_dir.y)) + rng.randf_range(-0.2, 0.2)), Vector3(s * 1.3, s, s), rng.randf() * TAU, rng.randf() * 0.6, rng.randf() * 0.6)

# ------------------------------------------------------------------ ladders, stairs, bridges

func _links(b: MeshBatch) -> void:
	var wm := Mats.pbr("wood", 0.6, Color(0.8, 0.72, 0.62))
	for lad in map.ladders:
		var a := Vector2i(int(lad["x"]), int(lad["z"]))
		var t := Vector2i(int(lad["tx"]), int(lad["tz"]))
		var dir := Vector3(t.x - a.x, 0, t.y - a.y)
		var c := map.cell_center(a.x, a.y)
		var low := map.h_at(a.x, a.y) * S
		var high := map.h_at(t.x, t.y) * S
		var rise := high - low + 0.9
		var foot := Vector3(c.x, low, c.y) + dir * (cell * 0.5 - 0.55)
		var top := Vector3(c.x, low, c.y) + dir * (cell * 0.5 - 0.05) + Vector3(0, rise, 0)
		var axis := (top - foot)
		var length := axis.length()
		var up := axis.normalized()
		var side := up.cross(dir).normalized()
		if side.length() < 0.1:
			side = Vector3(dir.z, 0, -dir.x)
		var basis := Basis(side, up, side.cross(up)).orthonormalized()
		for s in [-0.28, 0.28]:
			b.add_box(wm, Transform3D(basis, foot + axis * 0.5 + side * s), Vector3(0.07, length, 0.07))
		var rungs := int(length / 0.35)
		for i in range(1, rungs):
			b.add_box(wm, Transform3D(basis, foot + axis * (float(i) / rungs)), Vector3(0.6, 0.045, 0.045))
	for stv in map.stairs:
		var a := Vector2i(int(stv["x"]), int(stv["z"]))
		var t := Vector2i(int(stv["tx"]), int(stv["tz"]))
		var dir := Vector3(t.x - a.x, 0, t.y - a.y)
		var side := Vector3(dir.z, 0, -dir.x)
		var c := map.cell_center(a.x, a.y)
		var low := map.h_at(a.x, a.y) * S
		var rise := (map.h_at(t.x, t.y) - map.h_at(a.x, a.y)) * S
		var steps := int(rise / 0.3)
		var run := cell * 0.95
		var sm := Mats.pbr("stone", 0.3, Color(0.8, 0.78, 0.75))
		for i in range(steps):
			var f := (i + 0.5) / steps
			var p := Vector3(c.x, low, c.y) + dir * (-cell * 0.47 + run * f)
			var hgt := rise * (i + 1) / steps
			b.add_box(sm, Transform3D(Basis(), p + Vector3(0, hgt * 0.5, 0) + side * 0.0), _oriented_dir(run / steps + 0.01, hgt, 1.5, dir))
		# side wall of the stair
		var mid := Vector3(c.x, low, c.y) + side * 0.82
		b.add_box(Mats.darkstone(), Transform3D(Basis(), mid + Vector3(0, rise * 0.3, 0)), _oriented_dir(cell * 0.9, rise * 0.6, 0.18, dir))

func _oriented_dir(len_along: float, height: float, width: float, dir: Vector3) -> Vector3:
	if abs(dir.x) > 0.5:
		return Vector3(len_along, height, width)
	return Vector3(width, height, len_along)

func _bridges(b: MeshBatch) -> void:
	var wm := Mats.pbr("wood", 0.6, Color(0.7, 0.62, 0.55))
	for k in map.bridge_level:
		var v: Vector2i = k
		var l: int = map.bridge_level[k]
		var along_x := map.has_node(v.x - 1, v.y, l) or map.has_node(v.x + 1, v.y, l)
		var c := map.cell_center(v.x, v.y)
		var y := l * S
		var dir := Vector3(1, 0, 0) if along_x else Vector3(0, 0, 1)
		var side := Vector3(dir.z, 0, dir.x)
		# planks across the run
		for i in range(7):
			var off := dir * (-cell * 0.5 + cell * (i + 0.5) / 7.0)
			var rr := hashf(v.x, v.y, i)
			b.box_at(wm, Vector3(c.x, y - 0.06, c.y) + off, _oriented_dir(0.26, 0.07, 1.4 + rr * 0.15, dir), 0, (rr - 0.5) * 0.04, (rr - 0.5) * 0.06)
		# two beams under the planks
		for s in [-0.5, 0.5]:
			b.box_at(m_char, Vector3(c.x, y - 0.2, c.y) + side * s, _oriented_dir(cell + 0.02, 0.16, 0.14, dir))
		# rope rail posts
		for s in [-0.72, 0.72]:
			b.box_at(wm, Vector3(c.x, y + 0.45, c.y) + side * s, Vector3(0.08, 1.0, 0.08))
			b.box_at(wm, Vector3(c.x, y + 0.92, c.y) + side * s, _oriented_dir(cell, 0.04, 0.04, dir))

# ------------------------------------------------------------------ the idol of the Chained One

func _robe_mesh() -> Mesh:
	var m := CylinderMesh.new()
	m.bottom_radius = 1.15
	m.top_radius = 0.6
	m.height = 3.0
	m.radial_segments = 20
	m.rings = 3
	return m

func _idol() -> void:
	var cells: Array = []
	for z in range(map.d):
		for x in range(map.w):
			if map.prop_at(x, z) == "T":
				cells.append(Vector2i(x, z))
	if cells.is_empty():
		return
	var cx := 0.0
	var cz := 0.0
	for c in cells:
		cx += (c.x + 0.5) * cell
		cz += (c.y + 0.5) * cell
	cx /= cells.size()
	cz /= cells.size()
	var base := Vector3(cx, 0, cz)
	var b := MeshBatch.new()
	var ps := Mats.pbr("darkstone", 0.4, Color(0.75, 0.75, 0.78))
	var bronze := StandardMaterial3D.new()
	bronze.albedo_color = Color(0.2, 0.25, 0.2)
	bronze.metallic = 0.75
	bronze.roughness = 0.42
	bronze.normal_enabled = true
	bronze.normal_texture = load("res://textures/plaster_normal.png")
	bronze.normal_scale = 0.6
	bronze.uv1_triplanar = true
	bronze.uv1_world_triplanar = true
	bronze.uv1_scale = Vector3(0.6, 0.6, 0.6)
	bronze.rim_enabled = true
	bronze.rim = 0.3
	# stepped plinth
	b.box_at(ps, base + Vector3(0, 0.3, 0), Vector3(4.2, 0.6, 4.2))
	b.box_at(ps, base + Vector3(0, 0.85, 0), Vector3(3.4, 0.5, 3.4))
	b.box_at(ps, base + Vector3(0, 1.35, 0), Vector3(2.7, 0.5, 2.7))
	# the hooded, faceless god in his robe, head bowed, chained at the wrists
	var statue := Node3D.new()
	statue.position = base
	add_child(statue)
	var torso := base + Vector3(0, 4.1, 0)
	var top := 1.6
	_sp(statue, "cyl", Vector3(1.0, 3.0, 1.0), bronze, Vector3(0, top + 1.5, 0), Vector3.ZERO)
	var robe := statue.get_child(statue.get_child_count() - 1) as MeshInstance3D
	robe.mesh = _robe_mesh()
	robe.scale = Vector3.ONE
	# folds in the robe
	for i in range(12):
		var ang := i * TAU / 12.0 + 0.2
		var fup := Vector3(-cos(ang) * 0.55, 3.0, -sin(ang) * 0.55).normalized()
		var fside := fup.cross(Vector3(cos(ang), 0, sin(ang))).normalized()
		var f := _sp(statue, "capsule", Vector3.ONE, bronze, Vector3(cos(ang) * 0.86, top + 1.45, sin(ang) * 0.86), Vector3.ZERO)
		f.basis = Basis(fside, fup, fside.cross(fup)).orthonormalized() * Basis.from_scale(Vector3(0.2, 1.45, 0.2))
	_sp(statue, "sphere", Vector3(0.9, 0.42, 0.62), bronze, Vector3(0, top + 3.0, 0.05), Vector3(0.15, 0, 0))
	# hood bowed forward, with an empty dark face and two faint embers for eyes
	_sp(statue, "sphere", Vector3(0.52, 0.62, 0.55), bronze, Vector3(0, top + 3.55, 0.28), Vector3(0.45, 0, 0))
	_sp(statue, "sphere", Vector3(0.62, 0.55, 0.5), bronze, Vector3(0, top + 3.4, -0.08), Vector3(0.2, 0, 0))
	var void_m := StandardMaterial3D.new()
	void_m.albedo_color = Color(0.01, 0.01, 0.012)
	void_m.roughness = 1.0
	_sp(statue, "sphere", Vector3(0.34, 0.42, 0.2), void_m, Vector3(0, top + 3.42, 0.7), Vector3(0.45, 0, 0))
	var eye_m := Mats.glow(Color(0.35, 1.0, 0.85), 6.0, true)
	for s in [-1.0, 1.0]:
		_sp(statue, "sphere", Vector3(0.045, 0.03, 0.03), eye_m, Vector3(s * 0.11, top + 3.42, 0.86), Vector3.ZERO)
	var wrists := []
	for s in [-1.0, 1.0]:
		var sh := Vector3(s * 0.78, top + 3.0, 0.15)
		var el := Vector3(s * 0.82, top + 2.0, 0.55)
		var wr := Vector3(s * 0.32, top + 1.75, 1.05)
		for seg in [[sh, el, 0.36], [el, wr, 0.3]]:
			var p0: Vector3 = seg[0]
			var p1: Vector3 = seg[1]
			var up := (p0 - p1).normalized()
			var side := up.cross(Vector3.FORWARD).normalized()
			var bas := Basis(side, up, side.cross(up)).orthonormalized()
			var len := (p0 - p1).length() + 0.3
			var arm := _sp(statue, "capsule", Vector3.ONE, bronze, (p0 + p1) * 0.5, Vector3.ZERO)
			arm.basis = bas * Basis.from_scale(Vector3(seg[2], len * 0.5, seg[2]))
			if seg[1] == wr:
				var cuff := _sp(statue, "cyl", Vector3.ONE, Mats.iron(), wr + up * 0.1, Vector3.ZERO)
				cuff.basis = bas * Basis.from_scale(Vector3(0.4, 0.3, 0.4))
		_sp(statue, "sphere", Vector3(0.17, 0.2, 0.15), bronze, wr - Vector3(0, 0.12, -0.05), Vector3.ZERO)
		wrists.append(base + wr)
	# chains run from the shackles down to rings on the plinth corners
	var iron := Mats.iron()
	for i in range(2):
		var wr: Vector3 = wrists[i]
		var anchor := base + Vector3((-1.0 if i == 0 else 1.0) * 1.85, 0.62, 1.85)
		var links := 14
		for j in range(links):
			var t := float(j) / (links - 1)
			var p := wr.lerp(anchor, t) + Vector3(0, -sin(t * PI) * 0.55, 0)
			var d := (anchor - wr).normalized()
			var bas := Basis.looking_at(d, Vector3.UP).rotated(d, (PI * 0.5) if j % 2 else 0.0)
			b.add_box(iron, Transform3D(bas, p), Vector3(0.05, 0.2, 0.26))
		b.add_cyl(iron, Transform3D(Basis(), anchor - Vector3(0, 0.1, 0)), 0.18, 0.18, 0.2, 8)
	# back chains to the rear corners
	for s in [-1.0, 1.0]:
		var from := torso + Vector3(s * 0.6, 0.2, -0.45)
		var anchor := base + Vector3(s * 1.85, 0.62, -1.85)
		for j in range(12):
			var t := float(j) / 11.0
			var p := from.lerp(anchor, t) + Vector3(0, -sin(t * PI) * 0.4, 0)
			var d := (anchor - from).normalized()
			var bas := Basis.looking_at(d, Vector3.UP).rotated(d, (PI * 0.5) if j % 2 else 0.0)
			b.add_box(iron, Transform3D(bas, p), Vector3(0.05, 0.2, 0.26))
	var mi := b.build(true)
	mi.name = "Idol"
	add_child(mi)
	# a glowing crack through the plinth, where a godshard struck
	var crack := MeshBatch.new()
	var gm := Mats.glow(Color(0.3, 1.0, 0.85), 5.0)
	for i in range(6):
		var a := i * 0.6
		crack.box_at(gm, base + Vector3(-1.2 + i * 0.45, 0.62 + sin(a) * 0.08, 2.11), Vector3(0.5, 0.05, 0.02), 0, 0, sin(a * 2.0) * 0.5)
	var cmi := crack.build(false)
	add_child(cmi)
	var l := OmniLight3D.new()
	l.light_color = Color(0.3, 1.0, 0.8)
	l.light_energy = 1.4
	l.omni_range = 6.0
	l.position = base + Vector3(0, 0.9, 2.6)
	add_child(l)

# ------------------------------------------------------------------ the starstone

func _starstone() -> void:
	## A lump of the fallen god's flesh, crusted black and split with
	## green-white fire, sitting where it struck in the crater's heart.
	var cells: Array = []
	for z in range(map.d):
		for x in range(map.w):
			if map.prop_at(x, z) == "S":
				cells.append(Vector2i(x, z))
	if cells.is_empty():
		return
	var cx := 0.0
	var cz := 0.0
	for c in cells:
		cx += (c.x + 0.5) * cell
		cz += (c.y + 0.5) * cell
	cx /= cells.size()
	cz /= cells.size()
	var c0: Vector2i = cells[0]
	var base := Vector3(cx, map.h_at(c0.x, c0.y) * S, cz)
	# the crater floor: the paving burned away to dry, cracked ash, which
	# drinks the moonlight instead of shining like the wet streets
	var fb := MeshBatch.new()
	var ashfloor := Mats.pbr("dirt", 0.22, Color(0.3, 0.27, 0.25), 1.0)
	var scorch := Mats.pbr("dirt", 0.22, Color(0.16, 0.15, 0.15), 1.0)
	for z in range(map.d):
		for x in range(map.w):
			if map.h_at(x, z) != 0:
				continue
			var cc := Vector3((x + 0.5) * cell, 0, (z + 0.5) * cell)
			var dd := Vector2(cc.x - cx, cc.z - cz).length() / cell
			if dd > 6.8:
				continue
			var fm: StandardMaterial3D = scorch if dd < 3.2 + hashf(x, z, 31) * 1.2 else ashfloor
			var x0 := x * cell
			var z0 := z * cell
			fb.add_quad(fm, Vector3(x0, 0.012, z0), Vector3(x0 + cell, 0.012, z0), Vector3(x0 + cell, 0.012, z0 + cell), Vector3(x0, 0.012, z0 + cell), Vector3.UP)
	var fmi := fb.build(false)
	fmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(fmi)
	var b := MeshBatch.new()
	var crust := Mats.pbr("darkstone", 0.5, Color(0.22, 0.2, 0.21), 0.8)
	var ash := Mats.pbr("stone", 0.4, Color(0.3, 0.27, 0.25))
	var vein := Mats.glow(Color(0.45, 1.0, 0.75), 3.5)
	var core := Mats.glow(Color(0.7, 1.0, 0.85), 5.0)
	# a ring of thrown-up paving slabs, tilted out from the impact
	for i in range(14):
		var a := i * TAU / 14.0 + hashf(i, 7) * 0.3
		var r := 2.6 + hashf(i, 3) * 0.6
		var p := base + Vector3(cos(a) * r, 0.25, sin(a) * r)
		b.box_at(ash, p, Vector3(1.1, 0.25, 0.8 + hashf(i, 5) * 0.5), -a, 0.0, 0.45 + hashf(i, 9) * 0.3)
	# the stone itself: black, jagged lumps piled on each other
	var lumps := [[0.0, 0.7, 0.0, 2.6, 1.5, 2.3], [0.5, 1.6, -0.3, 1.9, 1.4, 1.7], [-0.6, 1.4, 0.4, 1.6, 1.6, 1.5],
		[0.1, 2.5, 0.1, 1.3, 1.4, 1.2], [-0.2, 3.3, -0.1, 0.8, 1.2, 0.7], [1.1, 0.6, 0.8, 1.2, 1.0, 1.1], [-1.1, 0.5, -0.8, 1.1, 0.9, 1.3]]
	for i in range(lumps.size()):
		var L: Array = lumps[i]
		b.box_at(crust, base + Vector3(L[0], L[1], L[2]), Vector3(L[3], L[4], L[5]),
			hashf(i, 1) * 3.0, (hashf(i, 2) - 0.5) * 0.6, (hashf(i, 4) - 0.5) * 0.6)
	var mi := b.build(true)
	mi.name = "Starstone"
	add_child(mi)
	# cracks of fire running over it, and a burning heart showing through
	var g := MeshBatch.new()
	for i in range(22):
		var a := hashf(i, 11) * TAU
		var y := 0.3 + hashf(i, 12) * 3.2
		var r := 1.25 - y * 0.18 + 0.06
		g.box_at(vein, base + Vector3(cos(a) * r, y, sin(a) * r), Vector3(0.05, 0.35 + hashf(i, 13) * 0.5, 0.05),
			-a, (hashf(i, 14) - 0.5) * 1.2, (hashf(i, 15) - 0.5) * 1.4)
	g.box_at(core, base + Vector3(0.25, 1.9, 0.75), Vector3(0.5, 0.7, 0.35), 0.4, 0.2, 0.1)
	g.box_at(core, base + Vector3(-0.5, 2.6, 0.35), Vector3(0.3, 0.5, 0.3), -0.3, 0.1, 0.3)
	var gmi := g.build(false)
	gmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(gmi)
	# green fire licking off the top, and a cold glow over the whole bowl
	var f := _fire_particles(22, 0.6, 1.0)
	var fq: QuadMesh = f.draw_pass_1
	(fq.material as StandardMaterial3D).albedo_color = Color(0.9, 1.1, 1.0)
	var pm: ParticleProcessMaterial = f.process_material
	var grad := Gradient.new()
	grad.set_color(0, Color(0.8, 1.0, 0.9, 1.0))
	grad.set_color(1, Color(0.05, 0.4, 0.25, 0.0))
	grad.add_point(0.4, Color(0.35, 1.0, 0.65, 0.8))
	var gt := GradientTexture1D.new()
	gt.gradient = grad
	pm.color_ramp = gt
	f.position = base + Vector3(0, 3.7, 0)
	add_child(f)
	var e := _embers(26)
	e.position = base + Vector3(0, 2.0, 0)
	add_child(e)
	var l := OmniLight3D.new()
	l.light_color = Color(0.3, 0.95, 0.6)
	l.light_energy = 2.2
	l.omni_range = 12.0
	l.omni_attenuation = 1.6
	l.light_specular = 0.15
	l.shadow_enabled = true
	l.position = base + Vector3(0, 5.5, 0)
	add_child(l)
	flicker_lights.append({"light": l, "base": l.light_energy, "seed": 3.3})

func _water() -> void:
	## Flood water over the drowned streets, out to the edge of the backdrop.
	if map.water <= 0.0:
		return
	var pm := PlaneMesh.new()
	pm.size = Vector2((map.w + RING * 2) * cell, (map.d + RING * 2) * cell)
	var mi := MeshInstance3D.new()
	mi.name = "Water"
	mi.mesh = pm
	var sm := ShaderMaterial.new()
	sm.shader = load("res://shaders/water.gdshader")
	mi.material_override = sm
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.position = Vector3(map.w * cell * 0.5, map.water, map.d * cell * 0.5)
	add_child(mi)
	# mooring piles and the stumps of drowned fences, standing out of it
	var b := MeshBatch.new()
	var wd := Mats.pbr("wood", 0.5, Color(0.42, 0.37, 0.33))
	var rng := RandomNumberGenerator.new()
	rng.seed = 77
	for z in range(map.d):
		for x in range(map.w):
			if map.h_at(x, z) != 0 or map.prop_at(x, z) != "." or map.bridge_level.has(Vector2i(x, z)):
				continue
			var nb := 0
			for dv in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
				if map.h_at(x + dv.x, z + dv.y) > 0 or map.bridge_level.has(Vector2i(x + dv.x, z + dv.y)):
					nb += 1
			if nb == 0 or rng.randf() > 0.3:
				continue
			var c := map.cell_center(x, z)
			var off := Vector3(rng.randf_range(-0.8, 0.8), 0, rng.randf_range(-0.8, 0.8))
			var tall := rng.randf_range(1.2, 2.6)
			b.add_cyl(wd, Transform3D(Basis.from_euler(Vector3(rng.randf_range(-0.12, 0.12), 0, rng.randf_range(-0.12, 0.12))), Vector3(c.x, tall * 0.5, c.y) + off), 0.11, 0.13, tall, 7)
	add_child(b.build(true))

func _bell() -> void:
	## Mael's bell: the sea god's great bronze bell, fallen from its frame on
	## the night the river came in, lying cracked across the shrine court.
	var cells: Array = []
	for z in range(map.d):
		for x in range(map.w):
			if map.prop_at(x, z) == "L":
				cells.append(Vector2i(x, z))
	if cells.is_empty():
		return
	var cx := 0.0
	var cz := 0.0
	for c in cells:
		cx += (c.x + 0.5) * cell
		cz += (c.y + 0.5) * cell
	cx /= cells.size()
	cz /= cells.size()
	var c0: Vector2i = cells[0]
	var base := Vector3(cx, map.h_at(c0.x, c0.y) * S, cz)
	var bronze := StandardMaterial3D.new()
	bronze.albedo_color = Color(0.42, 0.3, 0.17)
	bronze.metallic = 0.85
	bronze.roughness = 0.42
	var verd := StandardMaterial3D.new()
	verd.albedo_color = Color(0.24, 0.4, 0.33)
	verd.roughness = 0.85
	var prof := [[0.0, 1.62, 1.62], [0.06, 1.6, 1.6], [0.16, 1.45, 1.45], [0.32, 1.22, 1.22], [0.6, 1.02, 1.02],
		[1.0, 0.9, 0.9], [1.5, 0.86, 0.86], [2.0, 0.87, 0.87], [2.3, 0.86, 0.86], [2.48, 0.76, 0.76],
		[2.58, 0.52, 0.52], [2.62, 0.05, 0.05]]
	var bell := MeshInstance3D.new()
	bell.name = "Bell"
	bell.mesh = Figure.loft("mael_bell", prof, 28)
	bell.material_override = bronze
	# on its side, mouth to the south-east, sunk a hand into the flagstones
	bell.transform = Transform3D(Basis.from_euler(Vector3(0.0, 0.7, PI * 0.5 + 0.08)), base + Vector3(1.2, 1.28, -0.4))
	add_child(bell)
	# the dark hollow of its mouth
	var hollow := MeshInstance3D.new()
	var hm := CylinderMesh.new()
	hm.top_radius = 1.48
	hm.bottom_radius = 1.48
	hm.height = 0.02
	hollow.mesh = hm
	hollow.material_override = Mats.flat(Color(0.01, 0.008, 0.006), 1.0)
	hollow.transform = bell.transform * Transform3D(Basis(), Vector3(0, -0.012, 0))
	add_child(hollow)
	var lip := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 1.5
	tm.outer_radius = 1.68
	tm.rings = 32
	tm.ring_segments = 8
	lip.mesh = tm
	lip.material_override = bronze
	lip.transform = bell.transform * Transform3D(Basis(), Vector3(0, 0.08, 0))
	add_child(lip)
	var crown := MeshInstance3D.new()
	var cm := TorusMesh.new()
	cm.inner_radius = 0.16
	cm.outer_radius = 0.27
	crown.mesh = cm
	crown.material_override = bronze
	crown.transform = bell.transform * Transform3D(Basis(Vector3.RIGHT, PI * 0.5), Vector3(0, 2.8, 0))
	add_child(crown)
	var b := MeshBatch.new()
	# green bloom where the river lay on it
	var rng := RandomNumberGenerator.new()
	rng.seed = 5
	for i in range(26):
		var y := rng.randf_range(0.5, 2.3)
		var a := rng.randf_range(-1.5, 1.9)
		var r: float = 0.87 + 0.75 * pow(maxf(0.0, 1.0 - y / 1.0), 2.0)
		var p: Vector3 = bell.transform * Vector3(cos(a) * r, y, sin(a) * r)
		var nrm: Vector3 = (bell.transform.basis * Vector3(cos(a), 0.05, sin(a))).normalized()
		b.add_cyl(verd, Transform3D(Basis(Quaternion(Vector3.UP, nrm)) * Basis.from_scale(Vector3(rng.randf_range(0.6, 1.5), 1.0, rng.randf_range(0.4, 0.9))), p), rng.randf_range(0.12, 0.24), 0.1, 0.03, 7)
	# the broken frame it hung from: two posts down, the beam across them
	var wd := Mats.pbr("wood", 0.5, Color(0.36, 0.3, 0.26))
	b.add_box(wd, Transform3D(Basis.from_euler(Vector3(0, 0.3, 1.42)), base + Vector3(-1.6, 0.3, 1.5)), Vector3(0.36, 4.2, 0.36))
	b.add_box(wd, Transform3D(Basis.from_euler(Vector3(1.38, 0.9, 0)), base + Vector3(-0.8, 0.32, -1.9)), Vector3(0.34, 3.6, 0.34))
	b.add_box(wd, Transform3D(Basis.from_euler(Vector3(0.1, -0.5, 0.25)), base + Vector3(-1.9, 0.9, -0.2)), Vector3(4.6, 0.4, 0.42))
	var mi := b.build(true)
	mi.name = "BellWreck"
	add_child(mi)

func _azath() -> void:
	## A House of the Azath: a squat keep of black-green stone with a square
	## tower, older than any city round it. Roots have grown up its walls and
	## nothing has ever been seen through its windows but a pale, cold light.
	## Round it, in its yard, dead trees and the barrows of what it has taken.
	var cells: Array = []
	for z in range(map.d):
		for x in range(map.w):
			if map.prop_at(x, z) == "A":
				cells.append(Vector2i(x, z))
	var trees: Array = []
	var barrows: Array = []
	for z in range(map.d):
		for x in range(map.w):
			match map.prop_at(x, z):
				"t":
					trees.append(Vector2i(x, z))
				"m":
					barrows.append(Vector2i(x, z))
	if cells.is_empty() and trees.is_empty() and barrows.is_empty():
		return
	var b := MeshBatch.new()
	var rng := RandomNumberGenerator.new()
	rng.seed = 1201
	var bark := Mats.pbr("wood", 0.7, Color(0.2, 0.17, 0.15), 1.1)
	if not cells.is_empty():
		var mn: Vector2i = cells[0]
		var mx: Vector2i = cells[0]
		for c in cells:
			mn = Vector2i(mini(mn.x, c.x), mini(mn.y, c.y))
			mx = Vector2i(maxi(mx.x, c.x), maxi(mx.y, c.y))
		var x0 := mn.x * cell + 1.0
		var z0 := mn.y * cell + 1.0
		var x1 := (mx.x + 1) * cell - 1.0
		var z1 := (mx.y + 1) * cell - 1.0
		var gy := map.h_at(mn.x, mn.y) * S
		_azath_house(b, rng, Vector3(x0, gy, z0), Vector3(x1, gy, z1), bark)
	for t in trees:
		var c := map.cell_center(t.x, t.y)
		_dead_tree(b, rng, Vector3(c.x, map.h_at(t.x, t.y) * S, c.y), bark)
	for m in barrows:
		var c := map.cell_center(m.x, m.y)
		_barrow(b, rng, Vector3(c.x, map.h_at(m.x, m.y) * S, c.y))
	# dry grass in the yard
	if yard.size.x > 0:
		var grass := Mats.flat(Color(0.4, 0.36, 0.22), 0.95)
		var grass2 := Mats.flat(Color(0.26, 0.3, 0.17), 0.95)
		for z in range(yard.position.y, yard.end.y):
			for x in range(yard.position.x, yard.end.x):
				if not _in_yard(x, z) or map.prop_at(x, z) == "A":
					continue
				var gy := map.h_at(x, z) * S
				for i in range(rng.randi_range(4, 8)):
					var p := Vector3((x + rng.randf()) * cell, gy, (z + rng.randf()) * cell)
					for j in range(6):
						var hh := rng.randf_range(0.18, 0.45)
						b.box_at(grass if rng.randf() < 0.6 else grass2, p + Vector3(rng.randf_range(-0.08, 0.08), hh * 0.5, rng.randf_range(-0.08, 0.08)), Vector3(0.014, hh, 0.006), rng.randf() * TAU, rng.randf_range(-0.45, 0.45), rng.randf_range(-0.45, 0.45))
	var mi := b.build(true)
	mi.name = "AzathYard"
	add_child(mi)

func _azath_house(b: MeshBatch, rng: RandomNumberGenerator, lo: Vector3, hi: Vector3, bark: Material) -> void:
	var st := Mats.pbr("plaster", 0.2, Color(0.34, 0.4, 0.36))
	var st2 := Mats.pbr("plaster", 0.25, Color(0.46, 0.5, 0.45))
	var slate := Mats.pbr("roof", 0.35, Color(0.35, 0.4, 0.38))
	var moss := Mats.flat(Color(0.13, 0.19, 0.1), 0.95)
	var cold := Mats.glow(Color(0.55, 0.9, 0.72), 2.2)
	var gy := lo.y
	var wall_h := 8.2
	var cx := (lo.x + hi.x) * 0.5
	var cz := (lo.z + hi.z) * 0.5
	var sx := hi.x - lo.x
	var sz := hi.z - lo.z
	# a stepped plinth of great slabs
	b.box_at(st2, Vector3(cx, gy + 0.2, cz), Vector3(sx + 0.9, 0.4, sz + 0.9))
	b.box_at(st2, Vector3(cx, gy + 0.55, cz), Vector3(sx + 0.4, 0.3, sz + 0.4))
	# the core, then rough courses of stone over every face
	b.box_at(st, Vector3(cx, gy + wall_h * 0.5, cz), Vector3(sx - 0.2, wall_h, sz - 0.2))
	_rough_courses(b, rng, st, Vector3(lo.x, gy + 0.7, lo.z), Vector3(hi.x, gy + wall_h, hi.z))
	# squat buttresses, battered back toward the wall
	for f in [[Vector3(lo.x, 0, lo.z), Vector3(1, 0, 0), Vector3(0, 0, -1), sx], [Vector3(hi.x, 0, lo.z), Vector3(0, 0, 1), Vector3(1, 0, 0), sz],
			[Vector3(hi.x, 0, hi.z), Vector3(-1, 0, 0), Vector3(0, 0, 1), sx], [Vector3(lo.x, 0, hi.z), Vector3(0, 0, -1), Vector3(-1, 0, 0), sz]]:
		var o: Vector3 = f[0]
		var al: Vector3 = f[1]
		var nn: Vector3 = f[2]
		var ln: float = f[3]
		for u: float in [0.0, ln * 0.25, ln * 0.75, ln]:
			if f[3] == sx and nn.z > 0.5 and absf(u - ln * 0.5) < 2.5:
				continue
			var pb: Vector3 = o + al * u + Vector3(0, gy, 0)
			b.box_at(st2, pb + nn * 0.55 + Vector3(0, 1.6, 0), _oriented(1.0, 3.2, 1.1, al))
			b.box_at(st2, pb + nn * 0.4 + Vector3(0, 4.0, 0), _oriented(0.9, 1.8, 0.8, al), 0, _tilt(al, 0.0).x - (0.25 if absf(nn.z) > 0.5 else 0.0) * signf(nn.z), _tilt(al, 0.0).y + (0.25 if absf(nn.x) > 0.5 else 0.0) * signf(nn.x))
	# a heavy cornice and the low hipped roof of stone slates
	b.box_at(st2, Vector3(cx, gy + wall_h + 0.15, cz), Vector3(sx + 0.5, 0.3, sz + 0.5))
	var e := 0.35
	var ry := gy + wall_h + 0.3
	var rise := 3.6
	var a0 := Vector3(lo.x - e, ry, lo.z - e)
	var a1 := Vector3(hi.x + e, ry, lo.z - e)
	var a2 := Vector3(hi.x + e, ry, hi.z + e)
	var a3 := Vector3(lo.x - e, ry, hi.z + e)
	var r0 := Vector3(cx - sx * 0.18, ry + rise, cz)
	var r1 := Vector3(cx + sx * 0.18, ry + rise, cz)
	b.add_quad(slate, a0, a1, r1, r0, (Vector3(0, 1, -1)).normalized())
	b.add_quad(slate, a2, a3, r0, r1, (Vector3(0, 1, 1)).normalized())
	b.add_tri(slate, a1, a2, r1, Vector3(1, 1, 0).normalized())
	b.add_tri(slate, a3, a0, r0, Vector3(-1, 1, 0).normalized())
	# ridge stones
	for i in range(7):
		var f := i / 6.0
		b.box_at(st2, r0.lerp(r1, f) + Vector3(0, 0.12, 0), Vector3(0.55, 0.28, 0.55), rng.randf() * 0.4)
	# the tower over the north-west corner, its crown broken by nothing but time
	var tw0 := Vector3(lo.x - 0.6, gy, lo.z - 0.6)
	var tws := 5.2
	var twh := 17.5
	b.box_at(st, Vector3(tw0.x + tws * 0.5, gy + twh * 0.5, tw0.z + tws * 0.5), Vector3(tws - 0.2, twh, tws - 0.2))
	_rough_courses(b, rng, st, Vector3(tw0.x, gy + 0.7, tw0.z), Vector3(tw0.x + tws, gy + twh, tw0.z + tws))
	b.box_at(st2, Vector3(tw0.x + tws * 0.5, gy + twh + 0.18, tw0.z + tws * 0.5), Vector3(tws + 0.5, 0.36, tws + 0.5))
	for i in range(4):
		for side in range(4):
			var u := (i + 0.5) / 4.0 * tws
			var p := Vector3()
			match side:
				0: p = Vector3(tw0.x + u, 0, tw0.z)
				1: p = Vector3(tw0.x + u, 0, tw0.z + tws)
				2: p = Vector3(tw0.x, 0, tw0.z + u)
				_: p = Vector3(tw0.x + tws, 0, tw0.z + u)
			if i % 2 == 0:
				b.box_at(st2, p + Vector3(0, gy + twh + 0.75, 0), Vector3(0.8, 0.9, 0.8))
	# a cap of slates on the tower, steep
	var tc := Vector3(tw0.x + tws * 0.5, gy + twh + 0.36, tw0.z + tws * 0.5)
	b.add_cyl(slate, Transform3D(Basis(Vector3.UP, PI * 0.25), tc), tws * 0.62, 0.05, 4.2, 4)
	# deep slit windows: dark, and here and there that cold light
	var wins := [
		[Vector3(cx, gy + 5.4, lo.z), Vector3(0, 0, -1)], [Vector3(cx + sx * 0.3, gy + 5.4, lo.z), Vector3(0, 0, -1)],
		[Vector3(lo.x, gy + 5.4, cz + sz * 0.25), Vector3(-1, 0, 0)], [Vector3(hi.x, gy + 5.4, cz - sz * 0.2), Vector3(1, 0, 0)],
		[Vector3(hi.x, gy + 5.4, cz + sz * 0.25), Vector3(1, 0, 0)], [Vector3(cx - sx * 0.3, gy + 5.4, hi.z), Vector3(0, 0, 1)],
		[Vector3(cx + sx * 0.3, gy + 5.4, hi.z), Vector3(0, 0, 1)],
		[Vector3(tw0.x + tws * 0.5, gy + 13.5, tw0.z), Vector3(0, 0, -1)], [Vector3(tw0.x, gy + 13.5, tw0.z + tws * 0.5), Vector3(-1, 0, 0)],
		[Vector3(tw0.x + tws, gy + 13.5, tw0.z + tws * 0.5), Vector3(1, 0, 0)], [Vector3(tw0.x + tws * 0.5, gy + 13.5, tw0.z + tws), Vector3(0, 0, 1)],
	]
	for k in range(wins.size()):
		var w: Array = wins[k]
		var p: Vector3 = w[0]
		var n: Vector3 = w[1]
		var along := Vector3(-n.z, 0, n.x)
		var lit := k in [1, 3, 5, 8, 10]
		b.box_at(cold if lit else m_void, p + n * 0.22, _oriented(0.42, 1.7, 0.06, along))
		b.box_at(st2, p + n * 0.38 + along * 0.38, _oriented(0.32, 2.1, 0.35, along))
		b.box_at(st2, p + n * 0.38 - along * 0.38, _oriented(0.32, 2.1, 0.35, along))
		b.box_at(st2, p + n * 0.4 + Vector3(0, 1.15, 0), _oriented(1.15, 0.3, 0.4, along))
		b.box_at(st2, p + n * 0.4 - Vector3(0, 1.0, 0), _oriented(1.0, 0.18, 0.42, along))
	# the door: south face, deep, shut, and nobody has ever seen it open
	var dp := Vector3(cx, gy + 0.7, hi.z)
	b.box_at(m_void, dp + Vector3(0, 1.65, 0.05), Vector3(2.3, 3.3, 0.1))
	var door := Mats.pbr("wood", 0.45, Color(0.28, 0.22, 0.18))
	for i in range(5):
		b.box_at(door, dp + Vector3(-0.88 + i * 0.44, 1.55, 0.14), Vector3(0.4, 3.1, 0.12))
	var iron := Mats.iron()
	for yy in [0.6, 1.6, 2.6]:
		b.box_at(iron, dp + Vector3(0, yy, 0.22), Vector3(2.1, 0.1, 0.04))
	b.add_cyl(iron, Transform3D(Basis(Vector3.RIGHT, PI * 0.5), dp + Vector3(0.55, 1.5, 0.2)), 0.13, 0.13, 0.05, 12)
	b.box_at(st2, dp + Vector3(1.4, 1.75, 0.3), Vector3(0.55, 3.5, 0.6))
	b.box_at(st2, dp + Vector3(-1.4, 1.75, 0.3), Vector3(0.55, 3.5, 0.6))
	b.box_at(st2, dp + Vector3(0, 3.65, 0.32), Vector3(3.5, 0.6, 0.66))
	# three worn steps up to it
	for i in range(3):
		b.box_at(st2, Vector3(cx, gy + 0.12 + i * 0.2, hi.z + 1.25 - i * 0.3), Vector3(3.4 - i * 0.3, 0.24, 0.6))
	# roots that have climbed the walls
	var faces := [[Vector3(lo.x, 0, lo.z), Vector3(1, 0, 0), Vector3(0, 0, -1), sx], [Vector3(hi.x, 0, lo.z), Vector3(0, 0, 1), Vector3(1, 0, 0), sz],
		[Vector3(hi.x, 0, hi.z), Vector3(-1, 0, 0), Vector3(0, 0, 1), sx], [Vector3(lo.x, 0, hi.z), Vector3(0, 0, -1), Vector3(-1, 0, 0), sz]]
	for f in faces:
		var origin: Vector3 = f[0]
		var along: Vector3 = f[1]
		var n: Vector3 = f[2]
		var length: float = f[3]
		for r in range(5):
			var u := rng.randf_range(0.6, length - 0.6)
			if f == faces[2] and absf(u - length * 0.5) < 2.2:
				continue
			var p := origin + along * u + n * 0.35 + Vector3(0, gy + 0.3, 0)
			var rad := rng.randf_range(0.09, 0.17)
			var dir := Vector3(0, 1, 0)
			for sgm in range(rng.randi_range(5, 10)):
				dir = (dir + along * rng.randf_range(-0.6, 0.6) + Vector3(0, 0.6, 0)).normalized()
				var ln := rng.randf_range(0.5, 0.95)
				b.add_cyl(bark, Transform3D(Basis(Quaternion(Vector3.UP, dir)), p), rad, rad * 0.88, ln, 6)
				p += dir * ln
				rad *= 0.88
				if rng.randf() < 0.3:
					var side := (along * (1 if rng.randf() < 0.5 else -1) + Vector3(0, 0.3, 0)).normalized()
					b.add_cyl(bark, Transform3D(Basis(Quaternion(Vector3.UP, side)), p), rad * 0.6, rad * 0.3, rng.randf_range(0.5, 1.0), 5)
			# moss in the lee of the root
			b.box_at(moss, origin + along * u + n * 0.3 + Vector3(0, gy + 0.9, 0), _oriented(rng.randf_range(0.6, 1.4), rng.randf_range(0.6, 1.6), 0.04, along))
	# the cold light leaking out lights nothing much, but it is there
	var lamp := OmniLight3D.new()
	lamp.light_color = Color(0.5, 0.85, 0.7)
	lamp.light_energy = 0.9
	lamp.omni_range = 7.0
	lamp.position = Vector3(tw0.x + tws * 0.5, gy + 13.5, tw0.z - 1.2)
	add_child(lamp)
	var lamp2 := OmniLight3D.new()
	lamp2.light_color = Color(0.5, 0.85, 0.7)
	lamp2.light_energy = 0.8
	lamp2.omni_range = 6.0
	lamp2.position = Vector3(cx + sx * 0.3, gy + 5.4, lo.z - 1.0)
	add_child(lamp2)
	# and a thread of it under the door, the one place it touches the yard
	b.box_at(cold, dp + Vector3(0, 0.04, 0.2), Vector3(1.9, 0.05, 0.05))
	var lamp3 := OmniLight3D.new()
	lamp3.light_color = Color(0.5, 0.9, 0.72)
	lamp3.light_energy = 0.7
	lamp3.omni_range = 5.0
	lamp3.position = Vector3(cx - sx * 0.3, gy + 5.4, hi.z + 1.0)
	add_child(lamp3)

func _rough_courses(b: MeshBatch, rng: RandomNumberGenerator, mat: Material, lo: Vector3, hi: Vector3) -> void:
	## Lay big rough-dressed blocks in courses over the four faces of a box.
	var faces := [[Vector3(lo.x, 0, lo.z), Vector3(1, 0, 0), Vector3(0, 0, -1), hi.x - lo.x], [Vector3(hi.x, 0, lo.z), Vector3(0, 0, 1), Vector3(1, 0, 0), hi.z - lo.z],
		[Vector3(hi.x, 0, hi.z), Vector3(-1, 0, 0), Vector3(0, 0, 1), hi.x - lo.x], [Vector3(lo.x, 0, hi.z), Vector3(0, 0, -1), Vector3(-1, 0, 0), hi.z - lo.z]]
	for f in faces:
		var origin: Vector3 = f[0]
		var along: Vector3 = f[1]
		var n: Vector3 = f[2]
		var length: float = f[3]
		var y := lo.y
		var row := 0
		while y < hi.y - 0.1:
			var rh := minf(rng.randf_range(0.6, 1.0), hi.y - y)
			var t := -rng.randf_range(0.0, 0.8)
			while t < length:
				var bl := rng.randf_range(1.0, 2.2)
				var t0 := maxf(t, 0.0)
				var t1 := minf(t + bl, length)
				if t1 - t0 > 0.1:
					var bulge := rng.randf_range(0.05, 0.2)
					b.box_at(mat, origin + along * ((t0 + t1) * 0.5) + n * (bulge * 0.5 - 0.05) + Vector3(0, y + rh * 0.5, 0),
						_oriented(t1 - t0 - 0.06, rh - 0.06, bulge + 0.1, along), 0, _tilt(along, rng.randf_range(-0.03, 0.03)).x, _tilt(along, rng.randf_range(-0.03, 0.03)).y)
				t += bl
			y += rh
			row += 1

func _dead_tree(b: MeshBatch, rng: RandomNumberGenerator, base: Vector3, bark: Material) -> void:
	## A dead tree of the yard, black and twisted, that has not leafed in a
	## thousand years and has not fallen either.
	var p := base
	var dir := Vector3(rng.randf_range(-0.15, 0.15), 1, rng.randf_range(-0.15, 0.15)).normalized()
	var rad := rng.randf_range(0.32, 0.42)
	# roots, splayed over the earth
	for i in range(6):
		var ang := i * TAU / 6.0 + rng.randf() * 0.6
		var rd := Vector3(cos(ang), -0.35, sin(ang)).normalized()
		b.add_cyl(bark, Transform3D(Basis(Quaternion(Vector3.UP, rd)), base + Vector3(0, 0.45, 0)), rad * 0.55, rad * 0.12, rng.randf_range(1.0, 1.6), 6)
	var segs := rng.randi_range(6, 8)
	for i in range(segs):
		var ln := rng.randf_range(0.7, 1.0)
		b.add_cyl(bark, Transform3D(Basis(Quaternion(Vector3.UP, dir)), p), rad, rad * 0.86, ln + 0.05, 8)
		p += dir * ln
		rad *= 0.86
		dir = (dir + Vector3(rng.randf_range(-0.35, 0.35), 0.1, rng.randf_range(-0.35, 0.35))).normalized()
		if i >= 2:
			for k in range(rng.randi_range(1, 2)):
				_limb(b, rng, p, (Vector3(rng.randf_range(-1, 1), rng.randf_range(0.3, 0.9), rng.randf_range(-1, 1))).normalized(), rad * 0.62, 3, bark)
	_limb(b, rng, p, dir, rad, 3, bark)

func _limb(b: MeshBatch, rng: RandomNumberGenerator, p: Vector3, dir: Vector3, rad: float, depth: int, bark: Material) -> void:
	for i in range(rng.randi_range(2, 4)):
		var ln := rng.randf_range(0.4, 0.8) * (0.6 + depth * 0.2)
		b.add_cyl(bark, Transform3D(Basis(Quaternion(Vector3.UP, dir)), p), rad, rad * 0.75, ln, 5)
		p += dir * ln
		rad *= 0.75
		dir = (dir + Vector3(rng.randf_range(-0.6, 0.6), rng.randf_range(-0.3, 0.3), rng.randf_range(-0.6, 0.6))).normalized()
		if depth > 1 and rng.randf() < 0.55:
			_limb(b, rng, p, (dir + Vector3(rng.randf_range(-1, 1), 0.2, rng.randf_range(-1, 1))).normalized(), rad * 0.8, depth - 1, bark)
		if rad < 0.025:
			return

func _barrow(b: MeshBatch, rng: RandomNumberGenerator, base: Vector3) -> void:
	## A barrow of the yard: a long low mound of earth and turf, with a stone
	## set up at its head.
	var earth := Mats.pbr("dirt", 0.25, Color(0.42, 0.38, 0.3))
	var turf := Mats.flat(Color(0.2, 0.24, 0.13), 0.95)
	var yaw := rng.randf() * PI
	var mound := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.5
	sm.height = 1.0
	sm.radial_segments = 20
	sm.rings = 10
	mound.mesh = sm
	mound.material_override = earth
	mound.position = base + Vector3(0, -0.05, 0)
	mound.rotation.y = yaw
	mound.scale = Vector3(1.9, 1.3, 1.25)
	add_child(mound)
	var cap := MeshInstance3D.new()
	cap.mesh = sm
	cap.material_override = turf
	cap.position = base + Vector3(0, 0.1, 0)
	cap.rotation.y = yaw
	cap.scale = Vector3(1.5, 0.95, 0.95)
	add_child(cap)
	var head := Vector3(cos(yaw), 0, -sin(yaw)) * 1.05
	b.box_at(Mats.pbr("stone", 0.5, Color(0.55, 0.57, 0.52)), base + head + Vector3(0, 0.6, 0), Vector3(0.22, 1.3, 0.55), yaw, rng.randf_range(-0.12, 0.12), rng.randf_range(-0.12, 0.12))
	for i in range(rng.randi_range(2, 4)):
		var a := rng.randf() * TAU
		b.box_at(Mats.stone(), base + Vector3(cos(a), 0, sin(a)) * rng.randf_range(0.9, 1.3) + Vector3(0, 0.1, 0), Vector3(0.3, 0.2, 0.25), rng.randf() * TAU)

func _sleeper() -> void:
	## The goddess who sleeps in the earth, carved lying on her bier on the
	## temple's top tier. Since the fall the stone has run hot: red seams of
	## fever glow across her, and the offerings round the bier still burn.
	var cells: Array = []
	for z in range(map.d):
		for x in range(map.w):
			if map.prop_at(x, z) == "G":
				cells.append(Vector2i(x, z))
	if cells.is_empty():
		return
	var cx := 0.0
	var cz := 0.0
	for c in cells:
		cx += (c.x + 0.5) * cell
		cz += (c.y + 0.5) * cell
	cx /= cells.size()
	cz /= cells.size()
	var c0: Vector2i = cells[0]
	var base := Vector3(cx, map.h_at(c0.x, c0.y) * S, cz)
	var b := MeshBatch.new()
	var dark := Mats.pbr("darkstone", 0.45, Color(0.55, 0.5, 0.48))
	var tm := _temple_mat()
	# the bier: a plinth with a moulded lip and carved panels
	b.box_at(dark, base + Vector3(0, 0.4, 0), Vector3(7.6, 0.8, 3.5))
	b.box_at(tm, base + Vector3(0, 0.86, 0), Vector3(7.9, 0.16, 3.8))
	b.box_at(tm, base + Vector3(0, 0.08, 0), Vector3(7.9, 0.16, 3.8))
	for i in range(5):
		var px := -3.0 + i * 1.5
		for sz in [-1.0, 1.0]:
			b.box_at(tm, base + Vector3(px, 0.45, sz * 1.76), Vector3(1.0, 0.5, 0.06))
	var mi := b.build(true)
	mi.name = "Bier"
	add_child(mi)
	# her image: pale old marble, lying on her back, head to the west
	var body := Node3D.new()
	body.name = "Sleeper"
	body.position = base + Vector3(0, 0.94, 0)
	add_child(body)
	var mm := StandardMaterial3D.new()
	mm.albedo_color = Color(0.82, 0.78, 0.72)
	mm.roughness = 0.55
	mm.rim_enabled = true
	mm.rim = 0.35
	var hair := StandardMaterial3D.new()
	hair.albedo_color = Color(0.36, 0.33, 0.31)
	hair.roughness = 0.7
	var lie := Vector3(0, 0, PI * 0.5)
	# a stone pillow, her hair spread over it, and her face turned to the sky
	b = MeshBatch.new()
	b.box_at(_temple_mat(), base + Vector3(-3.05, 1.1, 0), Vector3(1.3, 0.32, 2.1))
	var pil := b.build(true)
	pil.name = "Pillow"
	add_child(pil)
	_sp(body, "sphere", Vector3(1.55, 0.3, 2.0), hair, Vector3(-3.2, 0.5, 0))
	_sp(body, "sphere", Vector3(0.78, 0.82, 0.88), mm, Vector3(-2.95, 0.8, 0))
	_sp(body, "sphere", Vector3(0.16, 0.16, 0.12), mm, Vector3(-2.88, 1.2, 0))
	_sp(body, "capsule", Vector3(0.42, 0.6, 0.42), mm, Vector3(-2.35, 0.62, 0), lie)
	# a shroud from shoulders to feet, with long folds, rising over chest and feet
	_sp(body, "capsule", Vector3(0.95, 2.2, 1.75), mm, Vector3(-1.2, 0.5, 0), lie)
	_sp(body, "capsule", Vector3(0.72, 4.6, 1.45), mm, Vector3(1.25, 0.38, 0), lie)
	_sp(body, "sphere", Vector3(1.1, 0.75, 1.8), mm, Vector3(-0.1, 0.45, 0))
	for i in range(5):
		var fz := -0.62 + i * 0.31
		_sp(body, "capsule", Vector3(0.16, 3.9 - absf(fz) * 1.2, 0.16), mm, Vector3(1.35, 0.7 - absf(fz) * 0.18, fz), lie)
	for sz in [-1.0, 1.0]:
		_sp(body, "sphere", Vector3(0.42, 0.75, 0.42), mm, Vector3(3.45, 0.62, sz * 0.3))
	# hands folded on her breast
	_sp(body, "sphere", Vector3(0.36, 0.18, 0.28), mm, Vector3(-1.05, 0.98, 0.1), Vector3(0, 0.5, 0))
	_sp(body, "sphere", Vector3(0.36, 0.18, 0.28), mm, Vector3(-1.12, 1.0, -0.1), Vector3(0, -0.5, 0))
	# her fever: red seams through the stone, and a banked glow beneath
	var g := MeshBatch.new()
	var hot := Mats.glow(Color(1.0, 0.33, 0.07), 3.0)
	var top := base + Vector3(0, 0.94, 0)
	# a seam of fire where she lies on the bier
	g.box_at(hot, top + Vector3(0.2, 0.02, 0), Vector3(6.6, 0.04, 1.3))
	for i in range(10):
		var px := -3.6 + i * 0.8
		g.box_at(hot, base + Vector3(px, 0.5 + hashf(i, 57) * 0.25, 1.78 * (1.0 if i % 2 == 0 else -1.0)), Vector3(0.05, 0.45, 0.03), 0, 0, (hashf(i, 58) - 0.5) * 1.2)
	# offerings round the bier: bowls and stubs of candle, some still lit
	var wax := Mats.pbr("plaster", 0.3, Color(0.9, 0.85, 0.7))
	var flame := Mats.glow(Color(1.0, 0.7, 0.3), 4.0, true)
	for i in range(16):
		var a := i * TAU / 16.0 + hashf(i, 61) * 0.2
		var p := base + Vector3(cos(a) * 4.5, 0, sin(a) * 2.35)
		var hgt := 0.15 + hashf(i, 62) * 0.3
		g.add_cyl(wax, Transform3D(Basis(), p), 0.06, 0.06, hgt, 6)
		if hashf(i, 63) < 0.7:
			g.box_at(flame, p + Vector3(0, hgt + 0.06, 0), Vector3(0.05, 0.1, 0.05))
		if i % 4 == 1:
			g.add_cyl(dark, Transform3D(Basis(), p + Vector3(0.25, 0, 0.15)), 0.22, 0.14, 0.12, 10)
	var gmi := g.build(false)
	gmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(gmi)
	var l := OmniLight3D.new()
	l.light_color = Color(1.0, 0.42, 0.16)
	l.light_energy = 1.8
	l.omni_range = 9.0
	l.omni_attenuation = 1.5
	l.light_specular = 0.2
	l.shadow_enabled = true
	l.position = base + Vector3(0, 4.2, 0)
	add_child(l)
	flicker_lights.append({"light": l, "base": l.light_energy, "seed": 5.1})
	# pale light falling on her from above, so she reads against the dark
	var sp := SpotLight3D.new()
	sp.light_color = Color(0.75, 0.82, 1.0)
	sp.light_energy = 3.0
	sp.spot_range = 16.0
	sp.spot_angle = 28.0
	sp.light_specular = 0.2
	sp.shadow_enabled = true
	var sp_at := base + Vector3(-1.5, 11.0, 2.5)
	sp.transform = Transform3D(Basis.looking_at(base + Vector3(0, 1.2, 0) - sp_at, Vector3.UP), sp_at)
	add_child(sp)
	var e := _embers(10)
	e.position = base + Vector3(0, 1.4, 0)
	add_child(e)

# ------------------------------------------------------------------ fire

func _fire_particles(amount: int, size: float, height: float) -> GPUParticles3D:
	var p := GPUParticles3D.new()
	p.amount = amount
	p.lifetime = 0.9
	p.randomness = 0.5
	p.visibility_aabb = AABB(Vector3(-2, -1, -2), Vector3(4, 6, 4))
	var pm := ParticleProcessMaterial.new()
	pm.direction = Vector3(0, 1, 0)
	pm.spread = 12.0
	pm.initial_velocity_min = height * 0.8
	pm.initial_velocity_max = height * 1.6
	pm.gravity = Vector3(0, 0.6, 0)
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	pm.emission_sphere_radius = size * 0.5
	pm.scale_min = 0.7
	pm.scale_max = 1.2
	var sc := Curve.new()
	sc.add_point(Vector2(0, 0.6))
	sc.add_point(Vector2(0.3, 1.0))
	sc.add_point(Vector2(1, 0.0))
	var sct := CurveTexture.new()
	sct.curve = sc
	pm.scale_curve = sct
	var grad := Gradient.new()
	grad.set_color(0, Color(1.0, 0.85, 0.4, 1.0))
	grad.set_color(1, Color(0.6, 0.1, 0.02, 0.0))
	grad.add_point(0.4, Color(1.0, 0.45, 0.1, 0.85))
	var gt := GradientTexture1D.new()
	gt.gradient = grad
	pm.color_ramp = gt
	p.process_material = pm
	var q := QuadMesh.new()
	q.size = Vector2(size, size * 1.3)
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.vertex_color_use_as_albedo = true
	m.albedo_texture = _soft_dot()
	m.albedo_color = Color(2.2, 2.0, 1.8)
	q.material = m
	p.draw_pass_1 = q
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return p

static var _dot_tex: Texture2D

static func _soft_dot() -> Texture2D:
	if _dot_tex == null:
		var g := Gradient.new()
		g.set_color(0, Color(1, 1, 1, 1))
		g.set_color(1, Color(1, 1, 1, 0))
		var t := GradientTexture2D.new()
		t.gradient = g
		t.fill = GradientTexture2D.FILL_RADIAL
		t.fill_from = Vector2(0.5, 0.5)
		t.fill_to = Vector2(1.0, 0.5)
		t.width = 64
		t.height = 64
		_dot_tex = t
	return _dot_tex

func _embers(rate: int) -> GPUParticles3D:
	var p := GPUParticles3D.new()
	p.amount = rate
	p.lifetime = 3.0
	p.visibility_aabb = AABB(Vector3(-4, -1, -4), Vector3(8, 12, 8))
	var pm := ParticleProcessMaterial.new()
	pm.direction = Vector3(0, 1, 0)
	pm.spread = 25.0
	pm.initial_velocity_min = 1.0
	pm.initial_velocity_max = 2.5
	pm.gravity = Vector3(0.3, 0.2, 0.1)
	pm.turbulence_enabled = true
	pm.turbulence_noise_strength = 0.6
	pm.scale_min = 0.5
	pm.scale_max = 1.0
	var grad := Gradient.new()
	grad.set_color(0, Color(1.0, 0.6, 0.2, 1))
	grad.set_color(1, Color(1.0, 0.2, 0.05, 0))
	var gt := GradientTexture1D.new()
	gt.gradient = grad
	pm.color_ramp = gt
	p.process_material = pm
	var q := QuadMesh.new()
	q.size = Vector2(0.05, 0.05)
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.vertex_color_use_as_albedo = true
	m.albedo_texture = _soft_dot()
	m.albedo_color = Color(3, 2.5, 2)
	q.material = m
	p.draw_pass_1 = q
	return p

func _flame(at: Vector3, big: bool, shadows: bool) -> void:
	var f := _fire_particles(28 if big else 18, 0.9 if big else 0.55, 1.4 if big else 0.9)
	f.position = at
	add_child(f)
	var e := _embers(10 if big else 5)
	e.position = at
	add_child(e)
	var l := OmniLight3D.new()
	l.light_color = Color(1.0, 0.55, 0.22)
	l.light_energy = 3.2 if big else 2.2
	l.omni_range = 12.0 if big else 8.0
	l.omni_attenuation = 1.2
	l.shadow_enabled = shadows
	l.position = at + Vector3(0, 0.6, 0)
	add_child(l)
	flicker_lights.append({"light": l, "base": l.light_energy, "seed": randf() * 100.0})

func _braziers() -> void:
	var n := 0
	for z in range(map.d):
		for x in range(map.w):
			if map.prop_at(x, z) != "B":
				continue
			var c := map.cell_center(x, z)
			var base := Vector3(c.x, map.h_at(x, z) * S, c.y)
			var b := MeshBatch.new()
			var iron := Mats.iron()
			for i in range(3):
				var a := TAU * i / 3.0
				var foot := base + Vector3(cos(a), 0, sin(a)) * 0.42
				var top := base + Vector3(0, 0.85, 0)
				var axis := top - foot
				var up := axis.normalized()
				var side := up.cross(Vector3(cos(a), 0, sin(a))).normalized()
				b.add_box(iron, Transform3D(Basis(side, up, side.cross(up)).orthonormalized(), foot + axis * 0.5), Vector3(0.06, axis.length(), 0.06))
			b.add_cyl(iron, Transform3D(Basis(), base + Vector3(0, 0.8, 0)), 0.18, 0.5, 0.32, 12)
			b.add_cyl(Mats.glow(Color(1.0, 0.35, 0.08), 3.0), Transform3D(Basis(), base + Vector3(0, 1.08, 0)), 0.42, 0.3, 0.06, 10)
			var mi := b.build(true)
			add_child(mi)
			_flame(base + Vector3(0, 1.1, 0), false, n < 2)
			n += 1

func _sconces() -> void:
	## Torches in iron brackets on the walls of the streets, every few cells.
	var dirs := [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
	var placed: Array = []
	var iron := Mats.iron()
	for z in range(map.d):
		for x in range(map.w):
			if map.prop_at(x, z) != "." or map.h_at(x, z) != 0:
				continue
			if hashf(x, z, 91) > 0.16:
				continue
			for dv in dirs:
				var v: Vector2i = dv
				if H(x + v.x, z + v.y) < 1:
					continue
				var c := map.cell_center(x, z)
				var p := Vector3(c.x + v.x * (cell * 0.5 - 0.12), 2.1, c.y + v.y * (cell * 0.5 - 0.12))
				var near := false
				for q in placed:
					if (q as Vector3).distance_to(p) < 7.0:
						near = true
				if near:
					break
				placed.append(p)
				var b := MeshBatch.new()
				var out := Vector3(-v.x, 0, -v.y)
				b.add_box(iron, Transform3D(Basis(), p + out * 0.1 - Vector3(0, 0.12, 0)), Vector3(0.08 + absf(out.x) * 0.2, 0.06, 0.08 + absf(out.z) * 0.2))
				b.add_cyl(iron, Transform3D(Basis(), p + out * 0.22 - Vector3(0, 0.2, 0)), 0.035, 0.05, 0.42, 6)
				b.add_cyl(m_char, Transform3D(Basis(), p + out * 0.22), 0.06, 0.05, 0.14, 6)
				add_child(b.build(false))
				var fire_at := p + out * 0.22 + Vector3(0, 0.08, 0)
				var f := _fire_particles(10, 0.32, 0.5)
				f.position = fire_at
				add_child(f)
				var l := OmniLight3D.new()
				l.light_color = Color(1.0, 0.52, 0.2)
				l.light_energy = 1.7
				l.omni_range = 7.5
				l.omni_attenuation = 1.4
				l.shadow_enabled = false
				l.position = fire_at + out * 0.25 + Vector3(0, 0.2, 0)
				add_child(l)
				flicker_lights.append({"light": l, "base": l.light_energy, "seed": randf() * 100.0})
				break
			if placed.size() >= 14:
				return

func _fires() -> void:
	## Burning wreckage on a few rooftops and in the backdrop streets.
	var spots := [Vector2i(1, 9), Vector2i(26, 18), Vector2i(10, 22), Vector2i(-3, 14), Vector2i(31, 12), Vector2i(14, -4), Vector2i(12, 31)]
	if map.data.has("fires"):
		spots = []
		for f in map.data["fires"]:
			spots.append(Vector2i(int(f[0]), int(f[1])))
	var i := 0
	for v in spots:
		var h := H(v.x, v.y)
		var base := Vector3((v.x + 0.5) * cell, h * S, (v.y + 0.5) * cell)
		var b := MeshBatch.new()
		for j in range(5):
			b.box_at(m_char, base + Vector3(0, 0.15 + j * 0.05, 0), Vector3(1.6, 0.14, 0.16), j * 0.7, 0, 0.15)
		add_child(b.build(true))
		_flame(base + Vector3(0, 0.3, 0), true, i == 0)
		i += 1

func _process(_delta: float) -> void:
	var t := Time.get_ticks_msec() / 1000.0
	for f in flicker_lights:
		var l: OmniLight3D = f["light"]
		var s: float = f["seed"]
		l.light_energy = f["base"] * (0.82 + 0.1 * sin(t * 9.0 + s) + 0.08 * sin(t * 23.0 + s * 2.0))

# ------------------------------------------------------------------ godshards

func add_shard(nd: int) -> void:
	if shard_nodes.has(nd) or not map.nodes.has(nd):
		return
	var root := Node3D.new()
	root.position = map.node_pos(nd)
	if map.is_wet(nd):
		root.position.y = map.water - 0.3   # caught on the wreck just under the surface
	var b := MeshBatch.new()
	var gm := Mats.shard()
	var rng := RandomNumberGenerator.new()
	rng.seed = nd
	for i in range(5):
		var h := rng.randf_range(0.35, 0.8) * (1.4 if i == 0 else 1.0)
		var tilt := Basis.from_euler(Vector3(rng.randf_range(-0.5, 0.5), rng.randf() * TAU, rng.randf_range(-0.5, 0.5)))
		b.add_cyl(gm, Transform3D(tilt, Vector3(rng.randf_range(-0.2, 0.2), 0, rng.randf_range(-0.2, 0.2))), 0.09, 0.0, h, 5)
		b.add_cyl(gm, Transform3D(tilt.rotated(tilt.x, PI), Vector3(0, 0.02, 0)), 0.09, 0.0, 0.08, 5)
	b.box_at(Mats.darkstone(), Vector3(0, 0.05, 0), Vector3(0.7, 0.14, 0.6), rng.randf() * 3.0)
	root.add_child(b.build(false))
	var l := OmniLight3D.new()
	l.light_color = Color(0.3, 1.0, 0.82)
	l.light_energy = 1.6
	l.omni_range = 4.5
	l.position = Vector3(0, 0.6, 0)
	root.add_child(l)
	var motes := _embers(6)
	var pm: ParticleProcessMaterial = motes.process_material
	var grad := Gradient.new()
	grad.set_color(0, Color(0.4, 1.0, 0.85, 1))
	grad.set_color(1, Color(0.2, 0.8, 1.0, 0))
	var gt := GradientTexture1D.new()
	gt.gradient = grad
	pm.color_ramp = gt
	pm.initial_velocity_max = 0.8
	pm.initial_velocity_min = 0.3
	root.add_child(motes)
	add_child(root)
	shard_nodes[nd] = root

func remove_shard(nd: int) -> void:
	if shard_nodes.has(nd):
		shard_nodes[nd].queue_free()
		shard_nodes.erase(nd)

# ------------------------------------------------------------------ the strongbox

var dig_nodes: Dictionary = {}     # node id -> Node3D: a marked spot, or the pit once dug
var box_ground: Node3D = null      # the strongbox lying in the open

static func make_strongbox() -> Node3D:
	## A paymaster's strongbox: dark oak, iron bands and corners, a padlock.
	var b := MeshBatch.new()
	var oak := Mats.pbr("wood", 0.35, Color(0.34, 0.24, 0.17))
	var iron := Mats.iron()
	b.box_at(oak, Vector3(0, 0.2, 0), Vector3(0.72, 0.4, 0.46))
	# a rounded lid in three staves
	for i in range(3):
		var a := (i - 1) * 0.42
		b.box_at(oak, Vector3(0, 0.44 + cos(a) * 0.05, sin(a) * 0.15), Vector3(0.72, 0.06, 0.17), 0.0, -a, 0.0)
	for x in [-0.27, 0.0, 0.27]:
		b.box_at(iron, Vector3(x, 0.23, 0), Vector3(0.05, 0.42, 0.48))
		for i in range(3):
			var a := (i - 1) * 0.42
			b.box_at(iron, Vector3(x, 0.455 + cos(a) * 0.05, sin(a) * 0.15), Vector3(0.055, 0.03, 0.18), 0.0, -a, 0.0)
	for cx in [-0.36, 0.36]:
		for cz in [-0.23, 0.23]:
			b.box_at(iron, Vector3(cx, 0.2, cz), Vector3(0.05, 0.42, 0.05))
	var brass := Mats.flat(Color(0.78, 0.6, 0.28), 0.35, 0.9)
	b.box_at(brass, Vector3(0, 0.3, 0.245), Vector3(0.12, 0.14, 0.03))
	b.add_cyl(brass, Transform3D(Basis(Vector3.RIGHT, PI * 0.5), Vector3(0, 0.39, 0.255)), 0.035, 0.035, 0.02, 8)
	# brass studs along the lid's edge, so it catches the light at a distance
	for x in [-0.3, -0.15, 0.15, 0.3]:
		for z in [-0.235, 0.235]:
			b.box_at(brass, Vector3(x, 0.405, z), Vector3(0.035, 0.035, 0.02))
	for hx in [-0.38, 0.38]:
		b.add_cyl(iron, Transform3D(Basis(Vector3.FORWARD, PI * 0.5), Vector3(hx, 0.28, 0)), 0.06, 0.06, 0.03, 8)
	var root := Node3D.new()
	root.add_child(b.build(false))
	return root

func add_dig_spot(nd: int) -> void:
	## A spot marked for digging: a ring of stones, a stake with a rag, a
	## spade left standing in the earth and a shuttered lantern.
	if dig_nodes.has(nd) or not map.nodes.has(nd):
		return
	var root := Node3D.new()
	root.position = map.node_pos(nd)
	var b := MeshBatch.new()
	var rng := RandomNumberGenerator.new()
	rng.seed = nd * 7 + 3
	var earth := Mats.pbr("dirt", 0.5, Color(0.36, 0.3, 0.24))
	var ston := Mats.pbr("stone", 0.4, Color(0.55, 0.52, 0.48))
	b.add_cyl(earth, Transform3D(Basis(), Vector3(0, 0.0, 0)), 0.62, 0.5, 0.07, 14)
	for i in range(9):
		var a := TAU * i / 9.0 + rng.randf_range(-0.15, 0.15)
		var r := 0.68 + rng.randf_range(-0.05, 0.06)
		b.box_at(ston, Vector3(cos(a) * r, 0.06, sin(a) * r), Vector3(rng.randf_range(0.16, 0.26), rng.randf_range(0.1, 0.17), rng.randf_range(0.14, 0.22)), rng.randf() * PI)
	var wood := Mats.pbr("wood", 0.4, Color(0.42, 0.33, 0.24))
	# the stake and its rag
	b.box_at(wood, Vector3(-0.42, 0.55, -0.35), Vector3(0.06, 1.1, 0.06), 0.0, 0.0, 0.08)
	b.box_at(Mats.flat(Color(0.62, 0.16, 0.1), 0.95), Vector3(-0.33, 0.98, -0.35), Vector3(0.2, 0.18, 0.012), 0.0, 0.0, -0.2)
	# a spade
	var sp := Vector3(0.3, 0.0, 0.18)
	b.box_at(wood, sp + Vector3(0, 0.55, 0), Vector3(0.045, 0.8, 0.045), 0.3, 0.0, 0.18)
	b.box_at(Mats.iron(), sp + Vector3(-0.03, 0.1, 0), Vector3(0.2, 0.26, 0.02), 0.3, 0.0, 0.18)
	b.box_at(wood, sp + Vector3(0.09, 0.96, 0), Vector3(0.16, 0.04, 0.04), 0.3, 0.0, 0.18)
	# lantern on the stones
	b.box_at(Mats.iron(), Vector3(0.45, 0.2, -0.4), Vector3(0.16, 0.24, 0.16))
	b.box_at(Mats.glow(Color(1.0, 0.72, 0.35), 2.5), Vector3(0.45, 0.2, -0.4), Vector3(0.13, 0.16, 0.17))
	root.add_child(b.build(false))
	var l := OmniLight3D.new()
	l.light_color = Color(1.0, 0.7, 0.4)
	l.light_energy = 1.1
	l.omni_range = 4.0
	l.position = Vector3(0.45, 0.45, -0.4)
	root.add_child(l)
	add_child(root)
	dig_nodes[nd] = root

func clear_dig_spots() -> void:
	for nd in dig_nodes:
		dig_nodes[nd].queue_free()
	dig_nodes.clear()

func set_dug(nd: int, empty: bool) -> void:
	## The spot has been dug: an open pit and a heap of spoil. If `empty`,
	## the turned earth shows broken pots and a bone.
	if dig_nodes.has(nd):
		dig_nodes[nd].queue_free()
		dig_nodes.erase(nd)
	if not map.nodes.has(nd):
		return
	var root := Node3D.new()
	root.position = map.node_pos(nd)
	var b := MeshBatch.new()
	var rng := RandomNumberGenerator.new()
	rng.seed = nd * 13 + 1
	var earth := Mats.pbr("dirt", 0.5, Color(0.3, 0.25, 0.2))
	b.add_cyl(Mats.flat(Color(0.03, 0.025, 0.02), 1.0), Transform3D(Basis(), Vector3(0, 0.005, 0)), 0.46, 0.46, 0.02, 14)
	b.add_cyl(earth, Transform3D(Basis(), Vector3(0, 0.0, 0)), 0.62, 0.58, 0.05, 14)
	for i in range(6):
		var a := rng.randf_range(0.4, 2.2)
		var r := rng.randf_range(0.7, 0.95)
		var mound := SphereMesh.new()
		mound.radius = rng.randf_range(0.22, 0.34)
		mound.height = mound.radius * 0.9
		var mi := MeshInstance3D.new()
		mi.mesh = mound
		mi.material_override = earth
		mi.position = Vector3(cos(a) * r, 0.0, sin(a) * r)
		root.add_child(mi)
	if empty:
		var pot := Mats.pbr("roof", 0.5, Color(0.6, 0.38, 0.26))
		for i in range(3):
			b.box_at(pot, Vector3(rng.randf_range(-0.9, -0.5), 0.06, rng.randf_range(-0.4, 0.4)), Vector3(0.14, 0.03, 0.1), rng.randf() * PI, 0.3, 0.0)
		b.add_cyl(Mats.flat(Color(0.82, 0.78, 0.68), 0.7), Transform3D(Basis(Vector3.FORWARD, PI * 0.5).rotated(Vector3.UP, rng.randf() * PI), Vector3(0.75, 0.06, -0.3)), 0.03, 0.025, 0.36, 6)
	b.box_at(Mats.pbr("wood", 0.4, Color(0.42, 0.33, 0.24)), Vector3(0.75, 0.05, 0.35), Vector3(0.05, 0.05, 0.85), rng.randf() * PI)
	root.add_child(b.build(false))
	add_child(root)

func set_box_ground(nd: int) -> void:
	## Show the strongbox lying at node nd, or nowhere if nd < 0.
	if box_ground != null:
		box_ground.queue_free()
		box_ground = null
	if nd < 0 or not map.nodes.has(nd):
		return
	box_ground = make_strongbox()
	box_ground.position = map.node_pos(nd) + Vector3(0.25, 0, 0.1)
	box_ground.rotation.y = 0.6
	var l := OmniLight3D.new()
	l.light_color = Color(1.0, 0.8, 0.45)
	l.light_energy = 0.8
	l.omni_range = 3.0
	l.position = Vector3(0, 0.9, 0)
	box_ground.add_child(l)
	add_child(box_ground)

# ------------------------------------------------------------------ grime

func _grime_decals() -> void:
	var g := Gradient.new()
	g.set_color(0, Color(0.05, 0.04, 0.035, 0.75))
	g.set_color(1, Color(0.05, 0.04, 0.035, 0.0))
	var t := GradientTexture2D.new()
	t.gradient = g
	t.fill = GradientTexture2D.FILL_RADIAL
	t.fill_from = Vector2(0.5, 0.5)
	t.fill_to = Vector2(1.0, 0.5)
	t.width = 128
	t.height = 128
	var rng := RandomNumberGenerator.new()
	rng.seed = 5150
	for i in range(55):
		var d := Decal.new()
		d.texture_albedo = t
		var s := rng.randf_range(2.0, 6.0)
		d.size = Vector3(s, 1.2, s * rng.randf_range(0.6, 1.4))
		var x := rng.randf_range(-6.0, map.w * cell + 6.0)
		var z := rng.randf_range(-6.0, map.d * cell + 6.0)
		var h := H(int(floor(x / cell)), int(floor(z / cell))) * S
		d.position = Vector3(x, h, z)
		d.rotation.y = rng.randf() * TAU
		d.albedo_mix = 0.9
		d.upper_fade = 0.5
		d.lower_fade = 0.5
		add_child(d)

# ------------------------------------------------------------------ picking

func _collision() -> void:
	walk_body = StaticBody3D.new()
	walk_body.collision_layer = 1
	walk_body.collision_mask = 0
	add_child(walk_body)
	var ground := CollisionShape3D.new()
	var gs := BoxShape3D.new()
	gs.size = Vector3((map.w + 2 * RING) * cell, 1.0, (map.d + 2 * RING) * cell)
	ground.shape = gs
	ground.position = Vector3(map.w * cell * 0.5, -0.5, map.d * cell * 0.5)
	walk_body.add_child(ground)
	for z in range(map.d):
		for x in range(map.w):
			var h := map.h_at(x, z)
			if h <= 0:
				continue
			var cs := CollisionShape3D.new()
			var bs := BoxShape3D.new()
			bs.size = Vector3(cell, h * S, cell)
			cs.shape = bs
			cs.position = Vector3((x + 0.5) * cell, h * S * 0.5, (z + 0.5) * cell)
			walk_body.add_child(cs)
	for k in map.bridge_level:
		var v: Vector2i = k
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = Vector3(cell, 0.2, cell)
		cs.shape = bs
		cs.position = Vector3((v.x + 0.5) * cell, map.bridge_level[k] * S - 0.1, (v.y + 0.5) * cell)
		walk_body.add_child(cs)

func node_from_hit(p: Vector3, n: Vector3) -> int:
	## Turns a ray hit on the city into the movement node the player meant.
	var q := p - n * 0.05
	var x := int(floor(q.x / cell))
	var z := int(floor(q.z / cell))
	if not inside(x, z):
		return -1
	if n.y > 0.5:
		var l := int(round(p.y / S))
		var id := BattleMap.nid(x, z, l)
		if map.nodes.has(id):
			return id
	return map.top_node(x, z)


func _sp(parent: Node3D, kind: String, scl: Vector3, mat: Material, pos: Vector3, rot := Vector3.ZERO) -> MeshInstance3D:
	## Unit-sized primitive scaled into place (statue parts).
	var mi := MeshInstance3D.new()
	match kind:
		"sphere":
			var m := SphereMesh.new()
			m.radius = 0.5
			m.height = 1.0
			mi.mesh = m
		"cyl":
			var m := CylinderMesh.new()
			m.top_radius = 0.5
			m.bottom_radius = 0.5
			m.height = 1.0
			mi.mesh = m
		_:
			var m := CapsuleMesh.new()
			m.radius = 0.5
			m.height = 2.0
			mi.mesh = m
			scl = Vector3(scl.x, scl.y * 0.5, scl.z)
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	mi.scale = scl
	parent.add_child(mi)
	return mi
