class_name CityBuilder
extends Node3D
## Builds the 3D ruins of Hethra from a BattleMap: masonry blocks with
## jagged broken tops, windows and ledges, ladders, stairs, plank bridges,
## the chained idol, braziers, barricades, rubble and godshards, plus a ring
## of ruined streets and distant towers fading into the fog.

const RING := 12          # cells of backdrop city beyond the battle map

var map: BattleMap
var cell: float
var S: float
var ext_h: Dictionary = {}     # Vector2i -> storeys, for backdrop cells
var block_of: Dictionary = {}  # Vector2i -> block id (playable area)
var block_style: Dictionary = {}
var shard_nodes: Dictionary = {}   # node id -> Node3D
var flicker_lights: Array = []
var walk_body: StaticBody3D

var m_void: StandardMaterial3D
var m_glow_win: StandardMaterial3D
var m_char: StandardMaterial3D

func build(battle_map: BattleMap, shards: Dictionary) -> void:
	map = battle_map
	cell = map.cell
	S = map.storey
	m_void = Mats.flat(Color(0.015, 0.014, 0.016), 1.0)
	m_glow_win = Mats.glow(Color(1.0, 0.42, 0.12), 1.6)
	m_char = Mats.pbr("wood", 0.5, Color(0.35, 0.3, 0.28))
	_make_backdrop_heights()
	_find_blocks()
	var batch := MeshBatch.new()
	var far_batch := MeshBatch.new()
	_ground(batch)
	_columns(batch, far_batch)
	_props(batch)
	_links(batch)
	_bridges(batch)
	_street_rubble(batch)
	_skyline(far_batch)
	var mi := batch.build(true)
	mi.name = "Ruins"
	add_child(mi)
	var fmi := far_batch.build(true)
	fmi.name = "Backdrop"
	add_child(fmi)
	_idol()
	_braziers()
	_fires()
	_sconces()
	for nd in shards:
		add_shard(nd)
	_grime_decals()
	_collision()

# ------------------------------------------------------------------ helpers

static func hashf(a: int, b: int, c: int = 0) -> float:
	var h := (a * 374761393 + b * 668265263 + c * 2147483647) & 0x7fffffff
	h = (h ^ (h >> 13)) * 1274126177
	h = h & 0x7fffffff
	h = h ^ (h >> 16)
	return float(h % 10007) / 10007.0

func H(x: int, z: int) -> int:
	## Storey height anywhere: battle map inside, backdrop outside.
	if x >= 0 and z >= 0 and x < map.w and z < map.d:
		return map.h_at(x, z)
	return ext_h.get(Vector2i(x, z), 0)

func inside(x: int, z: int) -> bool:
	return x >= 0 and z >= 0 and x < map.w and z < map.d

func _make_backdrop_heights() -> void:
	for z in range(-RING, map.d + RING):
		for x in range(-RING, map.w + RING):
			if inside(x, z):
				continue
			var gx := x + 100
			var gz := z + 100
			var street := (gx % 6 == 0) or (gz % 6 == 0)
			# keep the edge of the battle map walled in, with a few street mouths
			var edge := x == -1 or z == -1 or x == map.w or z == map.d
			# how many cells outside the battle map; nearby ruins stay low so
			# the camera can see over them into the streets
			var k: int = maxi(maxi(-x, x - (map.w - 1)), maxi(-z, z - (map.d - 1)))
			if edge:
				var ix := clampi(x, 0, map.w - 1)
				var iz := clampi(z, 0, map.d - 1)
				var mouth := map.h_at(ix, iz) == 0 and street and hashf(ix, iz, 3) < 0.7
				ext_h[Vector2i(x, z)] = 0 if mouth else 1
				continue
			if street:
				ext_h[Vector2i(x, z)] = 0
				continue
			var bx := int(floor(gx / 6.0))
			var bz := int(floor(gz / 6.0))
			var base := 2 + int(hashf(bx, bz, 1) * 3.2)
			if hashf(bx, bz, 2) < 0.15:
				base = 1   # a collapsed block
			if hashf(x, z, 7) < 0.18:
				base = max(1, base - 1)
			if k <= 3:
				base = mini(base, 1 if k <= 2 else 2)
			ext_h[Vector2i(x, z)] = base

func _find_blocks() -> void:
	var next := 0
	for z in range(map.d):
		for x in range(map.w):
			var k := Vector2i(x, z)
			if map.h_at(x, z) == 0 or block_of.has(k):
				continue
			var stack := [k]
			block_of[k] = next
			while not stack.is_empty():
				var c: Vector2i = stack.pop_back()
				for dv in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
					var n: Vector2i = c + dv
					if inside(n.x, n.y) and map.h_at(n.x, n.y) > 0 and not block_of.has(n):
						block_of[n] = next
						stack.append(n)
			var r := hashf(next, 11, 3)
			block_style[next] = "plaster" if r < 0.35 else ("dark" if r < 0.5 else "stone")
			next += 1

func _wall_mat(x: int, z: int, storey_index: int) -> StandardMaterial3D:
	var style := "stone"
	if inside(x, z):
		style = block_style.get(block_of.get(Vector2i(x, z), -1), "stone")
	else:
		var r := hashf(int(floor((x + 100) / 6.0)), int(floor((z + 100) / 6.0)), 9)
		style = "plaster" if r < 0.4 else ("dark" if r < 0.55 else "stone")
	if style == "dark":
		return Mats.darkstone()
	if style == "plaster" and storey_index >= 1:
		return Mats.pbr("plaster", 0.35, Color(0.82, 0.8, 0.78))
	return Mats.stone()

func _top_mat(x: int, z: int) -> StandardMaterial3D:
	var r := hashf(x, z, 21)
	if r < 0.35:
		return Mats.pbr("wood", 0.5, Color(0.7, 0.66, 0.62))
	if r < 0.8:
		return Mats.darkstone()
	return Mats.pbr("cobbles", 0.3, Color(0.8, 0.8, 0.8))

# ------------------------------------------------------------------ ground

func _ground(b: MeshBatch) -> void:
	var x0 := -RING * cell
	var z0 := -RING * cell
	var x1 := (map.w + RING) * cell
	var z1 := (map.d + RING) * cell
	b.add_quad(Mats.cobbles(), Vector3(x0, 0, z0), Vector3(x1, 0, z0), Vector3(x1, 0, z1), Vector3(x0, 0, z1), Vector3.UP)
	# a dirt plain beyond the backdrop ring, under the far towers
	var big := 900.0
	var dm := Mats.pbr("dirt", 0.08, Color(0.45, 0.42, 0.4))
	b.add_quad(dm, Vector3(-big, -0.02, -big), Vector3(big, -0.02, -big), Vector3(big, -0.02, z0), Vector3(-big, -0.02, z0), Vector3.UP)
	b.add_quad(dm, Vector3(-big, -0.02, z1), Vector3(big, -0.02, z1), Vector3(big, -0.02, big), Vector3(-big, -0.02, big), Vector3.UP)
	b.add_quad(dm, Vector3(-big, -0.02, z0), Vector3(x0, -0.02, z0), Vector3(x0, -0.02, z1), Vector3(-big, -0.02, z1), Vector3.UP)
	b.add_quad(dm, Vector3(x1, -0.02, z0), Vector3(big, -0.02, z0), Vector3(big, -0.02, z1), Vector3(x1, -0.02, z1), Vector3.UP)

# ------------------------------------------------------------------ masonry

func _columns(b: MeshBatch, fb: MeshBatch) -> void:
	var dirs := [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
	for z in range(-RING, map.d + RING):
		for x in range(-RING, map.w + RING):
			var h := H(x, z)
			if h <= 0:
				continue
			var playable := inside(x, z)
			var tb: MeshBatch = b if playable or _near_map(x, z, 3) else fb
			var x0 := x * cell
			var z0 := z * cell
			var top := h * S
			# top surface (walkable roofs are broken upper floors)
			var tm := _top_mat(x, z)
			tb.add_quad(tm, Vector3(x0, top, z0), Vector3(x0 + cell, top, z0), Vector3(x0 + cell, top, z0 + cell), Vector3(x0, top, z0 + cell), Vector3.UP)
			for dv in dirs:
				var nh := H(x + dv.x, z + dv.y)
				if not playable and not inside(x + dv.x, z + dv.y) and abs(x + dv.x - map.w / 2) > map.w / 2 + RING - 1:
					nh = 0
				if nh >= h:
					continue
				_wall_face(tb, x, z, dv, nh, h, playable)

func _near_map(x: int, z: int, r: int) -> bool:
	return x >= -r and z >= -r and x < map.w + r and z < map.d + r

func _face_frame(x: int, z: int, dv: Vector2i) -> Array:
	## Returns [origin corner a, along-wall unit vector, outward normal] for a cell face.
	var x0 := x * cell
	var z0 := z * cell
	if dv == Vector2i(1, 0):
		return [Vector3(x0 + cell, 0, z0), Vector3(0, 0, 1), Vector3(1, 0, 0)]
	if dv == Vector2i(-1, 0):
		return [Vector3(x0, 0, z0 + cell), Vector3(0, 0, -1), Vector3(-1, 0, 0)]
	if dv == Vector2i(0, 1):
		return [Vector3(x0 + cell, 0, z0 + cell), Vector3(-1, 0, 0), Vector3(0, 0, 1)]
	return [Vector3(x0, 0, z0), Vector3(1, 0, 0), Vector3(0, 0, -1)]

func _wall_face(b: MeshBatch, x: int, z: int, dv: Vector2i, nh: int, h: int, playable: bool) -> void:
	var fr := _face_frame(x, z, dv)
	var a: Vector3 = fr[0]
	var along: Vector3 = fr[1]
	var n: Vector3 = fr[2]
	var yaw := atan2(n.x, n.z)
	var near := playable or _near_map(x, z, 4)
	for k in range(nh, h):
		var y0 := k * S
		var y1 := (k + 1) * S
		var wm := _wall_mat(x, z, k)
		b.add_quad(wm, a + Vector3(0, y0, 0), a + along * cell + Vector3(0, y0, 0), a + along * cell + Vector3(0, y1, 0), a + Vector3(0, y1, 0), n)
		var mid := a + along * (cell * 0.5)
		# a ledge at each floor line
		if k > nh or k > 0:
			b.box_at(Mats.darkstone(), mid + Vector3(0, y0 + 0.05, 0) + n * 0.07, _oriented(cell + 0.02, 0.22, 0.14, along))
		if not near:
			if k >= 1 and hashf(x * 3 + dv.x, z * 3 + dv.y, k) < 0.35:
				b.box_at(m_void, mid + Vector3(0, y0 + 1.6, 0) + n * 0.03, _oriented(0.7, 1.2, 0.06, along))
			continue
		var r := hashf(x * 5 + dv.x * 2, z * 5 + dv.y * 2, k + 30)
		if k >= 1 and r < 0.5:
			var lit := hashf(x, z, k + 99) < 0.07
			var cy := y0 + 1.55
			b.box_at(m_glow_win if lit else m_void, mid + Vector3(0, cy, 0) + n * 0.02, _oriented(0.72, 1.25, 0.04, along))
			# jambs, sill and lintel make the window read as a recess
			b.box_at(wm, mid + along * 0.42 + Vector3(0, cy, 0) + n * 0.09, _oriented(0.14, 1.45, 0.18, along))
			b.box_at(wm, mid - along * 0.42 + Vector3(0, cy, 0) + n * 0.09, _oriented(0.14, 1.45, 0.18, along))
			b.box_at(Mats.darkstone(), mid + Vector3(0, cy - 0.7, 0) + n * 0.1, _oriented(1.0, 0.12, 0.2, along))
			b.box_at(Mats.darkstone(), mid + Vector3(0, cy + 0.68, 0) + n * 0.1, _oriented(1.0, 0.16, 0.2, along))
		elif k == 0 and nh == 0 and r < 0.16:
			b.box_at(m_void, mid + Vector3(0, 1.05, 0) + n * 0.02, _oriented(1.05, 2.1, 0.04, along))
			b.box_at(m_char, mid + Vector3(0, 2.18, 0) + n * 0.1, _oriented(1.5, 0.22, 0.22, along))
		elif k >= 1 and r > 0.93:
			# a charred beam jutting from a burnt-out floor
			var len := 1.0 + hashf(x, z, 77) * 0.8
			b.box_at(m_char, mid + Vector3(0, y0 + 0.2, 0) + n * (len * 0.5), _oriented(0.18, 0.18, len, along), 0, 0.15 * (hashf(x, z, 78) - 0.5))
	# broken parapet along the top edge (jagged ruin silhouette)
	var top := h * S
	var wm2 := _wall_mat(x, z, h - 1)
	var segs := 4
	for i in range(segs):
		var rr := hashf(x * 7 + i, z * 7 + dv.x * 3 + dv.y * 5, 55)
		var ph := 0.0
		if playable:
			ph = 0.0 if rr < 0.3 else 0.25 + rr * 0.75
		else:
			ph = 0.0 if rr < 0.2 else 0.4 + rr * 1.6
		if ph <= 0.0:
			continue
		var c := a + along * (cell * (i + 0.5) / segs) - n * 0.15 + Vector3(0, top + ph * 0.5, 0)
		b.box_at(wm2, c, _oriented(cell / segs + 0.01, ph, 0.3, along))
		# a few fallen blocks at the foot of the broken bits
		if not playable and rr > 0.9 and near:
			b.box_at(wm2, a + along * (cell * i / segs) + n * 0.6 + Vector3(0, nh * S + 0.15, 0), Vector3(0.4, 0.3, 0.35), rr * 6.0)

func _oriented(len_along: float, height: float, depth: float, along: Vector3) -> Vector3:
	## Box size for a box whose length runs `along` the wall (x or z).
	if abs(along.x) > 0.5:
		return Vector3(len_along, height, depth)
	return Vector3(depth, height, len_along)

# ------------------------------------------------------------------ skyline

func _skyline(b: MeshBatch) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 7741
	var cx := map.w * cell * 0.5
	var cz := map.d * cell * 0.5
	var dm := Mats.pbr("darkstone", 0.08, Color(0.55, 0.55, 0.6))
	var sm := Mats.pbr("stone", 0.08, Color(0.6, 0.58, 0.58))
	for i in range(46):
		var ang := rng.randf() * TAU
		var dist := rng.randf_range(95.0, 240.0)
		var p := Vector3(cx + cos(ang) * dist, 0, cz + sin(ang) * dist)
		var w := rng.randf_range(6.0, 16.0)
		var d := rng.randf_range(6.0, 16.0)
		var h := rng.randf_range(14.0, 34.0)
		if rng.randf() < 0.18:
			h = rng.randf_range(40.0, 70.0)   # a broken spire
			w = rng.randf_range(5.0, 8.0)
			d = w
		var mat := dm if rng.randf() < 0.6 else sm
		b.box_at(mat, p + Vector3(0, h * 0.5, 0), Vector3(w, h, d), ang)
		# jagged ruined crown
		for j in range(5):
			var jh := rng.randf_range(1.0, 6.0)
			var off := Vector3(rng.randf_range(-w, w) * 0.4, h + jh * 0.5, rng.randf_range(-d, d) * 0.4).rotated(Vector3.UP, ang)
			b.box_at(mat, p + off, Vector3(w * rng.randf_range(0.2, 0.4), jh, d * rng.randf_range(0.2, 0.4)), ang)
		if rng.randf() < 0.35:
			b.add_gable(Mats.pbr("roof", 0.1, Color(0.6, 0.6, 0.6)), p + Vector3(0, h, 0), w, d, rng.randf_range(3.0, 7.0), true, [rng.randi() % 8, rng.randi() % 8])
	# the old city wall, broken in places
	var ring_r := 300.0
	for i in range(64):
		if rng.randf() < 0.2:
			continue
		var a0 := TAU * i / 64.0
		var p := Vector3(cx + cos(a0) * ring_r, 0, cz + sin(a0) * ring_r)
		var h := rng.randf_range(10.0, 18.0)
		b.box_at(dm, p + Vector3(0, h * 0.5, 0), Vector3(8.0, h, 31.0), -a0)
		if i % 4 == 0:
			b.box_at(dm, p + Vector3(0, h * 0.75, 0), Vector3(12.0, h * 1.5, 12.0), -a0)

# ------------------------------------------------------------------ props

func _props(b: MeshBatch) -> void:
	for z in range(map.d):
		for x in range(map.w):
			var pr := map.prop_at(x, z)
			if pr == "." or pr == "T" or pr == "B":
				continue
			var c := map.cell_center(x, z)
			var base := Vector3(c.x, map.h_at(x, z) * S, c.y)
			match pr:
				"p":
					_pillar(b, base, x, z)
				"b":
					_barricade(b, base, x, z)
				"r":
					_rubble(b, base, x, z, 1.0)
				"c":
					_crates(b, base, x, z)

func _pillar(b: MeshBatch, base: Vector3, x: int, z: int) -> void:
	var sm := Mats.pbr("stone", 0.35, Color(0.85, 0.83, 0.8))
	b.box_at(sm, base + Vector3(0, 0.25, 0), Vector3(1.3, 0.5, 1.3))
	b.box_at(sm, base + Vector3(0, 0.6, 0), Vector3(1.1, 0.2, 1.1))
	var h := PROP_H("p") - 0.9 - hashf(x, z, 1) * 0.6
	b.add_cyl(sm, Transform3D(Basis(), base + Vector3(0, 0.7, 0)), 0.5, 0.44, h, 14)
	# broken jagged top: a tilted drum
	b.add_cyl(sm, Transform3D(Basis.from_euler(Vector3(0.2, hashf(x, z, 4) * 6.0, 0.15)), base + Vector3(0.02, 0.7 + h - 0.05, 0)), 0.43, 0.38, 0.35 + hashf(x, z, 5) * 0.5, 14)
	# a fallen drum on the ground beside it
	var ang := hashf(x, z, 2) * TAU
	var off := Vector3(cos(ang), 0, sin(ang)) * 0.95
	b.add_cyl(sm, Transform3D(Basis.from_euler(Vector3(0, ang, PI * 0.5)), base + off + Vector3(0, 0.42, 0)), 0.42, 0.42, 0.7, 12)

func PROP_H(p: String) -> float:
	return BattleMap.PROP_HEIGHT.get(p, 1.0)

func _barricade(b: MeshBatch, base: Vector3, x: int, z: int) -> void:
	var wm := Mats.pbr("wood", 0.6, Color(0.75, 0.68, 0.6))
	var yaw := (0.0 if hashf(x, z, 1) < 0.5 else PI * 0.5) + (hashf(x, z, 2) - 0.5) * 0.5
	var fwd := Vector3(cos(yaw), 0, -sin(yaw))
	# planks laid against cross-trestles
	for i in range(4):
		b.box_at(wm, base + Vector3(0, 0.25 + i * 0.27, 0), Vector3(1.9, 0.22, 0.08), yaw, 0, (hashf(x, z, i + 5) - 0.5) * 0.12)
	for s in [-0.75, 0.0, 0.75]:
		var p: Vector3 = base + fwd * s
		b.box_at(wm, p + Vector3(0, 0.6, 0), Vector3(0.1, 1.5, 0.1), yaw, 0.55, 0)
		b.box_at(wm, p + Vector3(0, 0.6, 0), Vector3(0.1, 1.5, 0.1), yaw, -0.55, 0)
	# sharpened stakes
	for i in range(3):
		var p := base + fwd * (-0.6 + i * 0.6) + Vector3(0, 0.9, 0)
		b.add_cyl(wm, Transform3D(Basis.from_euler(Vector3(0.6, yaw, 0)), p), 0.06, 0.0, 0.7, 6)
	_rubble(b, base + Vector3(0.5, 0, 0.6), x + 3, z + 7, 0.35)

func _rubble(b: MeshBatch, base: Vector3, x: int, z: int, scale: float) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = x * 1000 + z * 7 + 13
	var sm := Mats.stone()
	var dm := Mats.darkstone()
	var n := int(10 * scale) + 3
	for i in range(n):
		var r := rng.randf_range(0.0, 0.85) * scale
		var a := rng.randf() * TAU
		var hgt := (1.0 - r / maxf(scale, 0.01)) * 0.6 * scale + 0.1
		var sz := Vector3(rng.randf_range(0.25, 0.6), rng.randf_range(0.15, 0.35), rng.randf_range(0.2, 0.5)) * (0.6 + scale * 0.4)
		b.box_at(sm if rng.randf() < 0.6 else dm, base + Vector3(cos(a) * r, hgt * rng.randf_range(0.2, 1.0), sin(a) * r), sz, rng.randf() * TAU, rng.randf_range(-0.5, 0.5), rng.randf_range(-0.5, 0.5))
	if scale >= 1.0:
		b.box_at(m_char, base + Vector3(0, 0.45, 0), Vector3(2.0, 0.16, 0.16), rng.randf() * TAU, 0.0, 0.35)

func _crates(b: MeshBatch, base: Vector3, x: int, z: int) -> void:
	var wm := Mats.pbr("wood", 0.7, Color(0.85, 0.75, 0.62))
	var yaw := hashf(x, z, 1) * PI
	b.box_at(wm, base + Vector3(-0.35, 0.4, 0.1), Vector3(0.8, 0.8, 0.8), yaw)
	b.box_at(wm, base + Vector3(0.45, 0.3, -0.25), Vector3(0.6, 0.6, 0.6), yaw + 0.4)
	b.box_at(wm, base + Vector3(-0.3, 1.1, 0.05), Vector3(0.55, 0.55, 0.55), yaw + 0.2)
	b.add_cyl(wm, Transform3D(Basis(), base + Vector3(0.4, 0, 0.55)), 0.3, 0.3, 0.85, 10)
	b.add_cyl(Mats.iron(), Transform3D(Basis(), base + Vector3(0.4, 0.15, 0.55)), 0.31, 0.31, 0.05, 10, false)
	b.add_cyl(Mats.iron(), Transform3D(Basis(), base + Vector3(0.4, 0.65, 0.55)), 0.31, 0.31, 0.05, 10, false)

func _street_rubble(b: MeshBatch) -> void:
	## Small fallen stones at the foot of walls (visual only).
	var rng := RandomNumberGenerator.new()
	rng.seed = 991
	var sm := Mats.stone()
	for z in range(-4, map.d + 4):
		for x in range(-4, map.w + 4):
			if H(x, z) != 0:
				continue
			var wall_dir := Vector2i.ZERO
			for dv in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
				if H(x + dv.x, z + dv.y) > 0:
					wall_dir = dv
			if wall_dir == Vector2i.ZERO or hashf(x, z, 61) > 0.45:
				continue
			var c := Vector3((x + 0.5) * cell, 0, (z + 0.5) * cell) + Vector3(wall_dir.x, 0, wall_dir.y) * 0.7
			for i in range(rng.randi_range(2, 6)):
				var s := rng.randf_range(0.12, 0.32)
				b.box_at(sm, c + Vector3(rng.randf_range(-0.8, 0.8) * (1 - abs(wall_dir.x)) + rng.randf_range(-0.2, 0.2), s * 0.4, rng.randf_range(-0.8, 0.8) * (1 - abs(wall_dir.y)) + rng.randf_range(-0.2, 0.2)), Vector3(s * 1.3, s, s), rng.randf() * TAU, rng.randf() * 0.6, rng.randf() * 0.6)

# ------------------------------------------------------------------ ladders, stairs, bridges

func _links(b: MeshBatch) -> void:
	var wm := Mats.pbr("wood", 0.6, Color(0.8, 0.72, 0.62))
	for lad in map.ladders:
		var a := Vector2i(int(lad["x"]), int(lad["z"]))
		var t := Vector2i(int(lad["tx"]), int(lad["tz"]))
		var dir := Vector3(t.x - a.x, 0, t.y - a.y)
		var c := map.cell_center(a.x, a.y)
		var low := map.h_at(a.x, a.y) * S
		var high := map.h_at(t.x, t.y) * S
		var rise := high - low + 0.9
		var foot := Vector3(c.x, low, c.y) + dir * (cell * 0.5 - 0.55)
		var top := Vector3(c.x, low, c.y) + dir * (cell * 0.5 - 0.05) + Vector3(0, rise, 0)
		var axis := (top - foot)
		var length := axis.length()
		var up := axis.normalized()
		var side := up.cross(dir).normalized()
		if side.length() < 0.1:
			side = Vector3(dir.z, 0, -dir.x)
		var basis := Basis(side, up, side.cross(up)).orthonormalized()
		for s in [-0.28, 0.28]:
			b.add_box(wm, Transform3D(basis, foot + axis * 0.5 + side * s), Vector3(0.07, length, 0.07))
		var rungs := int(length / 0.35)
		for i in range(1, rungs):
			b.add_box(wm, Transform3D(basis, foot + axis * (float(i) / rungs)), Vector3(0.6, 0.045, 0.045))
	for stv in map.stairs:
		var a := Vector2i(int(stv["x"]), int(stv["z"]))
		var t := Vector2i(int(stv["tx"]), int(stv["tz"]))
		var dir := Vector3(t.x - a.x, 0, t.y - a.y)
		var side := Vector3(dir.z, 0, -dir.x)
		var c := map.cell_center(a.x, a.y)
		var low := map.h_at(a.x, a.y) * S
		var rise := (map.h_at(t.x, t.y) - map.h_at(a.x, a.y)) * S
		var steps := int(rise / 0.3)
		var run := cell * 0.95
		var sm := Mats.pbr("stone", 0.3, Color(0.8, 0.78, 0.75))
		for i in range(steps):
			var f := (i + 0.5) / steps
			var p := Vector3(c.x, low, c.y) + dir * (-cell * 0.47 + run * f)
			var hgt := rise * (i + 1) / steps
			b.add_box(sm, Transform3D(Basis(), p + Vector3(0, hgt * 0.5, 0) + side * 0.0), _oriented_dir(run / steps + 0.01, hgt, 1.5, dir))
		# side wall of the stair
		var mid := Vector3(c.x, low, c.y) + side * 0.82
		b.add_box(Mats.darkstone(), Transform3D(Basis(), mid + Vector3(0, rise * 0.3, 0)), _oriented_dir(cell * 0.9, rise * 0.6, 0.18, dir))

func _oriented_dir(len_along: float, height: float, width: float, dir: Vector3) -> Vector3:
	if abs(dir.x) > 0.5:
		return Vector3(len_along, height, width)
	return Vector3(width, height, len_along)

func _bridges(b: MeshBatch) -> void:
	var wm := Mats.pbr("wood", 0.6, Color(0.7, 0.62, 0.55))
	for k in map.bridge_level:
		var v: Vector2i = k
		var l: int = map.bridge_level[k]
		var along_x := map.has_node(v.x - 1, v.y, l) or map.has_node(v.x + 1, v.y, l)
		var c := map.cell_center(v.x, v.y)
		var y := l * S
		var dir := Vector3(1, 0, 0) if along_x else Vector3(0, 0, 1)
		var side := Vector3(dir.z, 0, dir.x)
		# planks across the run
		for i in range(7):
			var off := dir * (-cell * 0.5 + cell * (i + 0.5) / 7.0)
			var rr := hashf(v.x, v.y, i)
			b.box_at(wm, Vector3(c.x, y - 0.06, c.y) + off, _oriented_dir(0.26, 0.07, 1.4 + rr * 0.15, dir), 0, (rr - 0.5) * 0.04, (rr - 0.5) * 0.06)
		# two beams under the planks
		for s in [-0.5, 0.5]:
			b.box_at(m_char, Vector3(c.x, y - 0.2, c.y) + side * s, _oriented_dir(cell + 0.02, 0.16, 0.14, dir))
		# rope rail posts
		for s in [-0.72, 0.72]:
			b.box_at(wm, Vector3(c.x, y + 0.45, c.y) + side * s, Vector3(0.08, 1.0, 0.08))
			b.box_at(wm, Vector3(c.x, y + 0.92, c.y) + side * s, _oriented_dir(cell, 0.04, 0.04, dir))

# ------------------------------------------------------------------ the idol of the Chained One

func _robe_mesh() -> Mesh:
	var m := CylinderMesh.new()
	m.bottom_radius = 1.15
	m.top_radius = 0.6
	m.height = 3.0
	m.radial_segments = 20
	m.rings = 3
	return m

func _idol() -> void:
	var cells: Array = []
	for z in range(map.d):
		for x in range(map.w):
			if map.prop_at(x, z) == "T":
				cells.append(Vector2i(x, z))
	if cells.is_empty():
		return
	var cx := 0.0
	var cz := 0.0
	for c in cells:
		cx += (c.x + 0.5) * cell
		cz += (c.y + 0.5) * cell
	cx /= cells.size()
	cz /= cells.size()
	var base := Vector3(cx, 0, cz)
	var b := MeshBatch.new()
	var ps := Mats.pbr("darkstone", 0.4, Color(0.75, 0.75, 0.78))
	var bronze := StandardMaterial3D.new()
	bronze.albedo_color = Color(0.2, 0.25, 0.2)
	bronze.metallic = 0.75
	bronze.roughness = 0.42
	bronze.normal_enabled = true
	bronze.normal_texture = load("res://textures/plaster_normal.png")
	bronze.normal_scale = 0.6
	bronze.uv1_triplanar = true
	bronze.uv1_world_triplanar = true
	bronze.uv1_scale = Vector3(0.6, 0.6, 0.6)
	bronze.rim_enabled = true
	bronze.rim = 0.3
	# stepped plinth
	b.box_at(ps, base + Vector3(0, 0.3, 0), Vector3(4.2, 0.6, 4.2))
	b.box_at(ps, base + Vector3(0, 0.85, 0), Vector3(3.4, 0.5, 3.4))
	b.box_at(ps, base + Vector3(0, 1.35, 0), Vector3(2.7, 0.5, 2.7))
	# the hooded, faceless god in his robe, head bowed, chained at the wrists
	var statue := Node3D.new()
	statue.position = base
	add_child(statue)
	var torso := base + Vector3(0, 4.1, 0)
	var top := 1.6
	_sp(statue, "cyl", Vector3(1.0, 3.0, 1.0), bronze, Vector3(0, top + 1.5, 0), Vector3.ZERO)
	var robe := statue.get_child(statue.get_child_count() - 1) as MeshInstance3D
	robe.mesh = _robe_mesh()
	robe.scale = Vector3.ONE
	# folds in the robe
	for i in range(12):
		var ang := i * TAU / 12.0 + 0.2
		var fup := Vector3(-cos(ang) * 0.55, 3.0, -sin(ang) * 0.55).normalized()
		var fside := fup.cross(Vector3(cos(ang), 0, sin(ang))).normalized()
		var f := _sp(statue, "capsule", Vector3.ONE, bronze, Vector3(cos(ang) * 0.86, top + 1.45, sin(ang) * 0.86), Vector3.ZERO)
		f.basis = Basis(fside, fup, fside.cross(fup)).orthonormalized() * Basis.from_scale(Vector3(0.2, 1.45, 0.2))
	_sp(statue, "sphere", Vector3(0.9, 0.42, 0.62), bronze, Vector3(0, top + 3.0, 0.05), Vector3(0.15, 0, 0))
	# hood bowed forward, with an empty dark face and two faint embers for eyes
	_sp(statue, "sphere", Vector3(0.52, 0.62, 0.55), bronze, Vector3(0, top + 3.55, 0.28), Vector3(0.45, 0, 0))
	_sp(statue, "sphere", Vector3(0.62, 0.55, 0.5), bronze, Vector3(0, top + 3.4, -0.08), Vector3(0.2, 0, 0))
	var void_m := StandardMaterial3D.new()
	void_m.albedo_color = Color(0.01, 0.01, 0.012)
	void_m.roughness = 1.0
	_sp(statue, "sphere", Vector3(0.34, 0.42, 0.2), void_m, Vector3(0, top + 3.42, 0.7), Vector3(0.45, 0, 0))
	var eye_m := Mats.glow(Color(0.35, 1.0, 0.85), 6.0, true)
	for s in [-1.0, 1.0]:
		_sp(statue, "sphere", Vector3(0.045, 0.03, 0.03), eye_m, Vector3(s * 0.11, top + 3.42, 0.86), Vector3.ZERO)
	var wrists := []
	for s in [-1.0, 1.0]:
		var sh := Vector3(s * 0.78, top + 3.0, 0.15)
		var el := Vector3(s * 0.82, top + 2.0, 0.55)
		var wr := Vector3(s * 0.32, top + 1.75, 1.05)
		for seg in [[sh, el, 0.36], [el, wr, 0.3]]:
			var p0: Vector3 = seg[0]
			var p1: Vector3 = seg[1]
			var up := (p0 - p1).normalized()
			var side := up.cross(Vector3.FORWARD).normalized()
			var bas := Basis(side, up, side.cross(up)).orthonormalized()
			var len := (p0 - p1).length() + 0.3
			var arm := _sp(statue, "capsule", Vector3.ONE, bronze, (p0 + p1) * 0.5, Vector3.ZERO)
			arm.basis = bas * Basis.from_scale(Vector3(seg[2], len * 0.5, seg[2]))
			if seg[1] == wr:
				var cuff := _sp(statue, "cyl", Vector3.ONE, Mats.iron(), wr + up * 0.1, Vector3.ZERO)
				cuff.basis = bas * Basis.from_scale(Vector3(0.4, 0.3, 0.4))
		_sp(statue, "sphere", Vector3(0.17, 0.2, 0.15), bronze, wr - Vector3(0, 0.12, -0.05), Vector3.ZERO)
		wrists.append(base + wr)
	# chains run from the shackles down to rings on the plinth corners
	var iron := Mats.iron()
	for i in range(2):
		var wr: Vector3 = wrists[i]
		var anchor := base + Vector3((-1.0 if i == 0 else 1.0) * 1.85, 0.62, 1.85)
		var links := 14
		for j in range(links):
			var t := float(j) / (links - 1)
			var p := wr.lerp(anchor, t) + Vector3(0, -sin(t * PI) * 0.55, 0)
			var d := (anchor - wr).normalized()
			var bas := Basis.looking_at(d, Vector3.UP).rotated(d, (PI * 0.5) if j % 2 else 0.0)
			b.add_box(iron, Transform3D(bas, p), Vector3(0.05, 0.2, 0.26))
		b.add_cyl(iron, Transform3D(Basis(), anchor - Vector3(0, 0.1, 0)), 0.18, 0.18, 0.2, 8)
	# back chains to the rear corners
	for s in [-1.0, 1.0]:
		var from := torso + Vector3(s * 0.6, 0.2, -0.45)
		var anchor := base + Vector3(s * 1.85, 0.62, -1.85)
		for j in range(12):
			var t := float(j) / 11.0
			var p := from.lerp(anchor, t) + Vector3(0, -sin(t * PI) * 0.4, 0)
			var d := (anchor - from).normalized()
			var bas := Basis.looking_at(d, Vector3.UP).rotated(d, (PI * 0.5) if j % 2 else 0.0)
			b.add_box(iron, Transform3D(bas, p), Vector3(0.05, 0.2, 0.26))
	var mi := b.build(true)
	mi.name = "Idol"
	add_child(mi)
	# a glowing crack through the plinth, where a godshard struck
	var crack := MeshBatch.new()
	var gm := Mats.glow(Color(0.3, 1.0, 0.85), 5.0)
	for i in range(6):
		var a := i * 0.6
		crack.box_at(gm, base + Vector3(-1.2 + i * 0.45, 0.62 + sin(a) * 0.08, 2.11), Vector3(0.5, 0.05, 0.02), 0, 0, sin(a * 2.0) * 0.5)
	var cmi := crack.build(false)
	add_child(cmi)
	var l := OmniLight3D.new()
	l.light_color = Color(0.3, 1.0, 0.8)
	l.light_energy = 1.4
	l.omni_range = 6.0
	l.position = base + Vector3(0, 0.9, 2.6)
	add_child(l)

# ------------------------------------------------------------------ fire

func _fire_particles(amount: int, size: float, height: float) -> GPUParticles3D:
	var p := GPUParticles3D.new()
	p.amount = amount
	p.lifetime = 0.9
	p.randomness = 0.5
	p.visibility_aabb = AABB(Vector3(-2, -1, -2), Vector3(4, 6, 4))
	var pm := ParticleProcessMaterial.new()
	pm.direction = Vector3(0, 1, 0)
	pm.spread = 12.0
	pm.initial_velocity_min = height * 0.8
	pm.initial_velocity_max = height * 1.6
	pm.gravity = Vector3(0, 0.6, 0)
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	pm.emission_sphere_radius = size * 0.5
	pm.scale_min = 0.7
	pm.scale_max = 1.2
	var sc := Curve.new()
	sc.add_point(Vector2(0, 0.6))
	sc.add_point(Vector2(0.3, 1.0))
	sc.add_point(Vector2(1, 0.0))
	var sct := CurveTexture.new()
	sct.curve = sc
	pm.scale_curve = sct
	var grad := Gradient.new()
	grad.set_color(0, Color(1.0, 0.85, 0.4, 1.0))
	grad.set_color(1, Color(0.6, 0.1, 0.02, 0.0))
	grad.add_point(0.4, Color(1.0, 0.45, 0.1, 0.85))
	var gt := GradientTexture1D.new()
	gt.gradient = grad
	pm.color_ramp = gt
	p.process_material = pm
	var q := QuadMesh.new()
	q.size = Vector2(size, size * 1.3)
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.vertex_color_use_as_albedo = true
	m.albedo_texture = _soft_dot()
	m.albedo_color = Color(2.2, 2.0, 1.8)
	q.material = m
	p.draw_pass_1 = q
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return p

static var _dot_tex: Texture2D

static func _soft_dot() -> Texture2D:
	if _dot_tex == null:
		var g := Gradient.new()
		g.set_color(0, Color(1, 1, 1, 1))
		g.set_color(1, Color(1, 1, 1, 0))
		var t := GradientTexture2D.new()
		t.gradient = g
		t.fill = GradientTexture2D.FILL_RADIAL
		t.fill_from = Vector2(0.5, 0.5)
		t.fill_to = Vector2(1.0, 0.5)
		t.width = 64
		t.height = 64
		_dot_tex = t
	return _dot_tex

func _embers(rate: int) -> GPUParticles3D:
	var p := GPUParticles3D.new()
	p.amount = rate
	p.lifetime = 3.0
	p.visibility_aabb = AABB(Vector3(-4, -1, -4), Vector3(8, 12, 8))
	var pm := ParticleProcessMaterial.new()
	pm.direction = Vector3(0, 1, 0)
	pm.spread = 25.0
	pm.initial_velocity_min = 1.0
	pm.initial_velocity_max = 2.5
	pm.gravity = Vector3(0.3, 0.2, 0.1)
	pm.turbulence_enabled = true
	pm.turbulence_noise_strength = 0.6
	pm.scale_min = 0.5
	pm.scale_max = 1.0
	var grad := Gradient.new()
	grad.set_color(0, Color(1.0, 0.6, 0.2, 1))
	grad.set_color(1, Color(1.0, 0.2, 0.05, 0))
	var gt := GradientTexture1D.new()
	gt.gradient = grad
	pm.color_ramp = gt
	p.process_material = pm
	var q := QuadMesh.new()
	q.size = Vector2(0.05, 0.05)
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.vertex_color_use_as_albedo = true
	m.albedo_texture = _soft_dot()
	m.albedo_color = Color(3, 2.5, 2)
	q.material = m
	p.draw_pass_1 = q
	return p

func _flame(at: Vector3, big: bool, shadows: bool) -> void:
	var f := _fire_particles(28 if big else 18, 0.9 if big else 0.55, 1.4 if big else 0.9)
	f.position = at
	add_child(f)
	var e := _embers(10 if big else 5)
	e.position = at
	add_child(e)
	var l := OmniLight3D.new()
	l.light_color = Color(1.0, 0.55, 0.22)
	l.light_energy = 3.2 if big else 2.2
	l.omni_range = 12.0 if big else 8.0
	l.omni_attenuation = 1.2
	l.shadow_enabled = shadows
	l.position = at + Vector3(0, 0.6, 0)
	add_child(l)
	flicker_lights.append({"light": l, "base": l.light_energy, "seed": randf() * 100.0})

func _braziers() -> void:
	var n := 0
	for z in range(map.d):
		for x in range(map.w):
			if map.prop_at(x, z) != "B":
				continue
			var c := map.cell_center(x, z)
			var base := Vector3(c.x, map.h_at(x, z) * S, c.y)
			var b := MeshBatch.new()
			var iron := Mats.iron()
			for i in range(3):
				var a := TAU * i / 3.0
				var foot := base + Vector3(cos(a), 0, sin(a)) * 0.42
				var top := base + Vector3(0, 0.85, 0)
				var axis := top - foot
				var up := axis.normalized()
				var side := up.cross(Vector3(cos(a), 0, sin(a))).normalized()
				b.add_box(iron, Transform3D(Basis(side, up, side.cross(up)).orthonormalized(), foot + axis * 0.5), Vector3(0.06, axis.length(), 0.06))
			b.add_cyl(iron, Transform3D(Basis(), base + Vector3(0, 0.8, 0)), 0.18, 0.5, 0.32, 12)
			b.add_cyl(Mats.glow(Color(1.0, 0.35, 0.08), 3.0), Transform3D(Basis(), base + Vector3(0, 1.08, 0)), 0.42, 0.3, 0.06, 10)
			var mi := b.build(true)
			add_child(mi)
			_flame(base + Vector3(0, 1.1, 0), false, n < 2)
			n += 1

func _sconces() -> void:
	## Torches in iron brackets on the walls of the streets, every few cells.
	var dirs := [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
	var placed: Array = []
	var iron := Mats.iron()
	for z in range(map.d):
		for x in range(map.w):
			if map.prop_at(x, z) != "." or map.h_at(x, z) != 0:
				continue
			if hashf(x, z, 91) > 0.16:
				continue
			for dv in dirs:
				var v: Vector2i = dv
				if H(x + v.x, z + v.y) < 1:
					continue
				var c := map.cell_center(x, z)
				var p := Vector3(c.x + v.x * (cell * 0.5 - 0.12), 2.1, c.y + v.y * (cell * 0.5 - 0.12))
				var near := false
				for q in placed:
					if (q as Vector3).distance_to(p) < 7.0:
						near = true
				if near:
					break
				placed.append(p)
				var b := MeshBatch.new()
				var out := Vector3(-v.x, 0, -v.y)
				b.add_box(iron, Transform3D(Basis(), p + out * 0.1 - Vector3(0, 0.12, 0)), Vector3(0.08 + absf(out.x) * 0.2, 0.06, 0.08 + absf(out.z) * 0.2))
				b.add_cyl(iron, Transform3D(Basis(), p + out * 0.22 - Vector3(0, 0.2, 0)), 0.035, 0.05, 0.42, 6)
				b.add_cyl(m_char, Transform3D(Basis(), p + out * 0.22), 0.06, 0.05, 0.14, 6)
				add_child(b.build(false))
				var fire_at := p + out * 0.22 + Vector3(0, 0.08, 0)
				var f := _fire_particles(10, 0.32, 0.5)
				f.position = fire_at
				add_child(f)
				var l := OmniLight3D.new()
				l.light_color = Color(1.0, 0.52, 0.2)
				l.light_energy = 1.7
				l.omni_range = 7.5
				l.omni_attenuation = 1.4
				l.shadow_enabled = false
				l.position = fire_at + out * 0.25 + Vector3(0, 0.2, 0)
				add_child(l)
				flicker_lights.append({"light": l, "base": l.light_energy, "seed": randf() * 100.0})
				break
			if placed.size() >= 14:
				return

func _fires() -> void:
	## Burning wreckage on a few rooftops and in the backdrop streets.
	var spots := [Vector2i(1, 9), Vector2i(26, 18), Vector2i(10, 22), Vector2i(-3, 14), Vector2i(31, 12), Vector2i(14, -4), Vector2i(12, 31)]
	var i := 0
	for v in spots:
		var h := H(v.x, v.y)
		var base := Vector3((v.x + 0.5) * cell, h * S, (v.y + 0.5) * cell)
		var b := MeshBatch.new()
		for j in range(5):
			b.box_at(m_char, base + Vector3(0, 0.15 + j * 0.05, 0), Vector3(1.6, 0.14, 0.16), j * 0.7, 0, 0.15)
		add_child(b.build(true))
		_flame(base + Vector3(0, 0.3, 0), true, i == 0)
		i += 1

func _process(_delta: float) -> void:
	var t := Time.get_ticks_msec() / 1000.0
	for f in flicker_lights:
		var l: OmniLight3D = f["light"]
		var s: float = f["seed"]
		l.light_energy = f["base"] * (0.82 + 0.1 * sin(t * 9.0 + s) + 0.08 * sin(t * 23.0 + s * 2.0))

# ------------------------------------------------------------------ godshards

func add_shard(nd: int) -> void:
	if shard_nodes.has(nd) or not map.nodes.has(nd):
		return
	var root := Node3D.new()
	root.position = map.node_pos(nd)
	var b := MeshBatch.new()
	var gm := Mats.shard()
	var rng := RandomNumberGenerator.new()
	rng.seed = nd
	for i in range(5):
		var h := rng.randf_range(0.35, 0.8) * (1.4 if i == 0 else 1.0)
		var tilt := Basis.from_euler(Vector3(rng.randf_range(-0.5, 0.5), rng.randf() * TAU, rng.randf_range(-0.5, 0.5)))
		b.add_cyl(gm, Transform3D(tilt, Vector3(rng.randf_range(-0.2, 0.2), 0, rng.randf_range(-0.2, 0.2))), 0.09, 0.0, h, 5)
		b.add_cyl(gm, Transform3D(tilt.rotated(tilt.x, PI), Vector3(0, 0.02, 0)), 0.09, 0.0, 0.08, 5)
	b.box_at(Mats.darkstone(), Vector3(0, 0.05, 0), Vector3(0.7, 0.14, 0.6), rng.randf() * 3.0)
	root.add_child(b.build(false))
	var l := OmniLight3D.new()
	l.light_color = Color(0.3, 1.0, 0.82)
	l.light_energy = 1.6
	l.omni_range = 4.5
	l.position = Vector3(0, 0.6, 0)
	root.add_child(l)
	var motes := _embers(6)
	var pm: ParticleProcessMaterial = motes.process_material
	var grad := Gradient.new()
	grad.set_color(0, Color(0.4, 1.0, 0.85, 1))
	grad.set_color(1, Color(0.2, 0.8, 1.0, 0))
	var gt := GradientTexture1D.new()
	gt.gradient = grad
	pm.color_ramp = gt
	pm.initial_velocity_max = 0.8
	pm.initial_velocity_min = 0.3
	root.add_child(motes)
	add_child(root)
	shard_nodes[nd] = root

func remove_shard(nd: int) -> void:
	if shard_nodes.has(nd):
		shard_nodes[nd].queue_free()
		shard_nodes.erase(nd)

# ------------------------------------------------------------------ grime

func _grime_decals() -> void:
	var g := Gradient.new()
	g.set_color(0, Color(0.05, 0.04, 0.035, 0.75))
	g.set_color(1, Color(0.05, 0.04, 0.035, 0.0))
	var t := GradientTexture2D.new()
	t.gradient = g
	t.fill = GradientTexture2D.FILL_RADIAL
	t.fill_from = Vector2(0.5, 0.5)
	t.fill_to = Vector2(1.0, 0.5)
	t.width = 128
	t.height = 128
	var rng := RandomNumberGenerator.new()
	rng.seed = 5150
	for i in range(55):
		var d := Decal.new()
		d.texture_albedo = t
		var s := rng.randf_range(2.0, 6.0)
		d.size = Vector3(s, 1.2, s * rng.randf_range(0.6, 1.4))
		var x := rng.randf_range(-6.0, map.w * cell + 6.0)
		var z := rng.randf_range(-6.0, map.d * cell + 6.0)
		var h := H(int(floor(x / cell)), int(floor(z / cell))) * S
		d.position = Vector3(x, h, z)
		d.rotation.y = rng.randf() * TAU
		d.albedo_mix = 0.9
		d.upper_fade = 0.5
		d.lower_fade = 0.5
		add_child(d)

# ------------------------------------------------------------------ picking

func _collision() -> void:
	walk_body = StaticBody3D.new()
	walk_body.collision_layer = 1
	walk_body.collision_mask = 0
	add_child(walk_body)
	var ground := CollisionShape3D.new()
	var gs := BoxShape3D.new()
	gs.size = Vector3((map.w + 2 * RING) * cell, 1.0, (map.d + 2 * RING) * cell)
	ground.shape = gs
	ground.position = Vector3(map.w * cell * 0.5, -0.5, map.d * cell * 0.5)
	walk_body.add_child(ground)
	for z in range(map.d):
		for x in range(map.w):
			var h := map.h_at(x, z)
			if h <= 0:
				continue
			var cs := CollisionShape3D.new()
			var bs := BoxShape3D.new()
			bs.size = Vector3(cell, h * S, cell)
			cs.shape = bs
			cs.position = Vector3((x + 0.5) * cell, h * S * 0.5, (z + 0.5) * cell)
			walk_body.add_child(cs)
	for k in map.bridge_level:
		var v: Vector2i = k
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = Vector3(cell, 0.2, cell)
		cs.shape = bs
		cs.position = Vector3((v.x + 0.5) * cell, map.bridge_level[k] * S - 0.1, (v.y + 0.5) * cell)
		walk_body.add_child(cs)

func node_from_hit(p: Vector3, n: Vector3) -> int:
	## Turns a ray hit on the city into the movement node the player meant.
	var q := p - n * 0.05
	var x := int(floor(q.x / cell))
	var z := int(floor(q.z / cell))
	if not inside(x, z):
		return -1
	if n.y > 0.5:
		var l := int(round(p.y / S))
		var id := BattleMap.nid(x, z, l)
		if map.nodes.has(id):
			return id
	return map.top_node(x, z)


func _sp(parent: Node3D, kind: String, scl: Vector3, mat: Material, pos: Vector3, rot := Vector3.ZERO) -> MeshInstance3D:
	## Unit-sized primitive scaled into place (statue parts).
	var mi := MeshInstance3D.new()
	match kind:
		"sphere":
			var m := SphereMesh.new()
			m.radius = 0.5
			m.height = 1.0
			mi.mesh = m
		"cyl":
			var m := CylinderMesh.new()
			m.top_radius = 0.5
			m.bottom_radius = 0.5
			m.height = 1.0
			mi.mesh = m
		_:
			var m := CapsuleMesh.new()
			m.radius = 0.5
			m.height = 2.0
			mi.mesh = m
			scl = Vector3(scl.x, scl.y * 0.5, scl.z)
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	mi.scale = scl
	parent.add_child(mi)
	return mi
