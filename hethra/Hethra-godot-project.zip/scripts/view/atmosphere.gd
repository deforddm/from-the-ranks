class_name Atmosphere
extends Node3D
## Sky, fog, moonlight, the rift torn across the heavens, and falling ash.

const RIFT_SHADER := """
shader_type spatial;
render_mode unshaded, blend_add, cull_disabled, depth_draw_never, fog_disabled;
uniform vec4 core : source_color = vec4(0.55, 1.0, 0.9, 1.0);
uniform vec4 edge : source_color = vec4(0.75, 0.12, 0.35, 1.0);
uniform float strength = 2.2;
float h(float x) { return fract(sin(x * 127.1) * 43758.5453); }
float n1(float x) { float i = floor(x); float f = fract(x); f = f * f * (3.0 - 2.0 * f); return mix(h(i), h(i + 1.0), f); }
void fragment() {
	vec2 p = UV * 2.0 - 1.0;
	float t = TIME * 0.05;
	float crack = (n1(p.x * 3.0 + 4.0) - 0.5) * 0.5 + (n1(p.x * 9.0 + t) - 0.5) * 0.18 + (n1(p.x * 27.0) - 0.5) * 0.06;
	float d = abs(p.y - crack);
	float taper = pow(clamp(1.0 - abs(p.x), 0.0, 1.0), 0.6);
	float width = 0.02 + 0.06 * taper;
	float c = exp(-d / (width * 0.35)) * taper;
	float halo = exp(-d / (width * 3.5)) * taper * 0.55;
	float wisps = exp(-d / (width * 9.0)) * taper * 0.25 * (0.6 + 0.4 * n1(p.x * 14.0 + p.y * 6.0 + t * 8.0));
	vec3 col = core.rgb * c * 1.6 + mix(edge.rgb, core.rgb, 0.25) * halo + edge.rgb * wisps;
	ALBEDO = col * strength;
	ALPHA = 1.0;
}
"""

var env: Environment
var moon: DirectionalLight3D
var we: WorldEnvironment

func build(center: Vector3, settings: Dictionary) -> void:
	we = WorldEnvironment.new()
	env = Environment.new()
	var sky := Sky.new()
	var sm := ProceduralSkyMaterial.new()
	sm.sky_top_color = Color(0.03, 0.035, 0.06)
	sm.sky_horizon_color = Color(0.17, 0.15, 0.18)
	sm.sky_curve = 0.12
	sm.ground_bottom_color = Color(0.02, 0.02, 0.025)
	sm.ground_horizon_color = Color(0.16, 0.14, 0.16)
	sm.sun_angle_max = 12.0
	sm.sun_curve = 0.2
	sm.energy_multiplier = 1.0
	sky.sky_material = sm
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.55
	env.ambient_light_sky_contribution = 0.85
	env.ambient_light_color = Color(0.4, 0.45, 0.55)
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_AGX
	env.tonemap_exposure = 1.4
	env.tonemap_white = 6.0
	# soft distance fog with a cold tint, and true volumetric fog for light shafts
	env.fog_enabled = true
	env.fog_mode = Environment.FOG_MODE_EXPONENTIAL
	env.fog_light_color = Color(0.16, 0.15, 0.19)
	env.fog_light_energy = 0.7
	env.fog_density = 0.0028
	env.fog_sky_affect = 0.55
	env.fog_height = 6.0
	env.fog_height_density = 0.06
	env.fog_aerial_perspective = 0.25
	if settings.get("fog", true):
		env.volumetric_fog_enabled = true
		env.volumetric_fog_density = 0.007
		env.volumetric_fog_albedo = Color(0.55, 0.57, 0.62)
		env.volumetric_fog_emission = Color(0.012, 0.014, 0.02)
		env.volumetric_fog_anisotropy = 0.55
		env.volumetric_fog_length = 90.0
		env.volumetric_fog_detail_spread = 2.0
		env.volumetric_fog_ambient_inject = 0.15
		env.volumetric_fog_sky_affect = 0.2
		env.volumetric_fog_temporal_reprojection_enabled = true
	if settings.get("ssao", true):
		env.ssao_enabled = true
		env.ssao_radius = 1.6
		env.ssao_intensity = 2.2
		env.ssao_power = 1.6
		env.ssao_detail = 0.6
	if settings.get("ssil", false):
		env.ssil_enabled = true
		env.ssil_radius = 4.0
		env.ssil_intensity = 0.8
	if settings.get("glow", true):
		env.glow_enabled = true
		env.glow_intensity = 0.55
		env.glow_strength = 1.0
		env.glow_bloom = 0.06
		env.glow_hdr_threshold = 0.9
		env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SCREEN
		env.set_glow_level(0, 0.0)
		env.set_glow_level(1, 1.0)
		env.set_glow_level(2, 1.0)
		env.set_glow_level(3, 0.5)
		env.set_glow_level(4, 0.0)
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.08
	env.adjustment_saturation = 0.82
	we.environment = env
	add_child(we)

	# a cold low moon throwing long shadows
	moon = DirectionalLight3D.new()
	moon.light_color = Color(0.62, 0.7, 0.92)
	moon.light_energy = 1.35
	moon.light_volumetric_fog_energy = 1.4
	moon.rotation_degrees = Vector3(-32.0, 205.0, 0.0)
	moon.shadow_enabled = settings.get("shadows", true)
	moon.shadow_blur = 1.2
	moon.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
	moon.directional_shadow_max_distance = 140.0
	moon.shadow_bias = 0.04
	moon.shadow_normal_bias = 1.2
	add_child(moon)
	# the rift's sickly glow from the other side
	var rift_light := DirectionalLight3D.new()
	rift_light.light_color = Color(0.45, 0.8, 0.75)
	rift_light.light_energy = 0.18
	rift_light.light_volumetric_fog_energy = 0.6
	rift_light.rotation_degrees = Vector3(-18.0, 35.0, 0.0)
	rift_light.shadow_enabled = false
	add_child(rift_light)

	var rift := MeshInstance3D.new()
	var q := QuadMesh.new()
	q.size = Vector2(420, 120)
	rift.mesh = q
	var mat := ShaderMaterial.new()
	var sh := Shader.new()
	sh.code = RIFT_SHADER
	mat.shader = sh
	rift.material_override = mat
	rift.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var dir := Vector3(-0.55, 0.0, -0.84).normalized()
	rift.position = center + dir * 520.0 + Vector3(0, 230, 0)
	rift.look_at_from_position(rift.position, center + Vector3(0, 40, 0), Vector3.UP)
	rift.rotate_object_local(Vector3(0, 0, 1), 0.25)
	add_child(rift)

	_ash(center)

func _ash(center: Vector3) -> void:
	var p := GPUParticles3D.new()
	p.amount = 1400
	p.lifetime = 14.0
	p.preprocess = 14.0
	p.visibility_aabb = AABB(Vector3(-60, -5, -60), Vector3(120, 50, 120))
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(55, 1, 55)
	pm.direction = Vector3(0.3, -1, 0.1)
	pm.spread = 20.0
	pm.initial_velocity_min = 0.6
	pm.initial_velocity_max = 1.4
	pm.gravity = Vector3(0.15, -0.6, 0.05)
	pm.turbulence_enabled = true
	pm.turbulence_noise_strength = 0.4
	pm.turbulence_noise_scale = 6.0
	pm.scale_min = 0.6
	pm.scale_max = 1.4
	p.process_material = pm
	var qm := QuadMesh.new()
	qm.size = Vector2(0.06, 0.06)
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_texture = CityBuilder._soft_dot()
	m.albedo_color = Color(0.62, 0.6, 0.6, 0.7)
	qm.material = m
	p.draw_pass_1 = qm
	p.position = center + Vector3(0, 30, 0)
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(p)
