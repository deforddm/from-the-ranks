class_name Atmosphere
extends Node3D
## Sky, fog, moonlight, the rift torn across the heavens, and falling ash.

const RIFT_SHADER := """
shader_type spatial;
render_mode unshaded, blend_add, cull_disabled, depth_draw_never, fog_disabled;
uniform vec4 core : source_color = vec4(0.55, 1.0, 0.9, 1.0);
uniform vec4 edge : source_color = vec4(0.75, 0.12, 0.35, 1.0);
uniform float strength = 2.2;
float h(float x) { return fract(sin(x * 127.1) * 43758.5453); }
float n1(float x) { float i = floor(x); float f = fract(x); f = f * f * (3.0 - 2.0 * f); return mix(h(i), h(i + 1.0), f); }
void fragment() {
	vec2 p = UV * 2.0 - 1.0;
	float t = TIME * 0.05;
	float crack = (n1(p.x * 3.0 + 4.0) - 0.5) * 0.5 + (n1(p.x * 9.0 + t) - 0.5) * 0.18 + (n1(p.x * 27.0) - 0.5) * 0.06;
	float d = abs(p.y - crack);
	float taper = pow(clamp(1.0 - abs(p.x), 0.0, 1.0), 0.6);
	float width = 0.02 + 0.06 * taper;
	float c = exp(-d / (width * 0.35)) * taper;
	float halo = exp(-d / (width * 3.5)) * taper * 0.55;
	float wisps = exp(-d / (width * 9.0)) * taper * 0.25 * (0.6 + 0.4 * n1(p.x * 14.0 + p.y * 6.0 + t * 8.0));
	vec3 col = core.rgb * c * 1.6 + mix(edge.rgb, core.rgb, 0.25) * halo + edge.rgb * wisps;
	ALBEDO = col * strength;
	ALPHA = 1.0;
}
"""

var env: Environment
var moon: DirectionalLight3D
var we: WorldEnvironment
var weather := "still"
var flash: DirectionalLight3D      # lightning, in rain
var _next_strike := 6.0
var _moon_energy := 0.85
var _amb_energy := 0.3
var calm := false                  # screenshots: no lightning going off at random
var near_rain: GPUParticles3D      # a dense curtain kept round the camera

func build(center: Vector3, settings: Dictionary, weather_name := "still", span := Vector3(100, 0, 100)) -> void:
	weather = weather_name
	we = WorldEnvironment.new()
	env = Environment.new()
	var sky := Sky.new()
	var sm := ProceduralSkyMaterial.new()
	sm.sky_top_color = Color(0.03, 0.035, 0.06)
	sm.sky_horizon_color = Color(0.17, 0.15, 0.18)
	sm.sky_curve = 0.12
	sm.ground_bottom_color = Color(0.02, 0.02, 0.025)
	sm.ground_horizon_color = Color(0.16, 0.14, 0.16)
	sm.sun_angle_max = 12.0
	sm.sun_curve = 0.2
	sm.energy_multiplier = 1.0
	sky.sky_material = sm
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.3
	env.ambient_light_sky_contribution = 0.85
	env.ambient_light_color = Color(0.34, 0.38, 0.5)
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_AGX
	env.tonemap_exposure = 1.3
	env.tonemap_white = 6.0
	# soft distance fog with a cold tint, and true volumetric fog for light shafts
	env.fog_enabled = true
	env.fog_mode = Environment.FOG_MODE_EXPONENTIAL
	env.fog_light_color = Color(0.16, 0.15, 0.19)
	env.fog_light_energy = 0.7
	env.fog_density = 0.0042
	env.fog_sky_affect = 0.55
	env.fog_height = 6.0
	env.fog_height_density = 0.09
	env.fog_aerial_perspective = 0.25
	if settings.get("fog", true):
		env.volumetric_fog_enabled = true
		env.volumetric_fog_density = 0.011
		env.volumetric_fog_albedo = Color(0.55, 0.57, 0.62)
		env.volumetric_fog_emission = Color(0.008, 0.009, 0.013)
		env.volumetric_fog_anisotropy = 0.55
		env.volumetric_fog_length = 90.0
		env.volumetric_fog_detail_spread = 2.0
		env.volumetric_fog_ambient_inject = 0.15
		env.volumetric_fog_sky_affect = 0.2
		env.volumetric_fog_temporal_reprojection_enabled = true
		# wet stone: the cobbles mirror torches and fire
		env.ssr_enabled = true
		env.ssr_max_steps = 48
		env.ssr_fade_in = 0.2
		env.ssr_fade_out = 2.5
		env.ssr_depth_tolerance = 0.3
	if settings.get("ssao", true):
		env.ssao_enabled = true
		env.ssao_radius = 1.6
		env.ssao_intensity = 2.2
		env.ssao_power = 1.6
		env.ssao_detail = 0.6
	if settings.get("ssil", false):
		env.ssil_enabled = true
		env.ssil_radius = 4.0
		env.ssil_intensity = 0.8
	if settings.get("glow", true):
		env.glow_enabled = true
		env.glow_intensity = 0.55
		env.glow_strength = 1.0
		env.glow_bloom = 0.06
		env.glow_hdr_threshold = 0.9
		env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SCREEN
		env.set_glow_level(0, 0.0)
		env.set_glow_level(1, 1.0)
		env.set_glow_level(2, 1.0)
		env.set_glow_level(3, 0.5)
		env.set_glow_level(4, 0.0)
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.08
	env.adjustment_saturation = 0.82
	match weather:
		"rain":
			# lower cloud, a greyer murk, and everything a little darker and wetter
			env.fog_density = 0.0075
			env.fog_light_color = Color(0.15, 0.16, 0.19)
			env.volumetric_fog_density = 0.017
			env.ambient_light_energy = 0.26
			env.ssr_max_steps = 64
			env.adjustment_saturation = 0.74
			sm.sky_horizon_color = Color(0.12, 0.12, 0.15)
		"fog":
			# thick in the streets, thinner over the roofs, so the overhead view
			# still shows the lie of the ground
			env.fog_density = 0.013
			env.fog_light_color = Color(0.3, 0.31, 0.34)
			env.fog_light_energy = 0.9
			env.fog_height = 5.0
			env.fog_height_density = 0.11
			env.fog_sky_affect = 0.9
			env.volumetric_fog_density = 0.026
			env.volumetric_fog_albedo = Color(0.7, 0.72, 0.76)
			env.adjustment_saturation = 0.7
		"dawn":
			# grey-gold dawn through the ash: a warm low sun, a rose horizon, the
			# mist lit from behind so the light comes in shafts down the streets
			sm.sky_top_color = Color(0.13, 0.17, 0.29)
			sm.sky_horizon_color = Color(0.86, 0.5, 0.34)
			sm.ground_horizon_color = Color(0.5, 0.32, 0.27)
			sm.sky_curve = 0.18
			sm.sun_angle_max = 22.0
			sm.sun_curve = 0.12
			env.ambient_light_energy = 0.42
			env.ambient_light_color = Color(0.56, 0.48, 0.5)
			env.ambient_light_sky_contribution = 0.7
			env.tonemap_exposure = 1.15
			env.fog_light_color = Color(0.52, 0.4, 0.37)
			env.fog_light_energy = 0.85
			env.fog_density = 0.0048
			env.fog_sun_scatter = 0.35
			env.volumetric_fog_density = 0.014
			env.volumetric_fog_albedo = Color(0.82, 0.7, 0.62)
			env.volumetric_fog_anisotropy = 0.72
			env.adjustment_saturation = 0.92
	_amb_energy = env.ambient_light_energy
	we.environment = env
	add_child(we)

	# a cold low moon throwing long shadows
	moon = DirectionalLight3D.new()
	moon.light_color = Color(0.62, 0.7, 0.92)
	moon.light_energy = 0.55 if weather == "rain" else (0.6 if weather == "fog" else 0.85)
	if weather == "dawn":
		# the sun just clear of the ruins, long gold shadows across the square
		moon.light_color = Color(1.0, 0.7, 0.46)
		moon.light_energy = 1.55
		moon.light_volumetric_fog_energy = 2.2
		moon.rotation_degrees = Vector3(-11.0, 118.0, 0.0)
	_moon_energy = moon.light_energy
	moon.light_volumetric_fog_energy = 1.4
	moon.rotation_degrees = Vector3(-32.0, 205.0, 0.0)
	moon.shadow_enabled = settings.get("shadows", true)
	moon.shadow_blur = 1.2
	moon.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
	moon.directional_shadow_max_distance = 140.0
	moon.shadow_bias = 0.04
	moon.shadow_normal_bias = 1.2
	add_child(moon)
	# the rift's sickly glow from the other side
	var rift_light := DirectionalLight3D.new()
	rift_light.light_color = Color(0.45, 0.8, 0.75)
	rift_light.light_energy = 0.08 if weather == "dawn" else 0.18
	rift_light.light_volumetric_fog_energy = 0.6
	rift_light.rotation_degrees = Vector3(-18.0, 35.0, 0.0)
	rift_light.shadow_enabled = false
	add_child(rift_light)

	var rift := MeshInstance3D.new()
	var q := QuadMesh.new()
	q.size = Vector2(420, 120)
	rift.mesh = q
	var mat := ShaderMaterial.new()
	var sh := Shader.new()
	sh.code = RIFT_SHADER
	mat.shader = sh
	rift.material_override = mat
	rift.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var dir := Vector3(-0.55, 0.0, -0.84).normalized()
	rift.position = center + dir * 520.0 + Vector3(0, 230, 0)
	rift.look_at_from_position(rift.position, center + Vector3(0, 40, 0), Vector3.UP)
	rift.rotate_object_local(Vector3(0, 0, 1), 0.25)
	add_child(rift)

	_ash(center, 250 if weather == "rain" else 1400)
	if settings.get("fog", true) or weather == "fog":
		_ground_mist(center)
	if weather == "rain":
		_rain(center, span, settings)
		flash = DirectionalLight3D.new()
		flash.light_color = Color(0.78, 0.84, 1.0)
		flash.light_energy = 0.0
		flash.rotation_degrees = Vector3(-62.0, 150.0, 0.0)
		flash.shadow_enabled = settings.get("shadows", true)
		flash.directional_shadow_max_distance = 120.0
		flash.light_volumetric_fog_energy = 0.4
		add_child(flash)
		_loop("amb_rain", -3.0)

func _loop(nm: String, db: float) -> void:
	## A second ambient bed under the wind and fire, for the weather.
	if not Sfx.enabled or not ResourceLoader.exists("res://audio/%s.ogg" % nm):
		return
	var st: AudioStream = load("res://audio/%s.ogg" % nm)
	if st is AudioStreamOggVorbis:
		(st as AudioStreamOggVorbis).loop = true
	var p := AudioStreamPlayer.new()
	p.bus = "Ambience"
	p.stream = st
	p.volume_db = -40.0
	add_child(p)
	p.play()
	create_tween().tween_property(p, "volume_db", db, 2.5)

func _process(delta: float) -> void:
	if near_rain != null:
		var cam := get_viewport().get_camera_3d()
		if cam != null:
			var f := -cam.global_transform.basis.z
			near_rain.global_position = cam.global_position + Vector3(f.x, 0.0, f.z).normalized() * 6.0 + Vector3(0, 7.0, 0)
	if flash == null or calm:
		return
	_next_strike -= delta
	if _next_strike <= 0.0:
		_next_strike = randf_range(14.0, 34.0)
		strike(randf() < 0.65)

func strike(near: bool) -> void:
	## Lightning: two or three flickers, then the thunder, later the further off.
	if flash == null:
		return
	flash.rotation_degrees.y = randf_range(0.0, 360.0)
	var peak := 3.2 if near else 1.3
	var tw := create_tween()
	for i in range(2 + (randi() % 2)):
		tw.tween_property(flash, "light_energy", peak * randf_range(0.6, 1.0), 0.03)
		tw.parallel().tween_property(env, "ambient_light_energy", _amb_energy + peak * 0.25, 0.03)
		tw.tween_property(flash, "light_energy", 0.0, randf_range(0.05, 0.12))
		tw.parallel().tween_property(env, "ambient_light_energy", _amb_energy, 0.08)
		tw.tween_interval(randf_range(0.04, 0.14))
	var delay := randf_range(0.2, 0.7) if near else randf_range(1.6, 3.2)
	get_tree().create_timer(delay).timeout.connect(func():
		Sfx.play("thunder_%d" % (randi() % 2 if near else 2), null, -3.0 if near else -6.0, 0.08))

func light_up(energy := 2.6) -> void:
	## Screenshots: hold a lightning flash.
	if flash != null:
		flash.light_energy = energy
		env.ambient_light_energy = _amb_energy + energy * 0.25

func _rain(center: Vector3, span: Vector3, settings: Dictionary) -> void:
	## Streaks of rain that stop on roofs, walls and streets, each throwing up
	## a little splash where it lands.
	var half := Vector3(span.x * 0.5 + 12.0, 0.0, span.z * 0.5 + 12.0)
	var hf := GPUParticlesCollisionHeightField3D.new()
	hf.size = Vector3(half.x * 2.0, 60.0, half.z * 2.0)
	hf.resolution = GPUParticlesCollisionHeightField3D.RESOLUTION_1024
	hf.update_mode = GPUParticlesCollisionHeightField3D.UPDATE_MODE_WHEN_MOVED
	hf.position = Vector3(center.x, 20.0, center.z)
	add_child(hf)

	var splash := GPUParticles3D.new()
	splash.amount = 6000
	splash.lifetime = 0.32
	splash.emitting = false
	splash.visibility_aabb = AABB(Vector3(-half.x, -10, -half.z), Vector3(half.x * 2.0, 60, half.z * 2.0))
	var spm := ParticleProcessMaterial.new()
	spm.direction = Vector3(0, 1, 0)
	spm.spread = 55.0
	spm.initial_velocity_min = 0.6
	spm.initial_velocity_max = 1.6
	spm.gravity = Vector3(0, -9.0, 0)
	spm.scale_min = 0.5
	spm.scale_max = 1.2
	var fade := Gradient.new()
	fade.set_color(0, Color(1, 1, 1, 0.8))
	fade.set_color(1, Color(1, 1, 1, 0.0))
	var ft := GradientTexture1D.new()
	ft.gradient = fade
	spm.color_ramp = ft
	splash.process_material = spm
	var sq := QuadMesh.new()
	sq.size = Vector2(0.045, 0.045)
	var sqm := StandardMaterial3D.new()
	sqm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sqm.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	sqm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	sqm.vertex_color_use_as_albedo = true
	sqm.albedo_texture = CityBuilder._soft_dot()
	sqm.albedo_color = Color(0.78, 0.82, 0.9, 0.7)
	sq.material = sqm
	splash.draw_pass_1 = sq
	splash.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(splash)

	var p := GPUParticles3D.new()
	p.amount = 14000 if settings.get("fog", true) else 7000
	p.lifetime = 1.6
	p.preprocess = 2.0
	p.fixed_fps = 0
	p.visibility_aabb = AABB(Vector3(-half.x, -40, -half.z), Vector3(half.x * 2.0, 45, half.z * 2.0))
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(half.x, 1.0, half.z)
	pm.direction = Vector3(0.12, -1, 0.05)
	pm.spread = 2.0
	pm.initial_velocity_min = 19.0
	pm.initial_velocity_max = 24.0
	pm.gravity = Vector3(0.4, -6.0, 0.2)
	pm.collision_mode = ParticleProcessMaterial.COLLISION_HIDE_ON_CONTACT
	pm.collision_use_scale = false
	pm.sub_emitter_mode = ParticleProcessMaterial.SUB_EMITTER_AT_COLLISION
	pm.sub_emitter_amount_at_collision = 2
	p.process_material = pm
	var qm := QuadMesh.new()
	qm.size = Vector2(0.022, 0.75)
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.billboard_mode = BaseMaterial3D.BILLBOARD_FIXED_Y
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_color = Color(0.7, 0.76, 0.88, 0.32)
	m.albedo_texture = CityBuilder._soft_dot()
	qm.material = m
	p.draw_pass_1 = qm
	p.position = Vector3(center.x, 32.0, center.z)
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(p)
	p.sub_emitter = p.get_path_to(splash)
	# the far rain is thin on the ground; close to the eye it has to be thick
	near_rain = GPUParticles3D.new()
	near_rain.amount = 5000 if settings.get("fog", true) else 2500
	near_rain.lifetime = 0.8
	near_rain.preprocess = 1.0
	near_rain.local_coords = false
	near_rain.visibility_aabb = AABB(Vector3(-20, -30, -20), Vector3(40, 40, 40))
	var npm: ParticleProcessMaterial = pm.duplicate()
	npm.emission_box_extents = Vector3(13.0, 4.0, 13.0)
	npm.sub_emitter_amount_at_collision = 1
	near_rain.process_material = npm
	var nq: QuadMesh = qm.duplicate()
	nq.size = Vector2(0.012, 0.5)
	var nm: StandardMaterial3D = m.duplicate()
	nm.albedo_color = Color(0.75, 0.8, 0.9, 0.28)
	nq.material = nm
	near_rain.draw_pass_1 = nq
	near_rain.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	near_rain.position = Vector3(center.x, 7.0, center.z)
	add_child(near_rain)
	near_rain.sub_emitter = near_rain.get_path_to(splash)

func _ground_mist(center: Vector3) -> void:
	## A low cold mist that pools in the streets.
	var fv := FogVolume.new()
	fv.shape = RenderingServer.FOG_VOLUME_SHAPE_BOX
	fv.size = Vector3(140, 7.0, 140) if weather == "fog" else Vector3(140, 2.4, 140)
	fv.position = Vector3(center.x, 2.4 if weather == "fog" else 0.6, center.z)
	var fm := FogMaterial.new()
	fm.density = 0.15 if weather == "fog" else 0.07
	fm.albedo = Color(0.62, 0.64, 0.7)
	fm.edge_fade = 0.6
	var nt := NoiseTexture3D.new()
	var fn := FastNoiseLite.new()
	fn.frequency = 0.045
	nt.noise = fn
	nt.width = 64
	nt.height = 16
	nt.depth = 64
	fm.density_texture = nt
	fv.material = fm
	add_child(fv)

func _ash(center: Vector3, amount := 1400) -> void:
	var p := GPUParticles3D.new()
	p.amount = amount
	p.lifetime = 14.0
	p.preprocess = 14.0
	p.visibility_aabb = AABB(Vector3(-60, -5, -60), Vector3(120, 50, 120))
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(55, 1, 55)
	pm.direction = Vector3(0.3, -1, 0.1)
	pm.spread = 20.0
	pm.initial_velocity_min = 0.6
	pm.initial_velocity_max = 1.4
	pm.gravity = Vector3(0.15, -0.6, 0.05)
	pm.turbulence_enabled = true
	pm.turbulence_noise_strength = 0.4
	pm.turbulence_noise_scale = 6.0
	pm.scale_min = 0.6
	pm.scale_max = 1.4
	p.process_material = pm
	var qm := QuadMesh.new()
	qm.size = Vector2(0.06, 0.06)
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_texture = CityBuilder._soft_dot()
	m.albedo_color = Color(0.62, 0.6, 0.6, 0.7)
	qm.material = m
	p.draw_pass_1 = qm
	p.position = center + Vector3(0, 30, 0)
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(p)
