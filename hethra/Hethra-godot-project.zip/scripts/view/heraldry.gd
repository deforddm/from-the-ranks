class_name Heraldry
## The marks a warband can fly on its banners, and the colours to fly them
## in: the same device drawn on cloth in 3D (a shader) and on the camp's
## pages and the city map (2D).

const DEVICES := ["Diamond", "Crescent", "Star", "Ring", "Chevron", "Saltire", "Tower"]

## GLSL: 1.0 inside device dev, for a point q measured from the device's
## centre (y runs down the cloth); the device spans about 0.16 each way.
const GLSL := """
float device_mask(vec2 q, int dev) {
	float r = length(q);
	if (dev == 1) {
		return step(r, 0.15) * (1.0 - step(length(q - vec2(0.07, -0.03)), 0.125));
	}
	if (dev == 2) {
		float a = atan(q.y, q.x) + 1.5708;
		float k = 0.065 + 0.095 * pow(0.5 + 0.5 * cos(5.0 * a), 3.0);
		return step(r, k);
	}
	if (dev == 3) {
		return step(abs(r - 0.11), 0.035);
	}
	if (dev == 4) {
		float y = q.y + abs(q.x) * 0.9;
		return step(abs(y + 0.02), 0.045) * step(abs(q.x), 0.16);
	}
	if (dev == 5) {
		return step(abs(abs(q.x) - abs(q.y)), 0.035) * step(max(abs(q.x), abs(q.y)), 0.15);
	}
	if (dev == 6) {
		float body = step(abs(q.x), 0.08) * step(-0.07, q.y) * step(q.y, 0.15);
		float teeth = step(abs(q.x), 0.1) * step(-0.13, q.y) * step(q.y, -0.07) * step(0.5, fract((q.x + 0.1) / 0.067));
		float door = step(abs(q.x), 0.028) * step(0.07, q.y);
		return clamp(body + teeth - door, 0.0, 1.0);
	}
	return step(abs(q.x) + abs(q.y), 0.16);
}
"""

static func colours() -> Array:
	return Campaign.data().get("heraldry_colours", [])

static func draw_device(ci: CanvasItem, at: Vector2, r: float, dev: int, col: Color, bg: Color) -> void:
	## The device in 2D, about r pixels from its centre to its edge.
	match dev:
		1:
			ci.draw_circle(at, r * 0.94, col)
			ci.draw_circle(at + Vector2(r * 0.44, -r * 0.19), r * 0.78, bg)
		2:
			var pts := PackedVector2Array()
			for i in range(10):
				var a := -PI * 0.5 + i * PI / 5.0
				var rr := r if i % 2 == 0 else r * 0.42
				pts.append(at + Vector2(cos(a), sin(a)) * rr)
			ci.draw_colored_polygon(pts, col)
		3:
			ci.draw_arc(at, r * 0.69, 0.0, TAU, 32, col, r * 0.44, true)
		4:
			var w := r * 0.32
			ci.draw_colored_polygon(PackedVector2Array([at + Vector2(-r, r * 0.75), at + Vector2(0, -r * 0.15), at + Vector2(r, r * 0.75),
				at + Vector2(r, r * 0.75 - w * 1.6), at + Vector2(0, -r * 0.15 - w * 1.6), at + Vector2(-r, r * 0.75 - w * 1.6)]), col)
		5:
			ci.draw_line(at + Vector2(-r, -r) * 0.9, at + Vector2(r, r) * 0.9, col, r * 0.42)
			ci.draw_line(at + Vector2(r, -r) * 0.9, at + Vector2(-r, r) * 0.9, col, r * 0.42)
		6:
			ci.draw_rect(Rect2(at + Vector2(-r * 0.5, -r * 0.44), Vector2(r, r * 1.38)), col)
			for i in range(3):
				ci.draw_rect(Rect2(at + Vector2(-r * 0.62 + i * r * 0.46, -r * 0.82), Vector2(r * 0.3, r * 0.4)), col)
			ci.draw_rect(Rect2(at + Vector2(-r * 0.17, r * 0.44), Vector2(r * 0.34, r * 0.5)), bg)
		_:
			ci.draw_colored_polygon(PackedVector2Array([at + Vector2(0, -r), at + Vector2(r, 0), at + Vector2(0, r), at + Vector2(-r, 0)]), col)
