class_name Figure
extends Node3D
## A fighter on the battlefield: a figure assembled from simple shapes on a
## round base, dressed by body type, helm and gear, coloured by warband.
## These are placeholders until real character art exists.

var unit_id: int = -1
var side: int = 0
var body: Node3D
var leg_l: Node3D
var leg_r: Node3D
var arm_l: Node3D
var arm_r: Node3D
var ring: MeshInstance3D
var label: Label3D
var stars: Node3D
var xray: MeshInstance3D
var moving := false
var _walk_t := 0.0
var _status := "ok"
var _fade := 1.0
var cloth: Color
var trim: Color

static var _font: Font

static func font() -> Font:
	if _font == null:
		_font = load("res://fonts/AlegreyaSans-Bold.ttf")
	return _font

func _mat(c: Color, rough := 0.85, metal := 0.0, rim := 0.35) -> StandardMaterial3D:
	var key := "fig|%s|%.2f|%.2f|%.2f" % [c.to_html(), rough, metal, rim]
	if Mats._cache.has(key):
		return Mats._cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	m.rim_enabled = rim > 0.0
	m.rim = rim
	m.rim_tint = 0.4
	Mats._cache[key] = m
	return m

func _part(parent: Node3D, mesh: Mesh, mat: Material, pos: Vector3, rot := Vector3.ZERO, scl := Vector3.ONE) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	mi.scale = scl
	parent.add_child(mi)
	return mi

func _box(parent: Node3D, size: Vector3, mat: Material, pos: Vector3, rot := Vector3.ZERO) -> MeshInstance3D:
	var m := BoxMesh.new()
	m.size = size
	return _part(parent, m, mat, pos, rot)

func _cyl(parent: Node3D, r0: float, r1: float, h: float, mat: Material, pos: Vector3, rot := Vector3.ZERO, segs := 12) -> MeshInstance3D:
	var m := CylinderMesh.new()
	m.bottom_radius = r0
	m.top_radius = r1
	m.height = h
	m.radial_segments = segs
	m.rings = 1
	return _part(parent, m, mat, pos, rot)

func _sphere(parent: Node3D, r: float, mat: Material, pos: Vector3, scl := Vector3.ONE) -> MeshInstance3D:
	var m := SphereMesh.new()
	m.radius = r
	m.height = r * 2.0
	m.radial_segments = 16
	m.rings = 8
	return _part(parent, m, mat, pos, Vector3.ZERO, scl)

func _capsule(parent: Node3D, r: float, h: float, mat: Material, pos: Vector3, rot := Vector3.ZERO) -> MeshInstance3D:
	var m := CapsuleMesh.new()
	m.radius = r
	m.height = h
	m.radial_segments = 12
	m.rings = 4
	return _part(parent, m, mat, pos, rot)

func setup(u: BUnit, wb: Dictionary) -> void:
	unit_id = u.id
	side = u.side
	var col: Array = wb.get("color", [0.5, 0.5, 0.5])
	var tr: Array = wb.get("trim", [0.8, 0.8, 0.7])
	cloth = Color(col[0], col[1], col[2])
	trim = Color(tr[0], tr[1], tr[2])
	var rng := RandomNumberGenerator.new()
	rng.seed = u.id * 7919
	var skins := [Color(0.55, 0.4, 0.3), Color(0.42, 0.3, 0.22), Color(0.66, 0.5, 0.4), Color(0.3, 0.21, 0.16), Color(0.6, 0.47, 0.37)]
	var skin: Color = skins[rng.randi() % skins.size()]
	if u.body == "wretch":
		skin = Color(0.5, 0.48, 0.45)
	var m_cloth := _mat(cloth)
	var m_dark := _mat(cloth.darkened(0.45))
	var m_trim := _mat(trim, 0.6, 0.2)
	var m_skin := _mat(skin, 0.7)
	var m_leather := _mat(Color(0.2, 0.13, 0.08), 0.8)
	var m_iron := _mat(Color(0.42, 0.42, 0.44), 0.35, 0.85, 0.2)
	var m_sand := _mat(Color(0.62, 0.52, 0.38))
	var m_boot := _mat(Color(0.09, 0.07, 0.06), 0.8)

	# round base, like a tabletop miniature
	var base := Node3D.new()
	add_child(base)
	_cyl(base, 0.44, 0.42, 0.06, _mat(Color(0.08, 0.08, 0.09), 0.7, 0.0, 0.0), Vector3(0, 0.03, 0), Vector3.ZERO, 24)
	var tm := TorusMesh.new()
	tm.inner_radius = 0.4
	tm.outer_radius = 0.46
	tm.rings = 24
	var rim_mat := Mats.glow(cloth.lightened(0.15), 0.9)
	_part(base, tm, rim_mat, Vector3(0, 0.05, 0))
	var sel := TorusMesh.new()
	sel.inner_radius = 0.5
	sel.outer_radius = 0.6
	sel.rings = 32
	ring = _part(self, sel, Mats.glow(Color(0.3, 1.0, 0.85), 3.0, true), Vector3(0, 0.04, 0))
	ring.visible = false
	ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	body = Node3D.new()
	add_child(body)
	var hip_y := 0.92
	var bulk := 1.0
	var hunch := 0.0
	match u.body:
		"brute":
			bulk = 1.22
		"heavy":
			bulk = 1.12
		"wretch":
			bulk = 0.85
			hunch = 0.38
			hip_y = 0.85
	# legs
	leg_l = Node3D.new()
	leg_r = Node3D.new()
	leg_l.position = Vector3(-0.11 * bulk, hip_y, 0)
	leg_r.position = Vector3(0.11 * bulk, hip_y, 0)
	body.add_child(leg_l)
	body.add_child(leg_r)
	var leg_mat := m_dark
	if u.body == "heavy":
		leg_mat = m_iron
	elif u.body == "light":
		leg_mat = m_sand
	elif u.body == "brute":
		leg_mat = m_leather
	for leg in [leg_l, leg_r]:
		_capsule(leg, 0.085 * bulk, hip_y + 0.05, leg_mat, Vector3(0, -hip_y * 0.5, 0))
		_box(leg, Vector3(0.15, 0.12, 0.26) * bulk, m_boot, Vector3(0, -hip_y + 0.08, 0.04))
	# torso
	var torso := Node3D.new()
	torso.position = Vector3(0, hip_y, 0)
	torso.rotation.x = hunch
	body.add_child(torso)
	var tw := 0.44 * bulk
	match u.body:
		"soldier":
			_box(torso, Vector3(tw, 0.6, 0.27), _mat(Color(0.35, 0.36, 0.38), 0.5, 0.6), Vector3(0, 0.3, 0))   # mail
			_box(torso, Vector3(tw + 0.02, 0.5, 0.29), m_cloth, Vector3(0, 0.25, 0.0))                          # tabard
			_box(torso, Vector3(tw + 0.04, 0.07, 0.3), m_leather, Vector3(0, 0.05, 0))                          # belt
			_box(torso, Vector3(tw * 0.9, 0.9, 0.04), m_dark, Vector3(0, 0.05, -0.17), Vector3(0.12, 0, 0))     # cloak
		"heavy":
			_box(torso, Vector3(tw, 0.62, 0.32), m_iron, Vector3(0, 0.31, 0))
			_box(torso, Vector3(tw * 0.6, 0.55, 0.05), m_cloth, Vector3(0, 0.15, 0.17))
			_sphere(torso, 0.15, m_iron, Vector3(-tw * 0.55, 0.56, 0), Vector3(1.1, 0.8, 1.1))
			_sphere(torso, 0.15, m_iron, Vector3(tw * 0.55, 0.56, 0), Vector3(1.1, 0.8, 1.1))
			_box(torso, Vector3(tw * 0.95, 0.85, 0.04), m_cloth, Vector3(0, 0.05, -0.19), Vector3(0.1, 0, 0))
		"robe":
			_box(torso, Vector3(tw, 0.6, 0.26), m_cloth, Vector3(0, 0.3, 0))
			_box(torso, Vector3(0.08, 0.6, 0.27), m_trim, Vector3(0, 0.3, 0.01))
			_cyl(torso, 0.34, 0.22, hip_y - 0.02, m_dark, Vector3(0, -hip_y * 0.5 + 0.02, 0))           # robe skirt
		"brute":
			_box(torso, Vector3(tw, 0.64, 0.36), m_skin, Vector3(0, 0.32, 0))
			_box(torso, Vector3(0.1, 0.8, 0.38), m_leather, Vector3(0, 0.32, 0), Vector3(0, 0, 0.6))     # strap
			_box(torso, Vector3(tw + 0.04, 0.12, 0.38), m_leather, Vector3(0, 0.05, 0))
			_cyl(torso, 0.3, 0.26, 0.4, m_cloth, Vector3(0, -0.15, 0))                                     # kilt
			for i in range(4):
				_box(torso, Vector3(0.05, 0.05, 0.05), m_iron, Vector3(-0.15 + i * 0.1, 0.62, 0.17))
		"wretch":
			_box(torso, Vector3(tw, 0.55, 0.24), m_skin, Vector3(0, 0.28, 0))
			_cyl(torso, 0.27, 0.2, 0.55, m_dark, Vector3(0, -0.05, 0))
			_box(torso, Vector3(tw + 0.04, 0.5, 0.05), m_dark, Vector3(0, 0.25, 0.12), Vector3(-0.1, 0, 0.1))
		_:  # light, desert
			_box(torso, Vector3(tw, 0.6, 0.26), m_sand, Vector3(0, 0.3, 0))
			_box(torso, Vector3(tw + 0.03, 0.1, 0.28), m_cloth, Vector3(0, 0.08, 0))                         # sash
			_box(torso, Vector3(0.1, 0.62, 0.28), m_cloth, Vector3(0.08, 0.3, 0.0), Vector3(0, 0, 0.5))
			_cyl(torso, 0.28, 0.24, 0.35, m_sand, Vector3(0, -0.12, 0))
	# arms
	arm_l = Node3D.new()
	arm_r = Node3D.new()
	arm_l.position = Vector3(-tw * 0.5 - 0.07, 0.55, 0)
	arm_r.position = Vector3(tw * 0.5 + 0.07, 0.55, 0)
	torso.add_child(arm_l)
	torso.add_child(arm_r)
	var sleeve := m_skin if u.body == "brute" or u.body == "wretch" else (m_iron if u.body == "heavy" else (m_sand if u.body == "light" else m_cloth))
	for arm in [arm_l, arm_r]:
		_capsule(arm, 0.07 * bulk, 0.62, sleeve, Vector3(0, -0.28, 0))
		_sphere(arm, 0.06, m_skin, Vector3(0, -0.6, 0))
	arm_r.rotation = Vector3(-0.45, 0, 0.08)
	arm_l.rotation = Vector3(-0.2, 0, -0.08)
	# head and helm
	var head := Node3D.new()
	head.position = Vector3(0, 0.78, 0.02)
	torso.add_child(head)
	_capsule(head, 0.06, 0.2, m_skin, Vector3(0, -0.1, 0))
	_sphere(head, 0.115, m_skin, Vector3(0, 0.04, 0), Vector3(0.95, 1.08, 1.0))
	match u.helm:
		"kettle":
			_cyl(head, 0.13, 0.11, 0.12, m_iron, Vector3(0, 0.14, 0))
			_cyl(head, 0.24, 0.24, 0.02, m_iron, Vector3(0, 0.09, 0), Vector3.ZERO, 16)
		"great":
			_cyl(head, 0.145, 0.14, 0.32, m_iron, Vector3(0, 0.06, 0))
			_box(head, Vector3(0.2, 0.025, 0.02), _mat(Color(0.02, 0.02, 0.02)), Vector3(0, 0.07, 0.14))
			_box(head, Vector3(0.03, 0.12, 0.06), m_trim, Vector3(0, 0.25, 0))
		"cap":
			_sphere(head, 0.125, m_leather, Vector3(0, 0.08, 0), Vector3(1, 0.65, 1))
		"hood":
			_sphere(head, 0.16, m_dark, Vector3(0, 0.07, -0.03), Vector3(1, 1.1, 1.05))
			_cyl(head, 0.12, 0.0, 0.22, m_dark, Vector3(0, 0.2, -0.1), Vector3(-0.7, 0, 0))
			_box(head, Vector3(0.16, 0.2, 0.02), _mat(Color(0.03, 0.03, 0.03)), Vector3(0, 0.02, 0.13))
		"mask":
			_box(head, Vector3(0.2, 0.24, 0.05), _mat(Color(0.78, 0.74, 0.66), 0.5), Vector3(0, 0.03, 0.11))
			_box(head, Vector3(0.05, 0.025, 0.02), _mat(Color(0.02, 0.02, 0.02)), Vector3(-0.045, 0.06, 0.14))
			_box(head, Vector3(0.05, 0.025, 0.02), _mat(Color(0.02, 0.02, 0.02)), Vector3(0.045, 0.06, 0.14))
			for i in range(3):
				_cyl(head, 0.012, 0.012, 0.3, m_iron, Vector3(-0.08 + i * 0.08, -0.12, 0.12), Vector3(0.1, 0, 0), 5)
		"wrap":
			_sphere(head, 0.13, m_cloth, Vector3(0, 0.08, -0.01), Vector3(1.05, 0.9, 1.05))
			_box(head, Vector3(0.21, 0.1, 0.05), m_cloth, Vector3(0, -0.04, 0.09))
			_box(head, Vector3(0.12, 0.3, 0.03), m_cloth, Vector3(0, -0.05, -0.12), Vector3(0.3, 0, 0))
		_:
			_sphere(head, 0.118, _mat(Color(0.08, 0.06, 0.05)), Vector3(0, 0.08, -0.02), Vector3(1, 0.7, 1))
	# weapons and kit
	var melee := u.best_melee_weapon()
	var missile := u.missile()
	var hand := Node3D.new()
	hand.position = Vector3(0, -0.6, 0.02)
	arm_r.add_child(hand)
	var lhand := Node3D.new()
	lhand.position = Vector3(0, -0.6, 0.02)
	arm_l.add_child(lhand)
	var bow_in_hand := missile != "" and (melee == "dagger" or melee == "fist" or melee == "")
	_weapon(hand, melee if not bow_in_hand else "dagger", m_iron, m_leather, m_trim)
	if u.dual_wield():
		_weapon(lhand, melee, m_iron, m_leather, m_trim)
	if u.gear.has("shield"):
		var sh := _cyl(lhand, 0.3, 0.3, 0.05, m_cloth, Vector3(-0.08, 0.12, 0.05), Vector3(0, 0, PI * 0.5), 18)
		_cyl(sh, 0.08, 0.08, 0.07, m_iron, Vector3.ZERO, Vector3.ZERO, 10)
		var rimt := TorusMesh.new()
		rimt.inner_radius = 0.27
		rimt.outer_radius = 0.31
		_part(sh, rimt, m_trim, Vector3.ZERO)
	if missile != "":
		if bow_in_hand:
			_missile(lhand, missile, m_leather, m_iron)
			arm_l.rotation = Vector3(-0.7, 0.2, -0.1)
		else:
			var back := Node3D.new()
			back.position = Vector3(0, 0.35, -0.2)
			back.rotation = Vector3(0, 0, 0.7)
			torso.add_child(back)
			_missile(back, missile, m_leather, m_iron)
	if not u.spells.is_empty():
		# a staff and a faint glow of warren power
		_cyl(lhand, 0.025, 0.02, 1.7, m_leather, Vector3(0, 0.3, 0), Vector3.ZERO, 6)
		var gl := Mats.glow(_warren_color(u.warren), 4.0)
		_sphere(lhand, 0.06, gl, Vector3(0, 1.18, 0))
		arm_l.rotation = Vector3(-0.5, 0, -0.15)
	if u.has_munitions():
		for i in range(2):
			_sphere(torso, 0.055, _mat(Color(0.5, 0.42, 0.3), 0.6), Vector3(-0.12 + i * 0.1, 0.05, 0.17))
	if u.is_leader():
		var plume := _box(head, Vector3(0.04, 0.18, 0.2), m_trim, Vector3(0, 0.27, -0.02))
		plume.rotation.x = -0.2

	# floating name
	label = Label3D.new()
	label.text = u.name
	label.font = font()
	label.font_size = 26
	label.outline_size = 8
	label.outline_modulate = Color(0, 0, 0, 0.85)
	label.modulate = cloth.lightened(0.55)
	label.pixel_size = 0.0008
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.no_depth_test = true
	label.fixed_size = true
	label.position = Vector3(0, 2.25, 0)
	label.render_priority = 5
	label.visibility_range_end = 34.0
	label.visibility_range_end_margin = 6.0
	label.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_SELF
	# silhouette shown only where walls hide the figure
	var xm := ShaderMaterial.new()
	xm.shader = load("res://shaders/xray.gdshader")
	xm.set_shader_parameter("tint", Color(cloth.lightened(0.3), 0.32))
	xm.render_priority = 2
	var xc := CapsuleMesh.new()
	xc.radius = 0.42
	xc.height = 2.0
	xc.radial_segments = 12
	xc.rings = 4
	xray = _part(self, xc, xm, Vector3(0, 1.0, 0))
	xray.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	xray.visible = false
	add_child(label)

	stars = Node3D.new()
	stars.position = Vector3(0, 0.6, 0)
	stars.visible = false
	add_child(stars)
	for i in range(4):
		var st := _sphere(stars, 0.05, Mats.glow(Color(1.0, 0.85, 0.4), 4.0), Vector3(cos(i * PI * 0.5) * 0.35, 0, sin(i * PI * 0.5) * 0.35))
		st.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

func _warren_color(w: String) -> Color:
	match w:
		"meanas":
			return Color(0.55, 0.45, 1.0)
		"denul":
			return Color(0.5, 1.0, 0.6)
		"serc":
			return Color(0.6, 0.85, 1.0)
		"dryjhna":
			return Color(1.0, 0.75, 0.35)
		"chains":
			return Color(1.0, 0.3, 0.25)
	return Color(0.8, 0.8, 1.0)

func _weapon(h: Node3D, w: String, m_iron: Material, m_leather: Material, m_trim: Material) -> void:
	match w:
		"sword", "tulwar":
			_cyl(h, 0.02, 0.02, 0.14, m_leather, Vector3(0, 0, 0), Vector3(PI * 0.5, 0, 0), 6)
			_box(h, Vector3(0.18, 0.03, 0.04), m_trim, Vector3(0, 0, 0.08))
			var blade := _box(h, Vector3(0.05, 0.012, 0.7), m_iron, Vector3(0, 0, 0.44))
			if w == "tulwar":
				blade.rotation.x = 0.12
				blade.scale = Vector3(1.4, 1, 1)
		"dagger":
			_box(h, Vector3(0.035, 0.012, 0.26), m_iron, Vector3(0, 0, 0.14))
		"axe":
			_cyl(h, 0.022, 0.022, 0.6, m_leather, Vector3(0, 0, 0.22), Vector3(PI * 0.5, 0, 0), 6)
			_box(h, Vector3(0.03, 0.2, 0.14), m_iron, Vector3(0, 0.08, 0.48))
		"mace":
			_cyl(h, 0.022, 0.022, 0.55, m_leather, Vector3(0, 0, 0.2), Vector3(PI * 0.5, 0, 0), 6)
			_sphere(h, 0.08, m_iron, Vector3(0, 0, 0.48))
		"spear":
			_cyl(h, 0.022, 0.022, 2.1, m_leather, Vector3(0, 0, 0.45), Vector3(PI * 0.5, 0, 0), 6)
			_cyl(h, 0.04, 0.0, 0.25, m_iron, Vector3(0, 0, 1.6), Vector3(PI * 0.5, 0, 0), 6)
		"greatblade":
			_box(h, Vector3(0.07, 0.015, 1.2), m_iron, Vector3(0, 0, 0.7))
			_box(h, Vector3(0.26, 0.04, 0.05), m_trim, Vector3(0, 0, 0.08))
		"chainflail":
			_cyl(h, 0.025, 0.025, 0.45, m_leather, Vector3(0, 0, 0.15), Vector3(PI * 0.5, 0, 0), 6)
			for i in range(4):
				_box(h, Vector3(0.03, 0.03, 0.06), m_iron, Vector3(0, -0.05 * i, 0.4 + 0.04 * i))
			var ball := _sphere(h, 0.1, m_iron, Vector3(0, -0.25, 0.55))
			for i in range(6):
				var d := Vector3(cos(i * 1.05), sin(i * 1.7), sin(i * 1.05)).normalized()
				_cyl(ball, 0.025, 0.0, 0.09, m_iron, d * 0.09, Basis.looking_at(d).get_euler() + Vector3(PI * 0.5, 0, 0), 4)
		_:
			pass

func _missile(h: Node3D, w: String, m_leather: Material, m_iron: Material) -> void:
	match w:
		"crossbow":
			_box(h, Vector3(0.06, 0.06, 0.6), m_leather, Vector3(0, 0, 0.2))
			_box(h, Vector3(0.62, 0.03, 0.04), m_iron, Vector3(0, 0, 0.45))
		"shortbow", "longbow":
			var l := 1.0 if w == "shortbow" else 1.4
			for s in [-1.0, 1.0]:
				_box(h, Vector3(0.03, l * 0.5, 0.03), m_leather, Vector3(0, s * l * 0.24, 0.05 - abs(s) * 0.02), Vector3(s * 0.22, 0, 0))
			_box(h, Vector3(0.005, l * 0.92, 0.005), _mat(Color(0.8, 0.78, 0.7)), Vector3(0, 0, -0.06))
		"sling":
			_box(h, Vector3(0.02, 0.35, 0.02), m_leather, Vector3(0, -0.15, 0.02))
			_sphere(h, 0.04, m_leather, Vector3(0, -0.33, 0.02))
		"knives":
			for i in range(3):
				_box(h, Vector3(0.025, 0.01, 0.18), m_iron, Vector3(-0.04 + i * 0.04, 0.2, 0.0))

func set_selected(kind: String) -> void:
	## kind: "", "active", "target", "ally"
	ring.visible = kind != ""
	var c := Color(0.3, 1.0, 0.85)
	if kind == "target":
		c = Color(1.0, 0.3, 0.2)
	elif kind == "ally":
		c = Color(0.9, 0.85, 0.5)
	ring.material_override = Mats.glow(c, 3.0, true)

func set_status(s: String) -> void:
	_status = s
	stars.visible = s == "stunned"
	var tw := create_tween()
	match s:
		"ok":
			tw.tween_property(body, "rotation", Vector3.ZERO, 0.35)
			tw.parallel().tween_property(body, "position", Vector3.ZERO, 0.35)
		"down", "stunned":
			tw.tween_property(body, "rotation", Vector3(-PI * 0.47, 0, 0.1), 0.35).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
			tw.parallel().tween_property(body, "position", Vector3(0, 0.18, 0.15), 0.35)
		"ooa":
			tw.tween_property(body, "rotation", Vector3(PI * 0.47, 0, -0.2), 0.4).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
			tw.parallel().tween_property(body, "position", Vector3(0, 0.12, -0.15), 0.4)
			tw.tween_interval(0.9)
			tw.tween_property(self, "scale", Vector3(1, 0.01, 1), 0.5)
			tw.tween_callback(func(): visible = false)

func face_point(p: Vector3) -> void:
	var d := p - global_position
	d.y = 0
	if d.length() > 0.05:
		rotation.y = atan2(d.x, d.z)

func lunge(at: Vector3) -> Tween:
	face_point(at)
	var tw := create_tween()
	var fwd := (at - global_position)
	fwd.y = 0
	fwd = fwd.normalized() * 0.35
	tw.tween_property(arm_r, "rotation", Vector3(-2.3, 0, 0.1), 0.12)
	tw.parallel().tween_property(body, "position", fwd.rotated(Vector3.UP, -rotation.y), 0.12)
	tw.tween_property(arm_r, "rotation", Vector3(0.3, 0, 0.08), 0.12)
	tw.tween_property(arm_r, "rotation", Vector3(-0.45, 0, 0.08), 0.2)
	tw.parallel().tween_property(body, "position", Vector3.ZERO, 0.2)
	return tw

func flinch() -> void:
	if _status != "ok":
		return
	var tw := create_tween()
	tw.tween_property(body, "rotation", Vector3(0.25, 0, 0.1), 0.08)
	tw.tween_property(body, "rotation", Vector3.ZERO, 0.25)

func aim(at: Vector3) -> void:
	face_point(at)
	var tw := create_tween()
	tw.tween_property(arm_r, "rotation", Vector3(-1.5, 0, 0.0), 0.15)
	tw.tween_property(arm_l, "rotation", Vector3(-1.4, 0.3, 0.0), 0.1)
	tw.tween_interval(0.35)
	tw.tween_property(arm_r, "rotation", Vector3(-0.45, 0, 0.08), 0.25)
	tw.parallel().tween_property(arm_l, "rotation", Vector3(-0.2, 0, -0.08), 0.25)

func _process(delta: float) -> void:
	if moving:
		_walk_t += delta * 9.0
		var sw := sin(_walk_t) * 0.6
		leg_l.rotation.x = sw
		leg_r.rotation.x = -sw
		body.position.y = abs(cos(_walk_t)) * 0.05
	elif leg_l.rotation.x != 0.0 and _status == "ok":
		leg_l.rotation.x = lerp(leg_l.rotation.x, 0.0, delta * 10.0)
		leg_r.rotation.x = lerp(leg_r.rotation.x, 0.0, delta * 10.0)
	if stars.visible:
		stars.rotation.y += delta * 3.0
