class_name Figure
extends Node3D
## A fighter on the battlefield, on a round base like a tabletop miniature.
## The body is built in code from smooth lofted shapes on a jointed skeleton
## (hips, spine, neck, shoulders, elbows, knees, ankles), dressed by body type,
## helm and gear, coloured by warband, and animated procedurally: breathing and
## weight shifts at rest, a real walk cycle, climbing, leaping, weapon-specific
## blows, drawing a bow, throwing, casting, flinching and falling.

var unit_id: int = -1
var side: int = 0
var body: Node3D          # whole figure; status falls tween this
var root: Node3D          # the pelvis; bobs and sways
var J := {}               # joint name -> Node3D
var ring: MeshInstance3D
var team_ring: MeshInstance3D
var base_node: Node3D
var rival_ring: MeshInstance3D
var watch_mark: Node3D
var hide_mark: Node3D           # an amber ring and a word: this fighter is on watch
static var water_y := -100.0   # height of flood water on this battlefield, if any
var label: Label3D
var stars: Node3D
var xray: MeshInstance3D
var moving := false
var motion := "walk"      # walk, climb, air: set by the battle while moving
var cloth: Color
var trim: Color

var _walk_t := 0.0
var _walk_w := 0.0
var _time := 0.0
var _phase := 0.0
var _status := "ok"
var _lie_w := 0.0
var _base := {}           # the stance at rest
var _aim_pose := {}
var _strike := "slash"    # slash, thrust, cleave, stab, flail
var _act_keys: Array = []
var _act_t := 0.0
var _act_dur := 0.0
var _act_end: Callable
var _cloak: Node3D
var _panel_f: Node3D
var _panel_b: Node3D
var _hand_items: Array = []   # melee items to hide while aiming
var _aim_item: Node3D
var _back_item: Node3D
var _hip_y := 0.92
var _dust := false        # one of the Kin of the Dust: crumbles when it falls for good
var _rip_t := 0.0
static var _ripple_mat: ShaderMaterial
static var _ripple_mesh: PlaneMesh

const JOINTS := ["root", "spine", "neck", "head", "sh_l", "el_l", "sh_r", "el_r",
	"hip_l", "kn_l", "ft_l", "hip_r", "kn_r", "ft_r"]

static var _font: Font
static var _meshes := {}

static func font() -> Font:
	if _font == null:
		_font = load("res://fonts/AlegreyaSans-Bold.ttf")
	return _font

# ------------------------------------------------------------------ materials

const SURF_SCALE := {"cloth": 7.0, "mail": 5.5, "leather": 3.0, "metal": 2.2, "skin": 4.0, "hair": 5.0}
const SURF_NORMAL := {"cloth": 0.45, "mail": 1.5, "leather": 0.8, "metal": 0.6, "skin": 0.35, "hair": 0.9}
static var hi_detail := true   # surface textures on the figures (off on the Fast setting)

func _mat(c: Color, rough := 0.85, metal := 0.0, rim := 0.35, two_sided := false, kind := "") -> StandardMaterial3D:
	if not hi_detail:
		kind = ""
	var key := "fig|%s|%.2f|%.2f|%.2f|%s|%s" % [c.to_html(), rough, metal, rim, two_sided, kind]
	if Mats._cache.has(key):
		return Mats._cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	if kind != "":
		# a fine surface (weave, rings, grain, scratches) in the part's own
		# space, so it moves with the limb and needs no UVs
		m.albedo_texture = Mats._tex("fig_%s_albedo" % kind)
		m.normal_enabled = true
		m.normal_texture = Mats._tex("fig_%s_normal" % kind)
		m.normal_scale = SURF_NORMAL[kind]
		m.roughness_texture = Mats._tex("fig_%s_rough" % kind)
		m.roughness_texture_channel = BaseMaterial3D.TEXTURE_CHANNEL_GRAYSCALE
		m.roughness = minf(1.0, rough * 1.08)
		m.uv1_triplanar = true
		m.uv1_triplanar_sharpness = 3.0
		var sc: float = SURF_SCALE[kind]
		m.uv1_scale = Vector3(sc, sc, sc)
		m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	m.rim_enabled = rim > 0.0
	m.rim = rim
	m.rim_tint = 0.4
	if two_sided:
		m.cull_mode = BaseMaterial3D.CULL_DISABLED
	Mats._cache[key] = m
	return m

# ------------------------------------------------------------------ meshes

static func _tri(st: SurfaceTool, p: Array, n: Array, outward: Vector3) -> void:
	## Adds a triangle wound so that its front faces along `outward`.
	var order := [0, 1, 2]
	if (p[1] - p[0]).cross(p[2] - p[0]).dot(outward) > 0.0:
		order = [0, 2, 1]
	for i in order:
		st.set_normal(n[i])
		st.add_vertex(p[i])

static func loft(key: String, rings: Array, segs := 12) -> ArrayMesh:
	## A smooth closed tube through elliptical rings stacked along Y.
	## Each ring is [y, radius_x, radius_z, (z_offset), (x_offset)].
	if _meshes.has(key):
		return _meshes[key]
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var n := rings.size()
	var pts: Array = []
	var nrm: Array = []
	for i in range(n):
		var r: Array = rings[i]
		var y: float = r[0]
		var rx: float = maxf(r[1], 0.0005)
		var rz: float = maxf(r[2], 0.0005)
		var zo: float = r[3] if r.size() > 3 else 0.0
		var xo: float = r[4] if r.size() > 4 else 0.0
		var rp: Array = rings[maxi(i - 1, 0)]
		var rn: Array = rings[mini(i + 1, n - 1)]
		var dy: float = rn[0] - rp[0]
		var slope := 0.0
		if absf(dy) > 0.0001:
			slope = -((rn[1] + rn[2]) - (rp[1] + rp[2])) * 0.5 / dy
		var ring: Array = []
		var rnorm: Array = []
		for s in range(segs):
			var a := TAU * s / segs
			ring.append(Vector3(xo + cos(a) * rx, y, zo + sin(a) * rz))
			rnorm.append(Vector3(cos(a) / rx, slope / maxf((rx + rz) * 0.5, 0.01) * signf(dy if dy != 0.0 else 1.0), sin(a) / rz).normalized())
		pts.append(ring)
		nrm.append(rnorm)
	for i in range(n - 1):
		var c0 := Vector3(rings[i][4] if rings[i].size() > 4 else 0.0, rings[i][0], rings[i][3] if rings[i].size() > 3 else 0.0)
		for s in range(segs):
			var s2 := (s + 1) % segs
			var a: Vector3 = pts[i][s]
			var b: Vector3 = pts[i][s2]
			var c: Vector3 = pts[i + 1][s]
			var d: Vector3 = pts[i + 1][s2]
			var out := ((a + b + c + d) * 0.25 - c0)
			out.y = 0.0
			_tri(st, [a, b, d], [nrm[i][s], nrm[i][s2], nrm[i + 1][s2]], out)
			_tri(st, [a, d, c], [nrm[i][s], nrm[i + 1][s2], nrm[i + 1][s]], out)
	# caps
	for e in [0, n - 1]:
		var r: Array = rings[e]
		if r[1] < 0.004 and r[2] < 0.004:
			continue
		var dir := -1.0 if e == 0 else 1.0
		if n > 1 and ((rings[n - 1][0] - rings[0][0]) < 0.0):
			dir = -dir
		var cen := Vector3(r[4] if r.size() > 4 else 0.0, r[0], r[3] if r.size() > 3 else 0.0)
		var up := Vector3(0, dir, 0)
		for s in range(segs):
			var s2 := (s + 1) % segs
			_tri(st, [cen, pts[e][s], pts[e][s2]], [up, up, up], up)
	var m := st.commit()
	_meshes[key] = m
	return m

static func sheet(key: String, w_top: float, w_bot: float, length: float, curve: float, rows := 6, cols := 6) -> ArrayMesh:
	## A hanging cloth: a grid that runs down -Y, wider at the hem, curved
	## back around the body by `curve` (z bulge at the middle).
	if _meshes.has(key):
		return _meshes[key]
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var g: Array = []
	for r in range(rows + 1):
		var v := float(r) / rows
		var w := lerpf(w_top, w_bot, v)
		var row: Array = []
		for c in range(cols + 1):
			var u := float(c) / cols * 2.0 - 1.0
			var x := u * w * 0.5
			var z := -(1.0 - u * u) * curve * (0.6 + v * 0.6) - v * 0.04
			row.append(Vector3(x, -v * length, z))
		g.append(row)
	for r in range(rows):
		for c in range(cols):
			var a: Vector3 = g[r][c]
			var b: Vector3 = g[r][c + 1]
			var cc: Vector3 = g[r + 1][c]
			var d: Vector3 = g[r + 1][c + 1]
			var n := (b - a).cross(cc - a).normalized()
			if n.z > 0.0:
				n = -n
			_tri(st, [a, b, d], [n, n, n], n)
			_tri(st, [a, d, cc], [n, n, n], n)
	var m := st.commit()
	_meshes[key] = m
	return m

func _part(parent: Node3D, mesh: Mesh, mat: Material, pos: Vector3, rot := Vector3.ZERO, scl := Vector3.ONE) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	mi.scale = scl
	# the fine detail (studs, fingers, eyes, links) casts no shadow and is
	# skipped once the camera is too far off to see it
	var ext: float = (mesh.get_aabb().size * scl.abs()).length()
	if ext < 0.06:
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mi.visibility_range_end = 45.0
	parent.add_child(mi)
	return mi

func _box(parent: Node3D, size: Vector3, mat: Material, pos: Vector3, rot := Vector3.ZERO) -> MeshInstance3D:
	var key := "box|%s" % size
	if not _meshes.has(key):
		var m := BoxMesh.new()
		m.size = size
		_meshes[key] = m
	return _part(parent, _meshes[key], mat, pos, rot)

func _cyl(parent: Node3D, r0: float, r1: float, h: float, mat: Material, pos: Vector3, rot := Vector3.ZERO, segs := 12) -> MeshInstance3D:
	var key := "cyl|%.3f|%.3f|%.3f|%d" % [r0, r1, h, segs]
	if not _meshes.has(key):
		var m := CylinderMesh.new()
		m.bottom_radius = r0
		m.top_radius = r1
		m.height = h
		m.radial_segments = segs
		m.rings = 1
		_meshes[key] = m
	return _part(parent, _meshes[key], mat, pos, rot)

func _sphere(parent: Node3D, r: float, mat: Material, pos: Vector3, scl := Vector3.ONE) -> MeshInstance3D:
	var key := "sph|%.3f" % r
	if not _meshes.has(key):
		var m := SphereMesh.new()
		m.radius = r
		m.height = r * 2.0
		m.radial_segments = 14 if r > 0.02 else 8
		m.rings = 7 if r > 0.02 else 4
		_meshes[key] = m
	return _part(parent, _meshes[key], mat, pos, Vector3.ZERO, scl)

func _loft(parent: Node3D, key: String, rings: Array, mat: Material, pos := Vector3.ZERO, rot := Vector3.ZERO, segs := 12) -> MeshInstance3D:
	return _part(parent, loft(key, rings, segs), mat, pos, rot)

func _joint(parent: Node3D, nm: String, pos: Vector3) -> Node3D:
	var n := Node3D.new()
	n.name = nm
	n.position = pos
	parent.add_child(n)
	J[nm] = n
	return n

static func _scaled(rings: Array, bx: float, bz: float) -> Array:
	var out: Array = []
	for r in rings:
		var q: Array = r.duplicate()
		q[1] = q[1] * bx
		q[2] = q[2] * bz
		out.append(q)
	return out

# ------------------------------------------------------------------ building

func mark_rival() -> void:
	## A rival leader stands in a second, gold ring.
	if rival_ring != null or base_node == null:
		return
	var rr := TorusMesh.new()
	rr.inner_radius = 0.5
	rr.outer_radius = 0.56
	rr.rings = 32
	rival_ring = _part(base_node, rr, Mats.glow(Color(0.95, 0.75, 0.35), 1.4), Vector3(0, 0.04, 0))

func set_hidden(on: bool) -> void:
	## A fighter gone to ground: a faint grey-green ring and "hidden" over them.
	if not on:
		if hide_mark != null:
			hide_mark.visible = false
		return
	if hide_mark == null:
		hide_mark = Node3D.new()
		add_child(hide_mark)
		var rr := TorusMesh.new()
		rr.inner_radius = 0.6
		rr.outer_radius = 0.64
		rr.rings = 40
		_part(hide_mark, rr, Mats.glow(Color(0.55, 0.75, 0.62), 1.0), Vector3(0, 0.05, 0))
		var l := Label3D.new()
		l.text = "hidden"
		l.font = font()
		l.font_size = 34
		l.pixel_size = 0.005
		l.outline_size = 8
		l.modulate = Color(0.7, 0.88, 0.76, 0.9)
		l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		l.no_depth_test = true
		l.position = Vector3(0, 2.6, 0)
		hide_mark.add_child(l)
	hide_mark.visible = true

func set_watch(on: bool) -> void:
	## A fighter standing watch: an amber ring at their feet and "on watch"
	## over their head, gone the moment they fire or their turn comes again.
	if not on:
		if watch_mark != null:
			watch_mark.visible = false
		return
	if watch_mark == null:
		watch_mark = Node3D.new()
		add_child(watch_mark)
		var rr := TorusMesh.new()
		rr.inner_radius = 0.6
		rr.outer_radius = 0.65
		rr.rings = 40
		_part(watch_mark, rr, Mats.glow(Color(1.0, 0.68, 0.25), 1.8), Vector3(0, 0.05, 0))
		var l := Label3D.new()
		l.text = "on watch"
		l.font = font()
		l.font_size = 34
		l.pixel_size = 0.005
		l.outline_size = 8
		l.modulate = Color(1.0, 0.78, 0.4, 0.95)
		l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		l.no_depth_test = true
		l.position = Vector3(0, 2.6, 0)
		watch_mark.add_child(l)
	watch_mark.visible = true

func setup(u: BUnit, wb: Dictionary) -> void:
	unit_id = u.id
	side = u.side
	# a sellsword wears their own colours, not the band's
	var ud: Dictionary = (wb.get("units", {}) as Dictionary).get(u.unit_type, {})
	if ud.has("look"):
		var lk: Dictionary = ud["look"]
		wb = wb.duplicate()
		wb["id"] = "sellsword"
		wb.erase("skin")
		wb.erase("tall")
		for k in lk:
			wb[k] = lk[k]
	var col: Array = wb.get("color", [0.5, 0.5, 0.5])
	var tr: Array = wb.get("trim", [0.8, 0.8, 0.7])
	cloth = Color(col[0], col[1], col[2])
	trim = Color(tr[0], tr[1], tr[2])
	var wid: String = String(wb.get("id", ""))
	var rng := RandomNumberGenerator.new()
	rng.seed = u.id * 7919 + 13
	_phase = rng.randf() * TAU
	var skins := [Color(0.55, 0.4, 0.3), Color(0.42, 0.3, 0.22), Color(0.66, 0.5, 0.4), Color(0.3, 0.21, 0.16), Color(0.6, 0.47, 0.37)]
	var skin: Color = skins[rng.randi() % skins.size()]
	if u.body == "wretch":
		skin = Color(0.5, 0.48, 0.45)
	if wb.has("skin"):
		var sk: Array = wb["skin"]
		skin = Color(sk[0], sk[1], sk[2]).lightened(rng.randf_range(-0.06, 0.1))
	var hairs := [Color(0.06, 0.045, 0.035), Color(0.13, 0.08, 0.05), Color(0.2, 0.14, 0.08), Color(0.04, 0.04, 0.045)]
	var hair: Color = hairs[rng.randi() % hairs.size()]
	if wid == "andii":
		hair = Color(0.66, 0.67, 0.71) if rng.randf() < 0.45 else Color(0.03, 0.03, 0.04)
	# dyed cloth, worn and dulled by the ruins
	var lum := cloth.get_luminance()
	var cl := cloth.lerp(Color(lum, lum, lum), 0.28).darkened(0.03)
	var m_cloth := _mat(cl, 0.85, 0.0, 0.35, false, "cloth")
	var m_cloth2 := _mat(cl, 0.85, 0.0, 0.25, true, "cloth")
	var m_dark := _mat(cl.darkened(0.45), 0.85, 0.0, 0.35, false, "cloth")
	var m_dark2 := _mat(cl.darkened(0.5), 0.9, 0.0, 0.25, true, "cloth")
	var m_trim := _mat(trim, 0.55, 0.25)
	var m_skin := _mat(skin, 0.65, 0.0, 0.3, false, "skin")
	var m_leather := _mat(Color(0.24, 0.15, 0.09), 0.75, 0.0, 0.35, false, "leather")
	var m_iron := _mat(Color(0.44, 0.44, 0.46), 0.36, 0.85, 0.15, false, "metal")
	var m_mail := _mat(Color(0.36, 0.37, 0.39), 0.5, 0.75, 0.1, false, "mail")
	var m_sand := _mat(Color(0.56, 0.47, 0.34), 0.85, 0.0, 0.35, false, "cloth")
	var m_boot := _mat(Color(0.11, 0.08, 0.06), 0.8, 0.0, 0.35, false, "leather")
	var m_hair := _mat(hair, 0.7, 0.0, 0.35, false, "hair")
	var m_brass := _mat(Color(0.62, 0.48, 0.24), 0.4, 0.8, 0.15)
	var m_white := _mat(Color(0.86, 0.83, 0.76), 0.5, 0.0, 0.0)
	var m_lip := _mat(skin.darkened(0.25).lerp(Color(0.5, 0.2, 0.18), 0.25), 0.6, 0.0, 0.1)
	var m_black := _mat(Color(0.015, 0.012, 0.01), 0.9, 0.0, 0.0)
	var dust := u.body == "dust"
	_dust = dust
	if dust:
		# skin dried to leather on the bone, and hair faded to rust
		m_skin = _mat(skin, 0.92, 0.0, 0.22, false, "leather")
		hair = [Color(0.3, 0.17, 0.09), Color(0.22, 0.15, 0.1), Color(0.36, 0.27, 0.18)][rng.randi() % 3]
		m_hair = _mat(hair, 0.85, 0.0, 0.3, false, "hair")
		m_lip = _mat(skin.darkened(0.4), 0.9, 0.0, 0.05)
	var m_fur := _mat(Color(0.27, 0.2, 0.13).lerp(cl, 0.2), 0.95, 0.0, 0.35, false, "hair")
	var m_fur2 := _mat(Color(0.2, 0.15, 0.1).lerp(cl, 0.15), 0.95, 0.0, 0.3, true, "hair")
	var m_bone := _mat(Color(0.74, 0.69, 0.58), 0.7, 0.0, 0.15, false, "leather")
	if wid == "imass":
		# knapped flint for every blade and point
		m_iron = _mat(Color(0.34, 0.31, 0.28), 0.5, 0.05, 0.25, false, "metal")

	# round base, like a tabletop miniature
	var base := Node3D.new()
	add_child(base)
	_cyl(base, 0.44, 0.42, 0.06, _mat(Color(0.08, 0.08, 0.09), 0.7, 0.0, 0.0), Vector3(0, 0.03, 0), Vector3.ZERO, 24)
	var tm := TorusMesh.new()
	tm.inner_radius = 0.4
	tm.outer_radius = 0.46
	tm.rings = 24
	team_ring = _part(base, tm, Mats.glow(cloth.lightened(0.15), 0.9), Vector3(0, 0.05, 0))
	base_node = base
	if u.rival:
		mark_rival()
	var sel := TorusMesh.new()
	sel.inner_radius = 0.5
	sel.outer_radius = 0.6
	sel.rings = 32
	ring = _part(self, sel, Mats.glow(Color(0.3, 1.0, 0.85), 3.0, true), Vector3(0, 0.04, 0))
	ring.visible = false
	ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	# --- skeleton
	body = Node3D.new()
	add_child(body)
	var b := 1.0       # bulk
	var hunch := 0.0
	match u.body:
		"brute":
			b = 1.2
		"heavy":
			b = 1.1
		"wretch":
			b = 0.86
			hunch = 0.42
			_hip_y = 0.86
		"dust":
			b = 0.9
			hunch = 0.14
	var bk := "%.2f" % b
	root = _joint(body, "root", Vector3(0, _hip_y, 0))
	var spine := _joint(root, "spine", Vector3(0, 0.1, 0))
	var neck := _joint(spine, "neck", Vector3(0, 0.5 * b, 0.0))
	var head := _joint(neck, "head", Vector3(0, 0.17, 0.012))
	var sx := 0.2 * b + 0.035
	var sh_l := _joint(spine, "sh_l", Vector3(-sx, 0.425 * b, 0))
	var sh_r := _joint(spine, "sh_r", Vector3(sx, 0.425 * b, 0))
	var el_l := _joint(sh_l, "el_l", Vector3(0, -0.29, 0))
	var el_r := _joint(sh_r, "el_r", Vector3(0, -0.29, 0))
	var thigh := _hip_y * 0.48
	var shin := _hip_y * 0.455
	var hip_l := _joint(root, "hip_l", Vector3(-0.09 * b, -0.05, 0))
	var hip_r := _joint(root, "hip_r", Vector3(0.09 * b, -0.05, 0))
	var kn_l := _joint(hip_l, "kn_l", Vector3(0, -thigh, 0))
	var kn_r := _joint(hip_r, "kn_r", Vector3(0, -thigh, 0))
	var ft_l := _joint(kn_l, "ft_l", Vector3(0, -shin, 0))
	var ft_r := _joint(kn_r, "ft_r", Vector3(0, -shin, 0))
	var hand_l := Node3D.new()
	hand_l.position = Vector3(0, -0.265, 0)
	el_l.add_child(hand_l)
	var hand_r := Node3D.new()
	hand_r.position = Vector3(0, -0.265, 0)
	el_r.add_child(hand_r)

	# --- the body itself
	var torso_mat := m_skin
	var thigh_mat := m_dark
	var shin_mat := m_dark
	var upper_mat := m_cloth
	var fore_mat := m_skin
	match u.body:
		"soldier":
			torso_mat = m_dark
			upper_mat = m_mail
		"heavy":
			upper_mat = m_mail
			thigh_mat = m_mail
		"robe":
			torso_mat = m_cloth
		"brute":
			thigh_mat = m_leather
			shin_mat = m_skin
			upper_mat = m_skin
		"wretch":
			thigh_mat = m_dark
			shin_mat = m_skin
			upper_mat = m_skin
		"dust":
			thigh_mat = m_skin
			shin_mat = m_skin
			upper_mat = m_skin
		_:
			torso_mat = m_sand
			thigh_mat = m_sand
			shin_mat = m_sand
			upper_mat = m_sand
	_loft(root, "pelvis" + bk, _scaled([[-0.13, 0.12, 0.09], [-0.05, 0.16, 0.105], [0.05, 0.155, 0.1], [0.14, 0.145, 0.098]], b, b), torso_mat if u.body != "brute" else m_leather)
	var chest_r := _scaled([[0.0, 0.145, 0.098], [0.1, 0.15, 0.1], [0.22, 0.178, 0.112, 0.012], [0.33, 0.2, 0.118, 0.008], [0.41, 0.2, 0.108], [0.47, 0.155, 0.09], [0.52, 0.07, 0.06]], b, b)
	_loft(spine, "chest" + bk, chest_r, torso_mat if u.body != "soldier" else m_mail)
	# neck and head
	_loft(neck, "neck", [[-0.03, 0.052, 0.055], [0.1, 0.046, 0.048, 0.005]], m_skin, Vector3.ZERO, Vector3.ZERO, 10)
	var skull := [[-0.135, 0.018, 0.02, 0.03], [-0.115, 0.048, 0.05, 0.03], [-0.07, 0.072, 0.082, 0.018], [-0.01, 0.088, 0.1, 0.004],
		[0.05, 0.094, 0.106, -0.004], [0.1, 0.086, 0.098, -0.01], [0.14, 0.06, 0.072, -0.014], [0.165, 0.012, 0.016, -0.014]]
	_loft(head, "skull", skull, m_skin, Vector3.ZERO, Vector3.ZERO, 14)
	# a face: brow ridge and brows, eyes with whites, cheekbones, nose,
	# lips, chin and ears
	_sphere(head, 0.03, m_skin, Vector3(0, 0.05, 0.078), Vector3(2.4, 0.6, 0.75))
	for s in [-1.0, 1.0]:
		if dust:
			# empty sockets, with a dull ember far down in each
			_sphere(head, 0.021, m_black, Vector3(s * 0.036, 0.024, 0.084), Vector3(1.25, 1.0, 0.7))
			var em := _sphere(head, 0.0045, Mats.glow(Color(0.85, 0.45, 0.18), 1.6), Vector3(s * 0.035, 0.024, 0.093))
			em.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		else:
			_sphere(head, 0.017, m_black, Vector3(s * 0.036, 0.026, 0.082), Vector3(1.25, 0.85, 0.6))
			_sphere(head, 0.011, m_white, Vector3(s * 0.036, 0.026, 0.088), Vector3(1.3, 0.7, 0.5))
			_sphere(head, 0.006, m_black, Vector3(s * 0.035, 0.026, 0.094), Vector3(1.0, 1.0, 0.6))
		var brow := _box(head, Vector3(0.042, 0.011, 0.012), m_hair, Vector3(s * 0.037, 0.05, 0.1), Vector3(0, 0, -s * 0.16))
		brow.rotation.x = -0.15
		_sphere(head, 0.026, m_skin, Vector3(s * 0.055, -0.012, 0.07), Vector3(1.0, 0.75, 0.75))
		_sphere(head, 0.022, m_skin, Vector3(s * 0.092, 0.005, -0.005), Vector3(0.5, 1.1, 0.8))
	_box(head, Vector3(0.022, 0.055, 0.032), m_skin, Vector3(0, -0.003, 0.1), Vector3(-0.3, 0, 0))
	_sphere(head, 0.016, m_skin, Vector3(0, -0.03, 0.108), Vector3(1.3, 0.8, 0.9))
	_sphere(head, 0.018, m_lip, Vector3(0, -0.06, 0.088), Vector3(1.5, 0.32, 0.6))
	_box(head, Vector3(0.042, 0.004, 0.012), m_black, Vector3(0, -0.061, 0.096))
	if dust:
		# the lips have shrunk back from the teeth
		_box(head, Vector3(0.05, 0.016, 0.01), m_black, Vector3(0, -0.061, 0.099))
		for i in range(6):
			_box(head, Vector3(0.0065, 0.013, 0.006), m_bone, Vector3(-0.02 + i * 0.008, -0.061, 0.103))
		# hollow cheeks
		for s in [-1.0, 1.0]:
			_sphere(head, 0.02, _mat(skin.darkened(0.35), 0.95, 0.0, 0.0), Vector3(s * 0.05, -0.04, 0.078), Vector3(0.8, 1.2, 0.4))
	_sphere(head, 0.03, m_skin, Vector3(0, -0.1, 0.07), Vector3(1.2, 0.8, 0.8))
	if (u.body == "brute" or u.body == "soldier") and rng.randf() < 0.35 and wid != "andii" and wid != "seguleh":
		_loft(head, "beard", [[-0.15, 0.03, 0.03, 0.05], [-0.11, 0.07, 0.06, 0.04], [-0.06, 0.09, 0.085, 0.02], [-0.02, 0.092, 0.09, 0.0]], m_hair, Vector3.ZERO, Vector3.ZERO, 12)

	# legs
	var thigh_r := _scaled([[0.05, 0.098, 0.102], [-0.05, 0.096, 0.1], [-0.2, 0.084, 0.088, 0.006], [-0.36, 0.066, 0.07], [-thigh - 0.02, 0.058, 0.062]], b, b)
	var shin_r := _scaled([[0.03, 0.06, 0.064], [-0.1, 0.062, 0.07, -0.01], [-0.26, 0.048, 0.054], [-shin, 0.04, 0.044]], b, b)
	for side_i in [[hip_l, kn_l, ft_l], [hip_r, kn_r, ft_r]]:
		_loft(side_i[0], "thigh%s%.2f" % [bk, thigh], thigh_r, thigh_mat)
		_sphere(side_i[1], 0.058 * b, thigh_mat, Vector3.ZERO)
		_loft(side_i[1], "shin%s%.2f" % [bk, shin], shin_r, shin_mat)
		var ft: Node3D = side_i[2]
		if u.body == "wretch":
			_box(ft, Vector3(0.085, 0.05, 0.2), m_skin, Vector3(0, 0.03, 0.05))
		else:
			_loft(ft, "cuff" + bk, _scaled([[0.12, 0.052, 0.058], [-0.03, 0.05, 0.056]], b, b), m_boot)
			_loft(ft, "foot" + bk, _scaled([[-0.11, 0.04, 0.05, 0.0], [0.0, 0.05, 0.065, 0.02], [0.13, 0.042, 0.05, 0.03], [0.17, 0.02, 0.025, 0.03]], b, 0.75), m_boot, Vector3(0, 0.035, 0.0), Vector3(PI * 0.5, 0, 0), 10)

	# arms
	var upper_r := _scaled([[0.045, 0.06, 0.062], [-0.02, 0.064, 0.066], [-0.15, 0.054, 0.058], [-0.29, 0.045, 0.048]], b, b)
	var fore_r := _scaled([[0.02, 0.045, 0.047], [-0.07, 0.05, 0.05], [-0.2, 0.038, 0.036], [-0.255, 0.033, 0.03]], b, b)
	for arm in [[sh_l, el_l, hand_l], [sh_r, el_r, hand_r]]:
		_sphere(arm[0], 0.068 * b, upper_mat, Vector3(0, 0.01, 0))
		_loft(arm[0], "upper" + bk, upper_r, upper_mat)
		_sphere(arm[1], 0.047 * b, upper_mat if u.body == "heavy" else fore_mat, Vector3.ZERO)
		_loft(arm[1], "fore" + bk, fore_r, fore_mat)
		_loft(arm[2], "fist", [[0.015, 0.034, 0.028], [-0.035, 0.044, 0.04, 0.008], [-0.085, 0.032, 0.034, 0.006]], m_skin, Vector3.ZERO, Vector3.ZERO, 10)
		# curled fingers in a row, and a thumb across them
		for fi in range(4):
			_sphere(arm[2], 0.014, m_skin, Vector3(-0.024 + fi * 0.016, -0.07, 0.03), Vector3(0.9, 1.4, 1.1))
		var th := _cyl(arm[2], 0.012, 0.01, 0.05, m_skin, Vector3(0.0, -0.045, 0.04), Vector3(0, 0, PI * 0.5), 6)
		th.rotation.y = 0.4
		if u.body == "heavy" or u.body == "soldier":
			# leather gauntlet cuffs
			_loft(arm[2], "gauntlet", [[0.03, 0.046, 0.042], [-0.02, 0.05, 0.046]], m_leather, Vector3.ZERO, Vector3.ZERO, 10)

	# --- dress by body type
	var cz := 0.112 * b
	match u.body:
		"soldier":
			_loft(spine, "mailskirt" + bk, _scaled([[-0.38, 0.2, 0.16], [-0.2, 0.175, 0.13], [-0.05, 0.155, 0.108], [0.02, 0.152, 0.104]], b, b), m_mail)
			_panels(m_cloth2, 0.25 * b, 0.82, cz + 0.016)
			_belt(b, m_leather, m_trim)
			_cloak_on(spine, b, m_dark2, 1.12)
			for el in [el_l, el_r]:
				_loft(el, "bracer" + bk, _scaled([[-0.08, 0.054, 0.054], [-0.21, 0.044, 0.042]], b, b), m_leather)
		"heavy":
			_loft(spine, "cuirass" + bk, _scaled([[-0.04, 0.165, 0.118], [0.1, 0.172, 0.122, 0.006], [0.22, 0.2, 0.135, 0.018], [0.34, 0.222, 0.135, 0.01], [0.43, 0.212, 0.122], [0.5, 0.15, 0.095]], b, b), m_iron)
			_box(spine, Vector3(0.02, 0.4, 0.02) * b, m_trim, Vector3(0, 0.24 * b, 0.15 * b), Vector3(-0.1, 0, 0))
			_loft(root, "tassets" + bk, _scaled([[0.1, 0.175, 0.125], [-0.1, 0.2, 0.15], [-0.28, 0.215, 0.16]], b, b), m_iron, Vector3.ZERO, Vector3.ZERO, 12)
			_panels(m_cloth2, 0.18 * b, 0.62, cz + 0.035, false)
			for sh in [sh_l, sh_r]:
				var pd := _sphere(sh, 0.08, m_iron, Vector3(0, 0.035, 0), Vector3(1.15, 0.7, 1.1) * b)
				pd.rotation.z = 0.2 * (1.0 if sh == sh_r else -1.0)
				_loft(sh, "rerebrace" + bk, _scaled([[-0.05, 0.067, 0.069], [-0.25, 0.054, 0.056]], b, b), m_iron)
			for el in [el_l, el_r]:
				_loft(el, "vambrace" + bk, _scaled([[-0.04, 0.056, 0.056], [-0.22, 0.045, 0.043]], b, b), m_iron)
			for kn in [kn_l, kn_r]:
				_loft(kn, "greave" + bk, _scaled([[0.05, 0.068, 0.072, 0.01], [-0.12, 0.07, 0.078, 0.004], [-0.3, 0.055, 0.06], [-shin + 0.04, 0.052, 0.055]], b, b), m_iron)
			_belt(b, m_leather, m_trim)
			_cloak_on(spine, b, m_cloth2, 1.05)
		"robe":
			_loft(root, "robeskirt" + bk, _scaled([[0.12, 0.165, 0.115], [-0.1, 0.2, 0.15], [-0.45, 0.255, 0.21], [-_hip_y + 0.08, 0.3, 0.26]], b, b), m_dark, Vector3.ZERO, Vector3.ZERO, 14)
			_box(spine, Vector3(0.07, 0.48, 0.02) * b, m_trim, Vector3(0, 0.24 * b, cz + 0.008))
			_box(root, Vector3(0.07, _hip_y * 0.9, 0.02), m_trim, Vector3(0, -_hip_y * 0.42, 0.21 * b), Vector3(-0.09, 0, 0))
			_belt(b, m_leather, m_trim)
			for el in [el_l, el_r]:
				_loft(el, "sleeve" + bk, [[0.03, 0.06, 0.06], [-0.1, 0.07, 0.07], [-0.2, 0.085, 0.085]], m_cloth2)
			_loft(spine, "mantle" + bk, _scaled([[0.3, 0.23, 0.15], [0.42, 0.215, 0.13], [0.5, 0.12, 0.09]], b, b), m_dark)
		"brute":
			_box(spine, Vector3(0.09, 0.62, 0.03) * b, m_leather, Vector3(0, 0.26 * b, cz + 0.012), Vector3(0, 0, 0.62))
			_box(spine, Vector3(0.09, 0.62, 0.03) * b, m_leather, Vector3(0, 0.26 * b, -cz - 0.012), Vector3(0, 0, 0.62))
			_loft(root, "kilt" + bk, _scaled([[0.1, 0.165, 0.112], [-0.1, 0.2, 0.15], [-0.32, 0.225, 0.17]], b, b), m_cloth2, Vector3.ZERO, Vector3.ZERO, 12)
			_belt(b, m_leather, m_iron)
			for i in range(5):
				_sphere(spine, 0.018, m_iron, Vector3((-0.14 + i * 0.07) * b, 0.38 * b, cz - 0.01))
			for el in [el_l, el_r]:
				_loft(el, "bracer" + bk, _scaled([[-0.06, 0.056, 0.056], [-0.22, 0.046, 0.044]], b, b), m_leather)
		"dust":
			# a hide loincloth, a fur cloak gone bald in patches, shin wraps,
			# and the ribs showing through the dried skin
			_loft(root, "hidekilt" + bk, _scaled([[0.08, 0.16, 0.108], [-0.1, 0.19, 0.14], [-0.3, 0.205, 0.155]], b, b), m_fur2, Vector3.ZERO, Vector3.ZERO, 11)
			_belt(b, m_leather, m_bone)
			_cloak_on(spine, b, m_fur2, 0.95)
			_loft(spine, "furmantle" + bk, _scaled([[0.3, 0.235, 0.16], [0.4, 0.225, 0.14], [0.49, 0.13, 0.095]], b, b), m_fur)
			var m_rib := _mat(skin.lightened(0.28), 0.9, 0.0, 0.1, false, "leather")
			for i in range(5):
				var ry: float = (0.13 + i * 0.05) * b
				var rw: float = (0.105 - absf(i - 1.5) * 0.006) * b
				for sd2: float in [-1.0, 1.0]:
					var rib := _cyl(spine, 0.005, 0.004, rw, m_rib, Vector3(sd2 * rw * 0.45, ry, cz - 0.004 + (0.012 - i * 0.002)), Vector3(0, -sd2 * 0.35, PI * 0.5 + sd2 * 0.28), 5)
					rib.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			for kn in [kn_l, kn_r]:
				_loft(kn, "shinwrap" + bk, _scaled([[-0.06, 0.056, 0.06], [-shin + 0.06, 0.047, 0.05]], b, b), m_leather)
			for el in [el_l, el_r]:
				_loft(el, "armwrap" + bk, _scaled([[-0.1, 0.048, 0.048], [-0.22, 0.041, 0.04]], b, b), m_leather)
		"wretch":
			_loft(spine, "rags" + bk, _scaled([[-0.42, 0.22, 0.17], [-0.15, 0.17, 0.125], [0.1, 0.16, 0.11], [0.32, 0.2, 0.125], [0.45, 0.17, 0.1]], b, b), m_dark, Vector3.ZERO, Vector3.ZERO, 9)
			_cloak_on(spine, b, m_dark2, 0.8)
		_:  # light: padded coat, sash and loose trousers
			_loft(spine, "coat" + bk, _scaled([[-0.34, 0.19, 0.155], [-0.12, 0.165, 0.12], [0.1, 0.158, 0.108], [0.3, 0.205, 0.124], [0.42, 0.205, 0.114], [0.49, 0.15, 0.09]], b, b), m_sand)
			_loft(root, "sash" + bk, _scaled([[0.02, 0.17, 0.115], [0.13, 0.168, 0.113]], b, b), m_cloth)
			_box(root, Vector3(0.07, 0.4, 0.015), m_cloth2, Vector3(0.09 * b, -0.12, 0.125 * b), Vector3(-0.12, 0, 0.12))
			_box(spine, Vector3(0.05, 0.52, 0.02) * b, m_cloth, Vector3(0.05 * b, 0.24 * b, cz + 0.016), Vector3(0, 0, 0.42))
			for hp in [hip_l, hip_r]:
				_loft(hp, "baggy" + bk, _scaled([[0.03, 0.11, 0.112], [-0.2, 0.105, 0.108], [-thigh + 0.02, 0.08, 0.084]], b, b), m_sand)
			for kn in [kn_l, kn_r]:
				_loft(kn, "wrap" + bk, _scaled([[-0.18, 0.055, 0.06], [-shin + 0.05, 0.048, 0.052]], b, b), m_leather)

	# --- the kit everyone carries: pouches, a knife, straps and buckles
	if u.body != "wretch" and not dust:
		for sx2: float in [-1.0, 1.0]:
			var pz := 0.07 * b
			var px: float = sx2 * 0.15 * b
			_box(root, Vector3(0.065, 0.075, 0.04) * b, m_leather, Vector3(px, 0.03, pz), Vector3(0, -sx2 * 0.9, 0))
			_box(root, Vector3(0.07, 0.03, 0.045) * b, m_boot, Vector3(px, 0.07, pz), Vector3(0.1, -sx2 * 0.9, 0))
			_sphere(root, 0.008, m_brass, Vector3(px + sx2 * 0.012, 0.058, pz + 0.018))
		# a sheathed knife at the back of the belt
		_cyl(root, 0.018, 0.012, 0.2, m_leather, Vector3(-0.08 * b, 0.0, -0.12 * b), Vector3(0.3, 0, 0.5), 6)
		_cyl(root, 0.012, 0.012, 0.07, m_boot, Vector3(-0.12 * b, 0.11, -0.13 * b), Vector3(0.3, 0, 0.5), 6)
		# boot straps
		for ft in [ft_l, ft_r]:
			_loft(ft, "bootstrap" + bk, _scaled([[0.07, 0.056, 0.062], [0.09, 0.056, 0.062]], b, b), m_leather)
	match u.body:
		"soldier":
			# a baldric over the mail, and riveted mail hems at the elbows
			_box(spine, Vector3(0.055, 0.64, 0.018) * b, m_leather, Vector3(0, 0.25 * b, cz + 0.02), Vector3(0, 0, -0.62))
			_box(spine, Vector3(0.055, 0.64, 0.018) * b, m_leather, Vector3(0, 0.25 * b, -cz - 0.02), Vector3(0, 0, 0.62))
			_box(spine, Vector3(0.04, 0.04, 0.012), m_brass, Vector3(-0.08 * b, 0.36 * b, cz + 0.03), Vector3(0, 0, -0.62))
			for sh in [sh_l, sh_r]:
				_loft(sh, "mailhem" + bk, _scaled([[-0.255, 0.052, 0.054], [-0.235, 0.056, 0.058]], b, b), m_trim)
		"heavy":
			# rivets along the cuirass's neck and waist, and a gorget
			for i in range(9):
				var a: float = -0.9 + i * 0.225
				_sphere(spine, 0.009, m_brass, Vector3(sin(a) * 0.16 * b, 0.46 * b, cos(a) * 0.1 * b + 0.008))
				_sphere(spine, 0.009, m_brass, Vector3(sin(a) * 0.17 * b, 0.0, cos(a) * 0.12 * b + 0.006))
			_loft(neck, "gorget" + bk, _scaled([[-0.06, 0.12, 0.095], [0.02, 0.07, 0.068]], b, b), m_iron, Vector3.ZERO, Vector3.ZERO, 14)
		"brute":
			if wid == "barghast":
				# a necklace of finger bones
				for i in range(9):
					var a: float = -1.1 + i * 0.275
					var bone := _cyl(spine, 0.007, 0.006, 0.05, m_white, Vector3(sin(a) * 0.15 * b, 0.43 * b - cos(a) * 0.03, cos(a) * 0.11 * b + 0.01), Vector3(0.2, 0, a * 0.4), 5)
					bone.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		"robe":
			# a cord with tassels, and a rolled scroll case
			for sx2: float in [-1.0, 1.0]:
				_cyl(root, 0.008, 0.008, 0.3, m_trim, Vector3(sx2 * 0.04, -0.08, 0.17 * b), Vector3(0.1, 0, sx2 * 0.1), 5)
			_cyl(root, 0.026, 0.026, 0.2, m_leather, Vector3(0.18 * b, -0.02, 0.02), Vector3(0.0, 0, 0.25), 8)

	# a shadow-thread cloak from the shard market: near black, with a slow
	# violet sheen where Meanas runs through the weave
	if u.cloaked():
		if _cloak != null:
			_cloak.queue_free()
		var m_shade := _mat(Color(0.05, 0.045, 0.07), 0.55, 0.0, 0.7, true)
		m_shade.emission_enabled = true
		m_shade.emission = Color(0.22, 0.12, 0.4)
		m_shade.emission_energy_multiplier = 0.35
		_cloak_on(spine, b, m_shade, 1.18)

	# --- each warband's own marks
	match wid:
		"marines":
			if u.body != "robe":
				# a satchel of Moranth munitions on the hip: clay globes, fuse cords
				var sat := _box(root, Vector3(0.1, 0.09, 0.06) * b, m_leather, Vector3(0.2 * b, -0.04, -0.03), Vector3(0, 0.5, 0.12))
				_box(sat, Vector3(0.105, 0.035, 0.065), m_boot, Vector3(0, 0.04, 0.0))
				var m_clay := _mat(Color(0.64, 0.5, 0.36), 0.9, 0.0, 0.2, false, "leather")
				for i in range(2):
					_sphere(sat, 0.024, m_clay, Vector3(-0.02 + i * 0.04, 0.07, 0.0))
					_cyl(sat, 0.004, 0.004, 0.03, m_white, Vector3(-0.02 + i * 0.04, 0.1, 0.0), Vector3(0.3, 0, 0), 4)
				# the Empire's brass sigil on the left shoulder
				_cyl(sh_l, 0.03, 0.03, 0.008, m_brass, Vector3(-0.055 * b, 0.0, 0.0), Vector3(0, 0, PI * 0.5), 10)
		"chained":
			# lengths of chain worn in the Fallen god's honour: a loop across the
			# chest and manacles on the wrists
			var link := _link_mesh()
			var m_chain := _mat(Color(0.36, 0.34, 0.32), 0.45, 0.85, 0.15)
			for i in range(13):
				var t: float = -1.0 + i / 6.0
				var pos := Vector3(t * 0.17 * b, 0.36 * b - (1.0 - t * t) * 0.15 * b, cz + 0.03 - t * t * 0.035)
				var ang: float = atan(2.0 * t * 0.15 / 0.17)
				var lk := _part(spine, link, m_chain, pos)
				lk.basis = Basis(Vector3.BACK, ang) * Basis(Vector3.RIGHT, PI * 0.5 if i % 2 == 0 else 0.0) * Basis.from_scale(Vector3(1.45, 1.0, 1.0))
				lk.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			for el in [el_l, el_r]:
				_loft(el, "manacle" + bk, _scaled([[-0.19, 0.047, 0.045], [-0.15, 0.05, 0.048]], b, b), m_chain, Vector3.ZERO, Vector3.ZERO, 10)
				for i in range(3):
					var lk2 := _part(el, link, m_chain, Vector3(0.052 * b, -0.19 - i * 0.034, 0.0))
					lk2.basis = Basis(Vector3.BACK, PI * 0.5) * Basis(Vector3.RIGHT, PI * 0.5 if i % 2 == 0 else 0.0) * Basis.from_scale(Vector3(1.45, 1.0, 1.0))
					lk2.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		"whirlwind":
			# tassels hanging from the sash, and a bronze charm on a cord
			for i in range(4):
				_cyl(root, 0.007, 0.004, 0.12, m_trim, Vector3(-0.1 * b + i * 0.025, -0.1, cz + 0.015), Vector3(0.08, 0, 0.05 * (i - 1.5)), 5)
			_cyl(spine, 0.028, 0.028, 0.006, m_brass, Vector3(0, 0.34 * b, cz + 0.03), Vector3(PI * 0.5, 0, 0), 10)
			_box(spine, Vector3(0.004, 0.12, 0.004), m_leather, Vector3(0, 0.41 * b, cz + 0.02), Vector3(-0.2, 0, 0))
		"andii":
			# a thin silver circlet, and a moon-pale brooch at the throat
			var m_silver := _mat(Color(0.78, 0.8, 0.86), 0.25, 0.9, 0.2)
			if u.helm == "" or u.helm == "none":
				_loft(head, "circlet", [[0.05, 0.106, 0.118, -0.006], [0.065, 0.106, 0.118, -0.006]], m_silver, Vector3.ZERO, Vector3(0.12, 0, 0), 16)
			_sphere(spine, 0.022, m_silver, Vector3(0.0, 0.44 * b, cz - 0.01), Vector3(1, 1, 0.5))
		"barghast":
			# fetish bundles of feathers and bone tied at the belt
			for sx2: float in [-1.0, 1.0]:
				var px: float = sx2 * 0.12 * b
				_box(root, Vector3(0.012, 0.13, 0.004), m_dark, Vector3(px, -0.1, cz + 0.02), Vector3(0.1, 0, sx2 * 0.25))
				_cyl(root, 0.006, 0.005, 0.08, m_white, Vector3(px + sx2 * 0.02, -0.08, cz + 0.025), Vector3(0, 0, -sx2 * 0.2), 5)
		"imass":
			# a cord of bone beads and a carved tooth, and a hide bundle of
			# the clan's relics on the hip
			for i in range(11):
				var a: float = -1.15 + i * 0.23
				_sphere(spine, 0.011, m_bone, Vector3(sin(a) * 0.15 * b, 0.43 * b - cos(a) * 0.035, cos(a) * 0.105 * b + 0.012))
			_cyl(spine, 0.013, 0.0, 0.06, m_bone, Vector3(0, 0.37 * b, cz + 0.02), Vector3(PI, 0, 0), 6)
			_box(root, Vector3(0.08, 0.09, 0.06) * b, m_fur, Vector3(0.17 * b, 0.0, 0.02), Vector3(0, -0.8, 0.1))
			_cyl(root, 0.007, 0.007, 0.12, m_leather, Vector3(0.17 * b, 0.07, 0.02), Vector3(0, 0, 0.3), 4)
		"teblor":
			# a bear-fur mantle over the shoulders, and a cord of trophies
			# taken from lowlanders hanging at the belt
			var mt := _loft(spine, "mantle%.2f" % b, _scaled([[0.36, 0.13, 0.1], [0.44, 0.2, 0.15], [0.5, 0.17, 0.12], [0.54, 0.08, 0.07]], b, b), m_fur, Vector3(0, 0, -0.005), Vector3.ZERO, 14)
			mt.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
			_box(spine, Vector3(0.36, 0.3, 0.03) * b, m_fur2, Vector3(0, 0.3 * b, -cz - 0.03), Vector3(-0.12, 0, 0))
			for i in range(5):
				var px: float = -0.1 * b + i * 0.05 * b
				var tro := _cyl(root, 0.012, 0.009, 0.06, m_bone if i % 2 == 0 else m_leather, Vector3(px, -0.03 - (i % 2) * 0.02, cz + 0.03), Vector3(0.1, 0, 0.15 * (i - 2)), 5)
				tro.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			# clan tattoo bars across the cheeks
			for sb: float in [-1.0, 1.0]:
				var tt := _box(head, Vector3(0.035, 0.006, 0.004), _mat(Color(0.1, 0.16, 0.24), 0.7), Vector3(sb * 0.052, 0.0, 0.098), Vector3(0, sb * 0.45, sb * -0.25))
				tt.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		"seguleh":
			# a second blade carried across the back
			var sc := _cyl(spine, 0.022, 0.018, 0.62, m_black, Vector3(0, 0.22 * b, -cz - 0.05), Vector3(0, 0, 0.75), 8)
			sc.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
			_cyl(spine, 0.012, 0.012, 0.14, m_leather, Vector3(-0.27 * b, 0.47 * b, -cz - 0.05), Vector3(0, 0, 0.75), 6)
			_box(spine, Vector3(0.09, 0.016, 0.03), m_brass, Vector3(-0.22 * b, 0.42 * b, -cz - 0.05), Vector3(0, 0, 0.75))

	# --- head gear and hair
	var mask_mat := _mat(Color(0.82, 0.79, 0.72), 0.45, 0.0, 0.15) if wid == "seguleh" else _mat(Color(0.25, 0.24, 0.23), 0.4, 0.7, 0.15)
	match u.helm:
		"kettle":
			_hair_cap(head, m_hair)
			_loft(head, "kettle", [[0.03, 0.108, 0.118, -0.004], [0.1, 0.1, 0.11, -0.008], [0.16, 0.06, 0.068, -0.01], [0.19, 0.005, 0.005, -0.01]], m_iron, Vector3.ZERO, Vector3.ZERO, 16)
			_loft(head, "brim", [[0.025, 0.215, 0.225, -0.005], [0.04, 0.21, 0.22, -0.005]], m_iron, Vector3.ZERO, Vector3(0.06, 0, 0), 18)
			_box(head, Vector3(0.012, 0.1, 0.012), m_leather, Vector3(0.09, -0.04, 0.02))
			_box(head, Vector3(0.012, 0.1, 0.012), m_leather, Vector3(-0.09, -0.04, 0.02))
		"great":
			_loft(head, "greathelm", [[-0.16, 0.112, 0.124, 0.012], [-0.05, 0.115, 0.125, 0.008], [0.1, 0.11, 0.12, -0.004], [0.17, 0.08, 0.09, -0.008], [0.2, 0.01, 0.01, -0.008]], m_iron, Vector3.ZERO, Vector3.ZERO, 16)
			_box(head, Vector3(0.17, 0.02, 0.02), m_black, Vector3(0, 0.04, 0.128))
			_box(head, Vector3(0.018, 0.16, 0.02), m_iron, Vector3(0, -0.02, 0.134))
			for i in range(3):
				_box(head, Vector3(0.012, 0.012, 0.01), m_black, Vector3(-0.05 + i * 0.05, -0.06, 0.13))
			_box(head, Vector3(0.022, 0.06, 0.22), m_trim, Vector3(0, 0.205, -0.01))
		"cap":
			_hair_cap(head, m_hair)
			_loft(head, "cap", [[0.04, 0.1, 0.112, -0.008], [0.11, 0.09, 0.1, -0.012], [0.16, 0.05, 0.058, -0.014], [0.18, 0.005, 0.005, -0.014]], m_leather, Vector3.ZERO, Vector3.ZERO, 14)
		"hood":
			_loft(head, "hood", [[-0.27, 0.2, 0.16, -0.05], [-0.12, 0.125, 0.13, -0.025], [0.04, 0.118, 0.125, -0.018], [0.14, 0.098, 0.11, -0.03], [0.2, 0.045, 0.06, -0.06], [0.23, 0.005, 0.005, -0.09]], m_dark, Vector3.ZERO, Vector3.ZERO, 14)
			_sphere(head, 0.08, m_black, Vector3(0, -0.01, 0.075), Vector3(1.0, 1.3, 0.55))
		"mask":
			_hair_cap(head, m_hair if wid != "seguleh" else m_black)
			_sphere(head, 0.1, mask_mat, Vector3(0, 0.012, 0.072), Vector3(1.0, 1.32, 0.42))
			for s in [-1.0, 1.0]:
				_box(head, Vector3(0.042, 0.014, 0.02), m_black, Vector3(s * 0.037, 0.03, 0.11), Vector3(0, 0, -s * 0.12))
			if wid == "seguleh":
				# the slashes of rank on the mask
				var nslash := 1 + (u.id % 3)
				if u.is_leader():
					nslash = 0
				for i in range(nslash):
					_box(head, Vector3(0.008, 0.075, 0.006), _mat(Color(0.32, 0.06, 0.05), 0.6, 0.0, 0.0), Vector3(-0.05 + i * 0.022, -0.03, 0.111), Vector3(0, 0, 0.35))
			else:
				for i in range(3):
					_cyl(head, 0.01, 0.01, 0.3, m_iron, Vector3(-0.06 + i * 0.06, -0.15, 0.1), Vector3(0.1, 0, 0), 5)
		"paint":
			# Barghast face paint: ash-white over the whole face, black round the
			# eyes and teeth drawn on the jaw, so each warrior wears a skull
			var m_paint := _mat(Color(0.86, 0.84, 0.78), 0.85, 0.0, 0.05)
			if rng.randf() < 0.6:
				_hair_cap(head, m_hair)
			_sphere(head, 0.096, m_paint, Vector3(0, 0.006, 0.07), Vector3(1.0, 1.3, 0.43))
			for s in [-1.0, 1.0]:
				_sphere(head, 0.026, m_black, Vector3(s * 0.036, 0.028, 0.104), Vector3(1.2, 0.9, 0.5))
			_box(head, Vector3(0.02, 0.022, 0.01), m_black, Vector3(0, -0.005, 0.11))
			for i in range(5):
				_box(head, Vector3(0.006, 0.04, 0.006), m_black, Vector3(-0.036 + i * 0.018, -0.058, 0.103))
			# a topknot bound with a strip of hide, and a bone through it
			_cyl(head, 0.032, 0.022, 0.13, m_hair, Vector3(0, 0.19, -0.035), Vector3(-0.5, 0, 0), 7)
			_cyl(head, 0.036, 0.036, 0.03, m_leather, Vector3(0, 0.155, -0.02), Vector3(-0.5, 0, 0), 7)
			_cyl(head, 0.008, 0.008, 0.16, m_trim, Vector3(0, 0.2, -0.04), Vector3(0, 0, PI * 0.5), 5)
		"antler":
			# a hide cap with a stag's antlers, the tines worn smooth
			_hair_cap(head, m_fur)
			_loft(head, "hidecap", [[0.03, 0.104, 0.116, -0.008], [0.1, 0.094, 0.106, -0.012], [0.16, 0.052, 0.062, -0.016], [0.185, 0.005, 0.005, -0.016]], m_fur, Vector3.ZERO, Vector3.ZERO, 12)
			for s in [-1.0, 1.0]:
				var ant := Node3D.new()
				ant.position = Vector3(s * 0.07, 0.13, -0.01)
				ant.rotation = Vector3(-0.25, 0, -s * 0.55)
				head.add_child(ant)
				_cyl(ant, 0.014, 0.009, 0.24, m_bone, Vector3(0, 0.12, 0), Vector3.ZERO, 6)
				_cyl(ant, 0.009, 0.004, 0.16, m_bone, Vector3(-s * 0.03, 0.27, 0.03), Vector3(0.35, 0, s * 0.55), 5)
				_cyl(ant, 0.008, 0.003, 0.11, m_bone, Vector3(0.0, 0.12, 0.05), Vector3(0.9, 0, 0), 5)
				_cyl(ant, 0.007, 0.002, 0.09, m_bone, Vector3(s * 0.02, 0.24, -0.02), Vector3(-0.5, 0, -s * 0.3), 5)
			_hank(head, m_hair, rng)
		"skull":
			# a great beast's skull worn over the head, its horns swept back,
			# and the hide still hanging from it down the back
			_hair_cap(head, m_fur)
			var sk := Node3D.new()
			sk.position = Vector3(0, 0.12, 0.02)
			sk.rotation.x = 0.35
			head.add_child(sk)
			# cranium, then a long tapering muzzle reaching down over the brow
			_sphere(sk, 0.1, m_bone, Vector3(0, 0.02, -0.02), Vector3(1.0, 0.62, 1.05))
			_loft(sk, "muzzle", [[0.0, 0.07, 0.05, 0.0], [0.1, 0.055, 0.04, -0.005], [0.19, 0.035, 0.028, -0.012], [0.24, 0.012, 0.012, -0.016]], m_bone, Vector3(0, 0.0, 0.05), Vector3(PI * 0.5, 0, 0), 8)
			for i in range(4):
				_box(sk, Vector3(0.006, 0.014, 0.006), m_bone, Vector3(-0.024 + i * 0.016, -0.032, 0.2 - i * 0.0))
			for s in [-1.0, 1.0]:
				_sphere(sk, 0.022, m_black, Vector3(s * 0.058, 0.02, 0.07), Vector3(1.1, 0.9, 0.6))
				var hn := _cyl(sk, 0.024, 0.003, 0.34, m_bone, Vector3(s * 0.12, 0.06, -0.12), Vector3(-1.2, 0, -s * 0.85), 7)
				hn.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
			_box(head, Vector3(0.18, 0.4, 0.02), m_fur2, Vector3(0, -0.06, -0.13), Vector3(0.22, 0, 0))
		"wrap":
			var m_wrap := _mat(Color(0.5, 0.44, 0.34).lerp(cl, 0.35))
			_loft(head, "turban", [[0.055, 0.103, 0.114, -0.012], [0.11, 0.112, 0.122, -0.016], [0.17, 0.09, 0.1, -0.022], [0.215, 0.03, 0.035, -0.026]], m_wrap, Vector3.ZERO, Vector3.ZERO, 14)
			_loft(head, "veil", [[-0.15, 0.08, 0.085, 0.035], [-0.07, 0.095, 0.105, 0.018], [-0.02, 0.097, 0.108, 0.01]], m_cloth, Vector3.ZERO, Vector3.ZERO, 14)
			_box(head, Vector3(0.1, 0.32, 0.03), m_cloth2, Vector3(0, -0.12, -0.11), Vector3(0.25, 0, 0))
		_:
			_hair_cap(head, m_hair)
			if dust:
				_hank(head, m_hair, rng)
			if wid == "teblor":
				# long hair in two thick braids over the shoulders, and loose
				# locks down the back
				_hank(head, m_hair, rng)
				for sb: float in [-1.0, 1.0]:
					var br := Node3D.new()
					br.position = Vector3(sb * 0.085, 0.0, -0.02)
					br.rotation = Vector3(0.18, 0, sb * 0.1)
					head.add_child(br)
					for k in range(5):
						_sphere(br, 0.026 - k * 0.002, m_hair, Vector3(0, -0.05 - k * 0.055, 0.0), Vector3(1, 1.25, 1))
					_cyl(br, 0.011, 0.011, 0.02, m_trim, Vector3(0, -0.33, 0.0), Vector3.ZERO, 6)
			if wid == "andii":
				_loft(head, "longhair", [[-0.46, 0.045, 0.014, -0.03], [-0.32, 0.075, 0.022, -0.015], [-0.14, 0.088, 0.03, 0.0], [0.02, 0.092, 0.034, 0.015]], m_hair, Vector3(0, 0.02, -0.1), Vector3(0.12, 0, 0), 10)
	if u.is_leader() and u.helm != "antler" and u.helm != "skull":
		var plume := Node3D.new()
		plume.position = Vector3(0, 0.2 if u.helm != "great" else 0.27, -0.02)
		plume.rotation.x = -0.35
		head.add_child(plume)
		_loft(plume, "plume", [[0.0, 0.02, 0.02], [0.08, 0.03, 0.06, -0.03], [0.18, 0.02, 0.05, -0.1], [0.24, 0.005, 0.01, -0.16]], m_trim, Vector3.ZERO, Vector3.ZERO, 8)

	# --- stance, weapons and kit
	var melee := u.best_melee_weapon()
	var missile := u.missile()
	var bow_in_hand := missile != "" and (melee == "dagger" or melee == "fist" or melee == "")
	var caster := not u.spells.is_empty()
	var shield := u.gear.has("shield")
	_base = _rest_pose()
	_base["spine"] = Vector3(hunch, 0, 0)
	_base["head"] = Vector3(-hunch * 0.75, 0, 0)
	_base["neck"] = Vector3(-hunch * 0.2, 0, 0)
	var wpn := melee if not bow_in_hand else "dagger"
	var pose_w := "greatblade" if wpn == "bloodwood" else wpn
	match pose_w:
		"greatblade":
			_strike = "cleave"
			_base["sh_r"] = Vector3(-0.5, 0.0, 0.02)
			_base["el_r"] = Vector3(-1.05, 0, 0)
			_base["sh_l"] = Vector3(-0.62, 0.0, -0.02)
			_base["el_l"] = Vector3(-1.1, 0, 0)
			_base["spine"] += Vector3(0, 0.18, 0)
		"spear":
			_strike = "thrust"
			_base["sh_r"] = Vector3(-0.22, 0, 0.14)
			_base["el_r"] = Vector3(-1.25, 0, 0)
			_base["sh_l"] = Vector3(-0.45, 0, -0.1)
			_base["el_l"] = Vector3(-0.9, 0, 0)
		"dagger", "fist", "":
			_strike = "stab"
			_base["sh_r"] = Vector3(-0.2, 0, 0.14)
			_base["el_r"] = Vector3(-0.75, 0, 0)
		"chainflail":
			_strike = "flail"
			_base["sh_r"] = Vector3(-0.3, 0, 0.16)
			_base["el_r"] = Vector3(-0.8, 0, 0)
		_:
			_strike = "slash"
			_base["sh_r"] = Vector3(-0.32, 0, 0.15)
			_base["el_r"] = Vector3(-0.95, 0, 0)
	if u.dual_wield():
		_base["sh_l"] = Vector3(-0.32, 0, -0.15)
		_base["el_l"] = Vector3(-0.95, 0, 0)
	if shield:
		_base["sh_l"] = Vector3(-0.42, 0, -0.22)
		_base["el_l"] = Vector3(-1.12, 0, 0)
	if caster:
		_base["sh_l"] = Vector3(-0.16, 0, -0.16)
		_base["el_l"] = Vector3(-1.15, 0, 0)
	if bow_in_hand and missile != "crossbow" and missile != "moranthbow" and missile != "sling" and missile != "knives" and missile != "javelins":
		_base["sh_l"] = Vector3(-0.22, 0, -0.12)
		_base["el_l"] = Vector3(-0.8, 0, 0)
	elif bow_in_hand and (missile == "crossbow" or missile == "moranthbow"):
		_base["sh_r"] = Vector3(-0.3, 0, 0.12)
		_base["el_r"] = Vector3(-1.0, 0, 0)
		_base["sh_l"] = Vector3(-0.42, 0, -0.18)
		_base["el_l"] = Vector3(-0.95, 0, 0)
	_aim_pose = _base.duplicate()
	var is_bow := missile == "shortbow" or missile == "longbow"
	if is_bow:
		_aim_pose["sh_l"] = Vector3(-1.5, 0.0, -0.08)
		_aim_pose["el_l"] = Vector3(-0.06, 0, 0)
		_aim_pose["sh_r"] = Vector3(-1.45, -0.55, 0.2)
		_aim_pose["el_r"] = Vector3(-2.2, 0, 0)
		_aim_pose["spine"] = _base["spine"] + Vector3(0, 0.35, 0)
		_aim_pose["head"] = _base["head"] + Vector3(0, -0.35, 0)
	else:
		_aim_pose["sh_r"] = Vector3(-1.45, 0, 0.05)
		_aim_pose["el_r"] = Vector3(-0.15, 0, 0)
		_aim_pose["sh_l"] = Vector3(-1.3, 0, -0.28)
		_aim_pose["el_l"] = Vector3(-0.5, 0, 0)
		_aim_pose["head"] = _base["head"] + Vector3(0.12, 0, 0)

	# held weapons are set in the hand so they sit right in the stance
	_apply(_base)
	var grip_r := Node3D.new()
	hand_r.add_child(grip_r)
	grip_r.position = Vector3(0, -0.045, 0.0)
	var grip_l := Node3D.new()
	hand_l.add_child(grip_l)
	grip_l.position = Vector3(0, -0.045, 0.0)
	var wdir := Vector3(0.12, 0.78, 0.62)
	match pose_w:
		"greatblade":
			wdir = Vector3(-0.32, 0.82, 0.45)
		"spear":
			wdir = Vector3(0.0, 0.62, 0.8)
		"dagger", "fist", "":
			wdir = Vector3(0.05, 0.35, 1.0)
		"chainflail":
			wdir = Vector3(0.1, 0.4, 1.0)
	_orient(grip_r, wdir)
	var item := _weapon(grip_r, wpn, m_iron, m_leather, m_trim)
	if item != null:
		_hand_items.append(item)
	if u.dual_wield():
		_orient(grip_l, Vector3(-wdir.x, wdir.y, wdir.z))
		var item2 := _weapon(grip_l, melee, m_iron, m_leather, m_trim)
		if item2 != null:
			_hand_items.append(item2)
	if shield:
		var sg := Node3D.new()
		el_l.add_child(sg)
		sg.position = Vector3(-0.04, -0.15, 0.0)
		_orient_basis(sg, Basis.IDENTITY)
		var face := Node3D.new()
		face.position = Vector3(0, 0, 0.07)
		sg.add_child(face)
		_cyl(face, 0.3, 0.3, 0.045, m_cloth, Vector3.ZERO, Vector3(PI * 0.5, 0, 0), 20)
		_sphere(face, 0.075, m_iron, Vector3(0, 0, 0.02), Vector3(1, 1, 0.6))
		var rimt := TorusMesh.new()
		rimt.inner_radius = 0.28
		rimt.outer_radius = 0.315
		rimt.rings = 20
		_part(face, rimt, m_trim, Vector3.ZERO, Vector3(PI * 0.5, 0, 0))
		_box(face, Vector3(0.05, 0.5, 0.01), m_trim, Vector3(0, 0, 0.026))
		for i in range(10):
			var a: float = TAU * i / 10.0
			_sphere(face, 0.012, m_brass, Vector3(cos(a) * 0.255, sin(a) * 0.255, 0.024))
	if caster:
		var sgrip := Node3D.new()
		hand_l.add_child(sgrip)
		sgrip.position = Vector3(0, -0.045, 0)
		_orient(sgrip, Vector3(0.04, 1.0, 0.1))
		_cyl(sgrip, 0.022, 0.018, 1.75, m_leather, Vector3(0, 0, 0.35), Vector3(PI * 0.5, 0, 0), 7)
		_sphere(sgrip, 0.04, m_leather, Vector3(0, 0, 1.2), Vector3(1, 1, 1.4))
		var gl := Mats.glow(_warren_color(u.warren), 4.0)
		var orb := _sphere(sgrip, 0.055, gl, Vector3(0, 0, 1.3))
		orb.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	if missile != "":
		# the shooting weapon: in hand for bowmen, on the back otherwise, and
		# swapped into the hands when they shoot
		_apply(_aim_pose)
		var ag := Node3D.new()
		var in_left := is_bow
		(hand_l if in_left else hand_r).add_child(ag)
		ag.position = Vector3(0, -0.045, 0)
		if is_bow:
			_orient_basis(ag, Basis.IDENTITY)
		else:
			_orient(ag, Vector3(0, 0.05, 1))
		_missile(ag, missile, m_leather, m_iron)
		_aim_item = ag
		_apply(_base)
		if not bow_in_hand:
			ag.visible = false
			var back := Node3D.new()
			back.position = Vector3(0.02, 0.3 * b, -0.17 * b)
			back.rotation = Vector3(0, 0, 0.75)
			spine.add_child(back)
			var bb := Node3D.new()
			bb.rotation = Vector3(-PI * 0.5, 0, 0) if missile == "crossbow" or missile == "moranthbow" else Vector3.ZERO
			back.add_child(bb)
			_missile(bb, missile, m_leather, m_iron)
			_back_item = back
		if is_bow:
			var q := _cyl(spine, 0.05, 0.05, 0.5, m_leather, Vector3(-0.08 * b, 0.28 * b, -0.15 * b), Vector3(0.2, 0, 0.35), 8)
			for i in range(4):
				_box(q, Vector3(0.02, 0.07, 0.005), _mat(Color(0.75, 0.72, 0.65)), Vector3(-0.02 + i * 0.013, 0.28, 0.0))
	if u.has_munitions():
		for i in range(3):
			_sphere(root, 0.045, _mat(Color(0.5, 0.42, 0.3), 0.6), Vector3((-0.13 + i * 0.07) * b, 0.04, 0.13 * b))

	# floating name
	label = Label3D.new()
	label.text = u.name
	label.font = font()
	label.font_size = 26
	label.outline_size = 8
	label.outline_modulate = Color(0, 0, 0, 0.85)
	label.modulate = cloth.lightened(0.55)
	label.pixel_size = 0.0008
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.no_depth_test = true
	label.fixed_size = true
	label.position = Vector3(0, 2.25, 0)
	label.render_priority = 5
	label.visibility_range_end = 34.0
	label.visibility_range_end_margin = 6.0
	label.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_SELF
	# silhouette shown only where walls hide the figure
	var xm := ShaderMaterial.new()
	xm.shader = load("res://shaders/xray.gdshader")
	xm.set_shader_parameter("tint", Color(cloth.lightened(0.3), 0.24))
	xm.render_priority = 2
	var xc := CapsuleMesh.new()
	xc.radius = 0.42
	xc.height = 2.0
	xc.radial_segments = 12
	xc.rings = 4
	xray = _part(self, xc, xm, Vector3(0, 1.0, 0))
	xray.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	xray.visible = false
	add_child(label)

	# some peoples stand taller than humans
	var tall: float = float(wb.get("tall", 1.0))
	if tall != 1.0:
		body.scale = Vector3(1.0 + (tall - 1.0) * 0.5, tall, 1.0 + (tall - 1.0) * 0.5)
	stars = Node3D.new()
	stars.position = Vector3(0, 0.6, 0)
	stars.visible = false
	add_child(stars)
	for i in range(4):
		var st := _sphere(stars, 0.05, Mats.glow(Color(1.0, 0.85, 0.4), 4.0), Vector3(cos(i * PI * 0.5) * 0.35, 0, sin(i * PI * 0.5) * 0.35))
		st.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	# figures draw on layer 2 (the portrait camera sees only them, and the
	# movement area is not painted on them); markers on layer 3
	_layer(self, 2)
	for n in [label, ring, xray, stars]:
		_layer(n, 4)
	_time = _phase * 3.0

static func _link_mesh() -> Mesh:
	if not _meshes.has("chainlink"):
		var t := TorusMesh.new()
		t.inner_radius = 0.013
		t.outer_radius = 0.022
		t.rings = 8
		t.ring_segments = 5
		_meshes["chainlink"] = t
	return _meshes["chainlink"]

func _hair_cap(head: Node3D, m: Material) -> void:
	_loft(head, "hair", [[-0.02, 0.098, 0.112, -0.02], [0.06, 0.102, 0.114, -0.01], [0.12, 0.09, 0.1, -0.014], [0.16, 0.06, 0.07, -0.016], [0.182, 0.01, 0.012, -0.016]], m, Vector3.ZERO, Vector3.ZERO, 14)

func _belt(b: float, m_leather: Material, m_buckle: Material) -> void:
	_loft(root, "belt%.2f" % b, _scaled([[0.06, 0.168, 0.114], [0.12, 0.166, 0.112]], b, b), m_leather)
	_box(root, Vector3(0.06, 0.055, 0.015), m_buckle, Vector3(0, 0.09, 0.114 * b + 0.004))

func _panels(m: Material, w: float, length: float, z: float, back := true) -> void:
	## Tabard panels that hang from the belt and swing with the legs.
	_panel_f = Node3D.new()
	_panel_f.position = Vector3(0, 0.12, z)
	root.add_child(_panel_f)
	_part(_panel_f, sheet("tabard%.2f%.2f" % [w, length], w, w * 1.08, length * 0.55, 0.0, 3, 2), m, Vector3.ZERO, Vector3(0, PI, 0))
	if back:
		_panel_b = Node3D.new()
		_panel_b.position = Vector3(0, 0.12, -z)
		root.add_child(_panel_b)
		_part(_panel_b, sheet("tabard%.2f%.2f" % [w, length], w, w * 1.08, length * 0.55, 0.0, 3, 2), m, Vector3.ZERO)

func _hank(head: Node3D, m: Material, rng: RandomNumberGenerator) -> void:
	## Long, thin, matted locks hanging from the back and sides of the head.
	for i in range(5):
		var a: float = -1.5 + i * 0.75 + rng.randf_range(-0.12, 0.12)
		var ln: float = rng.randf_range(0.22, 0.36)
		var lk := _cyl(head, 0.014, 0.006, ln, m, Vector3(sin(a) * 0.095, 0.03 - ln * 0.45, -cos(a) * 0.075 - 0.01), Vector3(-0.12, 0, sin(a) * 0.12), 5)
		lk.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

func _cloak_on(spine: Node3D, b: float, m: Material, length: float) -> void:
	_cloak = Node3D.new()
	_cloak.position = Vector3(0, 0.47 * b, -0.1 * b)
	spine.add_child(_cloak)
	_part(_cloak, sheet("cloak%.2f%.2f" % [b, length], 0.4 * b, 0.62 * b, length, 0.1 * b), m, Vector3.ZERO)
	_loft(_cloak, "clasp%.2f" % b, [[-0.03, 0.2 * b, 0.07 * b, 0.07 * b], [0.03, 0.17 * b, 0.06 * b, 0.07 * b]], m, Vector3.ZERO, Vector3.ZERO, 10)

# ------------------------------------------------------------------ posing

func _rest_pose() -> Dictionary:
	return {
		"root": Vector3.ZERO, "spine": Vector3.ZERO, "neck": Vector3.ZERO, "head": Vector3.ZERO,
		"sh_l": Vector3(-0.06, 0, -0.1), "el_l": Vector3(-0.25, 0, 0),
		"sh_r": Vector3(-0.06, 0, 0.1), "el_r": Vector3(-0.25, 0, 0),
		"hip_l": Vector3(-0.04, 0, -0.03), "kn_l": Vector3(0.08, 0, 0), "ft_l": Vector3(-0.04, -0.12, 0),
		"hip_r": Vector3(0.04, 0, 0.03), "kn_r": Vector3(0.06, 0, 0), "ft_r": Vector3(-0.1, 0.12, 0)}

func _apply(p: Dictionary) -> void:
	for k in p:
		if J.has(k):
			(J[k] as Node3D).rotation = p[k]

func _chain_basis(n: Node3D) -> Basis:
	var bs := Basis.IDENTITY
	var cur: Node = n
	while cur != null and cur != body and cur != self:
		bs = (cur as Node3D).transform.basis * bs
		cur = cur.get_parent()
	return bs

func _orient(grip: Node3D, dir: Vector3) -> void:
	## Turns grip so its +Z points along `dir` (in figure space) in the
	## current pose.
	var d := dir.normalized()
	var up := Vector3.UP if absf(d.y) < 0.95 else Vector3.BACK
	_orient_basis(grip, Basis.looking_at(-d, up))

func _orient_basis(grip: Node3D, want: Basis) -> void:
	var parent_b := _chain_basis(grip.get_parent() as Node3D)
	grip.transform.basis = parent_b.inverse() * want

# ------------------------------------------------------------------ weapons

func _warren_color(w: String) -> Color:
	match w:
		"meanas":
			return Color(0.55, 0.45, 1.0)
		"denul":
			return Color(0.5, 1.0, 0.6)
		"serc":
			return Color(0.6, 0.85, 1.0)
		"dryjhna":
			return Color(1.0, 0.75, 0.35)
		"chains":
			return Color(1.0, 0.3, 0.25)
		"kurald":
			return Color(0.42, 0.3, 0.75)
		"spirits":
			return Color(0.85, 0.92, 0.72)
		"tellann":
			return Color(1.0, 0.55, 0.22)
	return Color(0.8, 0.8, 1.0)

func _weapon(h: Node3D, w: String, m_iron: Material, m_leather: Material, m_trim: Material) -> Node3D:
	## Builds a weapon along +Z of a new node under h.
	var n := Node3D.new()
	h.add_child(n)
	# the shard market's rare blades borrow a common shape in a stranger metal
	if w == "otataral":
		w = "dagger"
		m_iron = _mat(Color(0.45, 0.17, 0.09), 0.75, 0.35, 0.3)
	elif w == "darkforged":
		w = "sword"
		m_iron = _mat(Color(0.05, 0.05, 0.06), 0.25, 0.9, 0.5)
	match w:
		"sword", "tulwar":
			_cyl(n, 0.018, 0.018, 0.13, m_leather, Vector3(0, 0, 0.0), Vector3(PI * 0.5, 0, 0), 6)
			_sphere(n, 0.03, m_trim, Vector3(0, 0, -0.075))
			_box(n, Vector3(0.17, 0.028, 0.035), m_trim, Vector3(0, 0, 0.075))
			var blade := _loft(n, "blade" + w, [[0.09, 0.024, 0.006], [0.55, 0.021, 0.005], [0.72, 0.012, 0.004], [0.8, 0.001, 0.001]], m_iron, Vector3.ZERO, Vector3(PI * 0.5, 0, 0), 6)
			if w == "tulwar":
				blade.rotation.y = 0.1
				blade.scale = Vector3(1.5, 1, 1)
		"flintsword":
			# a long leaf of knapped flint on a bone grip bound with hide
			_cyl(n, 0.019, 0.019, 0.15, m_leather, Vector3(0, 0, 0.0), Vector3(PI * 0.5, 0, 0), 6)
			_sphere(n, 0.028, m_trim, Vector3(0, 0, -0.085), Vector3(1, 1, 0.7))
			_loft(n, "flintblade", [[0.07, 0.028, 0.014], [0.2, 0.05, 0.018], [0.42, 0.054, 0.017], [0.62, 0.04, 0.014], [0.78, 0.016, 0.008], [0.84, 0.001, 0.001]], m_iron, Vector3.ZERO, Vector3(PI * 0.5, 0, 0), 4)
			for i in range(5):
				# knapping scars along the edge
				var z: float = 0.16 + i * 0.12
				var kn := _box(n, Vector3(0.03, 0.006, 0.02), m_trim, Vector3(0.0, 0.0, z), Vector3(0, 0.6 * (1 if i % 2 == 0 else -1), 0))
				kn.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		"dagger":
			_cyl(n, 0.016, 0.016, 0.1, m_leather, Vector3.ZERO, Vector3(PI * 0.5, 0, 0), 6)
			_box(n, Vector3(0.08, 0.02, 0.02), m_trim, Vector3(0, 0, 0.055))
			_loft(n, "dagblade", [[0.06, 0.02, 0.005], [0.22, 0.012, 0.004], [0.28, 0.001, 0.001]], m_iron, Vector3.ZERO, Vector3(PI * 0.5, 0, 0), 6)
		"axe":
			_cyl(n, 0.02, 0.022, 0.65, m_leather, Vector3(0, 0, 0.22), Vector3(PI * 0.5, 0, 0), 6)
			_loft(n, "axehead", [[0.0, 0.025, 0.06], [0.1, 0.012, 0.075, 0.0], [0.16, 0.006, 0.11]], m_iron, Vector3(0, 0, 0.47), Vector3(0, 0, PI * 0.5), 8)
		"mace":
			_cyl(n, 0.02, 0.022, 0.55, m_leather, Vector3(0, 0, 0.2), Vector3(PI * 0.5, 0, 0), 6)
			_sphere(n, 0.07, m_iron, Vector3(0, 0, 0.48))
			for i in range(6):
				_box(n, Vector3(0.02, 0.17, 0.08), m_iron, Vector3(0, 0, 0.48), Vector3(0, 0, i * PI / 6.0))
		"spear":
			_cyl(n, 0.02, 0.02, 2.1, m_leather, Vector3(0, 0, 0.45), Vector3(PI * 0.5, 0, 0), 6)
			_loft(n, "spearhead", [[0.0, 0.02, 0.012], [0.08, 0.04, 0.01], [0.26, 0.001, 0.001]], m_iron, Vector3(0, 0, 1.5), Vector3(PI * 0.5, 0, 0), 6)
		"greatblade":
			_cyl(n, 0.022, 0.022, 0.32, m_leather, Vector3(0, 0, -0.06), Vector3(PI * 0.5, 0, 0), 6)
			_sphere(n, 0.035, m_trim, Vector3(0, 0, -0.23))
			_box(n, Vector3(0.28, 0.04, 0.05), m_trim, Vector3(0, 0, 0.11))
			_loft(n, "greatblade", [[0.13, 0.036, 0.008], [1.05, 0.03, 0.007], [1.22, 0.014, 0.005], [1.32, 0.001, 0.001]], m_iron, Vector3.ZERO, Vector3(PI * 0.5, 0, 0), 6)
		"bloodwood":
			# a huge sword carved from one piece of red bloodwood: a hide-
			# wrapped hilt, no guard, a broad blade with a dark grain
			var m_wood := _mat(Color(0.34, 0.1, 0.07), 0.58, 0.0, 0.25)
			var m_grain := _mat(Color(0.22, 0.05, 0.03), 0.5, 0.0, 0.2)
			_cyl(n, 0.026, 0.026, 0.34, m_leather, Vector3(0, 0, -0.06), Vector3(PI * 0.5, 0, 0), 6)
			_sphere(n, 0.04, m_wood, Vector3(0, 0, -0.25), Vector3(1, 1, 0.8))
			# a flat, sharp-edged blade (a diamond in section), widest past the hilt
			_loft(n, "bloodblade2", [[0.1, 0.05, 0.012], [0.2, 0.082, 0.014], [0.85, 0.076, 0.013], [1.2, 0.058, 0.011], [1.42, 0.001, 0.003]], m_wood, Vector3.ZERO, Vector3(PI * 0.5, 0, 0), 4)
			# a dark fuller of grain up the middle of each face
			for sd in [-1.0, 1.0]:
				var gl := _box(n, Vector3(0.016, 0.002, 0.95), m_grain, Vector3(0.0, sd * 0.0125, 0.68))
				gl.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		"chainflail":
			_cyl(n, 0.024, 0.024, 0.45, m_leather, Vector3(0, 0, 0.15), Vector3(PI * 0.5, 0, 0), 6)
			for i in range(4):
				_box(n, Vector3(0.03, 0.03, 0.06), m_iron, Vector3(0, -0.05 * i, 0.4 + 0.04 * i))
			var ball := _sphere(n, 0.1, m_iron, Vector3(0, -0.25, 0.55))
			for i in range(6):
				var d := Vector3(cos(i * 1.05), sin(i * 1.7), sin(i * 1.05)).normalized()
				_cyl(ball, 0.025, 0.0, 0.09, m_iron, d * 0.09, Basis.looking_at(d).get_euler() + Vector3(PI * 0.5, 0, 0), 4)
		_:
			n.queue_free()
			return null
	return n

func _missile(h: Node3D, w: String, m_leather: Material, m_iron: Material) -> void:
	## Built in the hand's frame: +Z forward, +Y up when held for shooting.
	if w == "moranthbow":
		# Moranth work: a stock of black lacquered chitin, green-tinted arms
		w = "crossbow"
		m_leather = _mat(Color(0.06, 0.07, 0.06), 0.3, 0.2, 0.5)
		m_iron = _mat(Color(0.16, 0.3, 0.2), 0.35, 0.5, 0.4)
	match w:
		"crossbow":
			_box(h, Vector3(0.06, 0.07, 0.62), m_leather, Vector3(0, 0.0, 0.18))
			_loft(h, "xbowarms", [[-0.32, 0.012, 0.02], [0.0, 0.022, 0.03], [0.32, 0.012, 0.02]], m_iron, Vector3(0, 0.03, 0.44), Vector3(0, 0, PI * 0.5), 6)
			_box(h, Vector3(0.62, 0.006, 0.006), _mat(Color(0.75, 0.72, 0.65)), Vector3(0, 0.03, 0.36))
		"shortbow", "longbow":
			var l := 1.0 if w == "shortbow" else 1.45
			var arc: Array = []
			for i in range(9):
				var v := float(i) / 8.0 * 2.0 - 1.0
				arc.append([v * l * 0.5, 0.016 * (1.2 - absf(v) * 0.6), 0.02 * (1.2 - absf(v) * 0.6), 0.1 * (1.0 - v * v) - 0.02])
			_loft(h, "bow" + w, arc, m_leather, Vector3.ZERO, Vector3.ZERO, 6)
			_box(h, Vector3(0.004, l * 0.98, 0.004), _mat(Color(0.8, 0.78, 0.7)), Vector3(0, 0, -0.015))
		"sling":
			_box(h, Vector3(0.015, 0.35, 0.015), m_leather, Vector3(0, -0.15, 0.02))
			_sphere(h, 0.04, m_leather, Vector3(0, -0.33, 0.02))
		"knives":
			for i in range(3):
				_box(h, Vector3(0.025, 0.01, 0.18), m_iron, Vector3(-0.04 + i * 0.04, 0.0, 0.08))
		"javelins":
			for i in range(3):
				_cyl(h, 0.012, 0.012, 1.3, m_leather, Vector3(-0.03 + i * 0.03, 0.0, 0.25), Vector3(PI * 0.5, 0, 0.05 * (i - 1)), 5)
				_cyl(h, 0.018, 0.0, 0.12, m_iron, Vector3(-0.03 + i * 0.03, 0.0, 0.96), Vector3(PI * 0.5, 0, 0), 5)

# ------------------------------------------------------------------ actions

func set_selected(kind: String) -> void:
	## kind: "", "active", "target", "ally"
	ring.visible = kind != ""
	var c := Color(0.3, 1.0, 0.85)
	if kind == "target":
		c = Color(1.0, 0.3, 0.2)
	elif kind == "ally":
		c = Color(0.9, 0.85, 0.5)
	ring.material_override = Mats.glow(c, 3.0, true)

func _act(keys: Array, dur: float, on_end := Callable()) -> void:
	## Plays a move. keys: [{"t": 0..1, joint: euler, ...}, ...]; each key
	## carries forward the joints it does not name, and the move eases in
	## from and out to whatever the figure was doing.
	var full: Array = []
	var prev := {}
	for k in keys:
		var d: Dictionary = (k as Dictionary).duplicate()
		for j in prev:
			if not d.has(j):
				d[j] = prev[j]
		full.append(d)
		prev = d
	_act_keys = full
	_act_t = 0.0
	_act_dur = maxf(dur, 0.05)
	_act_end = on_end

func _b(j: String) -> Vector3:
	return _base.get(j, Vector3.ZERO)

func face_point(p: Vector3) -> void:
	var d := p - global_position
	d.y = 0
	if d.length() > 0.05:
		rotation.y = atan2(d.x, d.z)

func lunge(at: Vector3, spd := 1.0) -> Tween:
	face_point(at)
	var fwd := (at - global_position)
	fwd.y = 0
	fwd = fwd.normalized() * 0.32
	var step := fwd.rotated(Vector3.UP, -rotation.y)
	var lunge_legs := {"hip_l": Vector3(-0.75, 0, -0.05), "kn_l": Vector3(0.75, 0, 0), "ft_l": Vector3(-0.05, 0, 0),
		"hip_r": Vector3(0.45, 0, 0.05), "kn_r": Vector3(0.2, 0, 0), "ft_r": Vector3(-0.5, 0, 0)}
	var keys: Array = []
	match _strike:
		"cleave":
			var up := {"t": 0.35, "sh_r": Vector3(-2.9, 0.2, 0.15), "el_r": Vector3(-0.9, 0, 0), "sh_l": Vector3(-2.9, -0.2, -0.15), "el_l": Vector3(-0.9, 0, 0), "spine": _b("spine") + Vector3(-0.22, 0.1, 0), "head": Vector3(0.1, 0, 0)}
			var down := {"t": 0.52, "sh_r": Vector3(-0.9, 0, 0.1), "el_r": Vector3(-0.2, 0, 0), "sh_l": Vector3(-0.95, 0, -0.1), "el_l": Vector3(-0.2, 0, 0), "spine": _b("spine") + Vector3(0.38, 0, 0), "head": Vector3(-0.25, 0, 0)}
			down.merge(lunge_legs)
			keys = [up, down, {"t": 0.72}]
		"thrust":
			var back := {"t": 0.3, "sh_r": Vector3(0.1, 0, 0.18), "el_r": Vector3(-1.6, 0, 0), "spine": _b("spine") + Vector3(0, 0.35, 0)}
			var out := {"t": 0.48, "sh_r": Vector3(-1.2, 0, 0.05), "el_r": Vector3(-0.35, 0, 0), "sh_l": Vector3(-1.0, 0, -0.1), "el_l": Vector3(-0.5, 0, 0), "spine": _b("spine") + Vector3(0.22, -0.3, 0)}
			out.merge(lunge_legs)
			keys = [back, out, {"t": 0.72}]
		"stab":
			var back2 := {"t": 0.28, "sh_r": Vector3(0.2, 0, 0.2), "el_r": Vector3(-1.4, 0, 0), "spine": _b("spine") + Vector3(0, 0.3, 0)}
			var out2 := {"t": 0.45, "sh_r": Vector3(-1.35, 0, 0.0), "el_r": Vector3(-0.15, 0, 0), "spine": _b("spine") + Vector3(0.25, -0.35, 0)}
			out2.merge(lunge_legs)
			keys = [back2, out2, {"t": 0.7}]
		_:
			# a rising cut drawn back over the shoulder, then brought down across
			var wind := {"t": 0.32, "sh_r": Vector3(-2.6, -0.3, 0.55), "el_r": Vector3(-1.2, 0, 0), "spine": _b("spine") + Vector3(-0.1, 0.42, 0), "head": Vector3(0, -0.3, 0)}
			var cut := {"t": 0.5, "sh_r": Vector3(-0.85, 0.5, -0.25), "el_r": Vector3(-0.3, 0, 0), "spine": _b("spine") + Vector3(0.28, -0.42, 0), "head": Vector3(-0.1, 0.25, 0)}
			cut.merge(lunge_legs)
			if _hand_items.size() > 1:
				cut["sh_l"] = Vector3(-2.2, 0.3, -0.5)
				cut["el_l"] = Vector3(-1.1, 0, 0)
			keys = [wind, cut, {"t": 0.72}]
	_act(keys, 0.85 / spd)
	var tw := create_tween()
	tw.tween_interval(0.3 / spd)
	tw.tween_property(body, "position", step, 0.14 / spd).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.tween_interval(0.15 / spd)
	tw.tween_property(body, "position", Vector3.ZERO, 0.26 / spd)
	return tw

func aim(at: Vector3, spd := 1.0) -> void:
	face_point(at)
	var draw := _aim_pose.duplicate()
	draw["t"] = 0.35
	var hold := draw.duplicate()
	hold["t"] = 0.75
	if _back_item != null:
		_back_item.visible = false
		for it in _hand_items:
			it.visible = false
		if _aim_item != null:
			_aim_item.visible = true
	_act([draw, hold], 1.1 / spd, _put_away)

func _put_away() -> void:
	if _back_item != null:
		_back_item.visible = true
		for it in _hand_items:
			it.visible = true
		if _aim_item != null:
			_aim_item.visible = false

func throw_at(at: Vector3, spd := 1.0) -> void:
	face_point(at)
	var wind := {"t": 0.35, "sh_r": Vector3(-2.7, 0, 0.35), "el_r": Vector3(-1.4, 0, 0), "sh_l": Vector3(-1.2, 0, -0.3), "el_l": Vector3(-0.3, 0, 0),
		"spine": _b("spine") + Vector3(-0.15, 0.45, 0), "hip_l": Vector3(-0.4, 0, 0), "kn_l": Vector3(0.3, 0, 0), "hip_r": Vector3(0.25, 0, 0)}
	var rel := {"t": 0.55, "sh_r": Vector3(-1.1, 0, -0.1), "el_r": Vector3(-0.1, 0, 0), "sh_l": Vector3(-0.2, 0, -0.3), "el_l": Vector3(-0.5, 0, 0),
		"spine": _b("spine") + Vector3(0.3, -0.4, 0), "hip_l": Vector3(-0.6, 0, 0), "kn_l": Vector3(0.6, 0, 0), "hip_r": Vector3(0.45, 0, 0)}
	_act([wind, rel, {"t": 0.75}], 0.95 / spd)

func cast_anim(spd := 1.0) -> void:
	var raise := {"t": 0.3, "sh_l": Vector3(-1.45, 0, -0.2), "el_l": Vector3(-0.35, 0, 0), "sh_r": Vector3(-1.5, 0.25, 0.3), "el_r": Vector3(-0.25, 0, 0),
		"spine": _b("spine") + Vector3(-0.15, 0, 0), "head": _b("head") + Vector3(-0.25, 0, 0)}
	var hold := raise.duplicate()
	hold["t"] = 0.6
	hold["sh_r"] = Vector3(-1.7, 0.25, 0.35)
	_act([raise, hold, {"t": 0.8}], 1.3 / spd)

func flinch(from := Vector3.ZERO, heavy := false) -> void:
	## A blow lands: the figure is rocked back, away from the attacker.
	if _status != "ok":
		return
	var back := Vector3.ZERO
	if from != Vector3.ZERO:
		back = global_position - from
		back.y = 0
		back = back.normalized().rotated(Vector3.UP, -rotation.y) * (0.32 if heavy else 0.2)
	var k := {"t": 0.15, "spine": _b("spine") + Vector3(-0.35 if heavy else -0.22, 0.15, 0.1), "head": Vector3(-0.35, 0.2, 0.15), "neck": Vector3(-0.15, 0, 0),
		"sh_l": Vector3(-0.5, 0, -0.75), "el_l": Vector3(-0.9, 0, 0), "sh_r": Vector3(-0.4, 0, 0.7), "el_r": Vector3(-0.8, 0, 0),
		"hip_l": Vector3(0.2, 0, 0), "kn_l": Vector3(0.4, 0, 0), "hip_r": Vector3(-0.35, 0, 0), "kn_r": Vector3(0.5, 0, 0)}
	_act([k, {"t": 0.4}], 0.75)
	var tw := create_tween()
	tw.tween_property(body, "position", back, 0.07)
	tw.tween_property(body, "position", Vector3.ZERO, 0.4).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

func set_status(s: String) -> void:
	_status = s
	stars.visible = s == "stunned"
	var tw := create_tween()
	match s:
		"ok":
			# push up off the stones and find the feet
			tw.tween_property(body, "rotation", Vector3(-0.7, 0, 0.0), 0.3)
			tw.parallel().tween_property(body, "position", Vector3(0, 0.08, -0.15), 0.3)
			tw.tween_property(body, "rotation", Vector3.ZERO, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
			tw.parallel().tween_property(body, "position", Vector3.ZERO, 0.35)
		"down", "stunned":
			# stagger, then go over backwards and hit the stones
			tw.tween_property(body, "rotation", Vector3(-0.35, 0, 0.15), 0.14)
			tw.parallel().tween_property(body, "position", Vector3(0, 0.0, -0.2), 0.14)
			tw.tween_property(body, "rotation", Vector3(-PI * 0.5, 0, 0.12), 0.3).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
			tw.parallel().tween_property(body, "position", Vector3(0, 0.12, -0.3), 0.3)
			tw.tween_property(body, "rotation", Vector3(-PI * 0.46, 0, 0.1), 0.08)
			tw.tween_property(body, "rotation", Vector3(-PI * 0.5, 0, 0.12), 0.12)
		"ooa" when _dust:
			_crumble(tw)
		"ooa":
			# buckle at the knees, then pitch forward onto the face
			tw.tween_property(body, "position", Vector3(0, -0.3, 0.05), 0.22)
			tw.parallel().tween_property(body, "rotation", Vector3(0.3, 0, -0.1), 0.22)
			tw.tween_property(body, "rotation", Vector3(PI * 0.5, 0, -0.25), 0.38).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
			tw.parallel().tween_property(body, "position", Vector3(0, 0.12, 0.3), 0.38)
			tw.tween_property(body, "rotation", Vector3(PI * 0.46, 0, -0.25), 0.07)
			tw.tween_property(body, "rotation", Vector3(PI * 0.5, 0, -0.25), 0.1)
			tw.tween_interval(1.6)
			tw.tween_property(self, "scale", Vector3(1, 0.01, 1), 0.5)
			tw.tween_callback(func(): visible = false)

func _crumble(tw: Tween) -> void:
	## The Imass do not die, they come apart: a shudder, then the dried flesh
	## and bone give way and pour down into a heap of dust.
	var sh := tw
	for k in 5:
		var a := 0.05 * (1.0 - k / 5.0)
		sh.tween_property(body, "rotation", Vector3(randf_range(-a, a), 0, randf_range(-a, a)), 0.05)
	sh.tween_callback(func():
		var sfx := get_tree().root.get_node_or_null("Sfx")   # absent in the look-dev scripts
		if sfx != null:
			sfx.play("crumble", global_position, -1.0, 0.08)
		_dust_burst())
	sh.tween_property(body, "scale", Vector3(1.25, 0.04, 1.25), 1.1).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	sh.parallel().tween_property(body, "rotation", Vector3(0.25, 0, -0.1), 1.1)
	sh.tween_callback(func(): body.visible = false)
	# the base goes the way every fallen fighter's does; the heap of dust stays
	sh.tween_interval(1.2)
	sh.tween_property(self, "scale", Vector3(1, 0.01, 1), 0.5)
	sh.tween_callback(func(): visible = false)

func _dust_burst() -> void:
	var at := global_position
	var host := get_parent()
	if host == null:
		return
	# the fine dust: a column that slumps and drifts off on the air
	var g := GPUParticles3D.new()
	g.one_shot = true
	g.amount = 70
	g.lifetime = 2.6
	g.explosiveness = 0.5
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(0.2, 0.7, 0.2)
	pm.direction = Vector3(0.3, -0.2, 0.1)
	pm.spread = 80.0
	pm.initial_velocity_min = 0.15
	pm.initial_velocity_max = 0.7
	pm.gravity = Vector3(0.3, -0.9, 0.1)
	pm.damping_min = 0.6
	pm.damping_max = 1.4
	pm.scale_min = 0.4
	pm.scale_max = 1.2
	var grad := Gradient.new()
	grad.set_color(0, Color(0.46, 0.41, 0.34, 0.0))
	grad.add_point(0.1, Color(0.46, 0.41, 0.34, 0.28))
	grad.add_point(0.5, Color(0.4, 0.36, 0.31, 0.16))
	grad.set_color(grad.get_point_count() - 1, Color(0.36, 0.33, 0.3, 0.0))
	var gt := GradientTexture1D.new()
	gt.gradient = grad
	pm.color_ramp = gt
	g.process_material = pm
	var q := QuadMesh.new()
	q.size = Vector2(0.55, 0.55)
	var m := StandardMaterial3D.new()
	m.roughness = 1.0
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.vertex_color_use_as_albedo = true
	m.albedo_texture = CityBuilder._soft_dot()
	q.material = m
	g.draw_pass_1 = q
	host.add_child(g)
	g.global_position = at + Vector3(0, 0.9, 0)
	g.emitting = true
	# the bits that do not blow away: flakes of hide and bone that rain down
	var c := GPUParticles3D.new()
	c.one_shot = true
	c.amount = 34
	c.lifetime = 1.6
	c.explosiveness = 0.7
	var pc := ParticleProcessMaterial.new()
	pc.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pc.emission_box_extents = Vector3(0.22, 0.75, 0.22)
	pc.direction = Vector3(0, 1, 0)
	pc.spread = 90.0
	pc.initial_velocity_min = 0.3
	pc.initial_velocity_max = 1.4
	pc.gravity = Vector3(0, -9.0, 0)
	pc.angular_velocity_min = -360.0
	pc.angular_velocity_max = 360.0
	pc.scale_min = 0.5
	pc.scale_max = 1.4
	pc.collision_mode = ParticleProcessMaterial.COLLISION_HIDE_ON_CONTACT
	c.process_material = pc
	var bx := BoxMesh.new()
	bx.size = Vector3(0.05, 0.02, 0.04)
	var mb := StandardMaterial3D.new()
	mb.albedo_color = Color(0.52, 0.46, 0.38)
	mb.roughness = 0.95
	bx.material = mb
	c.draw_pass_1 = bx
	host.add_child(c)
	c.global_position = at + Vector3(0, 0.9, 0)
	c.emitting = true
	# and what is left: a low heap of grey dust with a flint blade in it
	var heap := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.36
	sm.height = 0.36
	sm.radial_segments = 14
	sm.rings = 6
	var mh := StandardMaterial3D.new()
	mh.albedo_color = Color(0.4, 0.36, 0.31)
	mh.roughness = 1.0
	sm.material = mh
	heap.mesh = sm
	host.add_child(heap)
	heap.global_position = at
	heap.scale = Vector3(0.2, 0.05, 0.2)
	var ht := heap.create_tween()
	ht.tween_interval(0.25)
	ht.tween_property(heap, "scale", Vector3(1.0, 0.55, 0.8), 1.1).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	var bone := MeshInstance3D.new()
	var bm := CapsuleMesh.new()
	bm.radius = 0.035
	bm.height = 0.42
	var mbo := StandardMaterial3D.new()
	mbo.albedo_color = Color(0.78, 0.73, 0.62)
	mbo.roughness = 0.8
	bm.material = mbo
	bone.mesh = bm
	heap.add_child(bone)
	bone.position = Vector3(0.1, 0.2, -0.05)
	bone.rotation = Vector3(1.2, 0.7, 0.3)
	bone.scale = Vector3(1, 1, 1) / Vector3(1.0, 0.55, 0.8)

static func spawn_ripple(host: Node, at: Vector3, size: float, dur := 1.4) -> void:
	## A ring spreading on the flood water where a foot went in.
	if host == null or not host.is_inside_tree():
		return
	if _ripple_mat == null:
		var sh := Shader.new()
		sh.code = """
shader_type spatial;
render_mode unshaded, blend_mix, depth_draw_never, cull_disabled, shadows_disabled;
instance uniform float age = 0.0;
void fragment() {
	vec2 c = UV * 2.0 - 1.0;
	float r = length(c);
	float ang = atan(c.y, c.x);
	float wob = 0.025 * sin(ang * 5.0 + age * 3.0) + 0.018 * sin(ang * 9.0 - 1.3);
	float r1 = abs(r + wob - 0.8);
	float r2 = abs(r - wob - 0.56 + age * 0.08);
	float a = smoothstep(0.13, 0.0, r1) * (0.6 + 0.4 * sin(ang * 3.0 + 0.7)) + 0.45 * smoothstep(0.09, 0.0, r2);
	a *= smoothstep(1.0, 0.9, r);
	ALBEDO = vec3(0.62, 0.68, 0.72);
	ALPHA = a * (1.0 - age) * (1.0 - age) * 0.26;
}
"""
		_ripple_mat = ShaderMaterial.new()
		_ripple_mat.shader = sh
		_ripple_mat.render_priority = 2
		_ripple_mesh = PlaneMesh.new()
		_ripple_mesh.size = Vector2(1, 1)
	var mi := MeshInstance3D.new()
	mi.mesh = _ripple_mesh
	mi.material_override = _ripple_mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	host.add_child(mi)
	mi.global_position = at
	mi.rotation.y = randf() * TAU
	mi.scale = Vector3.ONE * size * 0.25
	var tw := mi.create_tween()
	tw.tween_property(mi, "scale", Vector3.ONE * size, dur).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
	tw.parallel().tween_method(func(v: float): mi.set_instance_shader_parameter("age", v), 0.0, 1.0, dur)
	tw.tween_callback(mi.queue_free)

func _layer(n: Node, l: int) -> void:
	if n is VisualInstance3D:
		(n as VisualInstance3D).layers = l
	for c in n.get_children():
		_layer(c, l)

# ------------------------------------------------------------------ the living pose

func _process(delta: float) -> void:
	if J.is_empty():
		return
	_time += delta
	if stars.visible:
		stars.rotation.y += delta * 3.0
	if not is_visible_in_tree():
		return
	if water_y > -50.0:
		# wading: lift the rings to the surface so they still show
		var off := maxf(0.0, water_y - global_position.y + 0.02)
		ring.position.y = 0.04 + off
		team_ring.position.y = 0.05 + off
		# rings on the water round the legs: quick ones while wading, slow ones standing
		if off > 0.12 and body.visible and _status != "ooa":
			_rip_t -= delta
			if _rip_t <= 0.0:
				var moving_now := moving and motion == "walk"
				_rip_t = 0.32 if moving_now else randf_range(1.8, 3.2)
				spawn_ripple(get_parent(), Vector3(global_position.x, water_y + 0.015, global_position.z), 1.7 if moving_now else 1.1, 1.3 if moving_now else 2.2)
	var t := _time
	var P := _base.duplicate()
	# at rest: breathing, weight on one leg and then the other, a look round
	var breath := sin(t * 1.7 + _phase)
	var shift := sin(t * 0.43 + _phase * 2.0)
	P["spine"] += Vector3(breath * 0.022, sin(t * 0.31 + _phase) * 0.05, shift * 0.02)
	P["head"] += Vector3(sin(t * 0.8 + _phase) * 0.04, sin(t * 0.23 + _phase * 1.7) * 0.35 * maxf(sin(t * 0.11 + _phase), 0.0), 0)
	P["root"] = Vector3(0, 0, -shift * 0.035)
	P["sh_l"] += Vector3(breath * 0.03, 0, -absf(breath) * 0.015)
	P["sh_r"] += Vector3(breath * 0.03, 0, absf(breath) * 0.015)
	P["hip_l"] += Vector3(0, 0, shift * 0.035)
	P["hip_r"] += Vector3(0, 0, shift * 0.035)
	P["kn_l"] += Vector3(maxf(shift, 0.0) * 0.12, 0, 0)
	P["kn_r"] += Vector3(maxf(-shift, 0.0) * 0.12, 0, 0)
	var bob := -absf(shift) * 0.012

	# moving: a walk, a climb, or a leap
	_walk_w = move_toward(_walk_w, 1.0 if moving else 0.0, delta * 6.0)
	if _walk_w > 0.001:
		_walk_t += delta * (10.0 if motion == "walk" else 6.0)
		var W := _base.duplicate()
		var p := _walk_t
		var wbob := 0.0
		match motion:
			"climb":
				var s := sin(p)
				W["sh_l"] = Vector3(-2.75 + s * 0.35, 0, -0.15)
				W["sh_r"] = Vector3(-2.75 - s * 0.35, 0, 0.15)
				W["el_l"] = Vector3(-0.55 - maxf(s, 0.0) * 0.5, 0, 0)
				W["el_r"] = Vector3(-0.55 - maxf(-s, 0.0) * 0.5, 0, 0)
				W["hip_l"] = Vector3(-0.85 - s * 0.35, 0, -0.1)
				W["hip_r"] = Vector3(-0.85 + s * 0.35, 0, 0.1)
				W["kn_l"] = Vector3(1.25 + s * 0.3, 0, 0)
				W["kn_r"] = Vector3(1.25 - s * 0.3, 0, 0)
				W["ft_l"] = Vector3(-0.4, 0, 0)
				W["ft_r"] = Vector3(-0.4, 0, 0)
				W["spine"] = _b("spine") + Vector3(0.15, 0, 0)
				W["head"] = Vector3(-0.35, 0, 0)
			"air":
				W["hip_l"] = Vector3(-0.9, 0, -0.1)
				W["hip_r"] = Vector3(-0.3, 0, 0.1)
				W["kn_l"] = Vector3(1.3, 0, 0)
				W["kn_r"] = Vector3(0.9, 0, 0)
				W["ft_l"] = Vector3(0.2, 0, 0)
				W["ft_r"] = Vector3(0.3, 0, 0)
				W["sh_l"] = _b("sh_l") + Vector3(-0.6, 0, -0.7)
				W["sh_r"] = _b("sh_r") + Vector3(-0.6, 0, 0.7)
				W["spine"] = _b("spine") + Vector3(0.2, 0, 0)
			_:
				var s := sin(p)
				var c := cos(p)
				W["hip_l"] = Vector3(-s * 0.55 - 0.05, 0, -0.02)
				W["hip_r"] = Vector3(s * 0.55 - 0.05, 0, 0.02)
				W["kn_l"] = Vector3(0.12 + maxf(c, 0.0) * 0.95 + maxf(-s, 0.0) * 0.15, 0, 0)
				W["kn_r"] = Vector3(0.12 + maxf(-c, 0.0) * 0.95 + maxf(s, 0.0) * 0.15, 0, 0)
				W["ft_l"] = Vector3(-(W["hip_l"].x + W["kn_l"].x) * 0.85, 0, 0)
				W["ft_r"] = Vector3(-(W["hip_r"].x + W["kn_r"].x) * 0.85, 0, 0)
				var free_l: bool = _hand_items.size() < 2 and _base["el_l"].x > -0.5
				var free_r: bool = _base["el_r"].x > -0.5
				W["sh_l"] = _b("sh_l") + Vector3(s * (0.45 if free_l else 0.12), 0, 0)
				W["sh_r"] = _b("sh_r") + Vector3(-s * (0.45 if free_r else 0.12), 0, 0)
				W["el_l"] = _b("el_l") + Vector3(-maxf(s, 0.0) * (0.35 if free_l else 0.05), 0, 0)
				W["el_r"] = _b("el_r") + Vector3(-maxf(-s, 0.0) * (0.35 if free_r else 0.05), 0, 0)
				W["spine"] = _b("spine") + Vector3(0.14, s * 0.12, 0)
				W["root"] = Vector3(0, -s * 0.12, 0)
				W["head"] = _b("head") + Vector3(-0.08, -s * 0.08, 0)
				wbob = absf(c) * 0.045 - 0.02
		for k in W:
			P[k] = (P[k] as Vector3).lerp(W[k], _walk_w)
		bob = lerpf(bob, wbob, _walk_w)

	# a blow, a shot, a spell
	if not _act_keys.is_empty():
		_act_t += delta
		var x := _act_t / _act_dur
		if x >= 1.0:
			_act_keys = []
			if _act_end.is_valid():
				_act_end.call()
				_act_end = Callable()
		else:
			var first: Dictionary = _act_keys[0]
			var last: Dictionary = _act_keys[-1]
			var pose: Dictionary
			var w := 1.0
			if x <= float(first["t"]):
				pose = first
				w = smoothstep(0.0, 1.0, x / maxf(float(first["t"]), 0.001))
			elif x >= float(last["t"]):
				pose = last
				w = 1.0 - smoothstep(0.0, 1.0, (x - float(last["t"])) / maxf(1.0 - float(last["t"]), 0.001))
			else:
				var i := 0
				while i < _act_keys.size() - 1 and x > float(_act_keys[i + 1]["t"]):
					i += 1
				var a: Dictionary = _act_keys[i]
				var bk: Dictionary = _act_keys[i + 1]
				var f := smoothstep(0.0, 1.0, (x - float(a["t"])) / maxf(float(bk["t"]) - float(a["t"]), 0.001))
				pose = {}
				for k in a:
					if k != "t" and bk.has(k):
						pose[k] = (a[k] as Vector3).lerp(bk[k], f)
			for k in pose:
				if k != "t" and P.has(k):
					P[k] = (P[k] as Vector3).lerp(pose[k], w)

	# down or out: the limbs go slack
	_lie_w = move_toward(_lie_w, 1.0 if _status != "ok" else 0.0, delta * 3.0)
	if _lie_w > 0.001:
		var L := {"sh_l": Vector3(-2.5, 0, -0.55), "el_l": Vector3(-0.5, 0, 0), "sh_r": Vector3(-2.2, 0, 0.7), "el_r": Vector3(-0.3, 0, 0),
			"hip_l": Vector3(-0.15, 0, -0.15), "kn_l": Vector3(0.5, 0, 0), "hip_r": Vector3(0.05, 0, 0.12), "kn_r": Vector3(0.15, 0, 0),
			"spine": Vector3(0.05, 0, 0), "head": Vector3(0.15, 0.6, 0), "neck": Vector3.ZERO, "root": Vector3.ZERO}
		if _status == "stunned":
			L["head"] = Vector3(0.1, sin(t * 2.0) * 0.5, 0)
		for k in L:
			P[k] = (P[k] as Vector3).lerp(L[k], _lie_w)
		bob *= 1.0 - _lie_w

	_apply(P)
	root.position.y = _hip_y + bob
	# cloth follows the legs and trails the walk
	var hl: float = P["hip_l"].x
	var hr: float = P["hip_r"].x
	if _panel_f != null:
		_panel_f.rotation.x = minf(minf(hl, hr) * 0.75, 0.0) - 0.04
	if _panel_b != null:
		_panel_b.rotation.x = maxf(maxf(hl, hr) * 0.75, 0.0) + 0.04
	if _cloak != null:
		_cloak.rotation.x = 0.12 + _walk_w * (0.32 + sin(_walk_t * 2.0) * 0.05) + sin(t * 1.3 + _phase) * 0.03 + maxf(maxf(hl, hr), 0.0) * 0.4
