class_name Mats
extends RefCounted
## Shared materials for the city. Stone and wood use world-space triplanar
## mapping, so generated geometry needs no UVs and blocks tile seamlessly.

static var _cache: Dictionary = {}

static func _tex(name: String) -> Texture2D:
	var p := "res://textures/%s.png" % name
	if ResourceLoader.exists(p):
		return load(p)
	return null

static func pbr(set_name: String, scale := 0.33, tint := Color(1, 1, 1), rough_mul := 1.0, triplanar := true) -> StandardMaterial3D:
	var key := "%s|%.3f|%s|%.2f|%s" % [set_name, scale, tint.to_html(), rough_mul, triplanar]
	if _cache.has(key):
		return _cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_texture = _tex(set_name + "_albedo")
	m.albedo_color = tint
	m.normal_enabled = true
	m.normal_texture = _tex(set_name + "_normal")
	m.normal_scale = 1.2
	m.roughness_texture = _tex(set_name + "_rough")
	m.roughness = rough_mul
	m.roughness_texture_channel = BaseMaterial3D.TEXTURE_CHANNEL_GRAYSCALE
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	if triplanar:
		m.uv1_triplanar = true
		m.uv1_world_triplanar = true
		m.uv1_triplanar_sharpness = 4.0
		m.uv1_scale = Vector3(scale, scale, scale)
	m.ao_enabled = false
	_cache[key] = m
	return m

static func flat(c: Color, rough := 0.8, metal := 0.0, key_extra := "") -> StandardMaterial3D:
	var key := "flat|%s|%.2f|%.2f|%s" % [c.to_html(), rough, metal, key_extra]
	if _cache.has(key):
		return _cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	_cache[key] = m
	return m

static func glow(c: Color, energy := 3.0, unshaded := false) -> StandardMaterial3D:
	var key := "glow|%s|%.2f|%s" % [c.to_html(), energy, unshaded]
	if _cache.has(key):
		return _cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.emission_enabled = true
	m.emission = c
	m.emission_energy_multiplier = energy
	if unshaded:
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_cache[key] = m
	return m

static func ghost(c: Color) -> StandardMaterial3D:
	var key := "ghost|%s" % c.to_html()
	if _cache.has(key):
		return _cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.no_depth_test = false
	_cache[key] = m
	return m

static func stone() -> StandardMaterial3D:
	return pbr("stone", 0.55)

static func darkstone() -> StandardMaterial3D:
	return pbr("darkstone", 0.5)

static func cobbles() -> StandardMaterial3D:
	# rain-dark and slick, so torchlight runs across the stones
	return pbr("cobbles", 0.45, Color(0.8, 0.8, 0.82), 0.42)

static func wood() -> StandardMaterial3D:
	return pbr("wood", 0.5)

static func plaster() -> StandardMaterial3D:
	return pbr("plaster", 0.35)

static func dirt() -> StandardMaterial3D:
	return pbr("dirt", 0.12)

static func roof() -> StandardMaterial3D:
	return pbr("roof", 0.3)

static func iron() -> StandardMaterial3D:
	return flat(Color(0.16, 0.15, 0.15), 0.45, 0.85)

static func shard() -> StandardMaterial3D:
	return glow(Color(0.25, 1.0, 0.82), 4.5)
