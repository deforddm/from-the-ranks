class_name MoveZone
extends Node3D
## The ground a fighter can still reach this turn, painted on the stones as one
## soft glowing area with a bright rim (one decal per level of the city),
## instead of a field of dots. Risky ground (jumps and drops) shows amber.

const PX := 10 # texels per map cell
const WALK := Color(0.32, 1.0, 0.82)
const RISK := Color(1.0, 0.66, 0.25)

var decals: Array = []

func clear() -> void:
	for d in decals:
		d.queue_free()
	decals.clear()

func show_reach(map: BattleMap, reach: Dictionary, origin: int) -> void:
	clear()
	if reach.is_empty():
		return
	var levels := {}
	var all: Array = reach.keys()
	if origin >= 0 and not reach.has(origin):
		all.append(origin)
	for nd in all:
		var l := map.node_level(nd)
		if not levels.has(l):
			levels[l] = {}
		var xz := map.node_xz(nd)
		var kind: String = reach[nd]["kind"] if reach.has(nd) else "walk"
		var risky: bool = kind == "jump" or (kind == "drop" and not (reach.has(nd) and int(reach[nd]["levels"]) <= 1 and map.is_wet(nd)))
		levels[l][xz] = 2 if risky else 1
	for l in levels:
		_make_level(map, int(l), levels[l])

func _smooth(t: float) -> float:
	return t * t * (3.0 - 2.0 * t)

func _make_level(map: BattleMap, l: int, cells: Dictionary) -> void:
	var x0 := 9999
	var z0 := 9999
	var x1 := -9999
	var z1 := -9999
	for k in cells:
		var v: Vector2i = k
		x0 = mini(x0, v.x)
		z0 = mini(z0, v.y)
		x1 = maxi(x1, v.x)
		z1 = maxi(z1, v.y)
	x0 -= 1
	z0 -= 1
	x1 += 1
	z1 += 1
	var cw := x1 - x0 + 1
	var cd := z1 - z0 + 1
	# a cell grid with a one-cell border, inside = 1, risky inside = 1 in the second grid
	var g := PackedFloat32Array()
	var r := PackedFloat32Array()
	g.resize(cw * cd)
	r.resize(cw * cd)
	for k in cells:
		var v: Vector2i = k
		var i := (v.y - z0) * cw + (v.x - x0)
		g[i] = 1.0
		r[i] = 1.0 if cells[k] == 2 else 0.0
	var W := cw * PX
	var H := cd * PX
	var img := Image.create(W, H, false, Image.FORMAT_RGBA8)
	# the glow is premultiplied: the soft fill barely lights the stones, the rim burns
	var glow := Image.create(W, H, false, Image.FORMAT_RGBA8)
	for py in range(H):
		var fz := (py + 0.5) / PX - 0.5
		var iz := clampi(int(floor(fz)), 0, cd - 2)
		var tz := _smooth(clampf(fz - iz, 0.0, 1.0))
		for px in range(W):
			var fx := (px + 0.5) / PX - 0.5
			var ix := clampi(int(floor(fx)), 0, cw - 2)
			var tx := _smooth(clampf(fx - ix, 0.0, 1.0))
			var a := iz * cw + ix
			var f := lerpf(lerpf(g[a], g[a + 1], tx), lerpf(g[a + cw], g[a + cw + 1], tx), tz)
			if f < 0.38:
				continue
			var rk := lerpf(lerpf(r[a], r[a + 1], tx), lerpf(r[a + cw], r[a + cw + 1], tx), tz)
			var inside := clampf((f - 0.47) / 0.06, 0.0, 1.0)
			var rim := clampf(1.0 - absf(f - 0.5) / 0.075, 0.0, 1.0)
			var c := WALK.lerp(RISK, clampf(rk * 1.6 - 0.3, 0.0, 1.0))
			var al := maxf(inside * 0.2, rim * 0.95)
			img.set_pixel(px, py, Color(c.r, c.g, c.b, al))
			var ge := maxf(inside * 0.14, rim)
			glow.set_pixel(px, py, Color(c.r * ge, c.g * ge, c.b * ge, al))
	var tex := ImageTexture.create_from_image(img)
	var d := Decal.new()
	d.texture_albedo = tex
	d.texture_emission = ImageTexture.create_from_image(glow)
	d.emission_energy = 1.6
	d.albedo_mix = 1.0
	d.normal_fade = 0.55
	d.upper_fade = 0.3
	d.lower_fade = 0.3
	d.cull_mask = 1
	d.size = Vector3(cw * map.cell, 1.8, cd * map.cell)
	d.position = Vector3((x0 + cw * 0.5) * map.cell, l * map.storey + 0.6, (z0 + cd * 0.5) * map.cell)
	add_child(d)
	decals.append(d)
