class_name CameraRig
extends Node3D
## Battle camera. Two ways of looking:
##  - Close: a third-person view over the shoulder of the fighter it follows,
##    at street level, kept out of walls like a spring arm.
##  - Tactical: free orbit, pan and zoom high over the city (V toggles).
## Keys: WASD / arrows pan (and let go of the fighter), Q/E turn, R/F tilt,
## mouse wheel zoom, right-drag orbit (close) or pan (tactical),
## middle-drag orbit.

const CLOSE_DIST := 6.2
const CLOSE_PITCH := 0.24
const TACTICAL_DIST := 26.0
const TACTICAL_PITCH := 0.9

var cam: Camera3D
var yaw := 0.6
var pitch := 0.85
var dist := 26.0
var target := Vector3.ZERO
var _goal := Vector3.ZERO
var _yaw_goal := 0.6
var _pitch_goal := 0.85
var _dist_goal := 26.0
var bounds := AABB(Vector3(-10, 0, -10), Vector3(80, 20, 80))
var _orbiting := false
var _panning := false
var _right_orbit := false
var shake := 0.0
var input_enabled := true
var collide := true
var follow_target: Node3D = null
var _arm := 26.0 # the spring arm's current length (eases back out after a wall)
var _kick := Vector3.ZERO
var _t := 0.0

func _ready() -> void:
	cam = Camera3D.new()
	cam.fov = 55.0
	cam.near = 0.08
	cam.far = 900.0
	add_child(cam)
	cam.current = true
	_apply(1.0)

func focus(p: Vector3, instant := false) -> void:
	## Look at a point; a followed fighter is let go unless it stands there.
	if follow_target != null and follow_target.global_position.distance_to(p) > 0.6:
		follow_target = null
	_goal = p
	if instant:
		target = p
		_apply(1.0)

func set_view(yaw_r: float, pitch_r: float, distance: float, instant := false) -> void:
	_yaw_goal = yaw_r
	_pitch_goal = pitch_r
	_dist_goal = distance
	if instant:
		yaw = yaw_r
		pitch = pitch_r
		dist = distance
		_arm = distance
		_apply(1.0)

func is_close() -> bool:
	return _dist_goal < 14.0

func follow(n: Node3D, behind := true, instant := false, look_at_p = null) -> void:
	## Ride over the shoulder of this figure. With look_at_p, face that point.
	follow_target = n
	if n == null:
		return
	_goal = n.global_position
	if is_close() or instant:
		var y := n.rotation.y + PI
		if look_at_p is Vector3:
			var d: Vector3 = look_at_p - n.global_position
			if Vector2(d.x, d.z).length() > 0.3:
				y = atan2(-d.x, -d.z)
		if behind:
			_yaw_goal = _near_angle(y, _yaw_goal)
		_dist_goal = clampf(_dist_goal, 3.5, CLOSE_DIST + 2.0) if is_close() else CLOSE_DIST
		_pitch_goal = clampf(_pitch_goal, 0.12, 0.7) if is_close() else CLOSE_PITCH
	if instant:
		target = _goal
		yaw = _yaw_goal
		dist = _dist_goal
		pitch = _pitch_goal
		_arm = dist
		_apply(1.0)

func toggle_tactical() -> void:
	if is_close():
		_dist_goal = TACTICAL_DIST
		_pitch_goal = TACTICAL_PITCH
	else:
		_dist_goal = CLOSE_DIST
		_pitch_goal = CLOSE_PITCH
		if follow_target != null:
			_yaw_goal = _near_angle(follow_target.rotation.y + PI, _yaw_goal)

func punch(strength: float, dir := Vector3.ZERO) -> void:
	## A hit: shake the view, with a push away from where the blow came from.
	shake = maxf(shake, strength)
	if dir != Vector3.ZERO:
		_kick += dir.normalized() * strength * 0.35

func _near_angle(a: float, ref: float) -> float:
	return ref + wrapf(a - ref, -PI, PI)

func _unhandled_input(event: InputEvent) -> void:
	if not input_enabled:
		return
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP and mb.pressed:
			_dist_goal = clampf(_dist_goal * 0.88, 3.0, 80.0)
		elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN and mb.pressed:
			_dist_goal = clampf(_dist_goal * 1.13, 3.0, 80.0)
		elif mb.button_index == MOUSE_BUTTON_MIDDLE:
			_orbiting = mb.pressed
		elif mb.button_index == MOUSE_BUTTON_RIGHT:
			_right_orbit = mb.pressed and is_close()
			_panning = mb.pressed and not is_close()
	elif event is InputEventMouseMotion:
		var mm := event as InputEventMouseMotion
		if _orbiting or _right_orbit:
			_yaw_goal -= mm.relative.x * 0.006
			_pitch_goal = clampf(_pitch_goal + mm.relative.y * 0.004, 0.08, 1.45)
		elif _panning:
			var k := _dist_goal * 0.0016
			var right := Vector3(cos(yaw), 0, -sin(yaw))
			var fwd := Vector3(-sin(yaw), 0, -cos(yaw))
			_goal -= right * mm.relative.x * k
			_goal += fwd * mm.relative.y * k
			follow_target = null

func _process(delta: float) -> void:
	_t += delta
	if input_enabled:
		var mv := Vector2.ZERO
		if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
			mv.y += 1
		if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
			mv.y -= 1
		if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
			mv.x -= 1
		if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
			mv.x += 1
		if mv != Vector2.ZERO:
			follow_target = null
			var sp := (6.0 + _dist_goal * 0.8) * delta
			if Input.is_key_pressed(KEY_SHIFT):
				sp *= 2.0
			var right := Vector3(cos(yaw), 0, -sin(yaw))
			var fwd := Vector3(-sin(yaw), 0, -cos(yaw))
			_goal += (right * mv.x + fwd * mv.y) * sp
		if Input.is_key_pressed(KEY_Q):
			_yaw_goal += 1.6 * delta
		if Input.is_key_pressed(KEY_E):
			_yaw_goal -= 1.6 * delta
		if Input.is_key_pressed(KEY_R):
			_pitch_goal = clampf(_pitch_goal + 0.9 * delta, 0.08, 1.45)
		if Input.is_key_pressed(KEY_F):
			_pitch_goal = clampf(_pitch_goal - 0.9 * delta, 0.08, 1.45)
	if follow_target != null:
		if not is_instance_valid(follow_target) or not follow_target.visible:
			follow_target = null
		else:
			_goal = follow_target.global_position
	_goal.x = clampf(_goal.x, bounds.position.x, bounds.end.x)
	_goal.z = clampf(_goal.z, bounds.position.z, bounds.end.z)
	_goal.y = clampf(_goal.y, 0.0, 12.0)
	var k := 1.0 - exp(-delta * (9.0 if follow_target != null else 6.0))
	_apply(k)
	if shake > 0.0:
		shake = maxf(0.0, shake - delta * 2.2)
		var s := shake * shake
		cam.position += Vector3(sin(_t * 61.0), sin(_t * 47.0 + 1.3), 0) * s * 0.22
		cam.rotate_object_local(Vector3(0, 0, 1), sin(_t * 39.0) * s * 0.035)
		cam.rotate_object_local(Vector3(1, 0, 0), sin(_t * 53.0 + 0.7) * s * 0.02)
	_kick = _kick.lerp(Vector3.ZERO, 1.0 - exp(-delta * 7.0))

func _apply(k: float) -> void:
	target = target.lerp(_goal, k)
	yaw = lerp_angle(yaw, _yaw_goal, k)
	pitch = lerpf(pitch, _pitch_goal, k)
	dist = lerpf(dist, _dist_goal, k)
	position = target
	# close in, the view sits over the right shoulder and looks at the chest
	var close := clampf(1.0 - (dist - 4.0) / 12.0, 0.0, 1.0)
	var right := Vector3(cos(yaw), 0, -sin(yaw))
	var pivot := Vector3(0, lerpf(0.8, 1.55, close), 0) + right * 0.7 * close
	var dir := Vector3(sin(yaw) * cos(pitch), sin(pitch), cos(yaw) * cos(pitch))
	var want := dist
	if collide and is_inside_tree():
		var space := get_world_3d().direct_space_state
		if close > 0.0:
			# spring arm: pull in to the first wall between fighter and camera
			var from := global_position + pivot
			var q := PhysicsRayQueryParameters3D.create(from, from + dir * (dist + 0.3), 1)
			var hit := space.intersect_ray(q)
			if not hit.is_empty():
				want = maxf(1.1, from.distance_to(hit["position"]) - 0.35)
		_arm = want if want < _arm else lerpf(_arm, want, k * 0.5)
		var off := pivot + dir * _arm
		if close < 1.0:
			# far out: never sit inside a building, lift clear of solid stone
			var pq := PhysicsPointQueryParameters3D.new()
			pq.collision_mask = 1
			pq.position = global_position + off
			for i in range(24):
				if space.intersect_point(pq, 1).is_empty():
					break
				off.y += 1.0
				pq.position.y += 1.0
		cam.position = off + _kick
	else:
		_arm = dist
		cam.position = pivot + dir * dist + _kick
	cam.look_at(global_position + pivot + Vector3(0, -0.15 * close, 0), Vector3.UP)

func clear_view(yaw_r: float, pitch_r: float, distance: float) -> float:
	## Returns the yaw nearest yaw_r from which the focus can be seen unblocked.
	var space := get_world_3d().direct_space_state
	var from := _goal + Vector3(0, 0.8, 0)
	for i in range(16):
		var y := yaw_r + (i / 2) * 0.4 * (1 if i % 2 == 0 else -1)
		var off := Vector3(sin(y) * cos(pitch_r), sin(pitch_r), cos(y) * cos(pitch_r)) * distance
		var q := PhysicsRayQueryParameters3D.create(from, from + off, 1)
		if space.intersect_ray(q).is_empty():
			return y
	return yaw_r
