class_name CameraRig
extends Node3D
## Free battle camera: orbit, pan and zoom around a focus point that can
## glide to follow the active fighter.
## Keys: WASD / arrows pan, Q/E turn, R/F tilt, mouse wheel zoom,
## middle-drag orbit, right-drag pan.

var cam: Camera3D
var yaw := 0.6
var pitch := 0.85
var dist := 26.0
var target := Vector3.ZERO
var _goal := Vector3.ZERO
var _yaw_goal := 0.6
var _pitch_goal := 0.85
var _dist_goal := 26.0
var bounds := AABB(Vector3(-10, 0, -10), Vector3(80, 20, 80))
var _orbiting := false
var _panning := false
var shake := 0.0
var input_enabled := true
var collide := true

func _ready() -> void:
	cam = Camera3D.new()
	cam.fov = 52.0
	cam.near = 0.1
	cam.far = 900.0
	add_child(cam)
	cam.current = true
	_apply(1.0)

func focus(p: Vector3, instant := false) -> void:
	_goal = p
	if instant:
		target = p
		_apply(1.0)

func set_view(yaw_r: float, pitch_r: float, distance: float, instant := false) -> void:
	_yaw_goal = yaw_r
	_pitch_goal = pitch_r
	_dist_goal = distance
	if instant:
		yaw = yaw_r
		pitch = pitch_r
		dist = distance
		_apply(1.0)

func _unhandled_input(event: InputEvent) -> void:
	if not input_enabled:
		return
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP and mb.pressed:
			_dist_goal = clampf(_dist_goal * 0.88, 4.0, 80.0)
		elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN and mb.pressed:
			_dist_goal = clampf(_dist_goal * 1.13, 4.0, 80.0)
		elif mb.button_index == MOUSE_BUTTON_MIDDLE:
			_orbiting = mb.pressed
		elif mb.button_index == MOUSE_BUTTON_RIGHT:
			_panning = mb.pressed
	elif event is InputEventMouseMotion:
		var mm := event as InputEventMouseMotion
		if _orbiting:
			_yaw_goal -= mm.relative.x * 0.006
			_pitch_goal = clampf(_pitch_goal + mm.relative.y * 0.004, 0.18, 1.45)
		elif _panning:
			var k := _dist_goal * 0.0016
			var right := Vector3(cos(yaw), 0, -sin(yaw))
			var fwd := Vector3(-sin(yaw), 0, -cos(yaw))
			_goal -= right * mm.relative.x * k
			_goal += fwd * mm.relative.y * k

func _process(delta: float) -> void:
	if input_enabled:
		var mv := Vector2.ZERO
		if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
			mv.y += 1
		if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
			mv.y -= 1
		if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
			mv.x -= 1
		if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
			mv.x += 1
		if mv != Vector2.ZERO:
			var sp := (8.0 + _dist_goal * 0.8) * delta
			if Input.is_key_pressed(KEY_SHIFT):
				sp *= 2.0
			var right := Vector3(cos(yaw), 0, -sin(yaw))
			var fwd := Vector3(-sin(yaw), 0, -cos(yaw))
			_goal += (right * mv.x + fwd * mv.y) * sp
		if Input.is_key_pressed(KEY_Q):
			_yaw_goal += 1.6 * delta
		if Input.is_key_pressed(KEY_E):
			_yaw_goal -= 1.6 * delta
		if Input.is_key_pressed(KEY_R):
			_pitch_goal = clampf(_pitch_goal + 0.9 * delta, 0.18, 1.45)
		if Input.is_key_pressed(KEY_F):
			_pitch_goal = clampf(_pitch_goal - 0.9 * delta, 0.18, 1.45)
	_goal.x = clampf(_goal.x, bounds.position.x, bounds.end.x)
	_goal.z = clampf(_goal.z, bounds.position.z, bounds.end.z)
	_goal.y = clampf(_goal.y, 0.0, 12.0)
	var k := 1.0 - exp(-delta * 6.0)
	_apply(k)
	if shake > 0.0:
		shake = maxf(0.0, shake - delta * 2.5)
		cam.position += Vector3(randf_range(-1, 1), randf_range(-1, 1), 0) * shake * 0.25

func _apply(k: float) -> void:
	target = target.lerp(_goal, k)
	yaw = lerp_angle(yaw, _yaw_goal, k)
	pitch = lerpf(pitch, _pitch_goal, k)
	dist = lerpf(dist, _dist_goal, k)
	position = target
	var off := Vector3(sin(yaw) * cos(pitch), sin(pitch), cos(yaw) * cos(pitch)) * dist
	# never sit inside a building: lift the camera clear of solid stone.
	# (fighters hidden behind walls show as silhouettes instead)
	if collide and is_inside_tree():
		var pq := PhysicsPointQueryParameters3D.new()
		pq.collision_mask = 1
		pq.position = global_position + off
		var space := get_world_3d().direct_space_state
		for i in range(24):
			if space.intersect_point(pq, 1).is_empty():
				break
			off.y += 1.0
			pq.position.y += 1.0
	cam.position = off
	cam.look_at(global_position + Vector3(0, 0.8, 0), Vector3.UP)

func clear_view(yaw_r: float, pitch_r: float, distance: float) -> float:
	## Returns the yaw nearest yaw_r from which the focus can be seen unblocked.
	var space := get_world_3d().direct_space_state
	var from := _goal + Vector3(0, 0.8, 0)
	for i in range(16):
		var y := yaw_r + (i / 2) * 0.4 * (1 if i % 2 == 0 else -1)
		var off := Vector3(sin(y) * cos(pitch_r), sin(pitch_r), cos(y) * cos(pitch_r)) * distance
		var q := PhysicsRayQueryParameters3D.create(from, from + off, 1)
		if space.intersect_ray(q).is_empty():
			return y
	return yaw_r
