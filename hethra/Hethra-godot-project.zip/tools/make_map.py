"""Builds data/maps/hethra_square.json, the first battle map.

The map is a grid of 2 m cells. Each cell has a height in storeys (3 m each):
0 is the street, 1-3 are ruined building tops you can stand on.
Props sit on top of a cell. Ladders and stairs join a cell to a taller
neighbour; bridges are planks laid across gaps at a given storey.
Run: python3 tools/make_map.py
"""
import json
import os
import random

W = D = 28
rnd = random.Random(4471)
H = [[0] * W for _ in range(D)]
P = [["." for _ in range(W)] for _ in range(D)]


def block(x0, z0, x1, z1, h):
    for z in range(z0, z1 + 1):
        for x in range(x0, x1 + 1):
            H[z][x] = h


# corner keeps with towers
block(0, 5, 5, 9, 2); block(0, 5, 2, 7, 3)
block(22, 5, 27, 9, 2); block(25, 5, 27, 7, 3)
block(0, 18, 5, 22, 2); block(0, 20, 2, 22, 3)
block(22, 18, 27, 22, 2); block(25, 20, 27, 22, 3)
# halls north and south of the square
block(9, 5, 12, 8, 2); block(15, 5, 18, 8, 2)
block(9, 19, 12, 22, 2); block(15, 19, 18, 22, 2)
# low ruins either side of the square
block(3, 12, 7, 15, 1); block(20, 12, 24, 15, 1)
# lone broken walls
for z in range(10, 13):
    H[z][9] = 1
for z in range(15, 18):
    H[z][18] = 1
for x in range(11, 14):
    H[3][x] = 1
for x in range(14, 17):
    H[24][x] = 1

# street gaps inside the keeps: one-cell gaps you can jump
for z in range(18, 23):
    if H[z][3] == 2:
        H[z][3] = 0
for z in range(5, 10):
    if H[z][24] == 2:
        H[z][24] = 0

# erosion: ruined edges drop a storey here and there
for z in range(D):
    for x in range(W):
        if H[z][x] >= 2 and rnd.random() < 0.10:
            edge = any(0 <= x + dx < W and 0 <= z + dz < D and H[z + dz][x + dx] < H[z][x]
                       for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)))
            if edge:
                H[z][x] -= 1

# the Fallen One's idol in the middle of the square (2x2, not walkable)
for z in (13, 14):
    for x in (13, 14):
        P[z][x] = "T"

# broken columns round the square
for (x, z) in [(10, 11), (17, 11), (10, 16), (17, 16), (12, 10), (15, 17)]:
    P[z][x] = "p"
# braziers
for (x, z) in [(11, 12), (16, 15), (2, 24), (25, 3), (12, 26), (15, 1)]:
    P[z][x] = "B"
# barricades and rubble in the streets
for (x, z) in [(12, 15), (15, 12), (11, 14), (16, 13), (7, 17), (20, 10), (6, 10), (21, 17),
               (13, 9), (14, 18), (5, 25), (22, 2), (8, 3), (19, 24)]:
    P[z][x] = "b"
for _ in range(36):
    x, z = rnd.randrange(W), rnd.randrange(D)
    if H[z][x] == 0 and P[z][x] == "." and not (z <= 2 or z >= 25):
        P[z][x] = "r"
for _ in range(10):
    x, z = rnd.randrange(W), rnd.randrange(D)
    if H[z][x] == 0 and P[z][x] == "." and not (z <= 2 or z >= 25):
        P[z][x] = "c"
# some rubble up on the roofs too (cover for shooters)
for (x, z) in [(1, 8), (4, 6), (23, 8), (26, 9), (1, 19), (5, 21), (23, 19), (26, 18), (10, 7), (17, 6), (11, 20), (16, 21)]:
    if H[z][x] > 0:
        P[z][x] = "r"

ladders = []   # (x, z) street cell -> (tx, tz) taller neighbour
stairs = []


def add_link(lst, x, z, tx, tz):
    assert 0 <= tx < W and 0 <= tz < D
    assert H[tz][tx] > H[z][x], (x, z, tx, tz, H[z][x], H[tz][tx])
    P[z][x] = "."
    lst.append({"x": x, "z": z, "tx": tx, "tz": tz})


def find_up(x, z):
    best = None
    for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        tx, tz = x + dx, z + dz
        if 0 <= tx < W and 0 <= tz < D and H[tz][tx] > H[z][x]:
            if best is None or H[tz][tx] < H[best[1]][best[0]]:
                best = (tx, tz)
    return best


# ladders and stairs (hand placed street cells; the taller neighbour is found automatically)
for (x, z) in [(6, 8), (21, 8), (6, 19), (21, 19), (8, 6), (19, 6), (8, 21), (19, 21),
               (5, 11), (22, 16), (3, 19), (24, 8)]:
    t = find_up(x, z)
    if t:
        add_link(ladders, x, z, *t)
for (x, z) in [(2, 16), (25, 11), (7, 16), (20, 11), (10, 18), (17, 9)]:
    t = find_up(x, z)
    if t:
        add_link(stairs, x, z, *t)
# roof-to-tower ladders (from a storey-2 roof onto the storey-3 tower)
for (x, z) in [(3, 6), (24, 6) if H[6][24] == 2 else (25, 8), (3, 21) if H[21][3] == 2 else (1, 19), (26, 19)]:
    if H[z][x] >= 1:
        t = find_up(x, z)
        if t:
            add_link(ladders, x, z, *t)

# bridges: planks at storey 2 over the gaps between the halls and the keeps
bridges = []
for x in (13, 14):
    bridges.append({"x": x, "z": 6, "level": 2})
    bridges.append({"x": x, "z": 21, "level": 2})
for x in (6, 7, 8):
    bridges.append({"x": x, "z": 7, "level": 2})
    bridges.append({"x": x, "z": 20, "level": 2})
for x in (19, 20, 21):
    bridges.append({"x": x, "z": 7, "level": 2})
    bridges.append({"x": x, "z": 20, "level": 2})
# make sure every bridge spans a real gap and lands on storey-2 roofs
for b in bridges:
    assert H[b["z"]][b["x"]] < b["level"], b

# godshards: a few in the square, more up high
shards = [[13, 12], [14, 15], [4, 13], [23, 14], [1, 6], [26, 21], [10, 7], [17, 20]]
for (x, z) in shards:
    if P[z][x] != ".":
        P[z][x] = "."

# deployment zones: south street for side 0, north street for side 1
deploy0 = [[x, z] for z in range(25, 28) for x in range(6, 22) if H[z][x] == 0 and P[z][x] == "."]
deploy1 = [[x, z] for z in range(0, 3) for x in range(6, 22) if H[z][x] == 0 and P[z][x] == "."]

data = {
    "name": "The Idol Square",
    "desc": "The temple quarter of Hethra, where the Fallen god's pain came down as burning stone. Shards still glow in the rubble.",
    "cell": 2.0,
    "storey": 3.0,
    "width": W,
    "depth": D,
    "heights": ["".join(str(h) for h in row) for row in H],
    "props": ["".join(row) for row in P],
    "legend": {"T": "idol", "p": "pillar", "B": "brazier", "b": "barricade", "r": "rubble", "c": "crates"},
    "ladders": ladders,
    "stairs": stairs,
    "bridges": bridges,
    "shards": [[x, z, H[z][x]] for (x, z) in shards],
    "deploy": {"0": deploy0, "1": deploy1},
    "rift": [27.0, 22.0, 27.0],
}
out = os.path.join(os.path.dirname(__file__), "..", "data", "maps", "hethra_square.json")
with open(out, "w") as f:
    json.dump(data, f, indent=1)
print("wrote", out)
for z in range(D):
    line = ""
    for x in range(W):
        c = P[z][x]
        line += (str(H[z][x]) if c == "." else c)
    print(f"{z:2d} {line}")
print("ladders", len(ladders), "stairs", len(stairs), "bridges", len(bridges))
