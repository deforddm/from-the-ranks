"""Generates the fighters' surface textures: cloth weave, riveted mail,
leather grain, worn iron, skin and hair. Each set is an albedo (a grey
multiplier for the material's colour), a normal map and a roughness map.
All tile seamlessly. Run: python3 tools/gen_fig_textures.py"""
import numpy as np
from PIL import Image
import os

N = 256
OUT = os.path.join(os.path.dirname(__file__), '..', 'textures')
rng = np.random.default_rng(1234)
yy, xx = np.mgrid[0:N, 0:N] / N

def noise(scale, seed):
    """Seamless band-limited noise in [0,1]: random spectrum, low-passed."""
    r = np.random.default_rng(seed)
    f = np.fft.fft2(r.standard_normal((N, N)))
    ky = np.fft.fftfreq(N)[:, None] * N
    kx = np.fft.fftfreq(N)[None, :] * N
    k = np.sqrt(kx * kx + ky * ky)
    f *= np.exp(-(k / scale) ** 2)
    a = np.real(np.fft.ifft2(f))
    a -= a.min(); a /= max(a.max(), 1e-9)
    return a

def normal_from(h, strength):
    dx = (np.roll(h, -1, 1) - np.roll(h, 1, 1)) * strength
    dy = (np.roll(h, -1, 0) - np.roll(h, 1, 0)) * strength
    n = np.dstack([-dx, dy, np.ones_like(h)])
    n /= np.linalg.norm(n, axis=2, keepdims=True)
    return ((n * 0.5 + 0.5) * 255).astype(np.uint8)

def save(name, alb, h, strength, rough):
    alb = np.clip(alb, 0, 1)
    Image.fromarray((alb * 255).astype(np.uint8), 'L').convert('RGB').save(os.path.join(OUT, name + '_albedo.png'))
    Image.fromarray(normal_from(h, strength), 'RGB').save(os.path.join(OUT, name + '_normal.png'))
    Image.fromarray((np.clip(rough, 0, 1) * 255).astype(np.uint8), 'L').save(os.path.join(OUT, name + '_rough.png'))
    print('wrote', name)

# --- cloth: a plain weave of 32 threads a tile, worn and stained
f = 32
u, v = xx * f, yy * f
warp = np.abs(np.sin(np.pi * u))
weft = np.abs(np.sin(np.pi * v))
over = ((np.floor(u) + np.floor(v)) % 2) == 0
h = np.where(over, warp * (0.55 + 0.45 * np.abs(np.sin(np.pi * v))), weft * (0.55 + 0.45 * np.abs(np.sin(np.pi * u))))
stain = noise(5, 1)
fuzz = noise(60, 2)
alb = 0.84 + 0.08 * h + 0.06 * fuzz - 0.12 * np.clip(stain - 0.55, 0, 1) * 2
save('fig_cloth', alb, h + 0.3 * fuzz, 2.2, 0.85 + 0.15 * (1 - h) * 0.6)

# --- mail: interlocking riveted rings, 16 rings a tile, alternate rows offset
R = 16
cell = 1.0 / R
best = np.zeros((N, N))
for oy in (-1, 0, 1):
    for ox in (-1, 0, 1):
        cy = (np.floor(yy * R) + oy + 0.5) * cell
        shift = np.where(((np.floor(yy * R) + oy) % 2) == 0, 0.0, 0.5 * cell)
        cx = (np.floor((xx - shift) * R) + ox + 0.5) * cell + shift
        dx = (xx - cx + 0.5) % 1.0 - 0.5
        dy = (yy - cy + 0.5) % 1.0 - 0.5
        d = np.sqrt((dx / 1.0) ** 2 + (dy / 0.8) ** 2) / cell
        ring = np.exp(-((d - 0.46) / 0.12) ** 2)
        best = np.maximum(best, ring)
grit = noise(40, 3)
alb = 0.38 + 0.62 * best - 0.1 * grit
save('fig_mail', alb, best, 3.0, 0.95 - 0.5 * best + 0.1 * grit)

# --- leather: pebbled grain, a few creases and scuffs
grain = noise(70, 4)
mott = noise(6, 5)
crease = np.abs(noise(9, 6) - 0.5) < 0.02
h = grain * 0.7 - crease * 0.6
alb = 0.75 + 0.2 * mott + 0.08 * grain - crease * 0.15
save('fig_leather', alb, h, 2.0, 0.8 + 0.2 * grain - crease * 0.1)

# --- worn iron: hammer dents, fine brushing and scratches
dents = noise(10, 7)
brush = noise(120, 8)
brush = np.repeat(brush[:, :1], N, axis=1) * 0.5 + brush * 0.5
scr = np.zeros((N, N))
for i in range(90):
    x0, y0 = rng.random() * N, rng.random() * N
    ang = rng.random() * np.pi
    ln = rng.random() * N * 0.35 + 8
    for t in np.linspace(0, ln, int(ln * 2)):
        px = int(x0 + np.cos(ang) * t) % N
        py = int(y0 + np.sin(ang) * t) % N
        scr[py, px] = 1.0
rust = np.clip(noise(8, 9) - 0.62, 0, 1) * 3
alb = 0.82 + 0.1 * dents + 0.14 * scr - 0.25 * rust
save('fig_metal', alb, dents * 0.8 + brush * 0.1 - scr * 0.2, 1.6, 0.75 + 0.25 * brush - 0.25 * scr + 0.4 * rust)

# --- skin: soft mottling and fine pores
pores = noise(110, 10)
mott = noise(8, 11)
alb = 0.9 + 0.08 * mott + 0.03 * pores
save('fig_skin', alb, pores * 0.5 + mott * 0.2, 0.8, 0.85 + 0.15 * pores)

# --- hair: streaks running one way
st = noise(90, 12)
st = np.repeat(st[:1, :], N, axis=0) * 0.7 + noise(30, 13) * 0.3
alb = 0.7 + 0.35 * st
save('fig_hair', alb, st, 2.5, 0.75 + 0.25 * (1 - st))
