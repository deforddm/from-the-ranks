"""Builds data/maps/starfall.json: the crater where a burning piece of the
fallen god struck Hethra. Run from the project folder: python3 tools/make_starfall.py"""
import json, math

W = D = 28
H = [[1] * W for _ in range(D)]
P = [['.'] * W for _ in range(D)]
cx = cz = 13.5

# the crater: a bowl of scorched street a storey down, with a raised lip
for z in range(D):
    for x in range(W):
        r = math.hypot(x + 0.5 - 14.0, z + 0.5 - 14.0)
        if r < 5.6:
            H[z][x] = 0

def block(x0, z0, x1, z1, lvl, broken=()):
    for z in range(z0, z1 + 1):
        for x in range(x0, x1 + 1):
            H[z][x] = lvl
    for (x, z, l) in broken:
        H[z][x] = l

# four burnt houses at the corners, half fallen towards the crater
block(2, 3, 6, 7, 3, [(6, 7, 2), (5, 7, 2), (6, 6, 2)])
block(21, 3, 25, 7, 3, [(21, 7, 2), (22, 7, 2), (21, 6, 2), (25, 3, 4), (24, 3, 4)])
block(2, 20, 6, 24, 3, [(6, 20, 2), (5, 20, 2), (6, 21, 2), (2, 24, 4), (3, 24, 4)])
block(21, 20, 25, 24, 3, [(21, 20, 2), (22, 20, 2), (21, 21, 2)])
# gatehouses on the near and far streets, joined by planks
block(9, 2, 12, 4, 2)
block(15, 2, 18, 4, 2)
block(9, 23, 12, 25, 2)
block(15, 23, 18, 25, 2)
# a shrine tower on each flank
block(1, 11, 3, 16, 2, [(3, 13, 3), (3, 14, 3), (2, 13, 3), (2, 14, 3)])
block(24, 11, 26, 16, 2, [(24, 13, 3), (24, 14, 3), (25, 13, 3), (25, 14, 3)])

# the starstone: a block of the god's burning flesh in the crater's heart
for (x, z) in [(13, 13), (14, 13), (13, 14), (14, 14)]:
    P[z][x] = 'S'
# rubble thrown out by the strike, and what the living left behind
for (x, z) in [(10, 12), (17, 15), (12, 17), (15, 10), (11, 15), (16, 11),
               (8, 9), (19, 18), (8, 18), (19, 9), (13, 6), (14, 21), (6, 13), (21, 14)]:
    P[z][x] = 'r'
for (x, z) in [(7, 10), (20, 17), (13, 0), (14, 27), (1, 9), (26, 18), (7, 26), (20, 1)]:
    P[z][x] = 'b'
for (x, z) in [(4, 9), (23, 18), (19, 6), (8, 21), (2, 18), (25, 9)]:
    P[z][x] = 'c'
for (x, z) in [(11, 7), (16, 20), (7, 16), (20, 11)]:
    P[z][x] = 'p'

ladders = [
    # corner houses
    (4, 8, 4, 7), (7, 4, 6, 4), (23, 8, 23, 7), (20, 4, 21, 4),
    (4, 19, 4, 20), (7, 23, 6, 23), (23, 19, 23, 20), (20, 23, 21, 23),
    # gatehouses
    (10, 5, 10, 4), (17, 5, 17, 4), (10, 22, 10, 23), (17, 22, 17, 23),
    # shrine towers
    (4, 12, 3, 12), (23, 15, 24, 15), (2, 10, 2, 11), (25, 17, 25, 16),
]
# steps down into the crater on four sides: the low step in the bowl, the
# high step on the lip, with a brazier beside each landing
stairs = []
def lip(x, z, dx, dz):
    while H[z][x] == 0:
        x += dx
        z += dz
    return x, z
for (x, z, dx, dz, bx, bz) in [(13, 13, 0, -1, -1, 0), (14, 14, 0, 1, 1, 0), (13, 14, -1, 0, 0, 1), (14, 13, 1, 0, 0, -1)]:
    hx, hz = lip(x, z, dx, dz)
    stairs.append((hx - dx, hz - dz, hx, hz))
    P[hz][hx] = '.'
    P[hz - dz][hx - dx] = '.'
    P[hz + bz][hx + bx] = 'B'
bridges = []
for x in (13, 14):
    bridges.append({"x": x, "z": 3, "level": 2})
    bridges.append({"x": x, "z": 24, "level": 2})

shards = [[11, 13, 0], [16, 14, 0], [13, 11, 0], [14, 16, 0],
          [4, 5, 3], [23, 22, 3], [24, 3, 4], [2, 24, 4],
          [2, 14, 3], [25, 13, 3]]

deploy = {"0": [], "1": []}
for z in (26, 27):
    for x in range(4, 24):
        if H[z][x] == 1 and P[z][x] == '.':
            deploy["0"].append([x, z])
for z in (0, 1):
    for x in range(4, 24):
        if H[z][x] == 1 and P[z][x] == '.':
            deploy["1"].append([x, z])

# sanity: every ladder and stair joins a lower cell to a higher one, on clear cells
for (x, z, tx, tz) in ladders + stairs:
    assert H[z][x] < H[tz][tx], ((x, z), (tx, tz), H[z][x], H[tz][tx])
    assert P[z][x] == '.' and P[tz][tx] == '.', ((x, z), (tx, tz))
for sh in shards:
    assert H[sh[1]][sh[0]] == sh[2] and P[sh[1]][sh[0]] == '.', sh

data = {
    "name": "The Starfall",
    "desc": "Where the biggest piece of the god came down, the street fell into a smoking bowl. The starstone still burns at its heart, and the shards it shed lie all around it.",
    "cell": 2.0, "storey": 3.0, "width": W, "depth": D,
    "heights": [''.join(str(v) for v in row) for row in H],
    "props": [''.join(row) for row in P],
    "legend": {"S": "starstone", "p": "pillar", "B": "brazier", "b": "barricade", "r": "rubble", "c": "crates"},
    "ladders": [{"x": a, "z": b, "tx": c, "tz": d} for (a, b, c, d) in ladders],
    "stairs": [{"x": a, "z": b, "tx": c, "tz": d} for (a, b, c, d) in stairs],
    "bridges": bridges,
    "shards": shards,
    "deploy": deploy,
    "objective": [13, 13],
    "fires": [[1, 1], [26, 26], [26, 1], [-3, 13], [31, 14], [13, -4], [14, 31]],
}
json.dump(data, open('data/maps/starfall.json', 'w'), indent=1)
print('\n'.join(data["heights"]))
print()
print('\n'.join(data["props"]))
