"""Builds data/maps/azath.json: the Azath Yard. In the middle of Hethra stands
a House of the Azath, a squat stone keep older than the city, which nobody
enters and nothing harms. A wall rings its yard of barrows and dead trees,
and what the house has taken lies under the mounds. The godfall cracked the
city round it and left the house untouched; godshards lie thick in the yard.
Run from the project folder: python3 tools/make_azath.py"""
import json
from collections import deque

W = D = 28
H = [[1] * W for _ in range(D)]
P = [['.'] * W for _ in range(D)]

def block(x0, z0, x1, z1, lvl, broken=()):
    for z in range(z0, z1 + 1):
        for x in range(x0, x1 + 1):
            H[z][x] = lvl
    for (x, z, l) in broken:
        H[z][x] = l

# the yard wall: one storey of old stone, walkable along its top
for x in range(5, 23):
    H[5][x] = 2
    H[22][x] = 2
for z in range(5, 23):
    H[z][5] = 2
    H[z][22] = 2
# its four gates, and a breach in the south-east where the godfall cracked it
for x in (13, 14):
    H[5][x] = 1
    H[22][x] = 1
for z in (13, 14):
    H[z][5] = 1
    H[z][22] = 1
for z in (18, 19):
    H[z][22] = 1
P[18][22] = 'r'

# the House: nobody goes in
for z in range(10, 18):
    for x in range(10, 18):
        P[z][x] = 'A'

# ruined houses in the streets round the wall
block(0, 6, 3, 10, 3, [(3, 6, 2), (3, 10, 2)])
block(24, 17, 27, 21, 3, [(24, 21, 2)])
block(0, 18, 2, 22, 2, [(0, 18, 3)])
block(25, 6, 27, 9, 2, [(27, 6, 3)])
block(8, 0, 10, 1, 2)      # a gatehouse on the north street
block(17, 26, 19, 27, 2)   # and one on the south

# dead trees and barrows in the yard
for (x, z) in [(7, 7), (20, 7), (7, 20), (20, 20), (11, 7), (16, 20), (7, 15), (20, 11)]:
    P[z][x] = 't'
for (x, z) in [(8, 10), (19, 9), (9, 19), (19, 17), (16, 8), (11, 20), (8, 16), (20, 15), (12, 8)]:
    P[z][x] = 'm'
# braziers at the gates, rubble and junk in the streets
for (x, z) in [(12, 4), (15, 4), (12, 23), (15, 23), (4, 12), (23, 15)]:
    P[z][x] = 'B'
for (x, z) in [(5, 3), (21, 3), (6, 24), (22, 24), (2, 14), (25, 13), (17, 2), (10, 25)]:
    P[z][x] = 'r'
for (x, z) in [(3, 3), (24, 3), (3, 24), (24, 24)]:
    P[z][x] = 'c'
for (x, z) in [(19, 3), (8, 24), (3, 16), (24, 11)]:
    P[z][x] = 'b'

stairs = [
    # up onto the wall from inside the yard
    (8, 6, 8, 5), (19, 21, 19, 22), (6, 18, 5, 18), (21, 9, 22, 9),
    (17, 6, 17, 5), (10, 21, 10, 22),
]
ladders = [
    # onto the wall from the streets
    (8, 4, 8, 5), (19, 23, 19, 22), (4, 18, 5, 18), (23, 9, 22, 9),
    (4, 8, 5, 8), (23, 20, 22, 20),
    # the ruined houses
    (4, 7, 3, 7), (23, 19, 24, 19), (3, 20, 2, 20), (24, 7, 25, 7),
    (11, 1, 10, 1), (16, 26, 17, 26),
]
bridges = []

shards = [
    [9, 13, 1], [18, 14, 1],         # in the yard, by the house
    [8, 11, 1], [19, 16, 1],         # among the barrows
    [13, 19, 1], [14, 8, 1],         # before the door, and behind the house
    [5, 10, 2], [22, 11, 2],         # on the wall
    [1, 8, 3], [26, 19, 3],          # on the roofs
]

deploy = {"0": [], "1": []}
for z in (26, 27):
    for x in range(3, 25):
        if H[z][x] == 1 and P[z][x] == '.':
            deploy["0"].append([x, z])
for z in (0, 1):
    for x in range(3, 25):
        if H[z][x] == 1 and P[z][x] == '.':
            deploy["1"].append([x, z])

bridge_cells = {(b["x"], b["z"]) for b in bridges}
for (x, z, tx, tz) in ladders + stairs:
    assert H[z][x] < H[tz][tx], ((x, z), (tx, tz), H[z][x], H[tz][tx])
    assert abs(x - tx) + abs(z - tz) == 1, ((x, z), (tx, tz))
    assert P[z][x] == '.' and P[tz][tx] == '.', ((x, z), (tx, tz))
    assert (x, z) not in bridge_cells and (tx, tz) not in bridge_cells, ((x, z), (tx, tz))
for (x, z, tx, tz) in stairs:
    assert H[tz][tx] - H[z][x] == 1, ((x, z), (tx, tz))
for sh in shards:
    assert H[sh[1]][sh[0]] == sh[2] and P[sh[1]][sh[0]] == '.', sh
for br in bridges:
    assert H[br["z"]][br["x"]] < br["level"] and P[br["z"]][br["x"]] == '.', br

# every deploy cell should reach every shard (walk, drop, stairs, ladders, planks)
def nodes():
    ns = set()
    for z in range(D):
        for x in range(W):
            if P[z][x] == '.':
                ns.add((x, z, H[z][x]))
    for b in bridges:
        ns.add((b["x"], b["z"], b["level"]))
    return ns
NS = nodes()
def top(x, z):
    best = None
    for (a, b, l) in NS:
        if a == x and b == z and (best is None or l > best):
            best = l
    return (x, z, best)
adj = {n: set() for n in NS}
for (x, z, l) in NS:
    for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        nx, nz = x + dx, z + dz
        if (nx, nz, l) in NS:
            adj[(x, z, l)].add((nx, nz, l))
        elif 0 <= nx < W and 0 <= nz < D and H[nz][nx] < l and (nx, nz, H[nz][nx]) in NS:
            adj[(x, z, l)].add((nx, nz, H[nz][nx]))     # drop
    if l != H[z][x] and (x, z, H[z][x]) in NS:
        adj[(x, z, l)].add((x, z, H[z][x]))             # off a plank
for (x, z, tx, tz) in ladders + stairs:
    a, b = top(x, z), top(tx, tz)
    adj[a].add(b)
    adj[b].add(a)
def reach(start):
    seen = {start}
    q = deque([start])
    while q:
        n = q.popleft()
        for m in adj[n]:
            if m not in seen:
                seen.add(m)
                q.append(m)
    return seen
for side in ("0", "1"):
    r = reach((deploy[side][0][0], deploy[side][0][1], 1))
    for sh in shards:
        assert (sh[0], sh[1], sh[2]) in r, ("shard unreachable", side, sh)
    for d2 in deploy["1" if side == "0" else "0"]:
        assert (d2[0], d2[1], 1) in r, ("enemy unreachable", side, d2)
    # nobody may be stranded on a roof
    for n in NS:
        assert (deploy[side][0][0], deploy[side][0][1], 1) in reach(n), ("stranded", n)
    break

data = {
    "name": "The Azath Yard",
    "desc": "A House of the Azath stands in the heart of Hethra, a squat stone keep older than the city, that nobody enters and nothing harms. The godfall broke the streets round it and left it untouched. A wall rings its yard of dead trees and barrows, and the shards lie thick among the mounds, where the house keeps what it has taken.",
    "cell": 2.0, "storey": 3.0, "width": W, "depth": D,
    "heights": [''.join(str(v) for v in row) for row in H],
    "props": [''.join(row) for row in P],
    "legend": {"A": "azath", "t": "tree", "m": "barrow", "B": "brazier", "b": "barricade", "r": "rubble", "c": "crates"},
    "ladders": [{"x": a, "z": b, "tx": c, "tz": d} for (a, b, c, d) in ladders],
    "stairs": [{"x": a, "z": b, "tx": c, "tz": d} for (a, b, c, d) in stairs],
    "bridges": bridges,
    "shards": shards,
    "deploy": deploy,
    "objective": [13, 19],
    "yard": [5, 5, 22, 22],
    "fires": [[1, 7], [26, 20], [1, 21], [26, 7], [9, 0], [18, 27]],
}
json.dump(data, open('data/maps/azath.json', 'w'), indent=1)
print('\n'.join(data["heights"]))
print()
print('\n'.join(data["props"]))
