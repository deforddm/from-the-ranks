"""Procedural, seamless PBR textures for Hethra, City of the Fallen.

Every texture here is generated from code (no outside images), so the game's
materials are original and free of third-party licences.
Run:  python3 tools/gen_textures.py   (writes textures/*.png)
Outputs per material: <name>_albedo.png, <name>_normal.png, <name>_rough.png
"""
import os
import numpy as np
from PIL import Image

N = 1024
OUT = os.path.join(os.path.dirname(__file__), "..", "textures")
rng = np.random.default_rng(1187)


def periodic_noise(n, scale, seed=None):
    """Band-limited periodic noise in [0,1] (FFT-filtered white noise)."""
    r = np.random.default_rng(seed) if seed is not None else rng
    white = r.standard_normal((n, n))
    f = np.fft.fft2(white)
    fy = np.fft.fftfreq(n)[:, None]
    fx = np.fft.fftfreq(n)[None, :]
    rad = np.sqrt(fx * fx + fy * fy) * n
    filt = np.exp(-(rad / scale) ** 2)
    out = np.real(np.fft.ifft2(f * filt))
    out -= out.min()
    out /= out.max() + 1e-9
    return out


def fbm(n, base=4, octaves=5, gain=0.5, seed=0):
    total = np.zeros((n, n))
    amp = 1.0
    s = base
    norm = 0.0
    for o in range(octaves):
        total += amp * periodic_noise(n, s, seed + o * 31)
        norm += amp
        amp *= gain
        s *= 2
    return total / norm


def normal_from_height(h, strength):
    dx = (np.roll(h, -1, axis=1) - np.roll(h, 1, axis=1)) * 0.5
    dy = (np.roll(h, -1, axis=0) - np.roll(h, 1, axis=0)) * 0.5
    nx = -dx * strength
    ny = -dy * strength
    nz = np.ones_like(h)
    ln = np.sqrt(nx * nx + ny * ny + nz * nz)
    nrm = np.stack([nx / ln, -ny / ln, nz / ln], axis=-1)  # OpenGL-style (Godot)
    return ((nrm * 0.5 + 0.5) * 255).astype(np.uint8)


def save(name, albedo, height, rough, strength=6.0):
    os.makedirs(OUT, exist_ok=True)
    a = np.clip(albedo * 255, 0, 255).astype(np.uint8)
    Image.fromarray(a, "RGB").save(os.path.join(OUT, f"{name}_albedo.png"))
    Image.fromarray(normal_from_height(height, strength), "RGB").save(os.path.join(OUT, f"{name}_normal.png"))
    r = np.clip(rough * 255, 0, 255).astype(np.uint8)
    Image.fromarray(r, "L").save(os.path.join(OUT, f"{name}_rough.png"))
    print("wrote", name)


def colorize(t, c0, c1):
    c0 = np.array(c0)[None, None, :]
    c1 = np.array(c1)[None, None, :]
    return c0 + (c1 - c0) * t[..., None]


def voronoi_periodic(n, count, seed):
    """Returns (f1 distance, f2 distance, cell id) for periodic Voronoi."""
    r = np.random.default_rng(seed)
    pts = r.random((count, 2)) * n
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float32)
    f1 = np.full((n, n), 1e9, np.float32)
    f2 = np.full((n, n), 1e9, np.float32)
    cid = np.zeros((n, n), np.int32)
    for i, (px, py) in enumerate(pts):
        dx = np.abs(xx - px)
        dx = np.minimum(dx, n - dx)
        dy = np.abs(yy - py)
        dy = np.minimum(dy, n - dy)
        d = np.sqrt(dx * dx + dy * dy)
        closer = d < f1
        f2 = np.where(closer, f1, np.minimum(f2, d))
        cid = np.where(closer, i, cid)
        f1 = np.where(closer, d, f1)
    return f1, f2, cid


def masonry(name, rows, base_col, var, mortar_col, seed, rough_base=0.82):
    """Ashlar masonry: rows of blocks with random widths, chipped edges."""
    r = np.random.default_rng(seed)
    h = np.zeros((N, N))
    alb = np.zeros((N, N, 3))
    row_h = N // rows
    grime = fbm(N, 3, 5, seed=seed + 5)
    fine = fbm(N, 40, 4, seed=seed + 9)
    chips = periodic_noise(N, 90, seed + 13)
    yy, xx = np.mgrid[0:N, 0:N]
    for ri in range(rows):
        y0 = ri * row_h
        x = int(r.integers(0, N // 4))
        widths = []
        while sum(widths) < N:
            widths.append(int(r.integers(int(row_h * 1.3), int(row_h * 2.8))))
        # rescale so that the row wraps exactly
        s = N / sum(widths)
        widths = [max(8, int(w * s)) for w in widths]
        widths[-1] += N - sum(widths)
        for w in widths:
            tint = np.array(base_col) * (1 + r.uniform(-var, var)) + r.uniform(-0.008, 0.008, 3)
            xs = (np.arange(x, x + w) % N)
            ys = np.arange(y0, y0 + row_h)
            # bevel height: distance to block edge
            lx = np.arange(w)[None, :]
            ly = np.arange(row_h)[:, None]
            edge = np.minimum(np.minimum(lx, w - 1 - lx), np.minimum(ly, row_h - 1 - ly)).astype(float)
            bev = np.clip((edge - 2.5) / 7.0, 0, 1) ** 0.6
            sub_h = bev * (0.85 + 0.15 * r.random())
            h[np.ix_(ys, xs)] = sub_h
            alb[np.ix_(ys, xs)] = tint
            x += w
    mortar = h < 0.02
    h = h + fine * 0.18 - (chips > 0.72) * 0.25 * (h > 0.08)
    alb = alb * (0.8 + 0.35 * fine[..., None]) * (0.75 + 0.35 * grime[..., None])
    alb[mortar] = np.array(mortar_col) * (0.8 + 0.4 * fine[mortar][:, None])
    # damp stains running down
    stain = fbm(N, 2, 3, seed=seed + 77)
    alb *= (1 - 0.25 * np.clip((stain - 0.55) * 3, 0, 1))[..., None]
    rough = np.clip(rough_base + 0.15 * fine - 0.1 * (stain > 0.6), 0, 1)
    rough[mortar] = 0.95
    save(name, alb, h, rough, strength=9.0)


def cobbles():
    f1, f2, cid = voronoi_periodic(N, 420, 21)
    edge = f2 - f1
    dome = np.clip(edge / 14.0, 0, 1) ** 0.5
    noise = fbm(N, 30, 4, seed=3)
    grime = fbm(N, 3, 4, seed=4)
    r = np.random.default_rng(5)
    tints = r.uniform(0.75, 1.15, 420)
    base = np.array([0.30, 0.29, 0.28])
    alb = base[None, None, :] * tints[cid][..., None]
    alb = alb * (0.75 + 0.4 * noise[..., None]) * (0.7 + 0.45 * grime[..., None])
    gap = edge < 3.0
    alb[gap] = np.array([0.08, 0.075, 0.06]) * (0.7 + 0.6 * noise[gap][:, None])
    h = dome * 0.9 + noise * 0.15
    rough = np.clip(0.55 + 0.35 * noise + 0.2 * gap, 0, 1)
    # puddles: low roughness in some hollows
    pud = periodic_noise(N, 3, 99)
    wet = pud > 0.72
    rough[wet] *= 0.25
    alb[wet] *= 0.6
    save("cobbles", alb, h, rough, strength=7.0)


def wood():
    yy, xx = np.mgrid[0:N, 0:N]
    planks = 6
    pw = N // planks
    grain = np.zeros((N, N))
    r = np.random.default_rng(8)
    alb = np.zeros((N, N, 3))
    stretch = periodic_noise(N, 8, 11)
    for p in range(planks):
        x0 = p * pw
        cols = slice(x0, x0 + pw)
        g = np.sin((xx[:, cols] * 0.9 + stretch[:, cols] * 60 + r.uniform(0, 6)) * 0.35)
        grain[:, cols] = g
        tint = np.array([0.24, 0.16, 0.10]) * r.uniform(0.75, 1.2)
        alb[:, cols] = tint
    fine = fbm(N, 60, 3, seed=12)
    seam = (xx % pw) < 3
    h = 0.5 + grain * 0.08 + fine * 0.1
    h[seam] = 0.0
    alb = alb * (0.8 + 0.25 * grain[..., None]) * (0.8 + 0.3 * fine[..., None])
    alb[seam] *= 0.3
    rough = np.clip(0.7 + 0.2 * fine, 0, 1)
    save("wood", alb, h, rough, strength=5.0)


def plaster():
    base = fbm(N, 3, 6, seed=40)
    fine = fbm(N, 50, 3, seed=41)
    cracks_f1, cracks_f2, _ = voronoi_periodic(N, 60, 42)
    crack = (cracks_f2 - cracks_f1) < 1.6
    crack &= periodic_noise(N, 6, 43) > 0.45
    alb = colorize(base, [0.32, 0.29, 0.24], [0.52, 0.47, 0.38])
    # sickly green-grey weathering
    alb *= (0.85 + 0.3 * fine[..., None])
    moss = np.clip((fbm(N, 4, 4, seed=44) - 0.6) * 4, 0, 1)
    alb = alb * (1 - moss[..., None] * 0.5) + np.array([0.14, 0.17, 0.10]) * moss[..., None] * 0.5
    h = base * 0.3 + fine * 0.2
    h[crack] -= 0.35
    alb[crack] *= 0.35
    rough = np.clip(0.88 + 0.1 * fine, 0, 1)
    save("plaster", alb, h, rough, strength=6.0)


def dirt():
    a = fbm(N, 4, 6, seed=60)
    b = fbm(N, 30, 4, seed=61)
    pebbles_f1, pebbles_f2, _ = voronoi_periodic(N, 900, 62)
    peb = np.clip(1 - pebbles_f1 / 6.0, 0, 1) * (periodic_noise(N, 10, 63) > 0.5)
    alb = colorize(a, [0.10, 0.09, 0.08], [0.24, 0.21, 0.17]) * (0.8 + 0.3 * b[..., None])
    alb += peb[..., None] * 0.08
    ash = np.clip((fbm(N, 3, 3, seed=64) - 0.55) * 3, 0, 1)
    alb = alb * (1 - ash[..., None] * 0.4) + ash[..., None] * np.array([0.30, 0.30, 0.29]) * 0.4
    h = a * 0.4 + b * 0.3 + peb * 0.4
    rough = np.clip(0.9 + 0.08 * b, 0, 1)
    save("dirt", alb, h, rough, strength=6.0)


def roof():
    """Broken clay tiles (for rooftop surfaces)."""
    rows = 16
    rh = N // rows
    yy, xx = np.mgrid[0:N, 0:N]
    tile_w = N // 12
    off = (yy // rh) % 2 * (tile_w // 2)
    lx = (xx + off) % tile_w
    ly = yy % rh
    curve = np.sin(lx / tile_w * np.pi)
    h = curve * 0.6 + (ly / rh) * 0.3
    noise = fbm(N, 30, 4, seed=70)
    r = np.random.default_rng(71)
    idx = ((xx + off) // tile_w) + (yy // rh) * 40
    tints = r.uniform(0.7, 1.2, idx.max() + 1)
    missing = r.random(idx.max() + 1) < 0.08
    alb = np.array([0.33, 0.16, 0.10])[None, None, :] * tints[idx][..., None]
    alb *= (0.75 + 0.35 * noise[..., None])
    gap = (ly < 3) | (lx < 2)
    alb[gap] *= 0.35
    miss = missing[idx]
    alb[miss] = np.array([0.12, 0.10, 0.08]) * (0.8 + 0.4 * noise[miss][:, None])
    h[miss] = 0.0
    h += noise * 0.1
    rough = np.clip(0.7 + 0.25 * noise, 0, 1)
    save("roof", alb, h, rough, strength=6.0)


if __name__ == "__main__":
    import sys
    if "stone" in sys.argv:
        masonry("stone", 10, [0.36, 0.35, 0.33], 0.12, [0.10, 0.10, 0.09], seed=1)
        masonry("darkstone", 14, [0.20, 0.21, 0.23], 0.15, [0.06, 0.06, 0.06], seed=2, rough_base=0.75)
        sys.exit()
    masonry("stone", 10, [0.36, 0.35, 0.33], 0.12, [0.10, 0.10, 0.09], seed=1)
    masonry("darkstone", 14, [0.20, 0.21, 0.23], 0.15, [0.06, 0.06, 0.06], seed=2, rough_base=0.75)
    cobbles()
    wood()
    plaster()
    dirt()
    roof()
