"""Builds data/maps/sleeper.json: the Sleeper's Stair, a stepped temple to the
sleeping earth goddess, with her stone image lying on its top tier.
Run from the project folder: python3 tools/make_sleeper.py"""
import json

W = D = 28
H = [[1] * W for _ in range(D)]
P = [['.'] * W for _ in range(D)]

def block(x0, z0, x1, z1, lvl, broken=()):
    for z in range(z0, z1 + 1):
        for x in range(x0, x1 + 1):
            H[z][x] = lvl
    for (x, z, l) in broken:
        H[z][x] = l

# the temple: a broad plinth, a second tier and the sleeper's bed on top
TEMPLE = (7, 8, 20, 19)
block(7, 8, 20, 19, 2)
block(9, 10, 18, 17, 3)
block(11, 12, 16, 15, 4)
# burnt houses in the four corners
block(2, 2, 6, 5, 3, [(6, 5, 2), (5, 5, 2), (2, 2, 4), (3, 2, 4)])
block(21, 2, 25, 5, 3, [(21, 5, 2), (22, 5, 2)])
block(2, 22, 6, 25, 3, [(6, 22, 2), (5, 22, 2)])
block(21, 22, 25, 25, 3, [(21, 22, 2), (22, 22, 2), (24, 25, 4), (25, 25, 4)])
# almshouses on the flanks, joined to the plinth by planks
block(1, 11, 4, 16, 2, [(1, z, 3) for z in range(11, 17)] + [(2, z, 3) for z in range(11, 17)])
block(23, 11, 26, 16, 2, [(25, z, 3) for z in range(11, 17)] + [(26, z, 3) for z in range(11, 17)])

# the sleeper herself, lying along the top tier
for x in range(12, 16):
    for z in (13, 14):
        P[z][x] = 'G'
# a colonnade round the plinth
for (x, z) in [(7, 8), (10, 8), (17, 8), (20, 8), (7, 19), (10, 19), (17, 19), (20, 19),
               (7, 11), (7, 17), (20, 10), (20, 16)]:
    P[z][x] = 'p'
# braziers at the feet of the great stairs and on the top tier
for (x, z) in [(12, 20), (15, 20), (12, 7), (15, 7), (11, 12), (16, 15)]:
    P[z][x] = 'B'
# obelisks along the processional way
for (x, z) in [(11, 22), (16, 22), (11, 5), (16, 5)]:
    P[z][x] = 'p'
# what the living left behind
for (x, z) in [(9, 23), (18, 4), (19, 21), (8, 6), (5, 9), (22, 18), (2, 19), (25, 8), (13, 24), (14, 3)]:
    P[z][x] = 'r'
for (x, z) in [(10, 25), (17, 2), (5, 18), (22, 9), (19, 25), (8, 2)]:
    P[z][x] = 'c'
for (x, z) in [(6, 20), (21, 7), (13, 26), (14, 1)]:
    P[z][x] = 'b'

stairs = [
    # the great stairs, north and south, street to plinth to tier to top
    (13, 20, 13, 19), (14, 20, 14, 19), (13, 18, 13, 17), (14, 18, 14, 17), (13, 16, 13, 15), (14, 16, 14, 15),
    (13, 7, 13, 8), (14, 7, 14, 8), (13, 9, 13, 10), (14, 9, 14, 10), (13, 11, 13, 12), (14, 11, 14, 12),
    # side stairs, east and west
    (6, 15, 7, 15), (8, 12, 9, 12), (21, 12, 20, 12), (19, 15, 18, 15),
]
ladders = [
    (7, 4, 6, 4), (20, 4, 21, 4), (7, 23, 6, 23), (20, 23, 21, 23),
    (4, 6, 4, 5), (23, 6, 23, 5), (4, 21, 4, 22), (23, 21, 23, 22),
    (4, 0 + 1, 4, 2), (23, 26, 23, 25),
    (5, 16, 4, 16), (22, 11, 23, 11), (3, 13, 2, 13), (24, 14, 25, 14),
    (10, 10, 10, 9), (17, 17, 17, 18),
]
# fix the one ladder that runs the wrong way (plinth down to the tier is up)
ladders = [l for l in ladders if not (l[0] == 10 and l[1] == 10)] + [(10, 9, 10, 10)]
ladders = [l for l in ladders if not (l[0] == 17 and l[1] == 17)] + [(17, 18, 17, 17)]
bridges = [{"x": 5, "z": 13, "level": 2}, {"x": 6, "z": 13, "level": 2},
           {"x": 21, "z": 14, "level": 2}, {"x": 22, "z": 14, "level": 2}]

shards = [[11, 14, 4], [16, 13, 4], [9, 16, 3], [18, 11, 3], [8, 9, 2], [19, 18, 2],
          [3, 3, 3], [24, 24, 3], [1, 14, 3], [26, 13, 3]]

deploy = {"0": [], "1": []}
for z in (26, 27):
    for x in range(4, 24):
        if H[z][x] == 1 and P[z][x] == '.':
            deploy["0"].append([x, z])
for z in (0, 1):
    for x in range(4, 24):
        if H[z][x] == 1 and P[z][x] == '.':
            deploy["1"].append([x, z])

for (x, z, tx, tz) in ladders + stairs:
    assert H[z][x] < H[tz][tx], ((x, z), (tx, tz), H[z][x], H[tz][tx])
    assert abs(x - tx) + abs(z - tz) == 1, ((x, z), (tx, tz))
    assert P[z][x] == '.' and P[tz][tx] == '.', ((x, z), (tx, tz))
for (x, z, tx, tz) in stairs:
    assert H[tz][tx] - H[z][x] == 1, ((x, z), (tx, tz))
for sh in shards:
    assert H[sh[1]][sh[0]] == sh[2] and P[sh[1]][sh[0]] == '.', sh
for br in bridges:
    assert H[br["z"]][br["x"]] < br["level"] and P[br["z"]][br["x"]] == '.', br

data = {
    "name": "The Sleeper's Stair",
    "desc": "A stepped temple to the goddess who sleeps in the earth. Her stone image lies on its top tier, warm to the touch since the fall, and her worshippers fled with the offerings still on the steps.",
    "cell": 2.0, "storey": 3.0, "width": W, "depth": D,
    "heights": [''.join(str(v) for v in row) for row in H],
    "props": [''.join(row) for row in P],
    "legend": {"G": "sleeper", "p": "pillar", "B": "brazier", "b": "barricade", "r": "rubble", "c": "crates"},
    "ladders": [{"x": a, "z": b, "tx": c, "tz": d} for (a, b, c, d) in ladders],
    "stairs": [{"x": a, "z": b, "tx": c, "tz": d} for (a, b, c, d) in stairs],
    "bridges": bridges,
    "shards": shards,
    "deploy": deploy,
    "temple": list(TEMPLE),
    "objective": [13, 13],
    "fires": [[1, 1], [26, 26], [26, 1], [1, 26], [-3, 13], [31, 14], [13, -4], [14, 31]],
}
json.dump(data, open('data/maps/sleeper.json', 'w'), indent=1)
print('\n'.join(data["heights"]))
print()
print('\n'.join(data["props"]))
