"""Builds data/maps/drowned.json: the Drowned Quarter, low streets where the
river wall broke on the night of the fall. The streets stand waist deep in
black water; quays, a shrine island and the roofs stay dry, joined by plank
walks. Mael's great bell lies cracked in the shrine court.
Run from the project folder: python3 tools/make_drowned.py"""
import json
from collections import deque

W = D = 28
H = [[0] * W for _ in range(D)]
P = [['.'] * W for _ in range(D)]

def block(x0, z0, x1, z1, lvl, broken=()):
    for z in range(z0, z1 + 1):
        for x in range(x0, x1 + 1):
            H[z][x] = lvl
    for (x, z, l) in broken:
        H[z][x] = l

# the two quays where the warbands come in, with warehouses at their ends
block(0, 0, 27, 2, 1)
block(0, 25, 27, 27, 1)
block(0, 0, 2, 3, 3, [(2, 3, 2), (1, 3, 2), (0, 3, 2)])
block(25, 0, 27, 3, 3, [(25, 3, 2)])
block(0, 24, 2, 27, 3, [(2, 24, 2)])
block(25, 24, 27, 27, 3, [(25, 24, 2), (26, 24, 2), (27, 24, 2)])
# side landings, west and east
block(0, 11, 2, 16, 1)
block(25, 11, 27, 16, 1)
# the shrine island in the middle, round Mael's bell
block(10, 10, 17, 17, 1)
# drowned houses standing out of the water
block(3, 5, 7, 8, 3, [(7, 8, 2), (6, 8, 2), (3, 5, 4)])
block(20, 5, 24, 8, 2, [(24, 5, 3), (23, 5, 3)])
block(3, 19, 7, 22, 2, [(3, 22, 3), (4, 22, 3)])
block(20, 19, 24, 22, 3, [(20, 19, 2), (21, 19, 2), (24, 22, 4)])
block(17, 4, 18, 6, 2)     # a gatehouse on the north channel
block(9, 21, 10, 23, 2)    # and its twin on the south

# Mael's bell, fallen and cracked, across the middle of the island
for x in (13, 14):
    for z in (13, 14):
        P[z][x] = 'L'
# drowned columns of the old colonnade, and the shrine's own pillars
for (x, z) in [(10, 10), (17, 10), (10, 17), (17, 17),
               (8, 4), (19, 23), (5, 14), (22, 13), (8, 11), (19, 16), (11, 7), (16, 20)]:
    P[z][x] = 'p'
# braziers on the island and at the quay heads
for (x, z) in [(12, 11), (15, 16), (11, 15), (16, 12), (6, 2), (21, 25)]:
    P[z][x] = 'B'
# barricades and crates on the quays, wreckage in the water
for (x, z) in [(9, 2), (18, 2), (9, 25), (18, 25), (1, 13), (26, 14)]:
    P[z][x] = 'b'
for (x, z) in [(4, 1), (23, 1), (4, 26), (23, 26), (11, 12), (16, 15)]:
    P[z][x] = 'c'
for (x, z) in [(6, 11), (21, 16), (9, 8), (18, 19), (15, 9), (12, 18), (2, 9), (25, 18), (24, 10), (3, 17)]:
    P[z][x] = 'r'

# water steps up out of the flood, and ladders onto the roofs
stairs = [
    # down off the north quay (south faces) and the south quay (north faces)
    (5, 3, 5, 2), (11, 3, 11, 2), (16, 3, 16, 2), (22, 3, 22, 2),
    (5, 24, 5, 25), (11, 24, 11, 25), (16, 24, 16, 25), (22, 24, 22, 25),
    # onto the shrine island, one on each side and two more at the corners
    (12, 9, 12, 10), (15, 18, 15, 17), (9, 12, 10, 12), (18, 15, 17, 15),
    (11, 9, 11, 10), (16, 18, 16, 17),
    # onto the side landings
    (3, 12, 2, 12), (3, 15, 2, 15), (24, 12, 25, 12), (24, 15, 25, 15),
]
ladders = [
    # the drowned houses, from the water
    (4, 9, 4, 8), (8, 6, 7, 6), (19, 7, 20, 7), (22, 9, 22, 8),
    (5, 18, 5, 19), (8, 20, 7, 20), (22, 18, 22, 19), (19, 21, 20, 21),
    # gatehouses and bridge towers
    (16, 5, 17, 5), (11, 22, 10, 22),
    # warehouses from the quays
    (3, 2, 2, 2), (24, 2, 25, 2), (3, 25, 2, 25), (24, 25, 25, 25),
]
# plank walks across the water at quay height
bridges = []
def walk(cells, level=1):
    for (x, z) in cells:
        bridges.append({"x": x, "z": z, "level": level})
walk([(13, z) for z in range(3, 10)])            # north quay to the island
walk([(14, z) for z in range(18, 25)])           # island to the south quay
walk([(x, 13) for x in range(3, 10)])            # west landing to the island
walk([(x, 14) for x in range(18, 25)])           # island to the east landing

shards = [
    [13, 11, 1], [14, 16, 1],        # on the shrine island by the bell
    [6, 12, 0], [21, 15, 0],         # sunk in the flooded streets
    [9, 6, 0], [18, 21, 0],
    [4, 6, 3], [23, 21, 3],          # on the roofs
    [1, 14, 1], [26, 13, 1],         # on the side landings
]

deploy = {"0": [], "1": []}
for z in (26, 27):
    for x in range(3, 25):
        if H[z][x] == 1 and P[z][x] == '.':
            deploy["0"].append([x, z])
for z in (0, 1):
    for x in range(3, 25):
        if H[z][x] == 1 and P[z][x] == '.':
            deploy["1"].append([x, z])

bridge_cells = {(b["x"], b["z"]) for b in bridges}
for (x, z, tx, tz) in ladders + stairs:
    assert H[z][x] < H[tz][tx], ((x, z), (tx, tz), H[z][x], H[tz][tx])
    assert abs(x - tx) + abs(z - tz) == 1, ((x, z), (tx, tz))
    assert P[z][x] == '.' and P[tz][tx] == '.', ((x, z), (tx, tz))
    assert (x, z) not in bridge_cells and (tx, tz) not in bridge_cells, ((x, z), (tx, tz))
for (x, z, tx, tz) in stairs:
    assert H[tz][tx] - H[z][x] == 1, ((x, z), (tx, tz))
for sh in shards:
    assert H[sh[1]][sh[0]] == sh[2] and P[sh[1]][sh[0]] == '.', sh
for br in bridges:
    assert H[br["z"]][br["x"]] < br["level"] and P[br["z"]][br["x"]] == '.', br

# every deploy cell should reach every shard (walk, drop, stairs, ladders, planks)
def nodes():
    ns = set()
    for z in range(D):
        for x in range(W):
            if P[z][x] == '.':
                ns.add((x, z, H[z][x]))
    for b in bridges:
        ns.add((b["x"], b["z"], b["level"]))
    return ns
NS = nodes()
def top(x, z):
    best = None
    for (a, b, l) in NS:
        if a == x and b == z and (best is None or l > best):
            best = l
    return (x, z, best)
adj = {n: set() for n in NS}
for (x, z, l) in NS:
    for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        nx, nz = x + dx, z + dz
        if (nx, nz, l) in NS:
            adj[(x, z, l)].add((nx, nz, l))
        elif 0 <= nx < W and 0 <= nz < D and H[nz][nx] < l and (nx, nz, H[nz][nx]) in NS:
            adj[(x, z, l)].add((nx, nz, H[nz][nx]))     # drop
    if l != H[z][x] and (x, z, H[z][x]) in NS:
        adj[(x, z, l)].add((x, z, H[z][x]))             # off a plank
for (x, z, tx, tz) in ladders + stairs:
    a, b = top(x, z), top(tx, tz)
    adj[a].add(b)
    adj[b].add(a)
def reach(start):
    seen = {start}
    q = deque([start])
    while q:
        n = q.popleft()
        for m in adj[n]:
            if m not in seen:
                seen.add(m)
                q.append(m)
    return seen
for side in ("0", "1"):
    r = reach((deploy[side][0][0], deploy[side][0][1], 1))
    for sh in shards:
        assert (sh[0], sh[1], sh[2]) in r, ("shard unreachable", side, sh)
    for d2 in deploy["1" if side == "0" else "0"]:
        assert (d2[0], d2[1], 1) in r, ("enemy unreachable", side, d2)
    # nobody may be stranded on a roof
    for n in NS:
        assert (deploy[side][0][0], deploy[side][0][1], 1) in reach(n), ("stranded", n)
    break

data = {
    "name": "The Drowned Quarter",
    "desc": "The night the god fell, the river wall broke and the low quarter went under. Black water stands waist deep in its streets; the quays, the roofs and the shrine of Mael stay dry, joined by plank walks. The sea god's great bell lies cracked in the shrine court, and godshards glint in the shallows.",
    "cell": 2.0, "storey": 3.0, "width": W, "depth": D,
    "heights": [''.join(str(v) for v in row) for row in H],
    "props": [''.join(row) for row in P],
    "legend": {"L": "bell", "p": "pillar", "B": "brazier", "b": "barricade", "r": "rubble", "c": "crates"},
    "ladders": [{"x": a, "z": b, "tx": c, "tz": d} for (a, b, c, d) in ladders],
    "stairs": [{"x": a, "z": b, "tx": c, "tz": d} for (a, b, c, d) in stairs],
    "bridges": bridges,
    "shards": shards,
    "deploy": deploy,
    "water": 0.8,
    "objective": [13, 13],
    "fires": [[1, 1], [26, 1], [1, 26], [26, 26], [4, 6], [23, 21], [22, 6], [5, 20]],
}
json.dump(data, open('data/maps/drowned.json', 'w'), indent=1)
print('\n'.join(data["heights"]))
print()
print('\n'.join(data["props"]))
