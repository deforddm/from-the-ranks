"""Builds the other battle maps of Hethra (the Idol Square is tools/make_map.py).

Same format: a grid of 2 m cells, each with a height in storeys (3 m each),
props on top, ladders and stairs from a cell to a taller neighbour, plank
bridges laid across gaps at a given storey.
Run: python3 tools/make_maps.py
"""
import json
import os
import random

OUT = os.path.join(os.path.dirname(__file__), "..", "data", "maps")


class Map:
    def __init__(self, w, d, seed, base=0):
        self.W, self.D = w, d
        self.rnd = random.Random(seed)
        self.H = [[base] * w for _ in range(d)]
        self.P = [["." for _ in range(w)] for _ in range(d)]
        self.ladders, self.stairs, self.bridges = [], [], []

    def inb(self, x, z):
        return 0 <= x < self.W and 0 <= z < self.D

    def block(self, x0, z0, x1, z1, h):
        for z in range(z0, z1 + 1):
            for x in range(x0, x1 + 1):
                self.H[z][x] = h

    def erode(self, chance, min_h=2):
        for z in range(self.D):
            for x in range(self.W):
                if self.H[z][x] >= min_h and self.rnd.random() < chance:
                    edge = any(self.inb(x + dx, z + dz) and self.H[z + dz][x + dx] < self.H[z][x]
                               for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)))
                    if edge:
                        self.H[z][x] -= 1

    def find_up(self, x, z):
        best = None
        for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            tx, tz = x + dx, z + dz
            if self.inb(tx, tz) and self.H[tz][tx] > self.H[z][x] and self.P[tz][tx] == ".":
                if best is None or self.H[tz][tx] < self.H[best[1]][best[0]]:
                    best = (tx, tz)
        return best

    def link(self, kind, x, z, to=None):
        t = to or self.find_up(x, z)
        if not t:
            return False
        tx, tz = t
        assert self.H[tz][tx] > self.H[z][x], (x, z, tx, tz)
        self.P[z][x] = "."
        self.P[tz][tx] = "."
        (self.ladders if kind == "ladder" else self.stairs).append({"x": x, "z": z, "tx": tx, "tz": tz})
        return True

    def bridge(self, x, z, level):
        assert self.H[z][x] < level, (x, z, level)
        self.bridges.append({"x": x, "z": z, "level": level})

    def scatter(self, ch, n, ok):
        for _ in range(n * 4):
            if n <= 0:
                break
            x, z = self.rnd.randrange(self.W), self.rnd.randrange(self.D)
            if self.P[z][x] == "." and ok(x, z):
                self.P[z][x] = ch
                n -= 1

    def save(self, file_id, name, desc, shards, deploy0, deploy1, objective, fires, extra=None):
        for (x, z) in shards:
            self.P[z][x] = "."
        bset = {(b["x"], b["z"]): b["level"] for b in self.bridges}
        sh = [[x, z, bset.get((x, z), self.H[z][x])] for (x, z) in shards]
        d0 = [[x, z] for (x, z) in deploy0 if self.P[z][x] == "."]
        d1 = [[x, z] for (x, z) in deploy1 if self.P[z][x] == "."]
        data = {
            "name": name, "desc": desc, "cell": 2.0, "storey": 3.0, "width": self.W, "depth": self.D,
            "heights": ["".join(str(h) for h in row) for row in self.H],
            "props": ["".join(row) for row in self.P],
            "legend": {"T": "idol", "p": "pillar", "B": "brazier", "b": "barricade", "r": "rubble", "c": "crates"},
            "ladders": self.ladders, "stairs": self.stairs, "bridges": self.bridges,
            "shards": sh, "deploy": {"0": d0, "1": d1},
            "objective": list(objective), "fires": [list(f) for f in fires],
        }
        if extra:
            data.update(extra)
        path = os.path.join(OUT, file_id + ".json")
        with open(path, "w") as f:
            json.dump(data, f, indent=1)
        print("wrote", path)
        for z in range(self.D):
            line = ""
            for x in range(self.W):
                c = self.P[z][x]
                if (x, z) in bset:
                    c = "="
                line += (str(self.H[z][x]) if c == "." else c)
            print(f"{z:2d} {line}")
        print("ladders", len(self.ladders), "stairs", len(self.stairs), "bridges", len(self.bridges), "deploy", len(d0), len(d1))


def causeway():
    """The Broken Causeway: a dry canal cuts the map east to west under
    raised quays. Plank bridges cross it; warehouses and tenements line both
    banks, their roofs joined by more planks over the alleys."""
    m = Map(28, 28, 9127, base=1)
    # the canal bed
    m.block(0, 12, 27, 15, 0)
    # north bank buildings (quay street z 0-1, alleys between, quay z 10-11)
    m.block(1, 3, 6, 8, 3); m.block(1, 3, 3, 5, 4)
    m.block(9, 3, 12, 9, 2)
    m.block(15, 2, 19, 8, 3)
    m.block(22, 3, 26, 9, 2); m.block(24, 3, 26, 5, 3)
    # south bank
    m.block(1, 19, 5, 24, 2)
    m.block(8, 18, 12, 25, 3); m.block(10, 22, 12, 25, 4)
    m.block(15, 19, 19, 24, 2)
    m.block(22, 18, 26, 25, 3)
    m.erode(0.08, min_h=3)
    # a fallen arch in the canal: a low ruin you can climb
    m.block(13, 13, 14, 14, 1)
    # bridges over the canal at quay level
    for z in range(12, 16):
        m.bridge(4, z, 1)
        m.bridge(20, z, 1)
    for z in (12, 15):
        m.bridge(13, z, 1)
        m.bridge(14, z, 1)
    # planks between roofs across the alleys
    for x in (7, 8):
        m.bridge(x, 5, 2)
    for x in (13, 14):
        m.bridge(x, 6, 2)
    for x in (20, 21):
        m.bridge(x, 6, 2)
    for x in (6, 7):
        m.bridge(x, 21, 2)
    for x in (13, 14):
        m.bridge(x, 21, 2)
    for x in (20, 21):
        m.bridge(x, 21, 2)
    # stairs down into the canal, ladders up the warehouses
    for (x, z, t) in [(1, 12, (1, 11)), (10, 12, (10, 11)), (17, 15, (17, 16)), (26, 15, (26, 16)),
                      (8, 15, (8, 16)), (24, 12, (24, 11))]:
        m.link("stairs", x, z, t)
    for (x, z) in [(7, 6), (8, 8), (13, 4), (14, 8), (21, 4), (20, 9), (0, 6), (27, 7),
                   (6, 22), (7, 20), (13, 20), (14, 24), (20, 20), (21, 23), (0, 21), (27, 20)]:
        m.link("ladder", x, z)
    # tower tops
    m.link("ladder", 4, 4, (3, 4))
    m.link("ladder", 11, 21, (11, 22))
    m.link("ladder", 25, 6, (25, 5))
    # props
    for (x, z) in [(2, 1), (25, 1), (2, 26), (25, 26), (9, 11), (18, 16)]:
        m.P[z][x] = "B"
    for (x, z) in [(6, 10), (21, 10), (6, 17), (21, 17), (11, 1), (16, 26), (3, 16), (24, 11)]:
        m.P[z][x] = "b"
    for (x, z) in [(7, 11), (19, 16)]:
        m.P[z][x] = "p"
    m.scatter("r", 18, lambda x, z: m.H[z][x] == 0 and x not in (4, 20, 13, 14))
    m.scatter("c", 10, lambda x, z: m.H[z][x] == 1 and z in (1, 10, 11, 16, 17, 26) and 2 < x < 25)
    m.scatter("r", 8, lambda x, z: m.H[z][x] >= 2)
    shards = [(2, 13), (25, 14), (10, 14), (17, 13), (2, 6), (25, 22), (11, 6), (16, 22), (13, 13)]
    deploy1 = [(x, z) for z in range(0, 2) for x in range(5, 23) if m.H[z][x] == 1]
    deploy0 = [(x, z) for z in range(26, 28) for x in range(5, 23) if m.H[z][x] == 1]
    m.save("causeway", "The Broken Causeway",
           "Hethra's old canal has run dry, and the fall split its stone bridges. Shards lie in the canal bed, and the warehouses on both banks give shooters a long view down it.",
           shards, deploy0, deploy1, objective=(13, 13), fires=[(1, 8), (26, 19), (10, 24), (-3, 13), (31, 14), (13, -4), (14, 31)])


def tower_ward():
    """The Tower Ward: tall, tight ruins in a maze of alleys, a small plaza
    in the middle. A climber's map: fights happen on the roofs."""
    m = Map(28, 28, 5531, base=0)
    rnd = m.rnd
    # blocks on a loose grid with alleys between; a small plaza in the middle
    xs = [(1, 4), (7, 10), (13, 14), (17, 20), (23, 26)]
    zs = [(3, 6), (9, 11), (16, 18), (21, 24)]
    for (x0, x1) in xs:
        for (z0, z1) in zs:
            if x0 == 13:
                continue        # the north-south street through the plaza
            if (x0, z0) in ((7, 9), (17, 9), (7, 16), (17, 16)):
                h = rnd.choice([1, 2])
            else:
                h = rnd.choice([2, 3, 3, 4])
            m.block(x0, z0, x1, z1, h)
            # a broken corner or a taller tower on some blocks
            r = rnd.random()
            if r < 0.35 and h >= 2:
                m.block(x0, z0, x0 + 1, z0 + 1, min(4, h + 1))
            elif r < 0.6:
                m.block(x1, z1, x1, z1, max(1, h - 1))
    # plaza
    m.block(11, 12, 16, 15, 0)
    m.erode(0.1, min_h=3)
    # access: every block gets a ladder or stair from the street, roofs link up
    for (x0, x1) in xs:
        for (z0, z1) in zs:
            if x0 == 13:
                continue
            cands = [(x0 - 1, z0 + 1), (x1 + 1, z1 - 1), (x0 + 1, z1 + 1), (x1 - 1, z0 - 1)]
            rnd.shuffle(cands)
            n = 0
            for (x, z) in cands:
                if m.inb(x, z) and m.H[z][x] == 0 and m.P[z][x] == ".":
                    kind = "stairs" if n == 0 and rnd.random() < 0.35 else "ladder"
                    if m.link(kind, x, z):
                        n += 1
                if n >= 2:
                    break
    # climbs from a lower roof onto a taller part of the same block or a neighbour
    for z in range(m.D):
        for x in range(m.W):
            if m.H[z][x] >= 1 and rnd.random() < 0.06:
                t = m.find_up(x, z)
                if t:
                    m.link("ladder", x, z, t)
    # plank walks between roofs across the alleys, where both sides stand tall enough
    have = set()
    blocks = [(x0, x1, z0, z1) for (x0, x1) in xs for (z0, z1) in zs if x0 != 13]
    for (ax0, ax1, az0, az1) in blocks:
        for (bx0, bx1, bz0, bz1) in blocks:
            if bx0 > ax1 and bx0 - ax1 <= 3 and az0 == bz0 and rnd.random() < 0.6:
                for z in rnd.sample(range(az0, az1 + 1), 1):
                    if m.H[z][ax1] >= 2 and m.H[z][bx0] >= 2:
                        for x in range(ax1 + 1, bx0):
                            if (x, z) not in have and m.H[z][x] < 2:
                                m.bridge(x, z, 2)
                                have.add((x, z))
            if bz0 > az1 and bz0 - az1 <= 3 and ax0 == bx0 and rnd.random() < 0.5:
                for x in rnd.sample(range(ax0, ax1 + 1), 1):
                    if m.H[az1][x] >= 2 and m.H[bz0][x] >= 2:
                        for z in range(az1 + 1, bz0):
                            if (x, z) not in have and m.H[z][x] < 2:
                                m.bridge(x, z, 2)
                                have.add((x, z))
    # the plaza: a broken idol of the Fallen One and pillars
    for (x, z) in [(13, 13), (14, 13), (13, 14), (14, 14)]:
        m.P[z][x] = "T"
    for (x, z) in [(11, 12), (16, 15), (11, 15), (16, 12)]:
        m.P[z][x] = "p"
    for (x, z) in [(12, 1), (15, 26), (5, 13), (22, 14)]:
        m.P[z][x] = "B"
    for (x, z) in [(13, 8), (14, 19), (6, 14), (21, 13), (3, 19), (24, 7)]:
        if m.H[z][x] == 0 and m.P[z][x] == ".":
            m.P[z][x] = "b"
    m.scatter("r", 22, lambda x, z: m.H[z][x] == 0 and 2 < z < 25)
    m.scatter("c", 8, lambda x, z: m.H[z][x] == 0 and 2 < z < 25)
    m.scatter("r", 14, lambda x, z: m.H[z][x] >= 2)
    # shards: plaza, alleys and high roofs
    shards = [(12, 13), (15, 14), (2, 4), (25, 23), (8, 10), (19, 17), (24, 4), (3, 23), (13, 4), (14, 23)]
    for (x, z) in shards:
        m.P[z][x] = "."
    deploy1 = [(x, z) for z in range(0, 2) for x in range(4, 24) if m.H[z][x] == 0]
    deploy0 = [(x, z) for z in range(26, 28) for x in range(4, 24) if m.H[z][x] == 0]
    m.save("tower_ward", "The Tower Ward",
           "The rich quarter's towers stood tallest, so they fell hardest. Tight alleys, broken stairs and plank walks between the roofs: whoever holds the heights holds the ward.",
           shards, deploy0, deploy1, objective=(13, 13), fires=[(2, 9), (25, 17), (9, 22), (-3, 15), (31, 11), (14, -4), (13, 31)])


if __name__ == "__main__":
    causeway()
    tower_ward()
