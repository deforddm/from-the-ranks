#!/usr/bin/env python3
"""Synthesizes every sound and piece of music in Hethra from nothing but
numbers: no samples, no recordings, no downloads. Writes Ogg Vorbis files to
audio/ (needs numpy and ffmpeg with libvorbis).

    python3 tools/make_audio.py            # everything
    python3 tools/make_audio.py sfx        # only the sound effects
"""
import os
import subprocess
import sys
import wave

import numpy as np

SR = 44100
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "audio")
rng = np.random.default_rng(1171)


# ------------------------------------------------------------------ basics

def T(d):
    return np.arange(int(SR * d)) / SR


def noise(d):
    return rng.uniform(-1, 1, int(SR * d))


def fft_filter(x, resp):
    """Filter x by a frequency response function resp(freqs) -> gain."""
    n = len(x)
    m = 1 << int(np.ceil(np.log2(max(2, n))))
    X = np.fft.rfft(x, m)
    f = np.fft.rfftfreq(m, 1 / SR)
    return np.fft.irfft(X * resp(f), m)[:n]


def lowpass(x, fc, order=2):
    return fft_filter(x, lambda f: 1 / np.sqrt(1 + (f / fc) ** (2 * order)))


def highpass(x, fc, order=2):
    return fft_filter(x, lambda f: 1 / np.sqrt(1 + (fc / np.maximum(f, 1e-3)) ** (2 * order)))


def bandpass(x, lo, hi, order=2):
    return highpass(lowpass(x, hi, order), lo, order)


def formant(x, peaks):
    """peaks: [(freq, bandwidth, gain)]: a vowel-like resonant filter."""
    def resp(f):
        g = np.zeros_like(f) + 0.02
        for fc, bw, gain in peaks:
            g += gain / (1 + ((f - fc) / bw) ** 2)
        return g
    return fft_filter(x, resp)


def env_exp(n, tau):
    return np.exp(-np.arange(n) / (SR * tau))


def ar(n, a, r):
    """Linear attack, exponential-ish release to the end."""
    e = np.ones(n)
    na = max(1, int(SR * a))
    na = min(na, n)
    e[:na] = np.linspace(0, 1, na)
    nr = min(n - na, int(SR * r))
    if nr > 0:
        e[n - nr:] *= np.linspace(1, 0, nr) ** 1.6
    return e


def saw(freq, d, phase=0.0):
    """Band-limited-ish sawtooth by additive harmonics (freq may be an array)."""
    t = T(d)
    if np.isscalar(freq):
        ph = 2 * np.pi * freq * t + phase
        f0 = freq
    else:
        ph = 2 * np.pi * np.cumsum(freq) / SR + phase
        f0 = float(np.max(freq))
    out = np.zeros_like(t)
    k = 1
    while k * f0 < 9000 and k < 60:
        out += np.sin(k * ph) / k
        k += 1
    return out * 0.6


def sine(freq, d, phase=0.0):
    t = T(d)
    if np.isscalar(freq):
        return np.sin(2 * np.pi * freq * t + phase)
    return np.sin(2 * np.pi * np.cumsum(freq) / SR + phase)


def glide(f0, f1, d, curve=1.0):
    n = int(SR * d)
    k = np.linspace(0, 1, n) ** curve
    return f0 * (f1 / f0) ** k


def reverb(x, seconds=2.0, mix=0.3, damp=4000, pre=0.02, stereo=True):
    """Convolution with a decaying noise burst: a cheap, smooth hall."""
    n_ir = int(SR * seconds)
    outs = []
    for ch in range(2 if stereo else 1):
        ir = rng.normal(0, 1, n_ir) * np.exp(-np.arange(n_ir) / (SR * seconds / 6.9))
        ir = lowpass(ir, damp, 1)
        ir = np.concatenate([np.zeros(int(SR * pre)), ir])
        ir /= np.sqrt(np.sum(ir ** 2)) + 1e-9
        src = x if x.ndim == 1 else x[:, ch]
        m = 1 << int(np.ceil(np.log2(len(src) + len(ir))))
        wet = np.fft.irfft(np.fft.rfft(src, m) * np.fft.rfft(ir, m), m)[:len(src) + len(ir)]
        dry = np.concatenate([src, np.zeros(len(ir))])
        outs.append(dry * (1 - mix) + wet * mix * 0.35)
    if not stereo:
        return outs[0]
    return np.stack(outs, axis=1)


def pad_to(x, n):
    if len(x) >= n:
        return x[:n]
    shape = (n - len(x),) + x.shape[1:]
    return np.concatenate([x, np.zeros(shape)])


def norm(x, peak=0.89):
    m = np.max(np.abs(x)) + 1e-9
    return x * (peak / m)


def write(name, x, stereo=False, q=5):
    os.makedirs(ROOT, exist_ok=True)
    x = np.asarray(x, dtype=np.float64)
    if x.ndim == 1 and stereo:
        x = np.stack([x, x], axis=1)
    x = np.clip(x, -1, 1)
    pcm = (x * 32000).astype(np.int16)
    wav = os.path.join(ROOT, name + ".tmp.wav")
    with wave.open(wav, "wb") as w:
        w.setnchannels(2 if x.ndim == 2 else 1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())
    out = os.path.join(ROOT, name + ".ogg")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-c:a", "libvorbis", "-q:a", str(q), out], check=True)
    os.remove(wav)
    print("  %-22s %5.1f s  %4d KB" % (name, len(x) / SR, os.path.getsize(out) // 1024))


def loopable(x, fade=1.5):
    """Crossfade the tail over the head so the file loops without a seam."""
    nf = int(SR * fade)
    head = x[:nf].copy()
    tail = x[-nf:]
    k = np.linspace(0, 1, nf)
    if x.ndim == 2:
        k = k[:, None]
    body = x[nf:-nf].copy() if len(x) > 2 * nf else x[nf:].copy()
    blend = tail * (1 - k) + head * k
    return np.concatenate([body, blend])


# ------------------------------------------------------------------ sound effects

def metal(f0, d, ratios=(1.0, 2.76, 5.40, 8.93, 13.34), decay=0.35, bright=1.0):
    t = T(d)
    out = np.zeros_like(t)
    for i, r in enumerate(ratios):
        a = (0.8 ** i) * (bright if i > 1 else 1.0)
        f = f0 * r * (1 + rng.uniform(-0.01, 0.01))
        out += a * np.sin(2 * np.pi * f * t + rng.uniform(0, 6)) * np.exp(-t / (decay / (1 + 0.45 * i)))
    return out


def transient(d=0.012, lo=1500):
    n = noise(d) * np.linspace(1, 0, int(SR * d)) ** 2
    return highpass(n, lo)


def sfx_clash(i):
    f0 = [930, 1180, 1050, 1320][i]
    d = 0.9
    x = metal(f0, d, decay=0.28 + 0.06 * i, bright=1.1)
    x += 0.35 * metal(f0 * 1.41, d, decay=0.2)
    x[:int(SR * 0.012)] += transient() * 2.2
    x += 0.6 * pad_to(lowpass(noise(0.08), 900) * env_exp(int(SR * 0.08), 0.02), len(x))
    return norm(reverb(x, 0.9, 0.22, stereo=False), 0.8)


def sfx_parry():
    x = metal(1560, 1.4, ratios=(1.0, 2.32, 4.25, 6.63), decay=0.6)
    x[:int(SR * 0.01)] += transient(0.01, 2500) * 2.5
    return norm(reverb(x, 1.2, 0.3, stereo=False), 0.75)


def sfx_swing(i):
    d = 0.32
    n = int(SR * d)
    x = noise(d)
    lo = bandpass(x, 300, 900)
    hi = bandpass(x, 900, 2600)
    k = np.sin(np.linspace(0, np.pi, n)) ** 2
    pos = np.linspace(0, 1, n)
    y = (lo * (1 - pos) + hi * pos) * k
    y *= 1.0 + 0.15 * i
    return norm(y, 0.55)


def sfx_hit(i):
    """Flesh and leather taking a blow."""
    d = 0.35
    n = int(SR * d)
    f = glide(130 - i * 15, 55, d, 0.4)
    body = sine(f, d) * env_exp(n, 0.07)
    smack = lowpass(noise(d), 1400) * env_exp(n, 0.03)
    crunch = bandpass(noise(d), 1800, 4500) * env_exp(n, 0.012) * 0.6
    return norm(body * 1.1 + smack + crunch, 0.85)


def sfx_bow():
    d = 0.7
    n = int(SR * d)
    t = T(d)
    f0 = 98
    twang = np.zeros(n)
    for k in range(1, 18):
        twang += np.sin(2 * np.pi * f0 * k * t * (1 + 0.002 * k)) / k * np.exp(-t * (6 + k * 3.5))
    twang *= 1 + 0.4 * np.exp(-t * 30)
    whoosh = bandpass(noise(d), 1200, 5000) * np.exp(-((t - 0.12) / 0.07) ** 2) * 0.5
    return norm(twang + whoosh, 0.8)


def sfx_crossbow():
    d = 0.6
    n = int(SR * d)
    t = T(d)
    clack = bandpass(noise(d), 1500, 6000) * env_exp(n, 0.008) * 2.0
    thunk = sine(glide(220, 90, d, 0.3), d) * env_exp(n, 0.06)
    string = metal(310, d, ratios=(1, 2.01, 3.02, 4.05), decay=0.12) * 0.4
    whoosh = bandpass(noise(d), 1500, 6000) * np.exp(-((t - 0.1) / 0.06) ** 2) * 0.4
    return norm(clack + thunk + string + whoosh, 0.85)


def sfx_arrow_hit():
    d = 0.3
    n = int(SR * d)
    thud = sine(glide(160, 70, d, 0.5), d) * env_exp(n, 0.05)
    tick = bandpass(noise(d), 2000, 7000) * env_exp(n, 0.006)
    return norm(thud + tick * 0.8, 0.75)


def sfx_whiff():
    d = 0.45
    n = int(SR * d)
    t = T(d)
    x = bandpass(noise(d), 1800, 7000) * np.exp(-((t - 0.15) / 0.09) ** 2)
    return norm(x, 0.4)


def sfx_step(i):
    d = 0.16
    n = int(SR * d)
    grit = bandpass(noise(d), 600 + 150 * i, 4000) * env_exp(n, 0.02)
    thump = sine(90 + 12 * i, d) * env_exp(n, 0.025)
    return norm(grit * 0.7 + thump, 0.35 + 0.04 * i)


def sfx_ladder():
    d = 0.25
    n = int(SR * d)
    knock = metal(420, d, ratios=(1, 1.6, 2.3, 3.7), decay=0.05) * 0.5
    wood = bandpass(noise(d), 300, 1600) * env_exp(n, 0.02)
    return norm(knock + wood, 0.4)


def boom(d, f0, f1, tau):
    n = int(SR * d)
    sub = sine(glide(f0, f1, d, 0.5), d) * env_exp(n, tau * 0.6)
    rumble = lowpass(noise(d), 300, 2) * env_exp(n, tau)
    crack = highpass(noise(d), 800) * env_exp(n, 0.03)
    return sub * 1.4 + rumble * 2.0 + crack * 0.9


def sfx_blast():
    x = boom(3.0, 70, 28, 0.55)
    x += 0.3 * lowpass(noise(3.0), 2000) * env_exp(int(SR * 3.0), 0.25)  # debris
    return norm(reverb(x, 2.4, 0.35, damp=1800), 0.95)


def sfx_cracker():
    x = boom(1.6, 120, 45, 0.18)
    x[:int(SR * 0.02)] += highpass(noise(0.02), 1500) * 3
    return norm(reverb(x, 1.6, 0.3, damp=2500), 0.9)


def sfx_lightning():
    d = 3.2
    n = int(SR * d)
    crack = highpass(noise(d), 600) * env_exp(n, 0.05) * 1.8
    sizzle = bandpass(noise(d), 3000, 9000) * env_exp(n, 0.25) * 0.4 * (rng.uniform(0, 1, n) > 0.6)
    thunder = lowpass(noise(d), 180, 2) * np.concatenate([np.zeros(int(SR * 0.15)), env_exp(n - int(SR * 0.15), 0.9)]) * 3.0
    return norm(reverb(crack + sizzle + thunder, 2.5, 0.3, damp=2500), 0.95)


def sfx_spell():
    """Reaching into a warren: a rising, shimmering swell."""
    d = 1.8
    n = int(SR * d)
    t = T(d)
    out = np.zeros(n)
    for k, r in enumerate([1.0, 1.5, 2.0, 2.997, 4.01]):
        f = glide(220 * r, 440 * r, d, 0.7) * (1 + 0.006 * np.sin(2 * np.pi * (5 + k) * t))
        out += sine(f, d) * (0.7 ** k)
    out *= np.sin(np.linspace(0, np.pi, n)) ** 1.5
    air = bandpass(noise(d), 2500, 8000) * np.sin(np.linspace(0, np.pi, n)) ** 3 * 0.25
    return norm(reverb(out + air, 2.2, 0.45, damp=6000), 0.7)


def sfx_spell_fail():
    d = 1.1
    n = int(SR * d)
    t = T(d)
    tone = sine(glide(520, 140, d, 0.6), d) * env_exp(n, 0.3)
    fizz = bandpass(noise(d), 1500, 6000) * env_exp(n, 0.25) * (0.6 + 0.4 * np.sin(2 * np.pi * 23 * t))
    return norm(reverb(tone * 0.6 + fizz * 0.5, 1.2, 0.3, stereo=False), 0.6)


def sfx_shadow():
    """Shadow step: a breath sucked in and let out somewhere else."""
    d = 0.9
    n = int(SR * d)
    t = T(d)
    x = lowpass(noise(d), 900) * np.sin(np.linspace(0, np.pi, n)) ** 2
    low = sine(glide(90, 45, d), d) * np.sin(np.linspace(0, np.pi, n)) * 0.5
    return norm(reverb(x + low, 1.5, 0.4, damp=1500), 0.6)


def sfx_shard():
    d = 2.2
    t = T(d)
    out = np.zeros_like(t)
    for k, (f, tau) in enumerate([(1568, 1.1), (2349, 0.8), (3136, 0.6), (4699, 0.35), (2093, 0.9)]):
        out += np.sin(2 * np.pi * f * t) * np.exp(-(t - 0.07 * k).clip(0) / tau) * (t >= 0.07 * k) * 0.6
    return norm(reverb(out, 2.0, 0.4, damp=8000), 0.55)


def sfx_fall():
    d = 0.9
    n = int(SR * d)
    thud = sine(glide(110, 40, d, 0.4), d) * env_exp(n, 0.1) * 1.4
    gravel = bandpass(noise(d), 500, 5000) * env_exp(n, 0.18) * (rng.uniform(0, 1, n) > 0.75) * 0.8
    return norm(thud + gravel + lowpass(noise(d), 600) * env_exp(n, 0.05), 0.85)


def sfx_groan(i):
    """A wounded fighter: a sawtooth throat through a vowel filter."""
    d = 0.9 + 0.2 * i
    n = int(SR * d)
    t = T(d)
    f = glide(150 - 25 * i, 85 - 10 * i, d, 0.8) * (1 + 0.02 * np.sin(2 * np.pi * 6 * t))
    voice = saw(f, d)
    vowels = [[(520, 90, 1.0), (920, 110, 0.5), (2500, 200, 0.15)],
              [(640, 90, 1.0), (1100, 120, 0.45), (2600, 200, 0.12)],
              [(420, 80, 1.0), (800, 100, 0.5), (2400, 200, 0.1)]]
    v = formant(voice, vowels[i % 3])
    breath = bandpass(noise(d), 400, 3000) * 0.15
    e = ar(n, 0.06, d * 0.7)
    return norm((v + breath) * e, 0.6)


def sfx_bell():
    """The turn bell: a big cracked bell somewhere in the ruins."""
    d = 5.0
    t = T(d)
    f0 = 196
    out = np.zeros_like(t)
    for r, a, tau in [(0.5, 0.6, 3.5), (1.0, 1.0, 2.6), (1.19, 0.5, 2.0), (1.5, 0.45, 1.6), (2.0, 0.4, 1.3), (2.51, 0.3, 0.9), (2.66, 0.25, 0.8), (3.01, 0.2, 0.6), (4.07, 0.15, 0.4)]:
        out += a * np.sin(2 * np.pi * f0 * r * t * (1 + rng.uniform(-0.002, 0.002))) * np.exp(-t / tau)
    out[:int(SR * 0.01)] += transient(0.01, 800)
    return norm(reverb(out, 3.5, 0.35, damp=3500), 0.6)


def sfx_horn():
    """The rout: a ragged horn calling the band off the field."""
    d = 3.2
    n = int(SR * d)
    t = T(d)
    f = glide(116, 98, d, 2.0) * (1 + 0.01 * np.sin(2 * np.pi * 4.5 * t))
    x = saw(f, d) + 0.5 * saw(f * 1.5, d) + 0.3 * saw(f * 1.003, d)
    x = lowpass(x, 1100, 2)
    x *= ar(n, 0.5, 1.4)
    return norm(reverb(x, 3.0, 0.4, damp=2500), 0.7)


def sfx_ui(kind):
    if kind == "click":
        d = 0.06
        n = int(SR * d)
        x = metal(2400, d, ratios=(1, 2.1, 3.3), decay=0.015) + bandpass(noise(d), 1000, 5000) * env_exp(n, 0.004)
        return norm(x, 0.35)
    if kind == "hover":
        d = 0.05
        n = int(SR * d)
        return norm(sine(1800, d) * env_exp(n, 0.008), 0.12)
    if kind == "open":
        d = 0.5
        n = int(SR * d)
        x = bandpass(noise(d), 200, 1500) * np.sin(np.linspace(0, np.pi, n)) ** 2 * 0.7 + sine(glide(300, 180, d), d) * env_exp(n, 0.1) * 0.4
        return norm(x, 0.35)
    if kind == "coins":
        d = 0.9
        out = np.zeros(int(SR * d))
        for k in range(7):
            at = int(SR * (0.05 + 0.07 * k + rng.uniform(0, 0.03)))
            c = metal(rng.uniform(2800, 4200), 0.3, ratios=(1, 1.47, 2.31, 3.2), decay=0.08)
            out[at:at + len(c)] += c[:len(out) - at] * rng.uniform(0.4, 1.0)
        return norm(reverb(out, 0.8, 0.2, stereo=False), 0.45)


def make_sfx():
    print("sound effects")
    for i in range(4):
        write("clash_%d" % i, sfx_clash(i))
    write("parry", sfx_parry())
    for i in range(3):
        write("swing_%d" % i, sfx_swing(i))
        write("hit_%d" % i, sfx_hit(i))
        write("groan_%d" % i, sfx_groan(i))
    write("bow", sfx_bow())
    write("crossbow", sfx_crossbow())
    write("arrow_hit", sfx_arrow_hit())
    write("whiff", sfx_whiff())
    for i in range(4):
        write("step_%d" % i, sfx_step(i))
    write("ladder", sfx_ladder())
    write("blast", sfx_blast(), stereo=True)
    write("cracker", sfx_cracker(), stereo=True)
    write("lightning", sfx_lightning(), stereo=True)
    write("spell", sfx_spell(), stereo=True)
    write("spell_fail", sfx_spell_fail())
    write("shadow", sfx_shadow(), stereo=True)
    write("shard", sfx_shard(), stereo=True)
    write("fall", sfx_fall())
    write("bell", sfx_bell(), stereo=True)
    write("horn", sfx_horn(), stereo=True)
    for k in ["click", "hover", "open", "coins"]:
        write("ui_" + k, sfx_ui(k))


# Water and dust, added for 0.14. They use their own random stream so that every
# older sound comes out exactly as it did before.
wrng = np.random.default_rng(1414)


def wnoise(d):
    return wrng.uniform(-1, 1, int(SR * d))


def sfx_splash(i):
    """A foot sloshing down into knee-deep water: a dull plunge, then the
    burble of water closing over it, with a few bright droplets."""
    d = 0.55
    n = int(SR * d)
    t = T(d)
    plunge = lowpass(wnoise(d), 700 + 120 * i) * env_exp(n, 0.06) * 1.2
    slosh = bandpass(wnoise(d), 300, 2200) * ar(n, 0.04, 0.32) * 0.7
    # bubbles: short rising chirps scattered through the tail
    bub = np.zeros(n)
    for k in range(7 + i):
        at = wrng.uniform(0.03, 0.4)
        f0 = wrng.uniform(500, 1400)
        dd = wrng.uniform(0.02, 0.05)
        m = int(SR * dd)
        s0 = int(SR * at)
        if s0 + m >= n:
            continue
        tt = np.arange(m) / SR
        bub[s0:s0 + m] += np.sin(2 * np.pi * (f0 * tt + f0 * 6 * tt * tt)) * np.exp(-tt / (dd * 0.4)) * wrng.uniform(0.15, 0.4)
    drip = highpass_like(wnoise(d)) * env_exp(n, 0.015) * 0.25
    return norm(plunge + slosh + bub + drip, 0.42 + 0.04 * i)


def highpass_like(x):
    return x - lowpass(x, 3000)


def sfx_crumble():
    """Dry flesh and bone giving way: a crackle of breaking, then a long
    hiss of dust pouring down onto stone."""
    d = 2.0
    n = int(SR * d)
    crack = bandpass(wnoise(d), 1200, 7000) * (wrng.uniform(0, 1, n) > 0.93) * env_exp(n, 0.35) * 1.4
    snap = np.zeros(n)
    for k in range(9):
        s0 = int(SR * wrng.uniform(0.0, 0.7))
        m = int(SR * 0.03)
        if s0 + m < n:
            snap[s0:s0 + m] += bandpass(wnoise(0.03), 900, 5000) * env_exp(m, 0.006) * wrng.uniform(0.6, 1.2)
    pour = bandpass(wnoise(d), 2000, 9000) * ar(n, 0.25, 1.3) * 0.55
    thud = sine(glide(80, 45, d, 0.5), d) * env_exp(n, 0.12) * 0.6
    return norm(reverb(crack + snap + pour + thud, 1.4, 0.25, damp=6000, stereo=False), 0.6)


def make_water_dust():
    print("water and dust")
    state = rng.bit_generator.state   # the reverb draws on the shared stream; put it back after
    for i in range(3):
        write("splash_%d" % i, sfx_splash(i))
    write("crumble", sfx_crumble())
    rng.bit_generator.state = state


# ------------------------------------------------------------------ the strongbox

crng = np.random.default_rng(1616)


def cnoise(d):
    return crng.standard_normal(int(SR * d))


def sfx_dig(i):
    """A spade bitten into rubble and earth twice: a scrape of iron on grit,
    a crunch, and loose soil pattering off the blade."""
    d = 1.3
    n = int(SR * d)
    out = np.zeros(n)
    for k, t0 in enumerate([0.02, 0.55 + 0.05 * i]):
        s0 = int(SR * t0)
        m = int(SR * 0.42)
        if s0 + m > n:
            m = n - s0
        scrape = bandpass(cnoise(0.42)[:m], 1800, 6500) * ar(m, 0.02, 0.18) * 0.55
        crunch = bandpass(cnoise(0.42)[:m], 250, 1600) * (crng.uniform(0, 1, m) > 0.6) * env_exp(m, 0.09) * 1.2
        ring = metal(620 + 40 * i, 0.42, decay=0.08, bright=0.6)[:m] * 0.12
        patter = bandpass(cnoise(0.42)[:m], 1200, 5000) * (crng.uniform(0, 1, m) > 0.985) * ar(m, 0.12, 0.25) * 1.5
        out[s0:s0 + m] += scrape + crunch + ring + patter
    return norm(reverb(out, 0.9, 0.18, damp=5000, stereo=False), 0.55)


def sfx_chest():
    """An iron-bound box hauled up and set down: a heavy wooden thump, the
    rattle of its bands and the clink of coin inside."""
    d = 1.6
    n = int(SR * d)
    thump = lowpass(cnoise(d), 260) * env_exp(n, 0.07) * 2.4 + sine(glide(110, 60, d, 0.4), d) * env_exp(n, 0.1) * 0.7
    bands = metal(410, d, decay=0.18, bright=0.8) * 0.18
    coin = np.zeros(n)
    for k in range(11):
        s0 = int(SR * (0.06 + crng.uniform(0, 0.5)))
        c = metal(crng.uniform(2600, 4200), 0.3, ratios=(1.0, 2.4, 4.1), decay=0.05, bright=1.2) * crng.uniform(0.05, 0.12)
        m = min(len(c), n - s0)
        coin[s0:s0 + m] += c[:m]
    return norm(reverb(thump + bands + coin, 1.2, 0.22, damp=6000, stereo=False), 0.62)


def make_cache():
    print("strongbox")
    state = rng.bit_generator.state
    for i in range(2):
        write("dig_%d" % i, sfx_dig(i))
    write("chest", sfx_chest())
    rng.bit_generator.state = state


# ------------------------------------------------------------------ weather

wrng = np.random.default_rng(1717)


def wn(d):
    return wrng.standard_normal(int(SR * d))


def make_weather():
    """Rain on stone, and thunder rolling over the ruins."""
    print("weather")
    d = 40.0
    n = int(SR * d)
    t = T(d)
    chans = []
    for ch in range(2):
        # the hiss of rain everywhere, swelling with the gusts
        swell = 0.75 + 0.18 * np.sin(2 * np.pi * t / 9.0 + ch * 1.7) + 0.07 * np.sin(2 * np.pi * t / 3.1 + ch)
        hiss = bandpass(wn(d), 900, 9000, 2) * 0.22 * swell
        body = lowpass(wn(d), 700, 2) * 0.35 * swell
        # close drops: little ticks on stone and in puddles
        drops = np.zeros(n)
        for _ in range(int(d * 70)):
            at = wrng.integers(0, n - 800)
            ln = wrng.integers(120, 700)
            f0 = wrng.uniform(1400, 5200)
            k = np.arange(ln) / SR
            drops[at:at + ln] += np.sin(2 * np.pi * (f0 - 900 * k / k[-1]) * k) * env_exp(ln, wrng.uniform(0.0015, 0.006)) * wrng.uniform(0.03, 0.22)
        # water running off broken eaves somewhere
        gutter = bandpass(wn(d), 300, 1500, 2) * (0.5 + 0.5 * np.sin(2 * np.pi * t / 13.0 + ch)) * 0.12
        chans.append(hiss + body + drops + gutter)
    x = np.stack(chans, axis=1)
    write("amb_rain", norm(loopable(x, 2.0), 0.55), q=3)
    for i in range(3):
        d = 7.0
        n = int(SR * d)
        t = T(d)
        crack_at = 0.0 if i == 0 else 0.05
        rumble = lowpass(np.cumsum(wn(d)), 90, 2)
        rumble = rumble / (np.max(np.abs(rumble)) + 1e-9)
        # rolls: a few swells that die away over seconds
        roll = np.zeros(n)
        for k in range(4 + i):
            c = wrng.uniform(0.2, 3.5)
            roll += np.exp(-((t - c) ** 2) / (2 * wrng.uniform(0.25, 0.9) ** 2)) * wrng.uniform(0.4, 1.0)
        roll *= np.exp(-t / (2.2 + i * 0.4))
        crack = np.zeros(n)
        if i != 2:   # a near strike; the third is far off and only rumbles
            m = int(SR * 0.9)
            crack[:m] = highpass(wn(0.9), 700) * env_exp(m, 0.12) * 0.9 + bandpass(wn(0.9), 120, 900) * env_exp(m, 0.25) * 0.8
        x = rumble * roll * 1.4 + crack * (1.0 - crack_at)
        write("thunder_%d" % i, norm(reverb(x, 2.5, 0.35, damp=2500, stereo=False), 0.8 if i != 2 else 0.55))


# ------------------------------------------------------------------ ambience

def make_ambience():
    print("ambience")
    d = 48.0
    n = int(SR * d)
    t = T(d)
    chans = []
    for ch in range(2):
        brown = np.cumsum(rng.normal(0, 1, n))
        brown -= lowpass(brown, 0.5, 1)
        wind = lowpass(brown, 500, 2)
        gust = 0.55 + 0.25 * np.sin(2 * np.pi * t / 11.0 + ch) + 0.2 * np.sin(2 * np.pi * t / 4.3 + 2 * ch)
        whistle = bandpass(noise(d), 700, 1400, 3) * (0.5 + 0.5 * np.sin(2 * np.pi * t / 7.7 + ch)) ** 4 * 0.05
        chans.append(wind / (np.std(wind) + 1e-9) * gust * 0.25 + whistle)
    x = np.stack(chans, axis=1)
    # distant fires: a low roar and scattered crackles
    crackle = np.zeros(n)
    for _ in range(int(d * 9)):
        at = rng.integers(0, n - 2000)
        crackle[at:at + 600] += highpass(rng.uniform(-1, 1, 600), 1500) * env_exp(600, 0.002) * rng.uniform(0.05, 0.3)
    roar = lowpass(noise(d), 160, 2) * 0.6
    x[:, 0] += crackle * 0.6 + roar * 0.5
    x[:, 1] += np.roll(crackle, 12345) * 0.6 + roar * 0.5
    write("amb_ruins", norm(loopable(x, 2.0), 0.5), q=3)

    d = 30.0
    n = int(SR * d)
    fire = lowpass(noise(d), 220, 2) * 1.2
    pops = np.zeros(n)
    for _ in range(int(d * 22)):
        at = rng.integers(0, n - 3000)
        ln = rng.integers(200, 1800)
        pops[at:at + ln] += bandpass(rng.uniform(-1, 1, ln), 900, 7000) * env_exp(ln, rng.uniform(0.001, 0.006)) * rng.uniform(0.1, 0.9)
    hiss = bandpass(noise(d), 2500, 8000) * 0.04
    x = np.stack([fire + pops + hiss, fire + np.roll(pops, 7777) + hiss], axis=1)
    write("amb_fire", norm(loopable(x, 1.5), 0.5), q=3)


# ------------------------------------------------------------------ music

NOTE = {"C": -9, "C#": -8, "Db": -8, "D": -7, "D#": -6, "Eb": -6, "E": -5, "F": -4, "F#": -3, "Gb": -3,
        "G": -2, "G#": -1, "Ab": -1, "A": 0, "A#": 1, "Bb": 1, "B": 2}


def hz(name):
    """'D3' -> frequency."""
    pitch, octv = name[:-1], int(name[-1])
    return 440.0 * 2 ** ((NOTE[pitch] + 12 * (octv - 4)) / 12)


class Track:
    def __init__(self, seconds):
        self.n = int(SR * seconds)
        self.buf = np.zeros((self.n, 2))

    def add(self, at, x, pan=0.0, gain=1.0):
        i = int(SR * at)
        if i >= self.n:
            return
        x = x[: self.n - i]
        l = np.cos((pan + 1) * np.pi / 4) * gain
        r = np.sin((pan + 1) * np.pi / 4) * gain
        if x.ndim == 1:
            self.buf[i:i + len(x), 0] += x * l
            self.buf[i:i + len(x), 1] += x * r
        else:
            self.buf[i:i + len(x), 0] += x[:, 0] * l
            self.buf[i:i + len(x), 1] += x[:, 1] * r


def strings(freq, d, attack=1.2, release=1.5, cutoff=1800, vib=0.004):
    n = int(SR * d)
    t = T(d)
    out = np.zeros(n)
    for det in (-0.006, 0.0, 0.0065):
        f = freq * (1 + det) * (1 + vib * np.sin(2 * np.pi * (4.8 + det * 100) * t + rng.uniform(0, 6)))
        out += saw(f, d)
    out = lowpass(out, cutoff, 2)
    return out * ar(n, attack, release) / 3


def choir(freq, d, vowel="ah", attack=1.6, release=2.0):
    n = int(SR * d)
    t = T(d)
    out = np.zeros(n)
    for det in (-0.008, -0.003, 0.004, 0.009):
        f = freq * (1 + det) * (1 + 0.006 * np.sin(2 * np.pi * (5.2 + 40 * det) * t + rng.uniform(0, 6)))
        out += saw(f, d)
    peaks = {"ah": [(700, 110, 1.0), (1220, 130, 0.5), (2600, 220, 0.2)],
             "oo": [(330, 80, 1.0), (850, 120, 0.3), (2400, 200, 0.08)],
             "eh": [(530, 90, 1.0), (1850, 150, 0.45), (2500, 200, 0.2)]}[vowel]
    out = formant(out, peaks) + 0.04 * bandpass(noise(d), 2000, 6000)
    return out * ar(n, attack, release) / 4


def pluck(freq, d, bright=1.0, decay=1.6):
    """An oud-like plucked string: harmonics that die faster the higher they are."""
    t = T(d)
    out = np.zeros_like(t)
    for k in range(1, 20):
        if freq * k > 9000:
            break
        a = (1.0 / k) * (bright if k > 3 else 1.0) * (0.5 + 0.5 * abs(np.sin(k * 0.9)))
        out += a * np.sin(2 * np.pi * freq * k * t * (1 + 0.0007 * k * k)) * np.exp(-t * (1 / decay) * (1 + 0.6 * k))
    out[: int(SR * 0.004)] += bandpass(noise(0.004), 1500, 6000) * 0.3
    return out * 0.5


def drum(d=1.2, f0=72, f1=42, tau=0.35, skin=0.4):
    n = int(SR * d)
    body = sine(glide(f0, f1, d, 0.35), d) * env_exp(n, tau)
    hit = lowpass(noise(d), 1200) * env_exp(n, 0.03) * skin
    return body + hit


def frame_drum(d=0.5):
    n = int(SR * d)
    return sine(glide(180, 120, d), d) * env_exp(n, 0.08) * 0.6 + bandpass(noise(d), 400, 3000) * env_exp(n, 0.04) * 0.5


def drone(freqs, d):
    out = np.zeros(int(SR * d))
    for f in freqs:
        out += strings(f, d, attack=4.0, release=4.0, cutoff=700, vib=0.0015)
    return out


def make_title():
    """'The Fallen City': slow choir and strings over a drone, D phrygian."""
    bar = 4.0
    bars = 20
    tr = Track(bar * bars + 6)
    tr.add(0, drone([hz("D2"), hz("A2")], bar * bars + 2), gain=0.9)
    chords = [["D3", "F3", "A3"], ["Eb3", "G3", "Bb3"], ["D3", "F3", "A3"], ["C3", "F3", "A3"],
              ["Bb2", "D3", "F3"], ["C3", "Eb3", "G3"], ["D3", "F3", "A3"], ["D3", "F3", "A3"]]
    for i in range(bars):
        ch = chords[i % len(chords)]
        if i >= 2:
            for j, nm in enumerate(ch):
                tr.add(i * bar, choir(hz(nm), bar + 1.8, "ah" if i % 4 < 2 else "oo"), pan=-0.4 + 0.4 * j, gain=0.55)
        for j, nm in enumerate(ch[:2]):
            tr.add(i * bar, strings(hz(nm) / 2, bar + 1.5, attack=1.6, cutoff=1200), pan=0.3 - 0.6 * j, gain=0.45)
    # a lone bowed melody over the middle
    mel = [("A4", 2), ("Bb4", 1), ("A4", 1), ("G4", 2), ("F4", 2), ("E4", 3), ("D4", 5),
           ("F4", 2), ("G4", 1), ("A4", 1), ("Bb4", 2), ("C5", 2), ("A4", 3), ("G4", 1), ("A4", 4),
           ("D5", 2), ("C5", 1), ("Bb4", 1), ("A4", 2), ("G4", 2), ("F4", 2), ("Eb4", 2), ("D4", 8)]
    at = bar * 6
    beat = bar / 4
    for nm, b in mel:
        tr.add(at, strings(hz(nm), b * beat + 0.8, attack=0.25, release=0.7, cutoff=3200, vib=0.007), pan=0.1, gain=0.42)
        at += b * beat
    for i in range(0, bars, 2):
        tr.add(i * bar, drum(2.5, 55, 35, 0.8, 0.2), gain=0.5)
    x = reverb(tr.buf, 4.5, 0.42, damp=3500)
    write("music_title", norm(loopable(x, 4.0), 0.8), q=4)


def make_camp():
    """'Round the Fire': an oud over a soft pad, the old falling cadence."""
    bar = 2.4
    bars = 32
    tr = Track(bar * bars + 4)
    prog = [("D3", ["D4", "F4", "A4"]), ("C3", ["C4", "E4", "G4"]), ("Bb2", ["Bb3", "D4", "F4"]), ("A2", ["A3", "C#4", "E4"])]
    for i in range(bars):
        root, ch = prog[i % 4]
        tr.add(i * bar, strings(hz(root), bar + 1.2, attack=0.9, release=1.2, cutoff=900), gain=0.35)
        if i >= 4:
            tr.add(i * bar, strings(hz(ch[1]), bar + 1.2, attack=1.0, release=1.2, cutoff=1500), pan=-0.3, gain=0.16)
        step = bar / 6
        pattern = [0, 1, 2, 1, 2, 1] if i % 8 < 4 else [0, 2, 1, 2, 0, 1]
        for k, p in enumerate(pattern):
            nm = ch[p]
            tr.add(i * bar + k * step + rng.uniform(0, 0.015), pluck(hz(nm), 1.8, bright=0.8), pan=0.35, gain=0.5 if k == 0 else 0.36)
        if i >= 8 and i % 2 == 0:
            tr.add(i * bar, frame_drum(), pan=-0.2, gain=0.35)
            tr.add(i * bar + bar * 0.75, frame_drum(0.3), pan=-0.2, gain=0.2)
    mel = ["A4", "G4", "F4", "E4", "F4", "E4", "D4", "C#4", "D4", "E4", "F4", "G4", "A4", "Bb4", "A4", "G4"]
    for k in range(16):
        tr.add(bar * (12 + k), pluck(hz(mel[k]) * 2, 2.0, bright=1.1, decay=1.2), pan=-0.35, gain=0.32)
    x = reverb(tr.buf, 3.0, 0.35, damp=4000)
    write("music_camp", norm(loopable(x, 3.0), 0.75), q=4)


def make_battle():
    """'Into the Ruins': war drums, a driving low ostinato and brass-like swells."""
    bpm = 104
    beat = 60.0 / bpm
    bar = beat * 4
    bars = 32
    tr = Track(bar * bars + 4)
    roots = ["D2", "D2", "Bb1", "C2", "D2", "D2", "G1", "A1"]
    osti = [0, 0, 12, 0, 3, 0, 1, 0]  # semitone offsets per eighth
    for i in range(bars):
        root = hz(roots[i % len(roots)])
        for k, off in enumerate(osti):
            f = root * 2 ** (off / 12) * 2
            note = strings(f, beat * 0.5 + 0.12, attack=0.01, release=0.1, cutoff=1400 if i >= 8 else 900, vib=0.0)
            tr.add(i * bar + k * beat * 0.5, note, pan=-0.25, gain=0.55 if k % 2 == 0 else 0.4)
        # drums: big hits on 1 and the and of 3, small ones between
        tr.add(i * bar, drum(1.4, 70, 38, 0.4, 0.5), gain=1.0)
        tr.add(i * bar + beat * 2.5, drum(1.2, 66, 40, 0.35, 0.5), gain=0.8)
        if i >= 4:
            for k in [1, 3]:
                tr.add(i * bar + beat * k, frame_drum(0.4), pan=0.3, gain=0.45)
            tr.add(i * bar + beat * 3.5, frame_drum(0.3), pan=-0.3, gain=0.3)
        if i >= 8 and i % 2 == 0:
            ch = {0: ["D3", "A3", "D4"], 2: ["Bb2", "F3", "Bb3"], 4: ["D3", "A3", "D4"], 6: ["G2", "D3", "G3"]}[i % 8]
            for j, nm in enumerate(ch):
                sw = strings(hz(nm), bar * 2 + 0.5, attack=bar * 0.9, release=0.8, cutoff=2600, vib=0.003)
                tr.add(i * bar, sw, pan=-0.3 + 0.3 * j, gain=0.3)
        if i >= 16 and i % 4 == 0:
            tr.add(i * bar, choir(hz("D4"), bar * 4, "ah", attack=bar, release=1.5), pan=0.2, gain=0.35)
            tr.add(i * bar, choir(hz("A3"), bar * 4, "ah", attack=bar, release=1.5), pan=-0.2, gain=0.3)
    x = reverb(tr.buf, 2.6, 0.3, damp=3000)
    write("music_battle", norm(loopable(x, 1.0), 0.8), q=4)


def make_stings():
    tr = Track(9)
    for j, nm in enumerate(["D3", "F#3", "A3", "D4"]):
        tr.add(0.1 * j, strings(hz(nm), 6, attack=0.3, release=3.0, cutoff=3000), pan=-0.3 + 0.2 * j, gain=0.5)
        tr.add(0.1 * j, choir(hz(nm) * (2 if j < 2 else 1), 6, "ah", attack=0.6, release=3.0), gain=0.35)
    tr.add(0, drum(2.0, 60, 35, 0.6, 0.6), gain=1.0)
    write("sting_victory", norm(reverb(tr.buf, 3.5, 0.4), 0.8), q=4)
    tr = Track(9)
    for j, nm in enumerate(["D2", "A2", "D3", "F3"]):
        tr.add(0.2 * j, strings(hz(nm), 6, attack=0.8, release=3.0, cutoff=900), pan=-0.3 + 0.2 * j, gain=0.55)
    tr.add(0.6, choir(hz("Eb4"), 5, "oo", attack=1.0, release=2.5), gain=0.25)
    tr.add(0, drum(3.0, 45, 30, 1.0, 0.3), gain=1.0)
    write("sting_defeat", norm(reverb(tr.buf, 4.0, 0.45), 0.8), q=4)


if __name__ == "__main__":
    what = sys.argv[1:] or ["sfx", "water", "cache", "weather", "amb", "music"]
    if "sfx" in what:
        make_sfx()
    if "water" in what or "sfx" in what:
        make_water_dust()
    if "cache" in what or "sfx" in what:
        make_cache()
    if "weather" in what:
        make_weather()
    if "amb" in what:
        make_ambience()
    if "music" in what:
        print("music")
        make_stings()
        make_camp()
        make_battle()
        make_title()
