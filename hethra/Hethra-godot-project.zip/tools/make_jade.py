"""Builds data/maps/jade.json: the Jade Stranger. When the god fell, one of the
jade giants that drift in the dark between worlds fell with him and came down
across a ward of Hethra. It lies on its back from one side of the ward to the
other, a hill of green stone that glows from within, with the houses it crushed
round it. Fighters climb its arms and legs and fight across its chest.
Run from the project folder: python3 tools/make_jade.py"""
import json
from collections import deque

W = D = 28
H = [[1] * W for _ in range(D)]
P = [['.'] * W for _ in range(D)]
JADE = []    # rects [x0, z0, x1, z1] of the giant's walkable body

def block(x0, z0, x1, z1, lvl, broken=()):
    for z in range(z0, z1 + 1):
        for x in range(x0, x1 + 1):
            H[z][x] = lvl
    for (x, z, l) in broken:
        H[z][x] = l

def jade(x0, z0, x1, z1, lvl):
    block(x0, z0, x1, z1, lvl)
    JADE.append([x0, z0, x1, z1])

# the giant, lying on its back, head to the west
jade(8, 12, 19, 15, 3)      # chest and belly
jade(7, 13, 7, 14, 2)       # neck
for z in range(11, 17):     # the head: nobody climbs it
    for x in range(2, 7):
        P[z][x] = 'J'
jade(20, 11, 24, 12, 2)     # the north leg
jade(20, 15, 24, 16, 2)     # the south leg
for z in (11, 12, 15, 16):  # feet, toes to the sky
    for x in (25, 26):
        P[z][x] = 'F'
jade(10, 5, 11, 11, 2)      # the north arm, flung out
jade(9, 3, 12, 4, 2)        # its open hand
for x in range(9, 13):
    P[2][x] = 'f'           # fingers
jade(16, 16, 17, 21, 2)     # the south arm
jade(15, 22, 18, 23, 2)     # its hand
for x in range(15, 19):
    P[24][x] = 'f'

# houses it crushed, and those it missed
block(0, 4, 4, 8, 3, [(4, 4, 2), (4, 8, 2), (3, 8, 2)])
block(21, 3, 25, 6, 2, [(25, 3, 3), (24, 3, 3)])
block(1, 19, 5, 23, 2, [(1, 23, 3), (1, 22, 3)])
block(21, 19, 25, 23, 3, [(21, 19, 2), (22, 19, 2), (21, 20, 2)])
block(14, 6, 16, 8, 2)      # a broken house in the arm's shadow
block(10, 18, 12, 20, 2)    # and one under the other arm

# rubble where the giant came down, braziers, barricades, crates
for (x, z) in [(7, 10), (13, 10), (18, 10), (8, 17), (13, 17), (19, 17), (1, 10), (26, 9), (6, 2), (21, 25), (14, 1), (12, 25)]:
    P[z][x] = 'r'
for (x, z) in [(8, 1), (19, 1), (8, 26), (19, 26), (0, 14), (27, 14)]:
    P[z][x] = 'B'
for (x, z) in [(17, 3), (6, 24), (3, 13), (24, 14)]:
    if P[z][x] == '.':
        P[z][x] = 'b'
for (x, z) in [(2, 1), (25, 1), (2, 26), (25, 26)]:
    P[z][x] = 'c'

stairs = [
    # up from the limbs onto the chest
    (10, 11, 10, 12), (17, 16, 17, 15), (20, 12, 19, 12), (20, 15, 19, 15), (7, 13, 8, 13),
]
ladders = [
    # handholds up the giant's flanks from the street
    (9, 6, 10, 6), (12, 9, 11, 9), (15, 18, 16, 18), (18, 20, 17, 20),
    (13, 3, 12, 3), (14, 23, 15, 23), (21, 10, 21, 11), (22, 17, 22, 16),
    (7, 12, 7, 13), (13, 11, 13, 12), (14, 16, 14, 15), (23, 13, 23, 12), (23, 14, 23, 15),
    # the houses
    (5, 6, 4, 6), (20, 5, 21, 5), (6, 21, 5, 21), (20, 21, 21, 21),
    (13, 7, 14, 7), (9, 19, 10, 19),
]
bridges = []

shards = [
    [11, 13, 3], [16, 14, 3],        # on the giant's chest
    [10, 3, 2], [17, 23, 2],         # in its open hands
    [22, 13, 1], [22, 14, 1],        # between its legs
    [27, 12, 1], [1, 15, 1],         # by its feet and its head
    [1, 5, 3], [24, 22, 3],          # on the roofs
]

deploy = {"0": [], "1": []}
for z in (26, 27):
    for x in range(3, 25):
        if H[z][x] == 1 and P[z][x] == '.':
            deploy["0"].append([x, z])
for z in (0, 1):
    for x in range(3, 25):
        if H[z][x] == 1 and P[z][x] == '.':
            deploy["1"].append([x, z])

bridge_cells = {(b["x"], b["z"]) for b in bridges}
for (x, z, tx, tz) in ladders + stairs:
    assert H[z][x] < H[tz][tx], ((x, z), (tx, tz), H[z][x], H[tz][tx])
    assert abs(x - tx) + abs(z - tz) == 1, ((x, z), (tx, tz))
    assert P[z][x] == '.' and P[tz][tx] == '.', ((x, z), (tx, tz))
    assert (x, z) not in bridge_cells and (tx, tz) not in bridge_cells, ((x, z), (tx, tz))
for (x, z, tx, tz) in stairs:
    assert H[tz][tx] - H[z][x] == 1, ((x, z), (tx, tz))
for sh in shards:
    assert H[sh[1]][sh[0]] == sh[2] and P[sh[1]][sh[0]] == '.', sh
for br in bridges:
    assert H[br["z"]][br["x"]] < br["level"] and P[br["z"]][br["x"]] == '.', br

# every deploy cell should reach every shard (walk, drop, stairs, ladders, planks)
def nodes():
    ns = set()
    for z in range(D):
        for x in range(W):
            if P[z][x] == '.':
                ns.add((x, z, H[z][x]))
    for b in bridges:
        ns.add((b["x"], b["z"], b["level"]))
    return ns
NS = nodes()
def top(x, z):
    best = None
    for (a, b, l) in NS:
        if a == x and b == z and (best is None or l > best):
            best = l
    return (x, z, best)
adj = {n: set() for n in NS}
for (x, z, l) in NS:
    for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        nx, nz = x + dx, z + dz
        if (nx, nz, l) in NS:
            adj[(x, z, l)].add((nx, nz, l))
        elif 0 <= nx < W and 0 <= nz < D and H[nz][nx] < l and (nx, nz, H[nz][nx]) in NS:
            adj[(x, z, l)].add((nx, nz, H[nz][nx]))     # drop
    if l != H[z][x] and (x, z, H[z][x]) in NS:
        adj[(x, z, l)].add((x, z, H[z][x]))             # off a plank
for (x, z, tx, tz) in ladders + stairs:
    a, b = top(x, z), top(tx, tz)
    adj[a].add(b)
    adj[b].add(a)
def reach(start):
    seen = {start}
    q = deque([start])
    while q:
        n = q.popleft()
        for m in adj[n]:
            if m not in seen:
                seen.add(m)
                q.append(m)
    return seen
for side in ("0", "1"):
    r = reach((deploy[side][0][0], deploy[side][0][1], 1))
    for sh in shards:
        assert (sh[0], sh[1], sh[2]) in r, ("shard unreachable", side, sh)
    for d2 in deploy["1" if side == "0" else "0"]:
        assert (d2[0], d2[1], 1) in r, ("enemy unreachable", side, d2)
    # nobody may be stranded on a roof
    for n in NS:
        assert (deploy[side][0][0], deploy[side][0][1], 1) in reach(n), ("stranded", n)
    break

data = {
    "name": "The Jade Stranger",
    "desc": "When the god fell, one of the jade giants that drift in the dark between worlds fell with him. It came down on its back across a ward of Hethra and lies there still, a hill of green stone lit from within, with the houses it crushed round it. Shards caught in its hands and on its chest, and the only ways across are round its head and feet, or over it.",
    "cell": 2.0, "storey": 3.0, "width": W, "depth": D,
    "heights": [''.join(str(v) for v in row) for row in H],
    "props": [''.join(row) for row in P],
    "legend": {"J": "jade_head", "F": "jade_foot", "f": "jade_finger", "B": "brazier", "b": "barricade", "r": "rubble", "c": "crates"},
    "ladders": [{"x": a, "z": b, "tx": c, "tz": d} for (a, b, c, d) in ladders],
    "stairs": [{"x": a, "z": b, "tx": c, "tz": d} for (a, b, c, d) in stairs],
    "bridges": bridges,
    "shards": shards,
    "deploy": deploy,
    "objective": [13, 13],
    "jade": JADE,
    "fires": [[1, 3], [26, 24], [3, 18], [24, 7], [9, 0], [18, 27]],
}
json.dump(data, open('data/maps/jade.json', 'w'), indent=1)
print('\n'.join(data["heights"]))
print()
print('\n'.join(data["props"]))
