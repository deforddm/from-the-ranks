# Credits

**Hethra, City of the Fallen** is an unofficial, non-commercial fan project.

## The world
Inspired by the *Malazan Book of the Fallen* by **Steven Erikson** and the
*Novels of the Malazan Empire* by **Ian C. Esslemont**. The Malazan Empire,
its marines, sappers and Moranth munitions, the warrens, the Chained One
(the Crippled God), the Whirlwind, the Seguleh, the Tiste Andii and Kurald
Galain belong to them and their publishers.
The city of Hethra, its fighters, names, rules text and descriptions were
written for this game.

## Inspiration
A turn-based warband skirmish in the tradition of tabletop skirmish games set
in a ruined city. No art, names, text or rules text from any other game are
used; the rules were written from scratch.

## Engine
Godot Engine 4.7.2 — MIT licence — https://godotengine.org

## Fonts
- Grenze Gotisch — SIL Open Font License 1.1 (`fonts/OFL-GrenzeGotisch.txt`)
- Alegreya Sans — SIL Open Font License 1.1 (`fonts/OFL-AlegreyaSans.txt`)

## Art
The city, the figures, the textures (`tools/gen_textures.py`) and the effects
are generated in code for this project. No third-party art is included yet.
