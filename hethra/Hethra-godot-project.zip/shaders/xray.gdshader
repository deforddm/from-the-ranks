shader_type spatial;
// Draws a faint silhouette of a fighter only where walls hide them, so the
// player never loses track of their warband behind the ruins.
render_mode unshaded, depth_test_disabled, depth_draw_never, cull_back, shadows_disabled, fog_disabled;

uniform sampler2D depth_tex : hint_depth_texture, filter_nearest;
uniform vec4 tint : source_color = vec4(0.4, 1.0, 0.85, 0.35);

void fragment() {
	float scene = texture(depth_tex, SCREEN_UV).r;
	// reverse-z: a larger value is nearer the camera
	if (FRAGCOORD.z >= scene - 0.000002) {
		discard;
	}
	float rim = 1.0 - abs(dot(NORMAL, VIEW));
	ALBEDO = tint.rgb;
	ALPHA = tint.a * (0.35 + 0.65 * rim);
}
