shader_type spatial;
// Still, black flood water: slow ripples, a little scum, and sharp
// reflections of the firelight. All procedural; no textures.

uniform vec3 deep : source_color = vec3(0.03, 0.045, 0.048);
uniform vec3 murk : source_color = vec3(0.07, 0.09, 0.075);
uniform vec3 scum : source_color = vec3(0.13, 0.12, 0.085);
uniform vec3 sheen : source_color = vec3(0.16, 0.2, 0.27);
uniform float ripple = 0.07;

varying vec3 wpos;

float hash(vec2 p) {
	return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float vnoise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
		mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
}

float waves(vec2 p) {
	return vnoise(p * 0.8 + vec2(TIME * 0.12, TIME * 0.05)) * 0.55
		+ vnoise(p * 2.1 - vec2(TIME * 0.09, -TIME * 0.14)) * 0.3
		+ vnoise(p * 5.5 + vec2(TIME * 0.25, 0.0)) * 0.15;
}

void vertex() {
	wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
	vec2 p = wpos.xz;
	float e = 0.06;
	float c = waves(p);
	float dx = waves(p + vec2(e, 0.0)) - c;
	float dz = waves(p + vec2(0.0, e)) - c;
	vec3 n = normalize(vec3(-dx / e * ripple, 1.0, -dz / e * ripple));
	NORMAL = normalize((VIEW_MATRIX * vec4(n, 0.0)).xyz);
	float s = smoothstep(0.7, 0.82, vnoise(p * 0.55 + vec2(3.1, 7.7)) * 0.7 + vnoise(p * 3.0) * 0.3);
	ALBEDO = mix(mix(deep, murk, vnoise(p * 0.13)), scum, s);
	ROUGHNESS = mix(0.12, 0.8, s);
	METALLIC = 0.0;
	SPECULAR = 1.0;
	// the night sky caught on the surface, strongest at a low angle, broken by the ripples
	float fres = pow(1.0 - clamp(dot(NORMAL, VIEW), 0.0, 1.0), 3.0);
	float glint = vnoise(p * 1.7 + vec2(TIME * 0.2, -TIME * 0.13));
	EMISSION = sheen * (0.12 + fres * 0.9) * (0.6 + glint * 0.6) * (1.0 - s);
}
