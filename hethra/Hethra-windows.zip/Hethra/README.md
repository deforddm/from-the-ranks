# Hethra, City of the Fallen

A turn-based warband skirmish game in full 3D, set in a burning, ruined city of
the Malazan world. Lead a small warband through Hethra's streets, rooftops and
plank bridges, fight for godshards, and break the enemy's nerve.

Version 0.5 brings five warbands, three battlefields and three kinds of
battle, all playable as one-off skirmishes or as a campaign in which your
warband lives from battle to battle. Fighters are wounded, scarred or killed;
survivors gain experience and advances; godshards you bring out buy weapons,
armour and new fighters.

Version 0.6 gives every fighter a proper body: a jointed figure with a face,
armour, cloth and a helm that fits their warband, who walks, climbs, leaps,
swings, aims, throws, casts and falls. The title screen now shows the warband
you pick, mustered round a brazier above the burning city.

Version 0.7 adds a fourth battlefield, the Starfall, a crater blasted into
the street round a burning lump of the Fallen god's flesh, and a fourth kind
of battle, Take their leader, in which the band that loses its leader breaks
at once.

Version 0.8 adds a sixth warband, the White Face Barghast, with skull-painted
faces, javelins and a bone-shaman who calls on the spirits of the clan's
fathers. The warbands are rebalanced so that each wins about half its
fights, and a campaign band beaten down to a handful now draws in
stragglers instead of dying out.

Version 0.9 adds a fifth battlefield, the Sleeper's Stair, a stepped temple
whose top tier holds the stone image of the goddess who sleeps in the earth,
glowing with fever since the fall. It also adds a fifth kind of battle,
Through their lines: three fighters standing on the enemy's starting ground
wins it.

Version 0.10 adds the night after each campaign battle. One of fourteen
nights comes round your fire: a bonecaster at the well, deserters who want a
band, a fever, a cellar opened by a quake, thieves on the rooftops, a cold
tomb, a champion's challenge and more. Each one asks you to choose, and many
are settled by a die: coin, godshards, experience and new blood, or a fighter
who must sit out the next fight.

Version 0.11 gives the fighters close-up detail. Cloth shows its weave, mail
its rings, leather its grain and iron its dents and rust. Faces have eyes,
brows, noses, lips and ears; hands have fingers. Everyone carries pouches, a
knife and buckled straps, and each warband has its own marks: Moranth
munitions on the marines' hips, chains and manacles on the Chained One's
pilgrims, tassels and charms on the Whirlwind's rebels, silver circlets on the
Tiste Andii, fetishes on the Barghast and a second blade on every Seguleh's
back. The Fast graphics setting leaves the surface detail off.

Version 0.12 adds a sixth battlefield, the Drowned Quarter: the night the god
fell, the river wall broke and the low streets went under. Black water stands
waist deep between the quays, the roofs and the shrine of Mael, where the sea
god's great bell lies cracked in the court. Wading costs half as much again
as walking, plank walks are fast but narrow, and a fighter who drops off a
quay into the water lands safely. The title screen now shows the version.

Version 0.13 adds a seventh warband, the Kin of the Dust: a clan of T'lan
Imass, undead for a hundred thousand years, with flint swords, antler caps and
beast-skull helms, skin dried to leather and empty eye sockets. Every one is
Unliving: a stun becomes a knock-down on 4 or more, and the Barghast's
howling dead mean nothing to them. Their Bonecaster draws on Tellann: Ember
Fall drops old hearth-fire on an enemy and those beside it, and Rise from
Dust stands every fallen friend nearby back up. The Barghast can now buy from
the armoury in a campaign.

Version 0.14 brings the water and the dust to life. Fighters wading in the
Drowned Quarter slosh with every step and leave rings spreading on the black
water, those standing still in it stir it now and then, and anyone who drops
or falls in from a quay throws up a splash. When one of the Kin of the Dust
goes out of action it does not fall: it shudders and comes apart, pouring down
into a heap of grey dust that stays on the field, with a crackle of dry bone.
All of the new sounds are made in code, like the rest.

Version 0.15 adds a seventh battlefield, the Azath Yard: a walled yard of
dead trees and old barrows round one of the Azath houses, a squat keep with a
crooked tower and a door nobody has ever seen open, its slit windows leaking a
cold green light. The yard wall can be climbed and fought along, there are
gates on all four sides and a breach in the east wall, and the barrows give
low cover. The house itself is solid and blocks all sight.

From 0.15 on, Hethra keeps itself up to date. Each time it starts it checks
the download page; if there is a newer version it fetches it in the
background, checks it, and on the title screen restarts into it. If you are
in a battle it waits until the next time you open the game. Turn it off in
Settings, under Updates, and it will only tell you a new version is out.

Version 0.16 adds a sixth kind of battle, the buried strongbox. A paymaster's
strongbox lies under one of four marked spots, each with a stake, a spade and a
lantern, and nobody knows which. Walk onto a spot to dig: most turn up only
bones and broken pots. Whoever strikes iron carries the box on their back and
must get it to their own starting ground. They are too laden to dash, and drop
it where they fall if taken out, for anyone to pick up. While one of yours holds
it and stands, your warband will not break. Carry it home and you win at once;
at nightfall, whoever holds it wins. This is also the first update a 0.15 copy
fetches and installs by itself.

Version 0.17 brings weather. Half the nights are still; the rest bring driving
rain or thick fog. Rain falls on every roof and street and splashes where it
lands, lightning lights the ruins now and then with thunder after it, and the
rain hisses under the wind. In the rain shots need one more to hit, nobody
sees as far, and jumps and drops on the wet stone are harder. In thick fog
nobody sees past 14 m, so fights start close. The weather shows at the top of
the screen. In a skirmish you can choose it, under Weather.

Version 0.18 adds an eighth battlefield, the Jade Stranger. When the god fell,
one of the jade giants that drift in the dark between worlds fell with him and
came down on its back across a ward of Hethra. It lies there still, a hill of
green stone lit from within, cracked by the fall, with light leaking through
the cracks and its eyes still open to the sky. The two sides start on either
side of it: go round by its head or its feet, or climb its arms and legs and
fight across its chest, where the shards are richest. Godshards lie in its
open hands too.

Version 0.19 adds a cinematic camera. Every battle opens with a slow sweep over
the ruins between black bars, under the battlefield's name, the kind of battle,
the weather and the two warbands, and settles where your warband waits. When a
fighter is taken out of action the camera cuts in low beside them and time
slows while they go down, then the view comes back to where it was. Click or
press any key to skip the opening; Settings has a switch to turn both off.

Version 0.20 adds an eighth warband, the Teblor Raiders: a small band of
giant hill warriors down from the mountains, braided and tattooed, with
trophies at their belts and swords carved from red bloodwood. They are few,
but every one of them is Giantkin and may shrug off a blow that would knock
another fighter flat.

Version 0.21 brings Hood's crows to every battlefield. Small flocks sit along
the roofs and in the streets, pecking and hopping about. Come too close and
they burst up cawing, wheel over the ruins and settle again somewhere quieter.
A blast puts up every bird near it, and when a fighter is taken out of action
a crow or two come down beside the body once the fighting has moved on.

## Warbands

- **Malazan Marines:** steady soldiers with crossbows, a squad mage and a
  sapper who throws Moranth munitions.
- **Cult of the Chained One:** a big, cheap flock of fanatics who shrug off
  pain, led by a priest of the Chained One's warren.
- **Sworn of the Whirlwind:** fast desert raiders, dervishes and archers,
  with a seer of the Whirlwind's sand.
- **Masked of the Seguleh:** a handful of unarmoured swordsmen, masked by
  rank. Few, expensive and deadly; Duellists parry on a tie.
- **Children of the Dark:** tall Tiste Andii with longbows and great blades.
  Their mage draws on Kurald Galain: Night's Edge sharpens a friend's blade,
  Starless Night blinds an enemy's bow or warren.
- **White Face Barghast:** tough hill clansmen with axes, great blades and
  javelins, their faces painted as skulls. Their bone-shaman calls on the
  clan's dead: Call the Fathers hardens a friend, Spirit Howl shakes every
  enemy close by.
- **Kin of the Dust:** slow, unfeared T'lan Imass with flint swords, great
  blades and javelins, who are hard to put down. Their Bonecaster drops
  Tellann fire on the enemy and raises the fallen.
- **Teblor Raiders:** six or so giants from the mountains with bloodwood
  swords (+1 Strength, and armour saves worse against them), a javelin-armed
  Tracker who climbs well, and a War Chief who leads from the front. Every
  Teblor is Giantkin: a blow that would knock them down is shrugged off on
  a 5 or more.

## Battlefields and battles

- **The Idol Square**, around the Chained One's idol; **The Broken
  Causeway**, two quays split by a canal with a few bridges; **The Tower
  Ward**, a block of towers joined by ladders and plank bridges; **The
  Starfall**, a crater round a burning starstone, ringed by tall houses and
  gatehouses joined by planks; **The Sleeper's Stair**, a stepped temple with
  great stairs, a colonnade and the sleeping goddess on its top tier; **The
  Drowned Quarter**, streets standing waist deep in flood water between dry
  quays, roofs and Mael's shrine, joined by plank walks. Wading is slow, but
  the water breaks a fall from one storey.
- **Shard hunt:** carry godshards off the field. **Street fight:** break the
  enemy. **Hold the ground:** both bands want the ring of witch-fire in the
  middle; whoever has more fighters inside it at nightfall wins. **Take their
  leader:** put the enemy's leader out of the fight and their band breaks;
  keep yours standing. **Through their lines:** get three fighters onto the
  enemy's starting ground (it glows jade; yours glows red) and keep theirs
  off yours.

## Play on Windows

1. Run `Hethra.exe`. No install needed.
2. Pick your warband, then press **New campaign** (or **Skirmish** for one
   quick battle). **Continue** picks up your latest campaign.

If Windows SmartScreen warns about an unknown publisher, choose
*More info → Run anyway* (the file is not code-signed).

Slow PC? On the title screen, press **Graphics** to switch to *fast*
(turns off volumetric fog and ambient occlusion).

## Open the project in Godot

1. Install Godot 4.7 (standard, not .NET) from https://godotengine.org
2. Open Godot, choose **Import**, and select `project.godot` (in the `project` folder of this download, or `Hethra-project.zip` unzipped).
3. Press **F5** to play.

## Controls

| | |
|---|---|
| Camera | Rides over the shoulder of the active fighter |
| Close / overhead view | V |
| Look around | Right-drag (close view) or middle-drag; Q and E / R and F |
| Pan | WASD or arrow keys (Shift for faster); right-drag in overhead view |
| Zoom | Mouse wheel |
| Choose a fighter | Click them, or Tab for the next one |
| Move | Click anywhere inside the glowing area (amber means a jump or drop) |
| Fight / charge / shoot | Click an enemy (hover first to see the odds) |
| Actions | 1 Move · 2 Dash · 3 Charge · 4 Shoot · 5 Throw · 6 Cast |
| Cancel | Right-click or Escape |
| Back to the fighter | Space |
| End turn | Enter |
| Help | F1 |

## The campaign

- **The camp** between battles shows your warband round a fire. Choose a
  fighter to see their stat line, experience, skills and scars, to buy or
  sell their kit, or to settle an advance.
- **After each battle**, every fighter taken out of action rolls on the
  injury table (from a full recovery to death), survivors gain experience,
  and heroes still standing search the ruins for coin and godshards.
- **The night after** every battle brings an event to your fire. Choose how
  to meet it; some choices cost coin or godshards, and many are settled by a
  die. The events are in `data/events.json`.
- **Advances** come at set experience totals: a new skill or a better stat
  for heroes, a stat for henchmen, and now and then a henchman with real
  talent rises to be a hero.
- **Sell godshards** for jakatas (the more at once, the lower the price),
  then **Hire** new fighters or buy from the armoury.
- **Rating** sums your fighters and their experience. Foes are matched to
  it, and beating a stronger band earns extra experience.
- The campaign saves itself after every change. **Save and leave** returns
  to the title screen.

## The rules in brief

- Each fighter has a stat line: Move, Weapon Skill, Ballistic Skill,
  Strength, Toughness, Wounds, Initiative, Attacks and Leadership.
- Each turn a fighter gets movement (Move × 2.5 m) and two actions.
- The city is three-dimensional: climb ladders and stairs, cross bridges,
  jump gaps and drop from ledges. Jumps and drops need an Initiative test;
  failing one means a fall that can wound.
- Line of sight is traced in 3D. Enemies stay hidden until one of your
  fighters sees them, and a ghost marks where they were last seen.
- Wounds knock fighters down, stun them or take them out of action. When a
  quarter of a warband is down, its leader tests each turn or the band flees.
- After 12 rounds, the side holding more godshards wins (in a shard hunt),
  or the side with more fighters in the ring (when holding the ground).

All rules and data live in JSON under `data/` (`rules.json`, `warbands/`,
`maps/`), so stats, weapons, spells and warbands can be changed without code.

## For developers

- `scripts/core/` — rules engine, map graph, line of sight, AI (no graphics).
- `scripts/view/` — the 3D city, figures, camera, effects and battle controller.
- `scripts/ui/` — title screen, camp screen and battle HUD.
- `tests/run_battles.gd` — headless rules tests:
  `godot --headless --path . --script res://tests/run_battles.gd`
- `tests/run_campaign.gd` — plays AI campaigns with the full camp between
  battles and checks the books: `... --script res://tests/run_campaign.gd -- 6`
- Campaign rules (injuries, advances, prices, armoury) are in `data/campaign.json`.
- Watch the AI play itself: `godot --path . -- --autoplay`
- `tools/make_map.py` builds the Idol Square, `tools/make_maps.py` the other
  battlefields; `tools/gen_textures.py` the textures.
- Battles on any field: `-- --map=sleeper --scenario=breakthrough --player=seguleh --enemy=andii`

See `CREDITS.md` for the setting's authors and licences.
