# Hethra, City of the Fallen

A turn-based warband skirmish game in full 3D, set in a burning, ruined city of
the Malazan world. Lead a small warband through Hethra's streets, rooftops and
plank bridges, fight for godshards, and break the enemy's nerve.

This is the first playable milestone: one battle map, three warbands, the full
rules engine and an enemy AI. Campaign play, character art and more maps come
next.

## Play on Windows

1. Run `Hethra.exe`. No install needed.
2. Pick your warband and your foe, then press **Into the ruins**.

If Windows SmartScreen warns about an unknown publisher, choose
*More info → Run anyway* (the file is not code-signed).

Slow PC? On the title screen, press **Graphics** to switch to *fast*
(turns off volumetric fog and ambient occlusion).

## Open the project in Godot

1. Install Godot 4.7 (standard, not .NET) from https://godotengine.org
2. Open Godot, choose **Import**, and select `project.godot` (in the `project` folder of this download, or `Hethra-project.zip` unzipped).
3. Press **F5** to play.

## Controls

| | |
|---|---|
| Pan | WASD or arrow keys (Shift for faster), or right-drag |
| Turn / tilt | Q and E / R and F, or middle-drag to orbit |
| Zoom | Mouse wheel |
| Choose a fighter | Click them, or Tab for the next one |
| Move | Click a glowing disc |
| Fight / charge / shoot | Click an enemy (hover first to see the odds) |
| Actions | 1 Move · 2 Dash · 3 Charge · 4 Shoot · 5 Throw · 6 Cast |
| Cancel | Right-click or Escape |
| Focus camera | Space |
| End turn | Enter |
| Help | F1 |

## The rules in brief

- Each fighter has a stat line: Move, Weapon Skill, Ballistic Skill,
  Strength, Toughness, Wounds, Initiative, Attacks and Leadership.
- Each turn a fighter gets movement (Move × 2.5 m) and two actions.
- The city is three-dimensional: climb ladders and stairs, cross bridges,
  jump gaps and drop from ledges. Jumps and drops need an Initiative test;
  failing one means a fall that can wound.
- Line of sight is traced in 3D. Enemies stay hidden until one of your
  fighters sees them, and a ghost marks where they were last seen.
- Wounds knock fighters down, stun them or take them out of action. When a
  quarter of a warband is down, its leader tests each turn or the band flees.
- After 12 rounds, the side holding more godshards wins.

All rules and data live in JSON under `data/` (`rules.json`, `warbands/`,
`maps/`), so stats, weapons, spells and warbands can be changed without code.

## For developers

- `scripts/core/` — rules engine, map graph, line of sight, AI (no graphics).
- `scripts/view/` — the 3D city, figures, camera, effects and battle controller.
- `scripts/ui/` — title screen and battle HUD.
- `tests/run_battles.gd` — headless rules tests:
  `godot --headless --path . --script res://tests/run_battles.gd`
- Watch the AI play itself: `godot --path . -- --autoplay`
- `tools/make_map.py` builds the battle map; `tools/gen_textures.py` the textures.

See `CREDITS.md` for the setting's authors and licences.
